headline theme 1.0 readme

the theme only works 100% aligned, if you use IBMPC font.

you can find the font in the theme dir, containing this zip file.

this is not required:
maybe install the IBMPC font in your windows\fonts\ directory