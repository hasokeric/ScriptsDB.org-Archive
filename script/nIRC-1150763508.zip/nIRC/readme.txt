nIRC Script Version 5.4
Le Script n�c�ssite la version de mIRC 6.17 pour fonctionner correctement.

/!\ � installer dans un dossier dans espace ! Cette version n'�tant pas encore au point � ce niveau /!\
Je vous conseilles C:\nIRC\

---------------------------------------------
Sortie le Vendredi 19 Mars 2006
Site principal du t�l�chargement : 
	http://www.nirc.fr/
	`-> http://www.nirc.fr/downloads.aspx,view-150
---------------------------------------------
Attention : Ce script poss�de des alias venant d'autres personnes,
Ceux ci sont ont �t�s ajout�s au script il y a de cela quelques temps
Si vous reconnaissez un de vos alias, veuillez m'en faire part, je 
Rajouterais votre nom.

Les Modules, dlls et alias utilis�s sont la propri�t� priv�e de leur cr�ateur.
Le contenu reste libre tant que vous en sp�cifiez l'auteur.
----------------------------------------------
 mIRC� v6.17 Internet Relay Chat Client
 Copyright � 1995-2004 mIRC Co. Ltd.
 All Rights Reserved.
 
 Remember to visit the mIRC website at http://www.mirc.com for
 the latest version and information.
-----------------------------------------------
