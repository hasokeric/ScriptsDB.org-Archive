FraGma 0.2b
bore@fragma-script.net

_______________________________________________________________________________________________________

1. installation:
	� after extracting the files (you should have that done by now) get a clean version of mIRC.exe (if you don't have any just download it at www.mirc.co.uk) remember that it MUST be a 6.03 version or higher! after having that clean version of mIRC.exe past it to FraGma's dir , the dir where you have extracted all FraGma files, which CAN'T have spaces!
	� now just run mIRC.exe! once that you're ready to go!

2. using:

	� there's a very good help system in FraGma, it will really explain how to use all FraGma functions and also explain basic stuff (like connecting, joining, etc)! to open the help system just click on the last icon on the toolbar or type /help

3. credits:

	� SolidSnake . MTS Loader v1.0
	� DragonZap . MDX dll
	� [K]Freak . Ktools dll
	� Kamek . mIRC Customizer dll
	� |nsane . Downloader
	� Guy from QNX icon pack!

_______________________________________________________________________________________________________