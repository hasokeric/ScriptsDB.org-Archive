DreamBot IRC Bot version 5.4
Copyright (C) 2004-2006 DreamBot development team.
All rights reserved.

*** What is DreamBot? ***

DreamBot is an IRC robot. If you don't know what IRC is, then you do not need an IRC bot. 
It is designed for Windows and it requires mIRC 6.16 to run. This bot was not tested on 6.17
or later versions of mIRC and it may not function correctly. If you do not have mIRC 6.16
please get it from http://www.mirc.net/archive_files/mirc616.exe.

*** News (must read) ***

* There is no more !start command in DreamBot. To start scramble or trivia please type
   !scramble or !trivia. If the bot complains about game already running, type the following
   commmands in the bot's mIRC:
   /scramble_stop
   /trivia_stop
* Added channel rules script; can be triggered by !rules;
* Fixed some bugs in Services management;
* Added Google search script;
* Images now optimized for 1024x768 screen resolution;



*** Setup ***

The setup process should be easy. Just unpack the dreambot54.zip archive in C:\ using a
program such as WinZip. If you do not have WinZip get it from http://www.winzip.com.
You will then have a folder called DreamBot54 in C:\, (full path is: C:\DreamBot54).
Now you need to copy the mirc.exe file (mIRC execuatable) in the place where you have
DreamBot. *DreamBot requiers mIRC 6.16, read above on how to get it, if you don't have it.*
After that, just start mIRC from C:\DreamBot54\.

*** Commands ***
After setting yourself as owner (a window in the bot will tell you how) you can find out all
of the bot's commands by typing !commands in the channel.

*** Support ***

Before asking for assistance, please *completely* read this file. If this does not answer your
question, read the dbhelp.htm file (press F1 in your bot's mIRC).
*** NOTE: E-mail support is NO LONGER provided!
Still having problems? Do one of the following:
* Visit http://dreambot.eurion.com and do a forum search to see if that question was asked
   before or not.
* Post a message with your problem/question on the forum, describe it as clearly as possible.
   You will need to register before posting. Registration is easy and free.
* Or you can connect to irc.undernet.org and ask for help in #AllNightCafe. If nobody is active,
   follow the steps above.
* WE DO NOT SUPPORT MODIFIED VERSIONS OF DREAMBOT, THIS INCLUDES LOADING/USING
   OTHER SCRIPTS/ADDONS THAT ARE NOT APPROVED BY OUR TEAM.
* BY CHANGING ANYTHING IN THE BOT YOU LOOSE TECHNICAL SUPPORT.