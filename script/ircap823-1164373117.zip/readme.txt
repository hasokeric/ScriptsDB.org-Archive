IRcap 8.23
============

Install notes
-----------------------
Download mIRC  6.2 from any link from the file "getmirc62.html", included in this ZIP, install it in any folder, and unzip this file containing IRcap 8.21 in the same folder you have installed mIRC 6.2.

Or

Unzip this file containing IRcap 8.21 in any folder. Then copy "mirc.exe" file from mIRC 6.2 in the same folder.

ONLY WORKS WITH mIRC 6.2.







Instalaci�n
-----------------------
Descarga mIRC 6.2 desde alguno de los links del fichero "getmirc62.html", incluido en este ZIP, inst�lalo en cualquier directorio y descomprime este fichero que contiene IRcap 8.21 en el mismo directorio donde has instalado mIRC 6.2.

O

Descomprime este fichero de IRcap 8.21 en cualquier directorio y copia unicamente el fichero "mirc.exe" del mIRC 6.2 en el mismo directorio.

SOLO FUNCIONA CON mIRC 6.2.








---------------------------------
IRcap (c) Carlos Esteve Cremades, 1997-2006
http://www.ircap.com
http://www.ircap.net
