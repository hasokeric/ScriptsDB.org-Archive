This is Anac�n�a MTS theme version 1.7 dedicates to Anac�n�a NS script.
It contains 4 schemes, 1 dark (default) and a 3 whites. It also contains some background images

Big note: you'll have to use a good engine which supports MTS 1.3

How to install: It depends off your mts engine :P