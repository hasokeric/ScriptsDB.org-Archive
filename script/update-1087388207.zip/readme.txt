FraGma+ 1.2b

Script made by bore [migueleh@sapo.pt]

http://fragma.r8.org

________________________________________

1. installation:

	� after extracting the files (thing you should have done by now) get a clean version of mIRC.exe (if you don't have any just download it at www.mirc.co.uk)
	� the clean mIRC version must be 6.15
	� after having a clean mIRC version on FraGma+'s folder open mirc.exe
	� now just run mIRC.exe! once that you're ready to go!

2. using:

	� there's a very good help system in FraGma+
	� it will really explain how to use all FraGma+ functions!
	� to open the help system just click on the last icon on the toolbar, type /help or click Help on the Menubar
	� (if there's anything not mention in it search mirc.hlp or contact me!)

3. credits:

	� DragonZap . MDX and Popups dll
	� Kamek . mIRC Customizer dll
	� tabo . aIRC dll
	� kFreak . Ktools dll
	� BombStrike (?) . mDock61 dll and CTbar.dll
	� ? . mOTFV3 dll

	� Nixor . Some MP3 icons

	� Guy from QNX icon pack!
	� Vop . $theme.info
	� [arm]-commander . MTS utilities
	� praetorian . $isfont
	� Pai . $mtstoalias
	� i've used some other snippets ($seen, /join..) and i don't know who made them (sorry!)

4. thanks:

	� Infernal_Demon . beta testing and a lot of comments/help
	� BuLlD0ZzEr . beta testing and help

	� YOU!

	� Chtrunfinha . (*)

___________________________________________________