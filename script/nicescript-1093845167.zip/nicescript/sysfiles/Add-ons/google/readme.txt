  -----------------------------------
 | Google Search for mIRC
 | version 3.4
 | created by thame^
 |
 | pascaln@gmail.com
 | http://www.thame.nl/
  ------------------------------------


 ==============
  INTRODUCTION
 ==============

  Ho-ho!  thame^ 'returns' to mIRC scripting and introduces..  A
  script to search google.com with, and display the results in a
  nice and simple window!


  Okay, so perhaps it's not the most original concept you've ever
  heard of.  But if you've ever tried actually executing the idea
  yourself, you might've found it to be somewhat tricky, because
  of the ridiculously long and complicated HTML strings google.com
  replies with.

  This little script is the result of my attempts to overcome
  these obstacles.  Hopefully you'll find the ability to use the
  world's most popular search engine from within the world's most
  popular IRC client to be useful!


  In a nutshell: This script allows you to search google.com from
  within mIRC, displaying the results in a custom window.




 ================
  HOW TO INSTALL
 ================

  +++ Note: This script requires mIRC version 6.16 (or higher)!
      Get the most recent version at http://www.mirc.co.uk/

  Place google.mrc in a directory of your choice (preferably
  within mIRC's main directory or a subdirectory) and enter the
  following command in mIRC:

     /load -rs "C:\path\to\google.mrc"

  Where "C:\path\to\" is the directory you've placed google.mrc
  in.




 ============
  HOW TO USE
 ============

  This script does not feature a fancy dialog/MDX-interface as to
  emphasise its purpose; to integrate Google into mIRC.  I also do
  not feel like the usage of a (MDX-enhanced) dialog to display
  the results in will improve upon the script's userfriendliness
  or usability.


  +++ SCRIPTERS: Please note that I am not against the usage of
      MDX or any other eye-candy tools for that matter.  I believe
      that there are cases in which the usage of these tools are
      completely justified.  However, I feel like using them in a
      simple script like this would be out of place and
      unnecessary, as I feel like is the case with many other
      scripts these days.




 *** BASICS ***

  As such, the use of the script has been kept simple.  Simply
  enter

     /google <query>

  in any (regular) window, and the custom 'Google' window will pop
  up and perform a search on the given query.


  You may also use

     /google

  without any parameters to simply launch the custom 'Google'
  window without immediately performing a search.

  The same window can be reached by selecting the 'Google' entry
  in your menubar. (Google > Google)

  You may then enter your query in the editbox within the custom
  'Google' window, and a search will be performed upon it.


  To simulate Google's "I'm Feeling Lucky" feature, you can use

     /lgoogle <query>

  This feature bypasses the custom 'Google' window and immediately
  launches the first result to your query in your default browser.
  If a result is not found, nothing happens.

  +++ NOTE: A custom command can also be configured to launch the
      URL with.  See the SETTINGS section below.




 *** SEARCH RESULTS ***

  The search results are displayed similar to the way google.com
  displays them.  The website's title at the top, then the
  description, and then the URL.  This script will also show the
  number for every result on the left.

  You can double-click on any part of the result (title,
  description or URL) and the associating URL will be launched by
  your default browser  (using /url -n).

  +++ NOTE: Again, a custom command can also be configured to
      launch the URL with.  See the SETTINGS section below.




 *** BROWSING THROUGH PAGES ***

  You can browse through pages (if there are more than 10 results)
  by either right-clicking in the custom 'Google' window and
  selecting "Next page >" or "Previous page <", or by double-
  clicking the equally named lines at the bottom of the custom
  'Google' window.




 *** SETTINGS ***

  The script can be configured to use the colours of your choice
  for displaying the results, and a custom command can be set to
  launch the result's URL with.  You can also set the number of
  results you wish to be displayed per page.

  To reach these settings, select 'Settings' from your menubar
  (Google > Settings) or right-click in the custom 'Google' window
  and select 'Settings'.  The same can be accomplished by simply
  typing

     /google.settings


  You can configure the settings mentioned above in the dialog
  that will appear.

  +++ NOTE: to reset the colours to their original values, simply
      select the blank field (not a number) as a colour and press
      the 'Ok' button.




 *** OTHER ***

  The other options and features should be self-explanatory, such
  as "Close x" for closing the custom 'Google' window, and "Copy
  to clipboard", which will copy the currently selected line to
  the clipboard.




 ==================
  HOW TO UNINSTALL
 ==================

  To unload the script, simply enter

     /unload -rs google.mrc

  within mIRC, and the script will be unloaded.

  The script will prompt you whether to preserve your settings or
  not.  By clicking 'No', your settings (kept in google.ini) will
  be removed.  Otherwise this file will remain on your computer
  for possible future usage.




 ===========================================
  SUPPORTED AND UNSUPPORTED GOOGLE FEATURES
 ===========================================

  Obviously, this little script is not a web browser and does not
  support all the countless features that Google offers besides
  its regular and most popular search function.

  However, some of these functions ARE supported.  Currently these
  are:

     - The Google calculator
       Example: /google 10kg in pounds

     - "define <word>" function
       Example: /google define dictionary
       ** NOT define:word!! **

     - List of words excluded from a search

  Support for more of these might be added in future versions.




 =======
  TO-DO
 =======

  The script may work as it is, but it's not yet completed.
  Here's a small list of what I plan to add in future versions:

     - Support for define:<word> function
     - Ability to customise the font(?)
     - Additional Google functions(?)




 =========
  CREDITS
 =========

     - 'trb' @ http://www.mircscripts.org/comments_old.php?id=51
       For his $_nohtml() alias he posted as a comment there.

     - 'Techster' @ http://www.mircscripts.org/comments.php?cid=1225
       For his $rawurlencode() alias, which is part of the above
       snippet.

     - Google.com
       For obvious reasons.

     - The guys at #mircscripts.org on Undernet for not keeping me
       amused, forcing me to get back into mIRC scripting.  Oh,
       and some of them helped me test this thing.
       UPDATE: Here's news!  They actually helped me out this
       time!  Thanks guys ;)

     - http://www.mircscripts.org/
       For being the best mIRC scripting resource ^_^




 =================
  VERSION HISTORY
 =================

  -- version 1.0
       This was an old shitty version which used yahoo.com because
       I couldn't figure out how to get mIRC to work with the HUGE
       strings google.com sends.  It sucked ass and I got rid of
       it.

  -- version 2.0
       Rewritten from scratch, now using binary variables so it
       could actually use google.com.  Was never finished.

  -- version 3.0
       Rewritten from scratch again.  Again, using binary
       variables, but with updated code (for mIRC 6.1+) and
       updated for the new google.com layout.  It actually worked
       this time!

  -- version 3.0a
       Fixed a bug with google's calculator function.

  -- version 3.1
       Added support for pages (next/previous), along with some
       small changes.  Using $v1 now, so mIRC 6.16 is required.

  -- version 3.1a
       Fixed several bugs and added load/unload routines, as well
       as some functions for future user customisation (this got
       rid of the %variables too).  Also added support for "define
       <word>".  NOT "define:<word>".  There's a big difference,
       mind you.

  -- version 3.1b
       Changed the way the URL's for results were detected (and
       kept track of).  No more guessing around!  Also fixed some
       small bugs.  Oh, and wrote the first readme.txt ^_^
       Getting ready for a release at ms.org..

  -- version 3.2
       Added a simple interface for configuring the colours and a
       custom command to launch the URL's with.

  -- version 3.3
       Back to the drawing board for the dialog!  Redesigned the
       dialog according to the suggestions nukem gave me on
       ms.org, and also implemented his idea of adding a setting
       for configuring the number of results per page.  Some parts
       of the script had to be rewritten for this, but all should
       work fine now.

       Additionally, the first two lines no longer show the 'Copy
       to clipboard' menu item when right-clicking on them.  Oh,
       and 'Google Search Options' was renamed to 'Google Search
       Settings'.

  -- version 3.4
       The script now uses a hash table ('hashed binary variable')
       to save google.com's output instead of writing it to a
       file.  Theorically, this should make the script a little
       faster, but the difference is not noticeable on my own
       computer.  This idea came from Tychon.  Bugs in this new
       system were later fixed with the help of Ymar.  Love you
       guys <3

       Added support for Google's "I'm Feeling Lucky" feature in
       the shape of /lgoogle.  Read the readme.txt for more about
       this.

       Also fixed a couple of bugs, in particular ones to do with
       non-English results containing the 'Translate this page'
       link.  All should work just fine now.
