mIRC Webserver, v1.0 par Artwerks
21 juin 2003
-

Laisser les fichiers d�zipp�s dans le m�me ordre qu'ils sont l�, et n'effacer aucun de ces fichiers.
Ce webserver est fait pour une utilisation personnelle, donc n'h�bergez pas de site dessus.
Vous pouvez vous en servir pour montrer vos photos � vos amis, des choses du genre, donc plut�t un file server.

Vous n'avez qu'� inclure mIRC.exe dans le dossier principal.
Placer ensuite vos fichier dans le dossier webserver, vous pouvez y mettre des sous-dossiers.
Ensuite les configurations se font � partir des popups. Le port utilis� par Internet Explorer est le 80, si il est bloqu� chez-vous, utilisez-en un autre.
Si vous avez des probl�mes avec ce webserver, je serai absent jusqu'� la fin ao�t 2003, donc je ne pourrai pas vous r�pondre, d�sol�.

Aussi, soyez connect� � internet avant de le faire marcher.

Lorsque vous ouvrirez le webserver, mIRC ira directement en tray, et l'ic�ne sera un carr� bleu avec un W gris dedans. Donc vous saurez o� trouver le webserver.
J'ai enlev� les switchbar et toolbar, je ne veux pas qu'on chat avec ce webserver, il a �t� con�u pour une seule utilisation qui n'est pas de chatter.
Ne modifiez pas les .mrc, sinon il pourrait ne plus �tre fonctionnel par la suite.

Ce webserver prend les fichiers html et affichera toute les images qu'il y trouvera. Par contre, pour le php, n'en mettez surtout pas car il affichera la source php.
Je crois que j'ai fait le tour de la question, et que vous savez maintenant l'essentiel pour vous en servir correctement.

-
Paul-Philippe Nadeau [Artwerks]
ppnadeau@hotmail.com