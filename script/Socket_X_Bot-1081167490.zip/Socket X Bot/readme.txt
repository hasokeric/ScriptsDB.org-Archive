Socket X Bot

 1. Pour que le robot marche, vous devez inserer mIRC.exe dans le dossier.
  *** mIRC.exe : http://www.mirc.com (ne pas installer dans le meme dossier, juste copier mirc.exe)

 2. Une fois l'operation faite, demarer le bot et faire les ajustement. 
  (via le menu Socket X Bot puis Ajustement)

 3. les ajustement fais, connecter le bot.
  (via le menu Socket X Bot puis Status)


***** ATTENTION *****

 * Ne pas metre le robot dans le repertoir d'un script. *
 * Ne pas LOADER aucun autre fichier dans le robot.     *
 * Ne pas remplace le mirc.ini du robot par un autre    *