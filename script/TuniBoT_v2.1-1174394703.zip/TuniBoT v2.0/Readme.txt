////////////////////////////////////////////////////////

                    TuniBoT v2.0

 Scripter : Armed_boS / Arabeca
 
 Official Channel : #Tunibot,#CyberScripters (on Dalnet)

 E-mail :     NourElhak@Gmail.com

 Web site: http://www.CyberScriprters.c.la/

 Starting Projet : 13/06/2005

 Finishing Projet : 15/9/2005
 
 Last Update : 20/03/2007

////////////////////////////////////////////////////////


...........................:::: License Agreement ::::...........................

By downloading TuniBoT you agree to the following:  

1. You have permission to edit the bot for personal use only, you can not re-distribute it.  
2. You may not copy any of the scripting or images.  
3. All scripts and images within are copyright 2005-2006 by Armed_boS.
4. TuniBoT is freeware and has no time limitations of usage. It doesn't need any kind of registration to proceed to it's download and use.
5. TuniBoT doesn't include "malware" or "spyware".
6. TuniBoT is completely scanned with updated anti-virus to avoid any accidental distribution with any infected file.
7. TuniBoT will be excluded from any responsibility for any possible damage caused to the user's informatic equipment due to any misuse or being the result of an incorrect installation or any kind of incompatibility with other programs.
8. TuniBoT CANNOT BE DISTRIBUTED FROM OTHER WEB PAGES, or being distributed as part of any package (CD's, magazines, etc.), without express permission from its author.
9. Downloading TuniBoT from different web pages than the official site , could mean downloading a MODIFIED script, including backdoors, trojans or viruses.



...........................:::: Welcome ::::...........................

Hi, thanks for downloading the bot. The setup  
should be pretty easy, just fill in all the necessary fields in the  
Configuratio. If you have any problems setting the bot up,  
please first re-read the Readme (the one in the bot), and follow the  
instructions exactly. If you still have problems, you can find FAQ in the website: 
http://www.CyberScriprters.eur.st/
Also you can contact me by e-mail: NourElhak@gmail.com
You can always get in touch with me at the IRC server irc.dal.net and in the channel 
#Tunibot or #CyberScripters.


...........................:::: Installation ::::...........................

1. Download from the web site (http://www.mirc.com/) or copy and paste an mIRC into the directory you unzipped the bots files to (Tunibot).  
2. Run the mirc.exe that you placed in the bots directory.
3. Once opened you should set the default channel wich will be also the logs channel
4. After that set the Bot's nick wicth should be a registred nick and put his identify password and the server.
5. Click on "Add Admin" to add your self as admin.(you can also add many users as admin but they will have full access on the bot like you)
6. Finally, after the bot connect you should tape "/msg <Bot's nick> login <your IDnick> <your pass>" .
7. For help about all commands you can tape : /msg <Bot's nick> Help
   or
   You will find a help system in the bot's mirc .

Important: The bot's nick should be registred and added in the aop or sop list of all channels that he will join.
For mo
re help about commands you will find a help system into the bot.

 
...............................................................................

TuniBoT (c) Armed_boS ,2005-2006 
http://www.CyberScriprters.c.la/