menu * {
  $chr(58) $+ $chr(58) $+ .. $showtxt(context,1) :/dialog -m start start
  $chr(58) $+ $chr(58) $+ .. $showtxt(context,2)
  . $+ $chr(58) $+ $chr(58) $+ .. $showtxt(context,5) $iif(%defchan == $null, n/a , %defchan) :/
  . $+ $chr(58) $+ $chr(58) $+ .. $showtxt(context,6) :/changedefchan
  $chr(58) $+ $chr(58) $+ .. $showtxt(context,3) :/Aide
  $chr(58) $+ $chr(58) $+ .. $showtxt(context,7)
  . $+ $chr(58) $+ $chr(58) $+ .. $showtxt(context,8) :/set %lang FR
  . $+ $chr(58) $+ $chr(58) $+ .. $showtxt(context,9) :/set %lang EN
  $chr(58) $+ $chr(58) $+ .. $showtxt(context,4) :/F1

}
