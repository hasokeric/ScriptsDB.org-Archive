dialog about {
  title $showtxt(about,1)
  size -1 -1 300 330
  button "",1000,1000 1000 0 0,cancel,hide
  icon 1,27 10 246 58,system\graphics\logo.jpg,
  icon system\graphics\icon.ico , 0
  text "......:::::  TuniBoT v2.0  :::::.....",2,80 80 150 20,
  box "",3,10 100 280 210
  text "" ,4,20 120 50 20
  text "Armed_boS / Arabeca",5,70 120 150 20
  text "" ,6,20 160 100 20
  text "15/9/2005",7,100 160 150 20
  text "" ,16,20 180 100 20
  text "20/03/2007",17,100 180 150 20
  text "E-mail  :",8,20 140 100 20
  text "NourElhak@gmail.com",9,70 140 150 20
  text "" ,12,20 200 100 20
  text "#TuniBot,#CyberScripters (Dalnet)",13,105 200 200 20
  text "" ,10,20 220 90 20
  link "http://www.CyberScripters.c.la/",11,110 220 160 20
  text "" ,14,20 240 100 20
  text "" ,15,20 260 250 40
}
on *:dialog:about:sclick:11: { run http://www.CyberScripters.c.la/ }
on *:dialog:about:init:*: { 
  did -a about 4 $showtxt(about,2)
  did -a about 6 $showtxt(about,3)
  did -a about 16 $showtxt(about,4)
  did -a about 12 $showtxt(about,5)
  did -a about 10 $showtxt(about,6)
  did -a about 14 $showtxt(about,7)
  did -a about 15 $showtxt(about,8)
}
