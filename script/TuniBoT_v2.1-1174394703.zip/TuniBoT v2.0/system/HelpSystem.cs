;aide / Help
alias aide { dialog -m Help Help }
dialog Help {
  title $showtxt(help,1)
  size -1 -1 650 334
  button "",1000,1000 1000 0 0,cancel,hide
  icon system\graphics\icon.ico , 0
  icon 1,2 2 150 300,system\graphics\menu.jpg,1,
  box "" ,2,170 20 250 110
  combo  3,180 40 230 90,
  box "" ,4,170 150 470 153
  box "",6,-10 300 750 100
  button "" ,7,530 312 50 20
  button "" ,8,590 312 50 20, cancel
  ;
  button "<<<<<",9,190 312 80 20,
  button ">>>>>",10,320 312 80 20,
  ;
  text "" ,20,180 170 60 20
  text "",30,240 170 150 20
  text "" ,21,180 190 110 20
  text " n/a ",31,290 190 320 20
  text "" ,23,180 210 110 20
  text " n/a ",33,290 210 240 20
  text "" ,22,180 230 110 20
  text " n/a ",32,180 250 450 50


}


on *:dialog:help:init:*: {
  set %nn 0
  :start
  inc %nn
  if ($gettok($read($showtxt(help,12),%nn),1,42) == $null) { goto end }
  did -a help 3 $gettok($read($showtxt(help,12),%nn),1,42)
  goto start
  :end
  set %nHelp $calc(%nn -1)
  did -b help 9
  did -b help 10
  did -a help 2 $showtxt(help,2)
  did -a help 4 $showtxt(help,3)
  did -a help 20 $showtxt(help,4)
  did -a help 21 $showtxt(help,5)
  did -a help 23 $showtxt(help,6)
  did -a help 22 $showtxt(help,7)
  did -a help 7 $showtxt(help,8)
  did -a help 8 $showtxt(help,9)
  did -a help 30 $showtxt(help,10)
  did -a help 31 $showtxt(help,11)
  did -a help 32 $showtxt(help,11)
  did -a help 33 $showtxt(help,11)


}
on 1:dialog:help:sclick:3: {
  if ($did(help,3).sel != $null) {
    did -a help 30 $gettok($read($showtxt(help,12),$did(help,3).sel),1,42)
    did -a help 32 $gettok($read($showtxt(help,12),$did(help,3).sel),2,42)
    did -a help 31 $gettok($read($showtxt(help,12),$did(help,3).sel),3,42)
    did -a help 33 $gettok($read($showtxt(help,12),$did(help,3).sel),4,42)
    if ($did(help,3).sel == 1) { did -e help 10 | did -b help 9 }
    if ($did(help,3).sel == %nHelp) { did -e help 9 | did -b help 10 }
    if (($did(help,3).sel > 1) && ($did(help,3).sel < %nHelp)) {  did -e help 9 | did -e help 10 }
  }
}

on 1:dialog:help:sclick:9: { 
  did -a help 30 $gettok($read($showtxt(help,12),$calc($did(help,3).sel - 1)),1,42)
  did -a help 32 $gettok($read($showtxt(help,12),$calc($did(help,3).sel - 1)),2,42)
  did -a help 31 $gettok($read($showtxt(help,12),$calc($did(help,3).sel - 1)),3,42)
  did -a help 33 $gettok($read($showtxt(help,12),$calc($did(help,3).sel - 1)),4,42)
  if ($calc($did(help,3).sel - 1) == 1) { did -e help 10 | did -b help 9 }
  if ($calc($did(help,3).sel - 1) == %nHelp) { did -e help 9 | did -b help 10 }
  if (($calc($did(help,3).sel - 1) > 1) && ($calc($did(help,3).sel - 1) < %nHelp)) {  did -e help 9 | did -e help 10 }
  did -c help 3 $calc($did(help,3).sel - 1)
}
on 1:dialog:help:sclick:10: { 
  did -a help 30 $gettok($read($showtxt(help,12),$calc($did(help,3).sel + 1)),1,42)
  did -a help 32 $gettok($read($showtxt(help,12),$calc($did(help,3).sel + 1)),2,42)
  did -a help 31 $gettok($read($showtxt(help,12),$calc($did(help,3).sel + 1)),3,42)
  did -a help 33 $gettok($read($showtxt(help,12),$calc($did(help,3).sel + 1)),4,42)
  if ($calc($did(help,3).sel + 1) == 1) { did -e help 10 | did -b help 9 }
  if ($calc($did(help,3).sel + 1) == %nHelp) { did -e help 9 | did -b help 10 }
  if (($calc($did(help,3).sel + 1) > 1) && ($calc($did(help,3).sel + 1) < %nHelp)) {  did -e help 9 | did -e help 10 }
  did -c help 3 $calc($did(help,3).sel + 1)
}
on 1:dialog:help:sclick:7: { F1 }

alias changedefchan {
  .set %tempo $$?="Set bot's default channel (with the #):"
  if (%tempo == $null)  { halt }
  if (%defchan == $null) { .inc %chans 1 }
  .wchans %tempo chan %tempo
  .wchans %tempo deftopic Welcome To %tempo - For Love use : !LoveMeter
  .wchans %tempo welcome Welcome $ $+ nick To %tempo - For Love use : !LoveMeter
  .wchans %tempo strictop off
  .wchans %tempo defmodes +nt
  .wchans %tempo setwelcome ON
  .wchans %tempo suspend OFF
  .wchans %tempo autovoice ON
  .wchans %tempo bantimeout 0
  .wchans %tempo antipub off
  .wchans %Defchan antiwords off
  .wchans %tempo autolimit off
  if (%defchan != $null) { .remini system\database\chans.ini %defchan }
  .set %defchan %tempo
  .unset %tempo
  .echo -a 10 %defchan Has Been Successfully Registred

}
