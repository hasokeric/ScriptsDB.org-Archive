on 1:text:Deluser*:?: {
  if ($2 == $null) { .n $nick Error : Syntax : /msg $me DelUser <Idnick> | halt }
  else {
    if ($idnick($2) == $null) { .n $nick Error : This Idnick Is Not In User List | halt }
    else {
      if ($anicklist($nick) == $null) { .n $nick Error : Access Refused / You Should Auth First | halt }
      if ($lev($anicklist($nick)) < 500) { .n $nick Error : Your Access Level Sould Be 500 At Least ! | halt }
      elseif ($lev($2) >= $lev($anicklist($nick))) { .n $nick Error : User Access Level Sould Be Less Then Your Access ! | halt }
      else {
        if ($authidnick($2) != $null) {
          .remini system\database\anick.ini nicklist $authidnick($2)
          .remini system\database\nick.ini list $2
          .remini system\database\access.ini $2 
          .n $nick $2 Has Been Successfully Removed From User List
          .n $2 You Has Been Removed From User List
          .halt
        }
        else {
          .remini system\database\access.ini $2 
          .n $nick $2 Has Been Successfully Removed From User List
          .halt
        }
      }
    }
  }
}
