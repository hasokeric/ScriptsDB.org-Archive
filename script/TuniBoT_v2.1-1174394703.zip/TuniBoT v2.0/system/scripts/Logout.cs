on 1:text:Logout*:?: {
  if ($3 == $null) { .n $nick Error : Syntax : /msg $me Logout <Idnick> <pass> | halt }
  else {
    if ($idnick($2) == $null) { .n $nick Error : Invalid Idnick | halt }
    else {
      if ($authidnick($2) == $null) { .n $nick Error : This Idnick Is Not Identified | halt }
      if ($authidnick($2) == $nick) {
        .remini system\database\nick.ini list $anicklist($nick)
        .remini system\database\anick.ini nicklist $nick
        .n $nick You Have Successfully Logout
        .halt
      }
      else {
        if ($decode($pass($2),m) === $3) {
          .remini system\database\anick.ini nicklist $authidnick($2)
          .remini system\database\nick.ini list $2
          .n $nick You Have Successfully Logout
          .halt
        }
        else { .n $nick Error : Incorrect Password }
      }
    }
  }
}
