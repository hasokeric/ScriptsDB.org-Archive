on 1:text:Delchan*:?: {
  if (($2 == $null) || ($chr(35) !isin $2)) { .n $nick Error : Syntax : /msg $me DelChan <#channel> | halt }
  else {
    if ($anicklist($nick) == $null) { .n $nick Error : Access Refused / You Should Auth First | halt }
    if (700 > $lev($anicklist($nick))) { .n $nick Error : Your Access Level Sould Be 700 At Least To Do This Command ! | halt }
    if ($channelChan($2) == $null) { .n $nick Error : This Channel Is Not Registred At My Chanlist | halt }
    if ($2 == %Defchan) { .n $nick Error : Sorry You Can't Remove The Official Bot Channel | halt }
    else {
      .remini system\database\chans.ini $2 
      .n $nick $2 Has Been Successfully Removed
      .dec %chans 1
      .part $2 Channel Has Been Removed From My Chanlist
      .halt
    }
  }
}
