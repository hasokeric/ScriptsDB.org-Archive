on 1:text:Adduser*:?: {
  if ($4 == $null) { .n $nick Error : Syntax : /msg $me Adduser <Idnick> <pass> <level> | halt }
  else {
    if ($idnick($2) != $null) { .n $nick Error : This Idnick Is Already Registred With " $lev($2) " Level | halt }
    else {
      if ($anicklist($nick) == $null) { .n $nick Error : Access Refused / You Should Auth First | halt }
      if ($lev($anicklist($nick)) < 500) { .n $nick Error : Your Access Level Sould Be 500 At Least ! | halt }
      if ($lev($anicklist($nick)) < 100) { .n $nick Error : User Access Level Sould Be 100 At Least ! | halt }
      if ($lev($anicklist($nick)) =< $4) { .n $nick Error : User Access Level Sould Be Less Then Your Access ! | halt }
      else {
        adduser $2 $3 $4
        .n $nick $2 Has Been Successfully Added With $4 Level
        .halt
      }
    }
  }
}
alias waccess { .writeini system\database\access.ini $1- }
alias adduser {        
  waccess $1 idnick $1
  waccess $1 level $3
  waccess $2 pass $encode($2,m)
  waccess $3 suspend off

}
