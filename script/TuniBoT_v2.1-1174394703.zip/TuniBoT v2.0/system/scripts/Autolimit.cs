on 1:text:Autolimit*:?: {
  if (($3 == $null) || ($chr(35) !isin $2)) { .n $nick Error : Syntax : /msg $me Autolimit <#channel> <ON|OFF> | halt }
  if (($3 != on) && ($3 != off)) { .n $nick Error : Syntax : /msg $me Autolimit <#channel> <ON|OFF> | halt }
  if ($channelChan($2) == $null) { .n $nick Error : $2 Is Not Registred At My Channels List | halt }
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  if ($lev($anicklist($nick)) < 300) { .n $nick Error : You Should Have 300 Access Level To Do This Command | halt }
  if (($lev($anicklist($nick)) < 700) && ($2 == #TuniBoT)) { .n $nick Error : You Should Have 700 Access Level To Use $1 In $2 | halt }

  else {
    .wchans $2 autolimit $3
    .n $nick $2 AutoLimit Set To : $3
    .halt 
  }
}

on 1:text:!Autolimit*:#:{
  if ($2 == $null) { .n $nick Error : Syntax : !Autolimit <ON|OFF> | halt }
  if (($2 != on) && ($2 != off)) { .n $nick Error : Syntax : !Autolimit <ON|OFF> | halt }
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  if ($lev($anicklist($nick)) < 300) { .n $nick Error : You Should Have 300 Access Level To Do This Command | halt }
  if (($lev($anicklist($nick)) < 700) && ($chan == #TuniBoT)) { .n $nick Error : You Should Have 700 Access Level To Use $1 In $chan | halt }

  else {
    .wchans $chan autolimit $2
    .n $nick $chan AutoLimit Set To : $2
    .halt 
  }
}
