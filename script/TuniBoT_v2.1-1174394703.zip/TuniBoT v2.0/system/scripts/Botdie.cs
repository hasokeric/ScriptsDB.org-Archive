on 1:notice:Botdie*:?: {
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  if ($lev($anicklist($nick)) < 1000) { .n $nick Error : You Should Have 1000 Access Level To Do This Command | halt } 
  .n $nick Bot Quitting ...
  .quit
}
