on 1:text:Voice*:?: {
  if (($3 == $null) || ($chr(35) !isin $2)) { .n $nick Error : Syntax : /msg $me Voice <#channel> <nick> | halt }
  if ($channelChan($2) == $null) { .n $nick Error : $2 Is Not Registred At My Channels List | halt }
  if ($me !ison $2) { .n $nick Error : Sorry I'm Not In $2 | halt }
  elseif ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  else {
    .mode $2 +v $3
    .halt
  }
}
on 1:text:!Voice*:#: {
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have  Access To Do This Command | halt }
  else {
    if ($2 == $null) { .mode $chan +v $nick | halt }
    else { .mode $chan +v $2  | halt }

  }
}
