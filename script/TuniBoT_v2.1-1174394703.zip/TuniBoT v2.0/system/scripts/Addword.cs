on 1:text:Addword*:?: {
  if (($3 == $null) || ($chr(35) !isin $2)) { .n $nick Error : Syntax : /msg $me AddWord <#channel> <words..> | halt }
  if ($channelChan($2) == $null) { .n $nick Error : $2 Is Not Registred At My Channels List | halt }
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  if ($lev($anicklist($nick)) < 300) { .n $nick Error : You Should Have 300 Access Level To Do This Command | halt }
  if (($lev($anicklist($nick)) < 700) && ($2 == #TuniBoT)) { .n $nick Error : You Should Have 700 Access Level To Use $1 In $2 | halt }
  else {
    set %na  0
    :debut
    inc %na
    if ($gettok($channelwordlist($2),%na,161) == $3-) { .n $nick The Word " $3- " Is Already In $2  (Prohibited) Words List | goto end }
    if (%na >= %nwords) { 
      wchans $2 wordlist $channelwordlist($2) $+ $chr(161) $+ $3-
      countwords $2
      .n $nick The Word ( $3- ) Has Been Successfully Added To $2 (Prohibited) Words List
      goto end
    }
    goto debut
    :end
    .halt 
  }
}







on 1:text:!Addword*:#: {
  if ($2 == $null)  { .n $nick Error : Syntax : !AddWord  <words..> | halt }
  if ($channelChan($chan) == $null) { .n $nick Error : $chan Is Not Registred At My Channels List | halt }
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  if ($lev($anicklist($nick)) < 300) { .n $nick Error : You Should Have 300 Access Level To Do This Command | halt }
  if (($lev($anicklist($nick)) < 700) && ($chan == #TuniBoT)) { .n $nick Error : You Should Have 700 Access Level To Use $1 In $chan | halt }

  else {
    set %na  0
    :debut
    inc %na
    if ($gettok($channelwordlist($chan),%na,161) == $2-) { .n $nick The Word " $2- " Is Already In $chan (Prohibited) Words List | goto end }
    if (%na >= %nwords) { 
      wchans $chan wordlist $channelwordlist($chan) $+ $chr(161) $+ $2-
      countwords $chan
      .n $nick The Word ( $2- ) Has Been Successfully Added To $chan (Prohibited) Words List
      goto end
    }
    goto debut
    :end
    .halt 
  }
}
