on 1:text:Join*:?: {
  if (($2 == $null) || ($chr(35) !isin $2)) { .n $nick Error : Syntax : /msg $me Join <#channel> | halt }
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  if ($lev($anicklist($nick)) < 600) { .n $nick Error : You Should Have 600 Access Level To Do This Command | halt }    
  if ($channelChan($2) == $null) { .n $nick Error : $2 Is Not Registred At My Channels List | halt }
  if ($channelSuspend($2) == ON) { .n $nick Error : $2 Is Suspend - Raison : $channelwhy($2) | halt }
  if ($me ison $2) { .n $nick Error : I'm Already In $2 | halt }
  else { .join $2 | halt }
}
