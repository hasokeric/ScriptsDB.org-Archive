on 1:text:Newpass*:?: {
  if ($4 == $null) { .n $nick Error : Syntax : /msg $me NewPass <Idnick> <oldpass> <newpass> | halt }
  else {
    if ($idnick($2) == $null) { .n $nick Error : Invalid Idnick | halt }
    else {
      if ($decode($pass($2),m) === $3) {
        .writeini system\database\access.ini $2 pass $encode($4,m)
        .n $nick $2 Password Successfully Changed To : $4
        .halt
      }
      else { .n $nick Error : Incorrect Password | halt }
    }
  }
}
