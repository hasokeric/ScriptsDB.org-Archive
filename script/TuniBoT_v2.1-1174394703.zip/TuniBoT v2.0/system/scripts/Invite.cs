on 1:text:Invite:*:?: {
  if (($3 == $null) || ($chr(35) !isin $2)) { .n $nick Error : Syntax : /msg $me invite <#channel> <nick> | halt }
  if ($channelChan($2) == $null) { .n $nick Error : $2 Is Not Registred At My Channels List | halt }
  if ($me !ison $2) { .n $nick Error : Sorry I'm Not In $2 | halt }
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  if ($lev($anicklist($nick)) < 100) { .n $nick Error : You Should Have 100 Access Level To Do This Command | halt }
  if ($3 ison $2) { halt }
  else {
    .invite $3 $2
    .halt
  }
}

on 1:text:!Invite*:#: {
  if ($2 == $null) { .n $nick Error : Syntax : !invite <nick> | halt }
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  if ($lev($anicklist($nick)) < 100) { .n $nick Error : You Should Have 100 Access Level To Do This Command | halt }
  if (($lev($anicklist($nick)) < 700) && ($chan == #TuniBoT)) { .n $nick Error : You Should Have 700 Access Level To Use $1 In $chan | halt }

  if ($2 ison $chan) { halt }
  else {
    .invite $2 $chan
    .halt
  }
}
