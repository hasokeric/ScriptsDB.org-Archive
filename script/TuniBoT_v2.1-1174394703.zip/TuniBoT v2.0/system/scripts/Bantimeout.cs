on 1:text:Bantimeout*:?: {
  if (($3 == $null) || ($chr(35) !isin $2)) { .n $nick Error : Syntax : /msg $me BanTimeOut <#channel> <N secondes>  | halt }
  if ($3 !isnum ) { .n $nick Error : Syntax : /msg $me BanTimeOut <#channel> <N secondes> | halt }
  if ($channelChan($2) == $null) { .n $nick Error : $2 Is Not Registred At My Channels List | halt }
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  if ($lev($anicklist($nick)) < 500) { .n $nick Error : You Should Have 500 Access Level To Do This Command | halt }
  if (($lev($anicklist($nick)) < 700) && ($2 == #TuniBoT)) { .n $nick Error : You Should Have 700 Access Level To Use $1 In $2 | halt }
  else {
    .wchans $2 BanTimeOut $3
    .n $nick $2 BanTimeOut Set To : $3 Secondes
    .halt 
  }
}


on 1:text:!Bantimeout*:#: {
  if ($2 == $null) { .n $nick Error : Syntax : !BanTimeOut <N secondes> | halt }
  if ($2  !isnum) { .n $nick Error : Syntax : !BanTimeOut <N secondes> | halt }
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  if ($lev($anicklist($nick)) < 500) { .n $nick Error : You Should Have 500 Access Level To Do This Command | halt }
  if (($lev($anicklist($nick)) < 700) && ($chan == #TuniBoT)) { .n $nick Error : You Should Have 700 Access Level To Use $1 In $chan | halt }

  else {
    wchans $chan BanTimeOut $2
    n $nick $chan BanTimeOut Set To : $2 Secondes
    halt 
  }
}
