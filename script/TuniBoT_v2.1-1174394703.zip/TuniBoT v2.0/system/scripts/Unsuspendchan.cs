on 1:text:Unsuspendchan*:?: {
  if (($2 == $null) || ($chr(35) !isin $2)) { .n $nick Error : Syntax : /msg $me UnSuspendChan <#channel>  | halt }
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  if ($lev($anicklist($nick)) < 600) { .n $nick Error : You Should Have 700 Access Level To Do This Command | halt }    
  if ($channelchan($2) == $null) { .n $nick Error : $2 Is Not Registred At My Channel List | halt }
  if ($channelsuspend($2) == off) { .n $nick Error : $2 Is Already UnSuspended | halt }
  if ($2 == #tunibot) { halt }
  else { 
    .wchans $2 suspend off
    .remini system\database\chans.ini $2 why 
    .n $nick $2 Has Been Successfully UnSuspended
    .join $2 
    .halt
  }
}
