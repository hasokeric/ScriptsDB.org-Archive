on 1:text:Part*:?: {
  if (($2 == $null) || ($chr(35) !isin $2)) { .n $nick Error : Syntax : /msg $me Part <#channel> | halt }
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  if ($lev($anicklist($nick)) < 600) { .n $nick Error : You Should Have 600 Access Level To Do This Command | halt }    
  if ($me !ison $2) { .n $nick Error : I'm Not In $2 | halt }
  else { .part $2 | halt }
}
