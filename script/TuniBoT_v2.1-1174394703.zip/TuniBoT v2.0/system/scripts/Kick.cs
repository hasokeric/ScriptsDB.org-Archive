on 1:text:Kick*:?: {
  if (($4 == $null) || ($chr(35) !isin $2)) { .n $nick Error : Syntax : /msg $me kick <#channel> <nick> <raison> | halt }
  if ($channelChan($2) == $null) { .n $nick Error : $2 Is Not Registred At My Channels List | halt }
  if ($me !ison $2) { .n $nick Error : Sorry I'm Not In $2 | halt }
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  elseif ($lev($anicklist($nick)) < 100) { .n $nick Error : You Should Have 100 Access Level To Do This Command | halt }
  if (($lev($anicklist($nick)) < 700) && ($2 == #TuniBoT)) { .n $nick Error : You Should Have 700 Access Level To Use $1 In $2 | halt }
  if ($3 == $me) { .n $nick Error : Sorry You Can't Kick me | halt }
  else {
    if ($lev($anicklist($nick)) < $lev($anicklist($3))) { .n $nick Error : You Can't Kick User With Access Level Larger Then Yours | halt }
    .kick $2 $3 By $nick - $4-
    .halt
  }
}
on 1:text:!Kick*:#: {
  if ($3 == $null) { .n $nick Error : Syntax : !kick <nick> <raison> | halt }
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  elseif ($lev($anicklist($nick)) < 100) { .n $nick Error : You Should Have 100 Access Level To Do This Command | halt }
  if (($lev($anicklist($nick)) < 700) && ($chan == #TuniBoT)) { .n $nick Error : You Should Have 700 Access Level To Use $1 In $chan | halt }
  if ($2 == $me) { .n $nick Error : Sorry You Can't Kick me | halt }
  else {
    if ($lev($anicklist($nick)) < $lev($anicklist($2))) { .n $nick Error : You Can't Kick User With Access Level Larger Then Yours | halt }
    .kick $chan $2 By $nick - $3-
    .halt
  }
}
