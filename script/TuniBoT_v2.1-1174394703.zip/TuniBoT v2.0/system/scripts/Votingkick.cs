on 1:text:!Votingkick*:#: {
  if ($group(#VotingTuniBot.Kick) == on) {  .n $nick Sorry $nick but there is running now to kick " %VotingTuniBot.Nick " from " VotingTuniBot.channel " | halt }
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access  To Do This Command | halt }
  if ($lev($anicklist($nick)) < 100) { .n $nick Error : You Should Have At Least 100 Access Level To Do This Command | halt }
  if ($3 == $null) { .n $nick Error : Syntax : !votingkick <nick> <N (secondes, Voting delai> | halt }
  if ($2 == $me) { .n $nick Sorry but you can't kick me :) | halt }
  if ($2 == $nick) { .n $nick Sorry but you can't kick yourself :) | halt }
  if ($lev($anicklist($2)) != $null) { .n $nick Error : You can't kick a bot User :) | halt }
  if ($2 !ison $chan) { .n $nick Sorry but $2 isn't on this channel | halt }
  else { 
    VotingTuniBot.Kick $chan $2 $3 
    halt
  }
}


#VotingTuniBot.Kick off
on 1:text:Yes:#: {
  if ($group(#VotingTuniBot.Kick) == off) { halt }
  if ($chan != %VotingTuniBot.Channel) { halt }
  if ( $istok(%VotingTuniBot.AlreadyVoted,$nick,32) == $true ) { goto end }
  set %VotingTuniBot.AlreadyVoted %VotingTuniBot.AlreadyVoted $nick
  inc %Yes
  if ( $nick != %VotingTuniBot.Nick ) { .notice $nick Thanks for your voting ! We will win :+) }
  if ( $nick == %VotingTuniBot.Nick ) { .notice $nick Thanks for your voting ! You want kick your self :) }
  :end
  halt
}
on 1:text:No:#: {
  if ($group(#VotingTuniBot.Kick) == off) { halt }
  if ($chan != %VotingTuniBot.Channel) { halt }
  if ( $istok(%VotingTuniBot.AlreadyVoted,$nick,32) == $true ) { goto end }
  set %VotingTuniBot.AlreadyVoted %VotingTuniBot.AlreadyVoted $nick
  inc %No
  if ( $nick != %VotingTuniBot.Nick ) { .notice $nick Thanks for voting! } 
  if ( $nick == %VotingTuniBot.Nick ) { .notice $nick Hmmm ! Are you thinking that the result will be for you ? }
  :end
  halt
}

#VotingTuniBot.Kick end
alias VotingTuniBot.Kick {
  if (!$chan) { set %VotingTuniBot.Channel $1 }
  else { set %VotingTuniBot.Channel $chan }
  set %VotingTuniBot.Nick $2
  set %VotingTuniBot.Time $3
  set %Yes 0 | set %No 0
  set %VotingTuniBot.Off $calc( %VotingTuniBot.Time + 5 )
  .enable #VotingTuniBot.Kick
  msg $chan ----- Vote -----
  msg $chan Question: Should i kick 4 %VotingTuniBot.Nick $+ ?
  msg $chan Voting Time: %VotingTuniBot.Time secs
  msg $chan To vote tape: 'Yes' or 'No' 
  .timer 1 %VotingTuniBot.Time VotingTuniBot.Kick.Results
}
alias VotingTuniBot.Kick.Results {
  msg %VotingTuniBot.Channel Voting Time Finished ! 
  msg %VotingTuniBot.Channel The Question was: Should i kick 4 %VotingTuniBot.Nick $+ ?
  msg %VotingTuniBot.Channel Results: %Yes Yes ��� %No No
  if ( ( %Yes > %No ) && ( %VotingTuniBot.Nick ison %VotingTuniBot.Channel ) ) { /kick %VotingTuniBot.Channel %VotingTuniBot.Nick Sorry %VotingTuniBot.Nick ! But i should kick you under the users request ! }
  if ( ( %Yes > %No ) && ( %VotingTuniBot.Nick !ison %VotingTuniBot.Channel ) ) { /msg %VotingTuniBot.Channel %VotingTuniBot.Nick Has flee from being kicked :p }
  if ( %No > %Yes ) { msg %VotingTuniBot.Channel 4,0 %VotingTuniBot.Nick Will stay on %VotingTuniBot.Channel under users request }
  if (%Yes == %No) { msg %VotingTuniBot.Channel 4,0 %VotingTuniBot.Nick Will stay on %VotingTuniBot.Channel because the equality on voting :'( }
  .disable #VotingTuniBot.Kick
  unset %VotingTuniBot.* %Yes %No
}
