on 1:notice:Botrestart*:?: {
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  if ($lev($anicklist($nick)) < 900) { .n $nick Error : You Should Have 900 Access Level To Do This Command | halt } 
  .n $nick Bot Restarting ...
  .Username 4...:::: TuniBoT ::::...- By: 4Armed_boS  
  .server $server
}
