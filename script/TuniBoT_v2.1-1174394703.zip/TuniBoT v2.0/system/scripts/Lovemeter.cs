on 1:text:!LoveMeter*:#: {
  if ($3 == $null) { .n $nick Error Syntax: !LoveMeter <Name1> <Name2> - ex: !LoveMeter Romio Juliet | halt }
  if (($len($2) < 3) || ($len($3) < 3)) { .n $nick Error Name Lenth Should Be More Than 2 Letters | halt }
  if (($len($2) > 16) || ($len($3) > 16)) { .n $nick Error Name Lenth Should Be Less Than 16 Letters | halt }
  if ($2 == $3) { .n $nick Error : You Love Your Self ?? Plz Use Different Names  | halt }
  if ($timer(Love4) != $null) { .n $nick LoveMeter Is Busy Plz Try After 5 Secs | halt }
  else {
    set %score 0
    inc %score $rand(0,15)
    ;Cas 1
    if ($len($2) == $len($3)) { inc %score $rand(5,30) | set %nl $len($2) }
    if ($len($2) > $len($3)) { inc %score $rand(5,20) | set %nl $len($3) }
    if ($len($2) < $len($3)) { inc %score $rand(5,25) | set %nl $len($2) }
    inc %score $round($calc(($len($2) / $len($3)) * 10),0)
    inc %score $round($calc(($len($2) * $len($3)) / 100),0)
    inc %score $calc($len($encode($2 $+ $3,m))/2)

    if ($left($2,1) == $left($3,1)) { inc %score 10 }
    if ($left($2,2) == $left($3,2)) { inc %score 10 }
    if ($right($2,1) == $right($3,1)) { inc %score 10 }
    if ($right($2,2) == $right($3,2)) { inc %score 10 }
    if ($right($2,3) == $right($3,3)) { inc %score 10 }
    if (%score < 50) { inc %score $rand(0,40) }
    if (%score >= 100) { set %score $rand(90,99) }

    .timerLove0 1 0 /.msg $chan 4,4(�\/�) $spacer(,) - $spacer(,) 4,4
    .timerLove1 1 1 /.msg $chan 0,4(�\/�) 1,4LoveMeter v1.0 (Beta) - By: Armed_boS 
    .timerLove2 1 2 /.msg $chan 0,4 \0,4 0,4 / 4,4 $+ $spacer($2,$3) $+ 0,4 $2 0,4-0,4 $3 4,4  $+ $spacer($2,$3) $+ $spac($2,$3)
    .timerLove3 1 3 /.msg $chan 0,4 0,4 0,4\/ 4,4 4,4  $+ $spacer(1,) $+ 0,4 %score $chr(37) 4,4 $+ $spacer(1,) 4,4
    .timerLove4 1 4 /.msg $chan 1,4 Powered by http://www.CyberScripters.eur.st 
    halt
  }
}
;Love Meter


alias spacer {
  set %L1 $calc(36 - ($len($1) + $len($2)))
  set %L2 $round($calc((%L1 - 3) / 2),0)
  unset %Spacer
  set %NL 0
  :debut
  inc %NL
  if (%NL <= %L2) { set %Spacer %Spacer $+ L | goto debut }
  :end
  return %Spacer
}
alias spac {
  unset %it
  set %L1 $calc(36 - ($len($1) + $len($2)))
  set %L2 $calc((%L1 - 3) / 2)
  if ($chr(46) !isin %L2) {
    set %it l
  }
  return %it
}
