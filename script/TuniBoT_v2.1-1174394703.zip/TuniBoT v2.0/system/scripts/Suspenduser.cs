on 1:text:Suspenduser*:?: {
  if (($2 == $null) || ($3 == $null)) { .n $nick Error : Syntax : /msg $me Suspenduser <Idnick> <raison> | halt }
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  if ($lev($anicklist($nick)) < 600) { .n $nick Error : You Should Have 600 Access Level To Do This Command | halt }    
  if ($idnick($2) == $null) { .n $nick Error : $2 Is Not Registred At My User List | halt }
  if ($lev($anicklist($nick)) < $lev($2)) { .n $nick Error : You Can't Suspend User With A Heighter Level Then You | halt }
  if ($lev($anicklist($nick)) == $lev($2)) { .n $nick Error : You Can't Suspend User With The Same Level As You | halt }
  if ($suspend($2) == on) { .n $nick Error : $2 Access Is Already Suspended | halt }
  if ($authidnick($2) != $null) { 
    .set %suspend $authidnick($2)
    .remini system\database\anick.ini nicklist $authidnick($2)
    .remini system\database\nick.ini list $2
    .writeini system\database\access.ini $2 suspend on
    .writeini system\database\access.ini $2 why < $+ $nick $+ > $3-
    .n $nick $2 Access Has Been Successfully Suspended
    .n %suspend Your Access Has Been Suspended By $nick - Raison : $why($2)
    .unset %suspend
    .halt
  }
  if ($authidnick($2) == $null) { 
    .writeini system\database\access.ini $2 suspend on
    .writeini system\database\access.ini $2 why < $+ $nick $+ > $3-
    .n $nick $2 Access Has Been Successfully Suspended
    .halt
  }
}


on 1:text:!Suspenduser*:#: {
  if (($2 == $null) || ($3 == $null)) { .n $nick Error : Syntax : !Suspenduser <Idnick> <raison> | halt }
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  if ($lev($anicklist($nick)) < 600) { .n $nick Error : You Should Have 600 Access Level To Do This Command | halt }    
  if ($idnick($2) == $null) { .n $nick Error : $2 Is Not Registred At My User List | halt }
  if ($lev($anicklist($nick)) < $lev($2)) { .n $nick Error : You Can't Suspend User With A Heighter Level Then You | halt }
  if ($lev($anicklist($nick)) == $lev($2)) { .n $nick Error : You Can't Suspend User With The Same Level As You | halt }
  if ($suspend($2) == on) { .n $nick Error : $2 Access Is Already Suspended | halt }
  if ($authidnick($2) != $null) { 
    .set %suspend $authidnick($2)
    .remini system\database\anick.ini nicklist $authidnick($2)
    .remini system\database\nick.ini list $2
    .writeini system\database\access.ini $2 suspend on
    .writeini system\database\access.ini $2 why < $+ $nick $+ > $3-
    .n $nick $2 Access Has Been Successfully Suspended
    .n %suspend Your Access Has Been Suspended By $nick - Raison : $why($2)
    .unset %suspend
    .halt
  }
  if ($authidnick($2) == $null) { 
    .writeini system\database\access.ini $2 suspend on
    .writeini system\database\access.ini $2 why < $+ $nick $+ > $3-
    .n $nick $2 Access Has Been Successfully Suspended
    .halt
  }

}
