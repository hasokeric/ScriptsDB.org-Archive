on 1:text:Op*:?: {
  if (($3 == $null) || ($chr(35) !isin $2)) { .n $nick Error : Syntax : /msg $me op <#channel> <nick> | halt }
  if ($channelChan($2) == $null) { .n $nick Error : $2 Is Not Registred At My Channels List | halt }
  if ($me !ison $2) { .n $nick Error : Sorry I'm Not In $2 | halt }
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  if ($lev($anicklist($nick)) < 100) { .n $nick Error : You Should Have 100 Access Level To Do This Command | halt }
  if (($lev($anicklist($nick)) < 700) && ($2 == #TuniBoT)) { .n $nick Error : You Should Have 700 Access Level To Use $1 In $2 | halt }
  if ($channelstrictop($2) == on) {
    if ($3 == $nick) { mode $2 +o $3 | halt }
    else { .n $nick Error : $chr(91) $2 : Strictop ON $chr(93) Sorry You Can Only Op Your Self | halt }
  }
  else {
    .mode $2 +o $3
    .halt
  }
}


on 1:text:!Op*:#: {
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  if ($lev($anicklist($nick)) < 100) { .n $nick Error : You Should Have 100 Access Level To Do This Command | halt }
  if (($lev($anicklist($nick)) < 700) && ($chan == #TuniBoT)) { .n $nick Error : You Should Have 700 Access Level To Use $1 In $chan | halt }
  if ($2 != $null) {
    if ($channelstrictop($chan) == on) {
      if ($2 == $nick) { mode $chan +o $2 | halt }
      else { .n $nick Error : $chr(91) $chan : Strictop ON $chr(93) Sorry You Can Only Op Your Self | halt }
    }
    else {
      .mode $chan +o $2
      .halt
    }
  }
  else {  .mode $chan +o $nick | .halt }
}
