on 1:text:Delword*:?: {
  if (($3 == $null) || ($chr(35) !isin $2)) { .n $nick Error : Syntax : /msg $me DelWord <#channel> <words...> | halt }
  if ($channelChan($2) == $null) { .n $nick Error : $2 Is Not Registred At My Channels List | halt }
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  if ($lev($anicklist($nick)) < 300) { .n $nick Error : You Should Have 300 Access Level To Do This Command | halt }
  if (($lev($anicklist($nick)) < 700) && ($2 == #TuniBoT)) { .n $nick Error : You Should Have 700 Access Level To Use $1 In $2 | halt }

  else {
    set %nwords $gettok($channelwordlist($2),0,161)
    set %nb  0
    :debut1
    inc %nb
    if (%nb > %nwords) { 
      .n $nick The Word " $3- " Is Not In $2 (prohibited) Word List Or It's Not Wrote Correctly
      goto end1
    }
    if ($gettok($channelwordlist($2),%nb,161) != $3-) { goto debut1 }
    if ($gettok($channelwordlist($2),%nb,161) == $3-) {
      wchans $2 wordlist $chr(161) $+ $deltok($channelwordlist($2),%nb,161)
      countwords $2
      .n $nick The Word " $3- " Has Been Successfully Removed From $2 (prohibited) Word List
    }

    :end1
    .halt 
  }
}

on 1:text:!Delword*:#: {
  if ($2 == $null)  { .n $nick Error : Syntax : !DelWord <words..> | halt }
  if ($channelChan($chan) == $null) { .n $nick Error : $chan Is Not Registred At My Channels List | halt }
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  if ($lev($anicklist($nick)) < 300) { .n $nick Error : You Should Have 300 Access Level To Do This Command | halt }
  if (($lev($anicklist($nick)) < 700) && ($chan == #TuniBoT)) { .n $nick Error : You Should Have 700 Access Level To Use $1 In $chan | halt }

  else {
    set %nb  0
    set %nwords $gettok($channelwordlist($chan),0,161)
    :debut1
    inc %nb
    if (%nb > %nwords) { 
      .n $nick The Word " $2- " Is Not In $chan (prohibited) Word List Or It's Not Wrote Correctly
      goto end1
    }
    if ($gettok($channelwordlist($chan),%nb,161) != $2-) { goto debut1 }
    if ($gettok($channelwordlist($chan),%nb,161) == $2-) {
      wchans $chan wordlist $chr(161) $+ $deltok($channelwordlist($chan),%nb,161)
      countwords $chan
      .n $nick The Word " $2- " Has Been Successfully Removed From $chan (prohibited) Word List
    }
    :end1
    .halt 
  }
}
