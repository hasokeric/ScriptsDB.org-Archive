on 1:text:URL*:?: { .n $nick TuniBoT v2.0 - Made by Armed_boS - Downloaded From : http://www.CyberScripters.c.la/ | halt }
on 1:text:!URL*:#: { .n $nick TuniBoT v2.0 - Made by Armed_boS - Downloaded From : http://www.CyberScripters.c.la/ | halt }
