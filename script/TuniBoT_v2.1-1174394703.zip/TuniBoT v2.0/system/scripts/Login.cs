on *:text:Login*:?: {
  hello
  if ($3 == $null) { .n $nick Error : Syntax : /msg $me login <ident> <pass> | halt }
  else {
    if ($idnick($2) == $null) { .n $nick Error : Invalid Idnick | halt }
    else {
      if ($anicklist($nick) == $2) { .n $nick You are Already Authed | halt }
      if (($authidnick($2) != $nick) && ($authidnick($2) != $null)) { .n $nick This Idnick Is Already Identified By " $authidnick($2) " | halt }
      if ($anicklist($nick) != $null) {  .n $nick Error : You Are Already Log In With Idnick : $anicklist($nick) - You Can't Log In With 2 Idnicks | halt }
      if ($authidnick($2) == $null) {
        if ($suspend($2) == on) { .n $nick  Alert : $2 Access Is Suspended - Raison: $why($2) - Contact Ops At %Defchan | halt }
        if ($decode($pass($2),m) === $3) {
          .writeini system\database\access.ini $2 anick $nick
          .writeini system\database\anick.ini nicklist $nick $2
          .writeini system\database\nick.ini list $2 $nick
          .n $nick Password Accepted - (TuniBoT v2.0 - Made by Armed_boS) 
          .n $nick For Download : /msg $me URL
          .Invitation $nick
          halt
        }
        else { .n $nick Error : Invalid Password | halt }
      }

    }
  }
}
