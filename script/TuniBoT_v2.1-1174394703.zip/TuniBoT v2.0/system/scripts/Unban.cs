on 1:text:Unban*:?: {
  if ($3 == $null) { .n $nick Error : Syntax : /msg $me unban <#channel> <nick|hostmask> | halt }
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  elseif ($lev($anicklist($nick)) < 100) { .n $nick Error : You Should Have 100 Access Level To Do This Command | halt } 
  else {
    .mode $2 -b $3
    .halt
  }
}
on 1:text:!Unban*:#: {
  if ($2 == $null) { .n $nick Error : Syntax : !unban <nick|hostmask> | halt }
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  elseif ($lev($anicklist($nick)) < 100) { .n $nick Error : You Should Have 100 Access Level To Do This Command | halt } 
  else {
    .mode $chan -b $2
    .halt
  }
}
