;------------------------------------------------------
;   
;                    TuniBoT v2.0
;
;
; Scripter : Armed_boS / Arabeca
; 
; Official Channel : #Tunibot,#CyberScripters (on Dalnet)
;
; E-mail :     NourElhak@Gmail.com
;
; Web Site : http://www.CyberScripters.c.la/
;
; Starting Projet : 13/06/2005
;
; Finishing Projet : 7/9/2005
; 
; Last update : 20/03/2007
;
;--------------------------------------------------------


on 1:text:Awayscan*:?: {
  if (($2 == $null) || ($chr(35) !isin $2)) { .n $nick Error : Syntax : /msg $me AwayScan <#channel>  | halt }
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  if ($lev($anicklist($nick)) < 100) { .n $nick Error : You Should Have 100 Access Level To Do This Command | halt }    
  if ($channelchan($2) == $null) { .n $nick Error : $2 Is Not Registred At My Channel List | halt }
  if ($me !ison $2) { .n $nick Error : Sorry But I'm Not On That Channel | halt }
  if ($group(#awayscan) == on) { .n $nick Error : Sorry But An Other User Is Scanning For Aways | halt }
  else { 
    awayscan $2 $nick
    .halt
  }   
}


on 1:text:!Awayscan*:#:{
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  if ($lev($anicklist($nick)) < 100) { .n $nick Error : You Should Have 100 Access Level To Do This Command | halt }    
  if ($channelchan($chan) == $null) { .n $nick Error : $chan Is Not Registred At My Channel List | halt }
  if ($group(#awayscan) == on) { .n $nick Error : Sorry But An Other User Is Scanning For Aways | halt }
  else { 
    awayscan $chan $nick
    .halt
  }   
}








#awayscan off
raw 352:*:{ 
  if (G isin $7) { 
    inc %scan 1
    .n %temp.user $6 $str($chr(160),14) $3 $+ @ $+ $4
  }
}
raw 315:*:{
  .n %temp.user ...:::Scanning complete - Away Users Found = %scan :::...
  .disable #awayscan
  .unset %temp.chan
  .unset %temp.user
  halt 
}
#awayscan end
alias awayscan {
  set %temp.chan $1 
  set %temp.user $2
  set %scan 0 
  .enable #awayscan 
  .n %temp.user ...:::Scanning for away users on %temp.chan :::...
  who $1
}
