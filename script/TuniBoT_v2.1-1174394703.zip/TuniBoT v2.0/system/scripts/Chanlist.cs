on 1:text:Chanlist*:?: {
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access  To Do This Command | halt }
  if ($lev($anicklist($nick)) < 600) { .n $nick Error : You Should Have At Least 600 Access Level To Do This Command | halt }
  else { 
    .n $nick $chr(91) Channels List $chr(93)
    .set %n 0
    :debut
    .inc %n 1
    if ($ini(system\database\chans.ini,%n) == $null) { goto end }
  .n $nick 1[ 7 $ini(system\database\chans.ini,%n)  $chr(124) 1 Suspend :4 $channelsuspend($ini(system\database\chans.ini,%n))  $chr(124) 1 On Channel : $iif($me ison $ini(system\database\chans.ini,%n),3Yes,4No) 1 $chr(93) } 
  goto debut
  :end
}
on 1:text:!Chanlist*:#: {
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access  To Do This Command | halt }
  if ($lev($anicklist($nick)) < 600) { .n $nick Error : You Should Have At Least 600 Access Level To Do This Command | halt }
  else { 
    .n $nick $chr(91) Channels List $chr(93)
    .set %n 0
    :debut
    .inc %n 1
    if ($ini(system\database\chans.ini,%n) == $null) { goto end }
    .n $nick 1[ 7 $ini(system\database\chans.ini,%n)  $chr(124) 1 Suspend :4 $channelsuspend($ini(system\database\chans.ini,%n))  $chr(124) 1 On Channel : $iif($me ison $ini(system\database\chans.ini,%n),3Yes,4No) 1 $chr(93) 
    goto debut
    :end
  }
}
