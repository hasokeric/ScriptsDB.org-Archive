on 1:text:Unsuspenduser*:?: {
  if ($2 == $null) { .n $nick Error : Syntax : /msg $me UnSuspendUser <Idnick> | halt }
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  if ($lev($anicklist($nick)) < 600) { .n $nick Error : You Should Have 600 Access Level To Do This Command | halt }    
  if ($idnick($2) == $null) { .n $nick Error : $2 Is Not Registred At My User List | halt }
  if ($suspend($2) == off) { .n $nick Error : $2 Access Isn't Suspended | halt }
  if ($lev($anicklist($nick)) < $lev($2)) { .n $nick Error : You Can't UnSuspend User With A Heighter Level Then You | halt }
  if ($lev($anicklist($nick)) == $lev($2)) { .n $nick Error : You Can't UnSuspend User With The Same Level As You | halt }

  else { 
    .writeini system\database\access.ini $2 suspend off
    .remini system\database\access.ini $2 why 
    .n $nick $2 Access Has Been Successfully UnSuspended
    .halt
  }

}

on 1:text:!Unsuspenduser*:#: {
  if ($2 == $null) { .n $nick Error : Syntax : !UnSuspend <Idnick> | halt }
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  if ($lev($anicklist($nick)) < 600) { .n $nick Error : You Should Have 600 Access Level To Do This Command | halt }    
  if ($idnick($2) == $null) { .n $nick Error : $2 Is Not Registred At My User List | halt }
  if ($suspend($2) == off) { .n $nick Error : $2 Access Isn't Suspended | halt }
  if ($lev($anicklist($nick)) < $lev($2)) { .n $nick Error : You Can't UnSuspend User With A Heighter Level Then You | halt }
  if ($lev($anicklist($nick)) == $lev($2)) { .n $nick Error : You Can't UnSuspend User With The Same Level As You | halt }
  else { 
    .writeini system\database\access.ini $2 suspend off
    .remini system\database\access.ini $2 why 
    .n $nick $2 Access Has Been Successfully UnSuspended
    .halt
  }

}
