on 1:text:Wordlist*:?: {
  if (($2 == $null) || ($chr(35) !isin $2)) { .n $nick Error : Syntax : /msg $me WordList <#channel> | halt }
  if ($channelChan($2) == $null) { .n $nick Error : $2 Is Not Registred At My Channels List | halt }
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  if ($lev($anicklist($nick)) < 300) { .n $nick Error : You Should Have 300 Access Level To Do This Command | halt }
  if (($lev($anicklist($nick)) < 700) && ($2 == #TuniBoT)) { .n $nick Error : You Should Have 700 Access Level To Use $1 In $2 | halt }

  else {
    if ($channelwordlist($2) == $null) {
      .n $nick Words List Of $2 Is Empty
    }
    else {
      .n $nick This Is The List Of (prohibitted) Words Of $2 , Separated With $chr(161)
      .n $nick $channelwordlist($2) 
    }
    .halt 
  }
}

on 1:text::!Wordlist*:#: {
  if ($channelChan($chan) == $null) { .n $nick Error : $chan Is Not Registred At My Channels List | halt }
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access To Do This Command | halt }
  if ($lev($anicklist($nick)) < 300) { .n $nick Error : You Should Have 300 Access Level To Do This Command | halt }
  if (($lev($anicklist($nick)) < 700) && ($chan == #TuniBoT)) { .n $nick Error : You Should Have 700 Access Level To Use $1 In $chan | halt }

  else {
    if ($channelwordlist($chan) == $null) {
      .n $nick Words List Of $chan Is Empty
    }
    else {
      .n $nick This Is The List Of (prohibitted) Words Of $chan , Separated With $chr(161)
      .n $nick $channelwordlist($chan) 
    }
    .halt 
  }
}



;Words Filtre
;----->
alias countwords {
  set %nw  0
  :debut
  inc %nw
  if ($gettok($channelwordlist($1),%nw,161) != $null) { goto debut }
  else { set %nwords $calc(%nw -1) } 
  :end
}
