alias wchans { .writeini system\database\chans.ini $1- }
alias addchan { 
  .wchans $1 chan $1
  .wchans $1 deftopic Welcome To $1 - For Love use : !LoveMeter
  .wchans $1 welcome Welcome $ $+ nick  To $1 - For Love use : !LoveMeter
  .wchans $1 strictop off
  .wchans $1 defmodes +nt
  .wchans $1 setwelcome ON
  .wchans $1 suspend OFF
  .wchans $1 autovoice ON
  .wchans $1 bantimeout 0
  .wchans $1 antipub off
  .wchans $1 antiwords off
  .wchans $1 autolimit off
  .inc %chans 1
}
on 1:text:AddChan*:?: {
  if (($2 == $null) || ($chr(35) !isin $2)) { .n $nick Error : Syntax : /msg $me AddChan <#channel> | halt }
  else {
    if ($anicklist($nick) == $null) { .n $nick Error : Access Refused / You Should Auth First | halt }
    if (700 > $lev($anicklist($nick))) { .n $nick Error : Your Access Level Sould Be 700 At Least To Do This Command ! | halt }
    if ($channelChan($2) != $null) { .n $nick Error : This Channel Is Already Registred At My Chanlist | halt }
    else {
      if (%chans >= 20) { .n $nick Error : I Can't Join More Than 20 Channels | halt }
      addchan $2
      .n $nick $2 Has Been Successfully Registred
      .join $2
      .halt
    }
  }
}
