on 1:text:Alist*:?: {
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access  To Do This Command | halt }
  if ($lev($anicklist($nick)) < 100) { .n $nick Error : You Should Have At Least 100 Access Level To Do This Command | halt }
  else { 
    .n $nick $chr(91) Authed Users List $chr(93)
    .set %n 0
    :debut
    .inc %n 1
    if ($ini(system\database\anick.ini,nicklist,%n) == $null) { goto end }
    if ($ini(system\database\anick.ini,nicklist,%n) != $null) { .n $nick 1[ 3 $ini(system\database\nick.ini,list,%n)  $chr(124) 4 $lev($ini(system\database\nick.ini,list,%n))  $chr(124) 12 $authidnick($ini(system\database\nick.ini,list,%n)) 1 $chr(93) }
    goto debut
    :end
    .n $nick $chr(91) $calc(%n - 1) User(s) Found $chr(93)
    .halt
  }
}




on 1:text:!Alist*:#: {
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access  To Do This Command | halt }
  if ($lev($anicklist($nick)) < 100) { .n $nick Error : You Should Have At Least 100 Access Level To Do This Command | halt }
  else { 
    .n $nick $chr(91) Authed Users List $chr(93)
    .set %n 0
    :debut
    .inc %n 1
    if ($ini(system\database\anick.ini,nicklist,%n) == $null) { goto end }
    if ($ini(system\database\anick.ini,nicklist,%n) != $null) { .n $nick 1[ 3 $ini(system\database\nick.ini,list,%n)  $chr(124) 4 $lev($ini(system\database\nick.ini,list,%n))  $chr(124) 12 $authidnick($ini(system\database\nick.ini,list,%n)) 1 $chr(93) }
    goto debut
    :end
    .n $nick $chr(91) $calc(%n - 1) User(s) Found $chr(93)
    .halt
  }
}
