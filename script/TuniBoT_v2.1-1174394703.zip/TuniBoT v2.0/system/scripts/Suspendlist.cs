on 1:text:Suspendlist*:#: {
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access  To Do This Command | halt }
  if ($lev($anicklist($nick)) < 600) { .n $nick Error : You Should Have At Least 600 Access Level To Do This Command | halt }
  else { 
    .n $nick $chr(91) Suspended Users List $chr(93)
    .set %n 0
    :debut
    .inc %n 1
    if ($ini(system\database\access.ini,%n) == $null) { goto end }
    if ($suspend($ini(system\database\access.ini,%n)) == on) { .n $nick 1[ 7 $ini(system\database\access.ini,%n)  $chr(124) 4 $lev($ini(system\database\access.ini,%n))  $chr(124) 12 Raison: $why($ini(system\database\access.ini,%n)) 1 $chr(93) }
    goto debut
    :end
  }
}

on 1:text:!Suspendlist*:#: {
  if ($lev($anicklist($nick)) == $null) { .n $nick Error : You Should Have Access  To Do This Command | halt }
  if ($lev($anicklist($nick)) < 600) { .n $nick Error : You Should Have At Least 600 Access Level To Do This Command | halt }
  else { 
    .n $nick $chr(91) Suspended Users List $chr(93)
    .set %n 0
    :debut
    .inc %n 1
    if ($ini(system\database\access.ini,%n) == $null) { goto end }
    if ($suspend($ini(system\database\access.ini,%n)) == on) { .n $nick 1[ 7 $ini(system\database\access.ini,%n)  $chr(124) 4 $lev($ini(system\database\access.ini,%n))  $chr(124) 12 Raison: $why($ini(system\database\access.ini,%n)) 1 $chr(93) }
    goto debut
    :end
  }
}
