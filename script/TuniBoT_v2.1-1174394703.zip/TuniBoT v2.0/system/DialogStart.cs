;-----------------------------------------------
;------------- Dialog Demarrage ----------------
;-----------------------------------------------

dialog start {
  title $showtxt(start,1)
  size -1 -1 200 120
  option dbu
  box "",1,5 5 190 105
  button "",1000,1000 1000 0 0,cancel,hide
  text "" ,2,10 20 100 10
  edit %botnick ,3,105 18 80 10 
  text "" ,4,10 33 100 10
  edit $botpass ,5,105 31 80 10,pass
  text "" ,6,10 47 100 10
  edit %server ,7,105 45 80 10,
  text "" ,8,10 60 100 10
  edit %port ,9,105 58 20 10,
  text "",15,10 112 190 10 
  button "",10,10 75 40 12,
  button "",11,55 75 40 12,
  button "",12,105 75 40 12,
  button "",13,150 75 40 12,
  button "",14,10 95 180 12,
  icon system\graphics\icon.ico , 0

}
;MDX

on *:dialog:start:init:*: {
  Tupdate.mdx SetMircVersion $version
  Tupdate.mdx MarkDialog $dname
  Tupdate.mdx SetDialog $dname bgcolor $rgb(255,255,255)
  ;Txtbg
  Tupdate.mdx SetColor $dname 1 textbg $rgb(255,255,255)
  Tupdate.mdx SetColor $dname 2 textbg $rgb(255,255,255)
  Tupdate.mdx SetColor $dname 3 textbg $rgb(255,255,255)
  Tupdate.mdx SetColor $dname 4 textbg $rgb(255,255,255)
  Tupdate.mdx SetColor $dname 5 textbg $rgb(255,255,255)
  Tupdate.mdx SetColor $dname 6 textbg $rgb(255,255,255)
  Tupdate.mdx SetColor $dname 7 textbg $rgb(255,255,255)
  Tupdate.mdx SetColor $dname 8 textbg $rgb(255,255,255)
  Tupdate.mdx SetColor $dname 9 textbg $rgb(255,255,255)
  Tupdate.mdx SetColor $dname 15 textbg $rgb(255,255,255)

  ;Txtbg
  Tupdate.mdx SetColor $dname 1 background $rgb(255,255,255)
  Tupdate.mdx SetColor $dname 2 background $rgb(255,255,255)
  Tupdate.mdx SetColor $dname 3 background $rgb(255,255,255)
  Tupdate.mdx SetColor $dname 4 background $rgb(255,255,255)
  Tupdate.mdx SetColor $dname 5 background $rgb(255,255,255)
  Tupdate.mdx SetColor $dname 6 background $rgb(255,255,255)
  Tupdate.mdx SetColor $dname 7 background $rgb(255,255,255)
  Tupdate.mdx SetColor $dname 8 background $rgb(255,255,255)
  Tupdate.mdx SetColor $dname 9 background $rgb(255,255,255)
  Tupdate.mdx SetColor $dname 15 background $rgb(255,255,255)



  Tupdate.mdx SetColor $dname 1 text $rgb(255,0,0)
  Tupdate.mdx SetFont $dname 1 +a 20 900 Comic sans ms
  Tupdate.mdx SetFont $dname 2  12 600 Arial
  Tupdate.mdx SetFont $dname 3  12 500 Arial
  Tupdate.mdx SetFont $dname 4  12 600 Arial
  Tupdate.mdx SetFont $dname 5  12 500 Arial
  Tupdate.mdx SetFont $dname 6  12 600 Arial
  Tupdate.mdx SetFont $dname 7  12 500 Arial
  Tupdate.mdx SetFont $dname 8  12 600 Arial
  Tupdate.mdx SetFont $dname 9  12 500 Arial

  did -a start 1 $showtxt(start,2)
  did -a start 2 $showtxt(start,3)
  did -a start 4 $showtxt(start,4)
  did -a start 6 $showtxt(start,5)
  did -a start 8 $showtxt(start,6)
  did -a start 10 $showtxt(start,7)
  did -a start 11 $showtxt(start,8)
  did -a start 12 $showtxt(start,9)
  did -a start 13 $showtxt(start,10)
  did -a start 14 $showtxt(start,11)
  did -a start 15 $showtxt(start,12)



}
;fin MDX
on 1:dialog:start:sclick:10: {
  if ($did(3) == $null) { .did -a start 15 $showtxt(start,13) | .timer 1 2 /resetdialog | halt }
  if (%space isin $did(3)) { .did -a start 15 $showtxt(start,14) | .timer 1 2 /resetdialog | halt }
  if ($did(5) == $null) { .did -a start 15 $showtxt(start,15) | .timer 1 2 /resetdialog | halt }
  if (%space isin $did(5)) { .did -a start 15 $showtxt(start,16) | .timer 1 2 /resetdialog | halt }
  if ($did(7) == $null) { .did -a start 15 $showtxt(start,17) | .timer 1 2 /resetdialog | halt }
  if (%space isin $did(7)) { .did -a start 15 $showtxt(start,18) | .timer 1 2 /resetdialog | halt }
  if ($did(9) == $null) { .did -a start 15 $showtxt(start,19) | .timer 1 2 /resetdialog | halt }
  if ($did(9) !isnum) { .did -a start 15 $showtxt(start,20) | .timer 1 2 /resetdialog | halt }
  if (%space isin $did(9)) { .did -a start 15 $showtxt(start,21) | .timer 1 2 /resetdialog | halt }
  .set %botnick $did(3)
  .set %botpass $encode($encode($did(5),m),m)
  .set %server $did(7)
  .set %port $did(9)
  .did -a start 15 $showtxt(start,22)
  .timer 1 2 /resetdialog
  .halt
}
alias resetdialog {
  if ($dialog(start).title != $null) { .did -a start 15 $showtxt(start,12) }
}
on 1:dialog:start:sclick:13: {
  if ($server == $null) {   .Username 4...:::: TuniBoT ::::...- By: 4Armed_boS  | .server %server %port }
  dialog -x start 
}
on 1:dialog:start:sclick:14: {
  tupdate
}
on 1:dialog:start:sclick:11: {
  .set %temp1 $$?="Admin Nick:"
  if (%temp1 == $null) { halt }
  if (%space isin %temp1)  { .echo -a 4[Error]7 Spaces Are Not Allowed In Idnick !  | unset %temp1 | halt }
  if ($idnick(%temp1) != $null) { .echo -a 4[Error]7 This Idnick is Already Saved At My Users List With Level $lev(%temp1)  | unset %temp1 | halt }
  .set %temp2 $$?="Admin Pass:"
  if (%temp2 == $null) { halt }
  if (%space isin %temp2)  { .echo -a 4[Error]7 Spaces Are Not Allowed In Passwords !  | unset %temp2 | halt }
  .writeini system\database\access.ini %temp1 idnick %temp1
  .writeini system\database\access.ini %temp1 level 1000
  .writeini system\database\access.ini %temp1 pass $encode(%temp2,m)
  .writeini system\database\access.ini %temp1 suspend OFF
  .echo -a 3[New Admin]10 %temp1 Has Been Successfully Added As Admin (Level:1000) ! 
  .unset %temp1
  .unset %temp2
  .halt
}
on 1:dialog:start:sclick:12: {
  set %temp1 $$?="Admin Nick:"
  if (%temp1 == $null) { halt }
  if (%space isin %temp1)  { .echo -a 4[Error]7 Spaces Are Not Allowed In Idnick !  | unset %temp1 | halt }
  if ($idnick(%temp1) == $null) { .echo -a 4[Error]7 This Idnick Is Not Saved At My Users List | unset %temp1 | halt }
  if ($lev(%temp1) < 1000) { .echo -a 4[Error]7 This Idnick Is Not Admin - %temp1 Level : $lev(%temp1) | unset %temp1 | halt }
  .remini system\database\access.ini %temp1
  .echo -a 3[Del Admin]10 %temp1 Has Been Successfully Removed From Admin List ! 
  .unset %temp1
  .halt
}
