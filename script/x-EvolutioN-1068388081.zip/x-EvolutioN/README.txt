Changes :


  1.5
 -----

-ajout� l'aide des modules dans le control panel
-ajout� ini viewer
-ajout� iconset x-evolution
-ajout� choix du iconset dans la setup
-ajout� Fkey Configuration
-modifi� l icone dans about
-fix� bug au start (si mIRC �tait minimiz� la toolbar fonctionnait pas)
-fix� bug dans la firewall
-fix� bug dans la setup (others / sidebar)
-fix� bug dans la setup (toolbar editor) (trouv� par Juwau)
-fix� bug dans la sidebar (avec add-ons) (trouv� par Juwau)

  1.4.2
 -------

-supprim� fichier inutiles
-optimisation des codes
-ajout� add-ons a la sidebar (ATTENTION A LA TAILLE DE MIRC !!!)
-ajout� possibilit� de g�rer la sidebar (dans la conf)
-ajout� quit et setup au bouton "start"
-chang� calculatrice "hex / dec" en "hex / dec / bin"
-fix� bug dans l away (dans la liste des nick d away ki ne se supprimaient pas si il avait un nick)
-fix� bug dans le control panel
-fix� bug dans la Config du script
-fix� bug dans le mp3 player
-supprim� module : P�re~No�l 2003
-supprim� les logs :p



  1.4.1
 -------

-ajout� Start Button
-ajout� aide au control panel
-ajout� config du premier d�marrage
-ajout� News
-ajout� aide modules (dans le cpanel /_cpanel)
-chang� de pack d icones
-fix� control panel (les modules ne souvraient pas)



   1.4
  -----

-ajout du module p�re-noel
-ajout d une calculatrice hexad�cimale / d�cimale
-fix� le probl�me de la sidebar (ne ce loadait pas)
-fix� la lagbar (changement de celle de xhaker)
-fix� le mp3 player (suppression d un seul mp3)
-fix� le bug de la cr�ation de fichiers vides (d� au away)
-fix� le bug de l away qui ne s ouvrait pas (les fichiers images non trouv�s)
-am�lioration des popups
-Changement de quelques icones
-compatibilit� avec mIRC 6.12