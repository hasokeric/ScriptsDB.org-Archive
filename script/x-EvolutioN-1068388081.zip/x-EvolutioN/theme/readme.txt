##### XTS Theme Engin			XTS Theme Loader
##### Version 0.11			Version 1
##### ClickHeRe				MonarK
##### mIRC 6.01+			
##### XTS Version 1.1 (draft 8.2)

Cet addon permets d'int�grer des th�mes du format XTS � l'interface de votre mIRC
� l'aide de cet engin qui �mule un engin de lecture des th�mes et en porte l'affichage correspondant selon
les �v�nements se d�roulant sur mIRC.

L'auteur n'est aucunement responsable pour les th�mes que vous utilisez avec cet addon. Les th�mes t�l�charg�s
doivent �tre compatibles avec la norme 1.1 du standard XTS pour fonctionner correctement avec l'engin (l'engin v�rifie
une partie des informations, mais il peut toujours y avoir des cas d'exception).

##################################################################################################
# ATTENTION LORSQUE VOUS CHARGEZ UN THEME XTS VOUS PERDEZ VOS CONFIGURATIONS DE COULEURS DE MIRC #
##################################################################################################

Pour loader l'addon, il suffit de le d�zipper dans le r�pertoire o� est situ� votre mIRC. Ensuite il suffit de
tapper la commande suivante dans le bas d'un fen�tre dans mIRC:

/load -rs theme/xts-loader.mrc

L'interface principale de l'engin s'affichera vous permettant de s�lectionner un th�me de la banque d�j� pr�sente.
Vous pourrez aussi changer les diff�rentes options d'affichage des th�mes. Il y a aussi un menu de diponible pour ouvrir/fermer
le syst�me de th�mes et aussi acc�der � l'aide ou la configuration de l'interface.

Pour de l'aide ou des informations sur comment faire pour t�l�charger plus de th�mes et les installer, veuillez
vous r�f�rer � l'aide inclut dans l'addon.
