
 	* Outpost Theme 2.2 *
 
 Author:
	Zyberdog <zyberdog@quakenet.org>

 Description:
	Theme borrowed some whois stuff from 'Winter' theme by greeny, also using alignment system from 'Negative Entropy' by Darksaidin, both tweaked.
	Optimized for use with NNscript and/or QuakeNet/Undernet.

 Changelog:
   v2.2 (19/12/2003)
	+ Added support for notices from -psyBNC (More noticeable)
	* Changed highlighting to only color the word, and not the whole line. (only with actions)
	* Fixed bug where topics would be a weird color.
	* Fixed bug in scheme 10 (xemacs (aligned)) where channel text weren't themed.
   v2.1 (08/12/2003)
	- First public release.