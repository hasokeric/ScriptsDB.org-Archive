G-IRCD1.1:

To start G-IRCD, type /start in mIRC's window.
Be sure you have configured g-ircd.g and rehash.g

If you discover a bug, please make me aware about this one -> See Bug Report
section in http://www.G-NERATION.com/G-IRCD/

Thank you for using G-IRCD