Corpse Script Version 2.52
Copyright (C) 2002-2004 CorpseWeb.Tk, Inc.
All Rights Reserved

1. About
   Corpse Script was made using Windows XP, under mIRC v6.16.

2. Requirements
   1 - mIRC v6.16 and any version of Windows.
   2 - WinZIP or any other compressing program.

3. Attention
   1 - This script does NOT contain any trojans or virus.
   2 - I won't be responsible for anything wrong related with this mIRC script! Use it at your own risk.
   3 - For bug reports, please email me at bugs@corpseweb.Tk

4. Installation
   1 - Extract all files wherever you like, always checking that the script has its own directory (example: C:\program files\corpse script).
   2 - Make sure you have mIRC v6.16, if not you can download it from www.mirc.com
   3 - Copy mirc.exe to the script's folder and...
   4 - Run it :)

5. Contact
   You can always contact me at admin@corpseweb.tk about several topics:
   1 - Help with the script.
   2 - Report a bug in the script.
   3 - Suggest what i should add/improve/remove.
   4 - Don't ask for latest versions when you can always check yourself at www.corpseweb.tk