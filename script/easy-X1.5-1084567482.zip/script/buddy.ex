alias buddy {
if (!%buddy.dock) dialog $iif($dialog(buddy),-v,-m) buddy buddy
else dialog $iif($dialog(buddyd),-v,-m) buddyd buddyd
scid $activecid
buddy.refresh
}

alias buddy.undock {
dialog -x buddyd
set %buddy.dock 0
dialog -m buddy buddy
}

alias buddy.side {
if ($1 == 1) return $iif(%buddy.dockside == gauche,0,2)
elseif ($1 == 4) return $iif(%buddy.dockside == gauche,0,2)
elseif ($1 == 5) return $iif(%buddy.dockside == gauche,2,4)
}

alias buddy.dock {
dialog -c buddy
set %buddy.dock 1
buddy
buddy.resize
}

dialog buddyd {
title "Buddylist"
size -1 -1 142 333
option pixels
list 1, $buddy.side(1) 0 140 281, size
button "pos", 1000, -10 -10 1 1, hide
list 5, $buddy.side(5) 286 138 20, size
box "", 4, $buddy.side(4) 278 140 32
}

dialog buddy {
title "Buddylist"
size $iif(%buddy.x != $null,%buddy.x,-1) $iif(%buddy.y != $null,%buddy.y,-1) 144 $iif(%buddy.h,$calc(%buddy.h - 7),264)
icon $taskbar
option pixels
list 1, 1 2 142 280, size
button "pos", 1000, -10 -10 1 1, hide
list 5, 4 286 138 20, size
box "", 4, 1 278 142 32
}

on *:dialog:buddy:init:*:{
dll script/mdx/mdx.dll SetMircVersion $version
dll script/mdx/mdx.dll MarkDialog buddy
dll script/mdx/mdx.dll SetControlMDX 1 treeview haslines hasbuttons showsel > script\mdx\views.mdx
dll script/mdx/mdx.dll SetControlMDX 1000 Positioner size mini > script\mdx\dialog.mdx
dll script/mdx/mdx.dll SetControlMDX 5 ToolBar flat list nodivider arrows > script\mdx\bars.mdx
dll script/mdx/mdx.dll SetBorderStyle 1 staticedge
dll script/mdx/mdx.dll SetBorderStyle 5
did -i buddy 5 1 bmpsize 16 16
did -i buddy 5 1 pad 14 6
did -i buddy 5 1 setimage +nhd 0 icon small 1,script/icone/panel.icl
did -i buddy 5 1 setimage +nhd 0 icon small 2,script/icone/panel.icl
did -i buddy 5 1 setimage +nhd 0 icon small 10,script/icone/panel.icl
did -i buddy 5 1 setimage +nhd 0 icon small 11,script/icone/panel.icl
did -a buddy 5 +a 1 	Ajouter
did -a buddy 5 +a 2 	Supprimer
did -a buddy 5 +a 3 	Changer de fen�tre
did -a buddy 5 +a 4 	Fermer
did -i buddy 1 1 iconsize normal small
did -i buddy 1 1 seticon normal 8,script/icone/panel.icl 
did -i buddy 1 1 seticon normal 9,script/icone/panel.icl 
did -i buddy 1 1 setcolor bkg %couleur.buddyfond
did -i buddy 1 1 setcolor line %couleur.buddytexte
did -i buddy 1 1 setcolor text %couleur.buddytexte

var %h = $dialog(buddy).h
did -a buddy 1000 setsize 152 *
dll script/mdx/mdx.dll MoveControl buddy 1 * * * $calc(%h - 59)
dll script/mdx/mdx.dll MoveControl buddy 4 * $calc(%h - 60) * *
dll script/mdx/mdx.dll MoveControl buddy 5 * $calc(%h - 52) * *
buddy.refresh
}

on *:dialog:buddyd:init:*:{
dll script/dll/rebar.dll Dock $dialog(buddyd).hwnd > $iif(%buddy.dockside == droite,right,left)
dll script/mdx/mdx.dll SetMircVersion $version
dll script/mdx/mdx.dll MarkDialog buddyd
dll script/mdx/mdx.dll SetControlMDX 1 treeview haslines hasbuttons showsel > script\mdx\views.mdx
dll script/mdx/mdx.dll SetControlMDX 1000 Positioner > script\mdx\dialog.mdx
dll script/mdx/mdx.dll SetControlMDX 5 ToolBar flat list nodivider arrows > script\mdx\bars.mdx
dll script/mdx/mdx.dll SetBorderStyle 1 staticedge
dll script/mdx/mdx.dll SetBorderStyle 5
did -i buddyd 5 1 bmpsize 16 16
did -i buddyd 5 1 pad 14 6
did -i buddyd 5 1 setimage +nhd 0 icon small 1,script/icone/panel.icl
did -i buddyd 5 1 setimage +nhd 0 icon small 2,script/icone/panel.icl
did -i buddyd 5 1 setimage +nhd 0 icon small 10,script/icone/panel.icl
did -i buddyd 5 1 setimage +nhd 0 icon small 11,script/icone/panel.icl
did -a buddyd 5 +a 1 	Ajouter
did -a buddyd 5 +a 2 	Supprimer
did -a buddyd 5 +a 3 	Changer de fen�tre
did -a buddyd 5 +a 4 	Fermer
did -i buddyd 1 1 iconsize normal small
did -i buddyd 1 1 seticon normal 8,script/icone/panel.icl 
did -i buddyd 1 1 seticon normal 9,script/icone/panel.icl 
did -i buddyd 1 1 setcolor bkg %couleur.buddyfond
did -i buddyd 1 1 setcolor line %couleur.buddytexte
did -i buddyd 1 1 setcolor text %couleur.buddytexte

buddy.refresh
buddy.resize
}

on *:dialog:buddy:close:*:{
set %buddy.h $calc($dialog(buddy).h - 20)
set %buddy.x $dialog(buddy).x
set %buddy.y $dialog(buddy).y
}

on *:dialog:buddy*:sclick:5:{
if ($did($dname,5).sel == 2) buddy.add
elseif ($did($dname,5).sel == 3) buddy.del $dname
elseif ($did($dname,5).sel == 4) {
if ($dname == buddyd) buddy.undock
else buddy.dock
}
else {
if ($dname == buddyd) { dll script/dll/rebar.dll UnDock $iif(%buddy.dockside == droite,right,left) | dialog -x buddyd | showmirc -s }
else dialog -c buddy

}
}

on *:dialog:buddy*:sclick:1000:buddy.resize

alias buddy.resize {
if ($dialog(buddy)) && ($gettok($did(buddy,1000),1,32) == sizing) {
var %h = $gettok($did(buddy,1000),6,32)
did -a buddy 1000 setsize 152 *
dll script/mdx/mdx.dll MoveControl buddy 1 * * * $calc(%h - 59)
dll script/mdx/mdx.dll MoveControl buddy 4 * $calc(%h - 60) * *
dll script/mdx/mdx.dll MoveControl buddy 5 * $calc(%h - 52) * *
}
elseif ($dialog(buddyd)) {
var %h = $dialog(buddyd).h
dll script/mdx/mdx.dll MoveControl buddyd 1 * * * $calc(%h - 28)
dll script/mdx/mdx.dll MoveControl buddyd 5 * $calc(%h - 24) * *
dll script/mdx/mdx.dll MoveControl buddyd 4 * $calc(%h - 32) * *
did -h buddyd 4,1
did -v buddyd 4,1
}

elseif ($dialog(buddy)) && ($gettok($did(buddy,1000),1,32) == exitsizemove) {
did -h buddy 4,1
did -v buddy 4,1
}
}

on *:dialog:buddy*:sclick:1:{
scid $activecid
if (($gettok($did($buddy.win,1,1),1,32) == rclick) && ($gettok($did($buddy.win,1,1),3,32) == 2) && ($gettok($did($buddy.win,1,1),4,32))) var %a = $dll(script/dll/popread.dll,popread,script/bdd/menu.tbl?42?45? $+ $mouse.dx $+ ? $+ $mouse.dy)
}

alias buddy.list {
var %n = $calc($2 - 1)
var %a = 1
while (%a <= $notify(0)) {
if ($notify(%a).ison) var %liste.on = $addtok(%liste.on,$notify(%a),32)
inc %a
}
var %a = 1
while (%a <= $notify(0)) {
if (!$notify(%a).ison) var %liste.off = $addtok(%liste.off,$notify(%a),32)
inc %a
}
if ($1 == 2) return $gettok(%liste.on,%n,32)
if ($1 == 3) return $gettok(%liste.off,%n,32)
}


alias buddy.refresh {
scid $activecid
unset %dname
if ($dialog(buddy)) var %dname = buddy
if ($dialog(buddyd)) var %dname = buddyd
if (!%dname) halt

did -r %dname 1
did -i %dname 1 1 cb root
did -a %dname 1 +e 1 1 Online
did -i %dname 1 1 cb last

var %a = 1
while (%a <= $notify(0)) {
if ($notify(%a).ison) did -a %dname 1 1 1 0 0 0 $notify(%a)
inc %a
}

did -i %dname 1 1 cb up
did -a %dname 1 +e 2 2 Offline
did -i %dname 1 1 cb last

var %a = 1
while (%a <= $notify(0)) {
if (!$notify(%a).ison) did -a %dname 1 2 2 0 0 0 $notify(%a)
inc %a
}

}

on ^&*:notify:{
haltdef
scid $activecid
buddy.refresh
}

on ^&*:unotify:{
haltdef
scid $activecid
buddy.refresh
}

on *:dialog:buddy*:sclick:2:buddy.add

alias buddy.add {
var %nick = $iif($1,$1,$$?="Pseudo")
if (!%nick) halt
.notify %nick
buddy
scid $activecid
buddy.refresh
}

on *:dialog:buddy:sclick:3:buddy.del

alias buddy.del {
var %nick = $treeview($1,1)
if (%nick) .notify -r %nick
scid $activecid
buddy.refresh
}

alias buddy.win {
if ($dialog(buddy)) var %dname = buddy
if ($dialog(buddyd)) var %dname = buddyd
return %dname
}

alias treeview {
var %d = $1,%i = $2
if ($dialog(%d)) {
var %b = $gettok($did(%d,%i,1),4-,32), %n = $calc($numtok(%b,32) -1)
if (%n = 0) did -i %d %i 1 cb root
else did -i %d %i 1 cb root $gettok(%b,1- $+ %n,32)
return $gettok($gettok($did(%d,%i,$gettok(%b,-1,32)),7-,32),1,9)
}
}

alias treeview.rclick {
var %d = $1,%i = $2
if ($dialog(%d)) {
var %b = $gettok($did(%d,%i,1),3-,32), %n = $calc($numtok(%b,32) -1)
if (%n = 0) did -i %d %i 1 cb root
else did -i %d %i 1 cb root $gettok(%b,1- $+ %n,32)
return $gettok($gettok($did(%d,%i,$gettok(%b,-1,32)),7-,32),1,9)
}
}