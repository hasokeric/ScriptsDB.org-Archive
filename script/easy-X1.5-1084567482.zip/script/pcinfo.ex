alias pcinfo dialog $iif($dialog(pcinfo),-v,-m) pcinfo pcinfo

alias tailledisk {
if ($1 >= 1000000000) return $round($calc($1 / 1000000000),2) $+ Go
elseif ($1 >= 1000000) return $round($calc($1 / 1000000),0) $+ Mo
}

alias ifdisk {
if ($disk($1).type = fixed) {
var %disk = $tailledisk($disk($1).size) $+ , $tailledisk($disk($1).free) libre ( $+ $round($calc($disk($1).free / $disk($1).size * 100),1) $+ % $+ )
return $replace(%info,<nom>,$1,<info>,%disk)
}
}

dialog pcinfo {
title "PC infos"
size -1 -1 285 172
icon $taskbar
option pixels
tab "CPU", 1, 4 4 276 140
edit "", 8, 89 35 182 21, tab 1 autohs
text "Nom :", 13, 53 37 30 16, tab 1
text "Vitesse :", 14, 40 62 42 16, tab 1
edit "", 9, 89 60 182 21, tab 1
edit "", 10, 89 85 182 21, tab 1
text "Cache :", 15, 44 87 38 16, tab 1
text "Charge :", 16, 39 112 44 16, tab 1
edit "", 11, 89 110 182 21, tab 1
button "Dire", 101, 110 147 49 21, tab 1
tab "RAM", 2
text "Memoire utilis�e :", 17, 31 83 92 15, tab 2
edit "", 18, 29 98 176 21, tab 2
edit "", 20, 29 58 176 21, tab 2
text "Memoire totale :", 19, 31 43 78 15, tab 2
button "Dire", 102, 110 147 49 21, tab 2
tab "OS", 3
text "Nom :", 22, 53 37 30 16, tab 3
edit "", 23, 85 35 186 21, tab 3 autohs
edit "", 24, 85 60 186 21, tab 3
text "Version :", 25, 39 62 44 16, tab 3
text "Build :", 26, 52 87 30 16, tab 3
edit "", 27, 85 85 186 21, tab 3
text "Uptime :", 30, 41 112 44 16, tab 3
edit "", 31, 85 110 186 21, tab 3 autohs
button "Dire", 103, 110 147 49 21, tab 3
tab "GFX", 4
edit "", 39, 111 110 160 21, tab 4
text "Couleurs :", 38, 54 87 54 16, tab 4
text "Rafraichissement :", 36, 14 112 90 16, tab 4
edit "", 37, 111 85 160 21, tab 4
edit "", 35, 111 60 160 21, tab 4
text "R�solution :", 34, 46 62 60 16, tab 4
edit "", 33, 111 35 160 21, tab 4 autohs
text "Carte graphique :", 32, 18 37 88 16, tab 4
button "Dire", 104, 110 147 49 21, tab 4
tab "HD", 5
list 40, 13 35 258 97, tab 5 size
button "Dire", 105, 110 147 49 21, tab 5
tab "NET", 6
text "Depuis :", 54, 42 112 44 16, tab 6
text "Upload :", 51, 41 87 40 16, tab 6
text "Download :", 50, 27 62 56 16, tab 6
text "Connexion :", 46, 23 37 64 16, tab 6
edit "", 45, 89 35 182 21, tab 6 autohs
edit "", 49, 89 60 182 21, tab 6
edit "", 52, 89 85 182 21, tab 6
edit "", 53, 89 110 182 21, tab 6
button "Dire", 106, 110 147 49 21, tab 6
button "Dire tous", 43, 159 147 63 21
button "Fermer", 44, 222 147 59 21, ok
}

on *:dialog:pcinfo:init:*:{
dll script/mdx/mdx.dll SetMircVersion $version 
dll script/mdx/mdx.dll MarkDialog pcinfo
dll script/mdx/mdx.dll SetControlMDX 40 listview infotip report single rowselect nosortheader > script/mdx/views.mdx
did -i pcinfo 40 1 headerdims 74 57 57 49
did -i pcinfo 40 1 headertext Lecteur $+ $chr(9) $+ Taille $+ $chr(9) $+ Libre $+ $chr(9) $+ $chr(37) $+ Libre
var %cpu = $dll(script/dll/moo.dll,cpuinfo,_)
var %ram = $dll(script/dll/moo.dll,meminfo,_)
var %os = $dll(script/dll/moo.dll,osinfo,_)
var %gfx = $dll(script/dll/moo.dll,gfxinfo,_)
var %screen = $dll(script/dll/moo.dll,screeninfo,_)
var %net = $dll(script/dll/moo.dll,connection,_)

did -a pcinfo 8 $$right($gettok(%cpu,1,44),-2)
did -a pcinfo 9 $$gettok(%cpu,2,44)
did -a pcinfo 10 $$gettok($gettok(%cpu,3,44),1,32)
did -a pcinfo 11 $$left($right($gettok($gettok(%cpu,3,44),2-,32),-1),-1)

did -a pcinfo 20 $$replace($gettok($gettok(%ram,2,32),2,47),MB,Mo)
did -a pcinfo 18 $$gettok($gettok(%ram,2,32),1,47) $+ Mo $gettok(%ram,3,32)

did -a pcinfo 23 $$gettok(%os,1,40)
did -a pcinfo 24 $$gettok($gettok(%os,2,40),1,32)
did -a pcinfo 27 $$left($gettok($gettok(%os,2,40),3,32),-1)
did -a pcinfo 31 $$uptime(system,1)

did -a pcinfo 33 %gfx
did -a pcinfo 35 $$gettok(%screen,1,32)
did -a pcinfo 37 $$gettok(%screen,2,32)
did -a pcinfo 39 $$gettok(%screen,3,32)

if (%net != -1) && (%net != none detected) {
did -a pcinfo 45 $gettok(%net,1,64) @ $gettok($gettok(%net,2,64),1,32)
did -a pcinfo 49 $replace($gettok($gettok(%net,2,40),3,32),MB,Mo)
did -a pcinfo 52 $replace($gettok($gettok(%net,2,40),1,32),MB,Mo)
did -a pcinfo 53 $gettok($gettok($gettok(%net,2,64),3-,32),1,40)
}
else {
var %eth = $dll(script/dll/moo.dll,interfaceinfo,_)
if (%eth != -1) {
var %eth1 = $gettok(%eth,$gettok(%eth,0,35),35)
did -a pcinfo 45 $$gettok($gettok(%eth1,1- $+ $calc($gettok(%eth1,0,32) - 4),32),2-,40)
did -a pcinfo 49 $$replace($gettok(%eth,-4,32),MB,$chr(32) $+ Mo)
did -a pcinfo 52 $$replace($gettok(%eth,-2,32),MB,$chr(32) $+ Mo)
did -a pcinfo 53 $$uptime(system,2)
}
else did -a pcinfo 45 Non d�tect�
}

var %a = 67
while (%a <= 90) {
if ($disk($chr(%a)).type == fixed) {
var %free = $disk($chr(%a)).free
var %size = $disk($chr(%a)).size
did -a pcinfo 40 Lecteur $chr(%a) : $+ $chr(9) $+ $tailledisk(%size) $+ $chr(9) $+ $tailledisk(%free) $+ $chr(9) $+ $round($calc(%free / %size * 100),1) $+ %
var %totalsize = $calc(%totalsize + %size)
var %totalfree = $calc(%totalfree + %free)
}
inc %a
}
did -a pcinfo 40 $chr(32) $+ $chr(9) $+ $chr(32)
did -a pcinfo 40 Total : $+ $chr(9) $+ $tailledisk(%totalsize) $+ $chr(9) $+ $tailledisk(%totalfree) $+ $chr(9) $+ $round($calc(%totalfree / %totalsize * 100),1) $+ %
}

on *:dialog:pcinfo:sclick:101:{
scid $activecid
say $replace(%info,<nom>,Cpu,<info>,$did(pcinfo,8) @ $did(pcinfo,9) $+ $chr(44) $did(pcinfo,10) Cache)
}

on *:dialog:pcinfo:sclick:102:{
scid $activecid
say $replace(%info,<nom>,Ram,<info>,$gettok($did(pcinfo,18),1,32) $+ / $+ $did(pcinfo,20) $replace($gettok($did(pcinfo,18),2-,32),%,% utilis�))
}

on *:dialog:pcinfo:sclick:103:{
scid $activecid
say $replace(%info,<nom>,Os,<info>,$did(pcinfo,23) $chr(40) $+ $did(pcinfo,24) - $did(pcinfo,27) $+ $chr(41)) $replace(%info,<nom>,Uptime,<info>,$did(pcinfo,31))
}

on *:dialog:pcinfo:sclick:104:{
scid $activecid
say $replace(%info,<nom>,Gfx,<info>,$did(pcinfo,33)) $replace(%info,<nom>,Ecran,<info>,$did(pcinfo,35) $+ / $+ $did(pcinfo,37) $+ / $+ $did(pcinfo,39))
}

on *:dialog:pcinfo:sclick:105:{
scid $activecid
var %a = 67
while (%a <= 90) {
if ($disk($chr(%a)).type == fixed) {
var %totalsize = $calc(%totalsize + $disk($chr(%a)).size)
var %totalfree = $calc(%totalfree + $disk($chr(%a)).free)
var %disk = %disk $ifdisk($chr(%a))
}
inc %a
}
var %total = Total : $tailledisk(%totalsize) $+ , $tailledisk(%totalfree) libre ( $+ $round($calc(%totalfree / %totalsize * 100),1) $+ % $+ )
say $replace(%info,<nom>,Hds,<info>,%total) %disk
}

on *:dialog:pcinfo:sclick:106:{
scid $activecid
if (($did(pcinfo,45) != Non d�tect�) || ($did(pcinfo,45) != $null)) say $replace(%info,<nom>,Net,<info>,$did(pcinfo,45)) $replace(%info,<nom>,Download,<info>,$did(pcinfo,49)) $replace(%info,<nom>,Upload,<info>,$did(pcinfo,52)) $replace(%info,<nom>,Depuis,<info>,$did(pcinfo,53))
else say $replace(%info,<nom>,Net,<info>,Connexion non d�tect�e)
}

on *:dialog:pcinfo:sclick:43:{
scid $activecid
if ($did(pcinfo,45) != Non d�tect�e) var %net = $replace(%info,<nom>,Net,<info>,$did(pcinfo,45) $chr(40) $+ Download: $did(pcinfo,49) - Upload: $did(pcinfo,52) $+ $chr(41)) $replace(%info,<nom>,Depuis,<info>,$did(pcinfo,53))
else var %net = $replace(%info,<nom>,Net,<info>,Connexion non d�tect�e)
say $replace(%info,<nom>,Cpu,<info>,$did(pcinfo,8) @ $did(pcinfo,9) $+ $chr(44) $did(pcinfo,10) Cache) $replace(%info,<nom>,Ram,<info>,$gettok($did(pcinfo,18),1,32) $+ / $+ $did(pcinfo,20) $replace($gettok($did(pcinfo,18),2-,32),%,% utilis�)) $replace(%info,<nom>,Gfx,<info>,$did(pcinfo,33)) $replace(%info,<nom>,Ecran,<info>,$did(pcinfo,35) $+ / $+ $did(pcinfo,37) $+ / $+ $did(pcinfo,39)) %net

var %a = 67
while (%a <= 90) {
if ($disk($chr(%a)).type == fixed) {
var %totalsize = $calc(%totalsize + $disk($chr(%a)).size)
var %totalfree = $calc(%totalfree + $disk($chr(%a)).free)
}
inc %a
}
var %total = Total : $tailledisk(%totalsize) $+ , $tailledisk(%totalfree) libre ( $+ $round($calc(%totalfree / %totalsize * 100),1) $+ % $+ )

say $replace(%info,<nom>,Os,<info>,$did(pcinfo,23) $chr(40) $+ $did(pcinfo,24) - $did(pcinfo,27) $+ $chr(41)) $replace(%info,<nom>,Uptime,<info>,$did(pcinfo,31)) $replace(%info,<nom>,Hds,<info>,%total)
}

alias moo {
var %ticks = $ticks
var %cpu = $dll(script/dll/moo.dll,cpuinfo,_)
var %ram = $dll(script/dll/moo.dll,meminfo,_)
var %os = $dll(script/dll/moo.dll,osinfo,_)
var %gfx = $dll(script/dll/moo.dll,gfxinfo,_)
var %screen = $dll(script/dll/moo.dll,screeninfo,_)
var %net = $dll(script/dll/moo.dll,connection,_)
var %net = $dll(script/dll/moo.dll,interfaceinfo,_)
echo -a $calc($ticks - %ticks) $+ ms
}