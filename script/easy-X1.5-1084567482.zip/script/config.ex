alias config {
scid $activecid
dialog $iif($dialog(config),-v,-m) config config
}

on *:start:{
if (!$exists(script/bdd/correcteur.tbl)) write script/bdd/correcteur.tbl
if (!$exists(script/bdd/blacklist.tbl)) write script/bdd/blacklist.tbl
if (!$exists(script/bdd/hl.tbl)) write script/bdd/hl.tbl
if (!$exists(script/bdd/autojoin.tbl)) write script/bdd/autojoin.tbl
if (!$exists(script/bdd/autoauth.tbl)) write script/bdd/autoauth.tbl
if (!$exists(script/bdd/autoconnect.tbl)) write script/bdd/autoconnect.tbl
if (!$exists(script/bdd/kicks.tbl)) write script/bdd/kicks.tbl Kicked by easy-X
if (!$exists(script/bdd/quits.tbl)) write script/bdd/quits.tbl easy-X v1.5 - www.easy-X.tk
if (!$exists(script/bdd/sons.tbl)) {
write script/bdd/sons.tbl 0 + 0 0 2 Kick	+ 0 0 0 kick.wav	+ 0 0 0 $mircdir $+ script\sons\kick.wav
write script/bdd/sons.tbl 0 + 0 0 2 Priv�	+ 0 0 0 prive.wav	+ 0 0 0 $mircdir $+ script\sons\prive.wav
write script/bdd/sons.tbl 0 + 0 0 2 Op	+ 0 0 0 op.wav	+ 0 0 0 $mircdir $+ script\sons\op.wav
write script/bdd/sons.tbl 0 + 0 0 2 Deop	+ 0 0 0 deop.wav	+ 0 0 0 $mircdir $+ script\sons\deop.wav
write script/bdd/sons.tbl 0 + 0 0 2 Voice	+ 0 0 0 voice.wav	+ 0 0 0 $mircdir $+ script\sons\voice.wav
write script/bdd/sons.tbl 0 + 0 0 2 Devoice	+ 0 0 0 devoice.wav	+ 0 0 0 $mircdir $+ script\sons\devoice.wav
write script/bdd/sons.tbl 0 + 0 0 2 Ctcp	+ 0 0 0 ctcp.wav	+ 0 0 0 $mircdir $+ script\sons\ctcp.wav
write script/bdd/sons.tbl 0 + 0 0 2 Invite	+ 0 0 0 invite.wav	+ 0 0 0 $mircdir $+ script\sons\invite.wav
}
hmake correcteur
hmake blacklist
hmake exm.nicklist
hmake exm.menubar
hmake exm.channel
hload correcteur script/bdd/correcteur.tbl
hload blacklist script/bdd/blacklist.tbl
titlebar.refresh
.timer.titlebar -oi 0 1 titlebar.refresh
.timer.antiidle -oi 0 60 antiidle
if (%autoconnect) autoconnect
if (!%panel) { config | set %panel 1 }
}

alias taskbar return script/icone/dialog/ $+ %taskbar $+ .ico

dialog config {
title "Configuration"
size -1 -1 422 235
option pixels
icon $taskbar
list 1, 3 4 139 200, size
box "", 2, 146 -1 273 31
box "", 3, 146 22 273 210
button "Ok", 6, 3 208 57 23, default ok
button "Appliquer", 4, 62 208 79 23
text "", 7, 153 10 168 16, disable

edit $emailaddr, 1606, 251 45 154 21, autohs
edit $fullname, 1607, 251 69 154 21, autohs
edit $mnick, 1604, 251 93 125 21, autohs
edit $anick, 1605, 251 117 125 21, autohs
check "Mode invisible (+i)", 1608, 252 144 128 20
text "Pseudo :", 1600, 157 96 90 16, right
text "Pseudo alternatif :", 1601, 157 120 90 16, right
text "E-mail :", 1602, 157 48 90 16, right
text "Vrai nom :", 1603, 157 72 90 16, right

;away
radio "Avertir dans tout les channels", 100, 154 35 162 20, hide
radio "Avertir dans le channel actif", 101, 154 56 162 20, hide
radio "Ne rien dire", 102, 154 77 78 20, hide
check "Mettre away sur tout les serveurs", 103, 156 102 186 20, hide
check "Away pager", 104, 156 122 80 20, hide
check "Stoper la lecture du mp3", 112, 240 122 140 20, hide
text "Pseudo par d�faut :", 108, 157 150 100 15, hide
edit "", 109, 155 165 120 21, hide autohs center
text "Pseudo d'auto away :", 110, 281 150 110 15, hide
edit %away.nick, 111, 279 165 106 21, hide autohs center
check "Auto away apr�s", 105, 156 197 108 20, hide
edit %away.autoaway.min, 106, 264 197 35 21, hide autohs center
text "minutes d'inactivit�", 107, 305 200 100 15, hide

;half life
edit %hl.exe, 201, 154 49 182 21, hide autohs read
text "Executable :", 200, 156 35 64 14, hide
button "Parcourir...", 202, 338 49 73 21, hide
text "Param�tres :", 208, 156 73 64 14, hide
edit %hl.param, 209, 154 87 232 21, hide autohs
check "Mettre away", 203, 155 114 84 20, hide
check "Stopper la lecture du mp3", 204, 243 114 148 20, hide
check "Supprimer les # dans le nom des serveurs", 210, 155 134 224 20, hide
combo 205, 155 159 160 130, hide size drop
text "Pseudo de jeu :", 206, 156 187 78 14, hide
edit %hl.nick, 207, 154 201 110 21, hide autohs center

;sons
list 300, 154 36 257 160, size
button "Jouer", 302, 339 202 71 21
button "Editer", 301, 266 202 73 21

;message
text "Away :", 400, 156 34 36 14, hide
text "Retour :", 403, 156 72 44 14, hide
text "Mp3 :", 406, 156 110 30 14, hide
text "Infos :", 409, 156 148 36 14, hide
text "Half-life :", 412, 156 186 48 14, hide
edit %away.msg, 401, 154 49 234 21, hide autohs
edit %away.retour, 404, 154 87 234 21, hide autohs
edit %mp3.advertise, 407, 154 125 234 21, hide autohs
edit %info, 410, 154 163 234 21, hide autohs
edit %hl.msg, 413, 154 201 234 21, hide autohs
button "?", 402, 391 50 19 19, hide
button "?", 405, 391 88 19 19, hide
button "?", 408, 391 126 19 19, hide
button "?", 411, 391 164 19 19, hide
button "?", 414, 391 202 19 19, hide

;correcteur
edit "", 500, 153 36 90 21, hide autohs
edit "", 501, 247 36 90 21, hide autohs
list 502, 153 60 184 146, size hide
button "Ajouter", 503, 345 36 63 21, hide
button "Supprimer", 504, 345 61 63 21, hide
check "Activer le correcteur", 505, 154 208 122 20, hide

;fkeys
list 600, 153 36 259 165, size, hide
edit "", 601, 153 203 229 21, hide autohs
button "ok", 602, 384 203 27 19, hide

;couleurs
list 700, 154 37 18 18, hide size
list 701, 284 37 18 18, hide size
list 702, 284 61 18 18, hide size
list 703, 284 85 18 18, hide size
list 705, 154 85 18 18, hide size
list 706, 154 109 18 18, hide size
list 707, 284 109 18 18, hide size
list 708, 154 133 18 18, hide size
list 709, 284 133 18 18, hide size
list 710, 284 157 18 18, hide size
list 723, 154 157 18 18, hide size
text "Fond Lecteur mp3", 711, 179 39 90 16, hide
text "Texte Lecteur mp3", 712, 309 39 94 16, hide
text "Fond Lagbar", 713, 309 63 64 16, hide
text "Barre Lagbar", 715, 309 87 66 16, hide
text "Texte Lagbar", 716, 179 87 70 16, hide
text "Fond Half-life", 717, 179 111 70 16, hide
text "Texte Half-life", 718, 309 111 74 16, hide
text "Fond Buddylist", 719, 179 135 70 16, hide
text "Texte Buddylist", 720, 309 135 74 16, hide
text "Fond Configuration", 721, 309 159 100 16, hide
text "Texte Configuration", 724, 179 159 100 16, hide
text "Double-Cliquez pour changer la couleur...", 722, 156 188 210 16, hide disable
list 725, 154 61 18 18, hide size
text "Spectrum Mp3", 726, 179 63 90 16, hide

;slaps
list 800, 153 36 259 162, size hide
button "Ajouter", 801, 261 203 75 21, hide
button "Supprimer", 802, 336 203 75 21, hide

;aide
text "Topic :", 900, 154 39 36 16, hide
combo 901, 265 37 146 156, size drop hide
list 902, 153 62 259 163, size hide

;modules
list 1200, 153 36 259 161, hide size
text "", 1201, 161 205 160 16, disable hide
button "Mettre � jour", 1202, 326 201 85 23 hide

;autojoin
check "Activer l'Auto Join", 1005, 154 34 112 20, hide
check "Mise � jour de l'IAL", 1006, 278 34 116 20, hide
list 1000, 153 57 259 140, hide size
button "5", 1001, 154 202 25 21, hide
button "6", 1002, 179 202 25 21, hide
button "Ajouter", 1003, 273 202 67 21, hide
button "Supprimer", 1004, 340 202 71 21, hide

;autoauth
list 1100, 153 36 259 161, size hide
check "Mode +x", 1103, 165 203 65 20, hide
button "Ajouter", 1101, 273 202 67 21, hide
button "Supprimer", 1102, 340 202 71 21, hide

;ctcp
edit %ctcp.version.reply, 1301, 153 55 258 21, hide autohs
check "Version", 1300, 154 35 62 20, hide
edit %ctcp.finger.reply, 1303, 153 104 258 21, hide autohs
check "Finger", 1302, 154 84 56 20, hide
edit %ctcp.time.reply, 1305, 153 153 258 21, hide autohs
check "Time", 1304, 154 133 50 20, hide
edit %ctcp.ping.reply, 1307, 153 202 258 21, hide autohs
check "Ping", 1306, 154 182 50 20, hide

;affichage
text "Barre d'outils :", 1405, 155 36 110 16, hide
text "Fen�tres :", 1406, 302 36 100 16, hide
text "Variables :", 1408, 165 183 52 16, disable hide
text "<net> <mp3> <idle> <lag> <heure> <nick>", 1409, 164 200 236 16, disable hide
text "Lecteur Mp3 :", 1407, 155 84 74 16, hide
combo 1400, 155 53 132 139, size hide
combo 1401, 302 53 108 123, size hide
combo 1402, 155 101 132 123, size hide
check "Activer la lagbar", 1403, 302 90 110 20, hide
check "Activer la toolbar", 1411, 302 112 110 20, hide
box "Barre de titre", 1410, 155 139 255 84, hide
edit %titlebar, 1404, 163 157 238 21, autohs hide

;favoris
check "Connexion automatique � ce(s) serveur(s)", 1505, 154 34 240 20, hide
list 1500, 153 57 259 140, hide size
button "5", 1501, 154 202 25 21, hide
button "6", 1502, 179 202 25 21, hide
button "Ajouter", 1503, 273 202 67 21, hide
button "Supprimer", 1504, 340 202 71 21, hide

;anti-pv
check "Activer l'anti priv�", 1700, 155 35 118 20
check "Avertir la personne", 1701, 155 56 118 20
edit %antipv.message.msg, 1702, 154 79 254 21, autohs
check "Demande d'acceptation", 1703, 170 104 144 20
check "Informer du refus ou de l'acceptation", 1708, 170 125 204 20
check "Activer si vous �tes away", 1705, 240 160 148 20
check "R�pondeur", 1704, 155 160 78 20
edit %antipv.repondeur.msg, 1706, 154 183 254 21, autohs
text "Ne marche que si l'anti priv� est d�sactiv�.", 1707, 156 209 252 16, disable

;quits
check "Activer les messages de quit", 1804, 154 34 170 20, hide
list 1800, 153 56 259 142, hide size
button "Ajouter", 1801, 206 203 67 21, hide
button "Editer", 1802, 273 203 67 21, hide
button "Supprimer", 1803, 340 203 71 21, hide

;kicks
check "Activer les messages de kick", 1904, 154 34 170 20, hide
list 1900, 153 56 259 142, hide size
button "Ajouter", 1901, 206 203 67 21, hide
button "Editer", 1902, 273 203 67 21, hide
button "Supprimer", 1903, 340 203 71 21, hide

;divers
box "Anti-idle", 2000, 154 33 162 70, hide
check "Activer", 2001, 164 49 74 20, hide
combo 2002, 164 72 142 100, size drop hide disabled
box "Buddylist", 2003, 322 33 89 70, hide
text "Placer � :", 2004, 332 51 50 16, hide
combo 2005, 332 72 69 64, size drop hide
box "Liste de pseudos", 2006, 154 106 257 118, hide
text "Permet d'effectuer une action lorsque vous double-cliquez, et que vous maintenez le bouton Shift ou Control, sur le pseudo d'un channel.", 2007, 163 124 238 40, disable hide
check "Control", 2008, 163 171 68 20, hide
combo 2009, 163 194 112 170, size drop hide disabled
check "Shift", 2010, 290 171 60 20, hide
combo 2011, 290 194 112 170, size drop hide disabled
}

on *:dialog:config:init:*:{
dll script/mdx/mdx.dll SetMircVersion $version
dll script/mdx/mdx.dll MarkDialog config
dll script/mdx/mdx.dll SetControlMDX config 1 treeview haslines linesatroot hasbuttons > script\mdx\views.mdx
dll script/mdx/mdx.dll SetControlMDX 502,600,800,1000 listview infotip report showsel single rowselect nosortheader > script/mdx/views.mdx
dll script/mdx/mdx.dll SetControlMDX 300,1100,1200,1500 listview infotip showsel report single checkboxes rowselect nosortheader > script/mdx/views.mdx
dll script/mdx/mdx.dll SetControlMDX 700,701,702,703,705,706,707,708,709,710,723,725 listview > script/mdx/views.mdx
dll script/mdx/mdx.dll SetControlMDX 1400,1401,1402 comboboxex simple drop sortascending > script/mdx/views.mdx
dll script/mdx/mdx.dll SetFont 1001,1002,1501,1502 20 7 webdings
did -i config 1 1 setcolor bkg %couleur.configfond
did -i config 1 1 setcolor line %couleur.configtexte
did -i config 1 1 setcolor text %couleur.configtexte
did -i config 300 1 headerdims 100 153 0
did -i config 502 1 headerdims 72 92
did -i config 600 1 headerdims 172 67
did -i config 800 1 headerdims 63 176
did -i config 1000 1 headerdims 67 102 70
did -i config 1100 1 headerdims 81 158
did -i config 1200 1 headerdims 103 136
did -i config 1500 1 headerdims 152 103
did -i config 300 1 headertext Ev�nement $+ $chr(9) $+ Fichier son $+ $chr(9) $+ 0
did -i config 1500 1 headertext Adresse $+ $chr(9) $+ Cl�
did -i config 1200 1 headertext Fichier $+ $chr(9) $+ Description
did -i config 1000 1 headertext R�seau $+ $chr(9) $+ Salon $+ $chr(9) $+ Cl�
did -i config 1100 1 headertext R�seau $+ $chr(9) $+ Commande
did -i config 600 1 headertext Commande $+ $chr(9) $+ Touche
did -i config 502 1 headertext Mot $+ $chr(9) $+ Remplac� par
did -i config 800 1 headertext Nom $+ $chr(9) $+ Slaps
did -i config 700 1 setbkg color %couleur.mp3fond
did -i config 701 1 setbkg color %couleur.mp3texte
did -i config 702 1 setbkg color %couleur.lagbarfond
did -i config 703 1 setbkg color %couleur.lagbarbarre
did -i config 705 1 setbkg color %couleur.lagbartexte
did -i config 706 1 setbkg color %couleur.hlfond
did -i config 707 1 setbkg color %couleur.hltexte
did -i config 708 1 setbkg color %couleur.buddyfond
did -i config 709 1 setbkg color %couleur.buddytexte
did -i config 710 1 setbkg color %couleur.configfond
did -i config 723 1 setbkg color %couleur.configtexte
did -i config 725 1 setbkg color %couleur.mp3spectrum

did -i config 1 1 cb root
did -a config 1 +be Connexion
did -i config 1 1 cb last
did -a config 1 Informations
did -a config 1 Serveurs
did -a config 1 Auto Join
did -a config 1 Auto Auth
did -i config 1 1 cb root
did -a config 1 +be Outils
did -i config 1 1 cb last
did -a config 1 Anti Priv�
did -a config 1 Away
did -a config 1 Half-Life
did -a config 1 Modules
did -a config 1 Correcteur
did -a config 1 Fkeys
did -a config 1 Slaps
did -i config 1 1 cb root
did -a config 1 +be Messages
did -i config 1 1 cb last
did -a config 1 Informations
did -a config 1 Quits
did -a config 1 Kicks
did -i config 1 1 cb root
did -a config 1 +be Pr�f�rences
did -i config 1 1 cb last
did -a config 1 Affichage
did -a config 1 Couleurs
did -a config 1 Ctcp
did -a config 1 Sons
did -a config 1 Th�mes
did -a config 1 Divers
did -i config 1 1 cb root
did -a config 1 +be Divers
did -i config 1 1 cb last
did -a config 1 Aide
var %a = $dll(script/dll/nhtml.dll,attach,$dll(script/dll/nhtml.dll,item,$dialog(config).hwnd id:902))
var %a = $dll(script/dll/nhtml.dll,margins,-2)
var %a = $dll(script/dll/nhtml.dll,navigate,$mircdir $+ script\aide\Introduction.html)
loadbuf 1-100 -o config 300 script/bdd/sons.tbl
loadbuf 1-100 -o config 1100 script/bdd/autoauth.tbl
loadbuf 1-100 -o config 1000 script/bdd/autojoin.tbl
loadbuf 1-100 -o config 1500 script/bdd/autoconnect.tbl
loadbuf 1-100 -o config 1800 script/bdd/quits.tbl
loadbuf 1-100 -o config 1900 script/bdd/kicks.tbl
config.hide
config.informations
modules.refresh
correcteur.list
fkeyslist
slaps.list

if (%invisible) did -c config 1608

if (%away.say == 1) did -c config 100
elseif (%away.say == 2) did -c config 101
else did -c config 102
if (%away.all) did -c config 103
if (%away.pager) did -c config 104
if (%nick.default) did -a config 109 %nick.default
if (%away.autoaway) did -c config 105
if (%away.mp3) did -c config 112

if (%hl.away) did -c config 203
if (%hl.mp3) did -c config 204
if (%hl.pub) did -c config 210
didtok -a config 205 44 Ne rien dire,Dire dans le channel actif,Dire dans tous les channels
did -c config 205 %hl.say

if (!%toolbar.a) did -b config 1403

if (%correcteur) did -c config 505

if (%ctcp.version) did -c config 1300
if (%ctcp.finger) did -c config 1302
if (%ctcp.time) did -c config 1304
if (%ctcp.ping) did -c config 1306

if (%autojoin) did -c config 1005
if (%autojoin.ial) did -c config 1006
if (%autoauth.x) did -c config 1103
if (%autoconnect) did -c config 1505

did -i config 1400,1401,1402 1 iconsize small

var %a = 1
while (%a <= $findfile(script/icone/toolbar/,*?.icl,0)) {
var %file = $findfile(script/icone/toolbar/,*?.icl,%a)
did -i config 1400 1 seticon 0 5, $+ %file
did -a config 1400 %a %a %a 0 $left($nopath(%file),-4)
if (%toolbar == $left($nopath(%file),-4)) var %1400.sel = $calc(%a + 1)
inc %a
}

var %a = 1
while (%a <= $findfile(script/icone/taskbar/,*?.ico,0)) {
var %file = $findfile(script/icone/taskbar/,*?.ico,%a)
did -i config 1401 1 seticon 0 %file
did -a config 1401 %a %a %a 0 $left($nopath(%file),-4)
if (%taskbar == $left($nopath(%file),-4)) var %1401.sel = $calc(%a + 1)
inc %a
}

var %a = 1
while (%a <= $findfile(script/icone/mp3/,*?.icl,0)) {
var %file = $findfile(script/icone/mp3/,*?.icl,%a)
did -i config 1402 1 seticon 0 1, $+ %file
did -a config 1402 %a %a %a 0 $left($nopath(%file),-4)
if (%mp3.icone == $left($nopath(%file),-4)) var %1402.sel = $calc(%a + 1)
inc %a
}

did -c config 1400 %1400.sel
did -c config 1401 %1401.sel
did -c config 1402 %1402.sel

if (%lagbar) did -c config 1403
if (%toolbar.a) did -c config 1411

if (%antipv) did -c config 1700
if (%antipv.message) did -c config 1701
if (%antipv.demande) did -c config 1703
if (%antipv.repondeur) did -c config 1704
if (%antipv.repondeur.away) did -c config 1705
if (%antipv.informer) did -c config 1708
if (!%antipv) did -b config 1701,1702,1703,1708
if (!%antipv.repondeur) did -b config 1705,1706

if (%message.quit) did -c config 1804
if (%message.kick) did -c config 1904

if (%antiidle) { did -c config 2001 | did -e config 2002 }
didtok -a config 2002 44 Lorsque vous �tes away,Lorsque vous �tes pr�sent,Les deux
did -c config 2002 %antiidle.sel

didtok -a config 2005 44 Gauche,Droite
did -c config 2005 $iif(%buddy.dockside == gauche,1,2)

if (%nicklist.control) { did -c config 2008 | did -e config 2009 }
if (%nicklist.shift) { did -c config 2010 | did -e config 2011 }

didtok -a config 2009,2011 44 Op,Deop,Voice,Hop,Dehop,Devoice,Kick,Kickban,Slaps,Whois,Buddylist,Version
did -c config 2009 $didwm(config,2009,%nicklist.control.action)
did -c config 2011 $didwm(config,2009,%nicklist.shift.action)

didtok -a config 901 44 Introduction,-,Affichage,Anti-idle,Anti Prive,Auto Auth,Auto Join,Away,Blacklist,Buddylist,Commandes,Correcteur,Couleurs,Credits,Ctcp Reply,Fkeys,Half-life,Lecteur Mp3,Messages,Modules,PC Infos,Protections,Serveurs,Slaps,Sons,Themes
did -c config 901 1
}

alias config.hide did -h config 100,101,102,103,104,105,106,107,108,109,110,111,112,200,201,202,203,204,205,206,207,208,209,210,300,301,302,400,401,402,403,404,405,406,407,408,408,409,410,411,412,413,414,500,501,502,503,504,505,600,601,602,700,701,702,703,705,706,707,708,709,710,711,712,713,715,716,717,718,719,720,721,722,723,724,725,726,800,801,802,900,901,902,1000,1001,1002,1003,1004,1005,1006,1100,1101,1102,1103,1200,1201,1202,1300,1301,1302,1303,1304,1305,1306,1307,1400,1401,1402,1403,1404,1405,1406,1407,1408,1409,1410,1411,1500,1501,1502,1503,1504,1505,1600,1601,1602,1603,1604,1605,1606,1607,1608,1700,1701,1702,1703,1704,1705,1706,1707,1708,1800,1801,1802,1803,1804,1900,1901,1902,1903,1904,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011

alias config.modules {
did -v config 1200,1201,1202
did -o config 7 1 Configuration - Modules
}

alias config.informations {
did -v config 1600,1601,1602,1603,1604,1605,1606,1607,1608
did -o config 7 1 Configuration - Informations
}

alias config.autojoin {
did -v config 1000,1001,1002,1003,1004,1005,1006
did -o config 7 1 Configuration - Auto Join
}

alias config.autoauth {
did -v config 1100,1101,1102,1103
did -o config 7 1 Configuration - Auto Auth
}

alias config.autoconnect {
did -v config 1500,1501,1502,1503,1504,1505
did -o config 7 1 Configuration - Favoris
}

alias config.away {
did -v config 100,101,102,103,104,105,106,107,108,109,110,111,112
did -o config 7 1 Configuration - Away
}

alias config.hl {
did -v config 200,201,202,203,204,205,206,207,208,209,210
did -o config 7 1 Configuration - Half-Life
}

alias config.antipv {
did -v config 1700,1701,1702,1703,1704,1705,1706,1707,1708
did -o config 7 1 Configuration - Anti Priv�
}

alias config.sons {
did -v config 300,301,302
did -o config 7 1 Configuration - Sons
}

alias config.messages {
did -v config 400,401,402,403,404,405,406,407,408,408,409,410,411,412,413,414
did -o config 7 1 Configuration - Messages
}

alias config.correcteur {
did -v config 500,501,502,503,504,505
did -o config 7 1 Configuration - Correcteur
}

alias config.fkeys {
did -v config 600,601,602
did -o config 7 1 Configuration - Fkeys
}

alias config.quits {
did -v config 1800,1801,1802,1803,1804
did -o config 7 1 Configuration - Message de Quit
}

alias config.kicks {
did -v config 1900,1901,1902,1903,1904
did -o config 7 1 Configuration - Message de Kick
}

alias config.ctcp {
did -v config 1300,1301,1302,1303,1304,1305,1306,1307
did -o config 7 1 Configuration - Ctcp Reply
}

alias config.couleurs {
did -v config 700,701,702,703,705,706,707,708,709,710,711,712,713,715,716,717,718,719,720,721,722,723,724,725,726
did -o config 7 1 Configuration - Couleurs
}

alias config.affichage {
did -v config 1400,1401,1402,1403,1404,1405,1406,1407,1408,1409,1410,1411
did -o config 7 1 Configuration - Affichage
}

alias config.slaps {
did -v config 800,801,802
did -o config 7 1 Configuration - Slaps
}

alias config.divers {
did -v config 2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011
did -o config 7 1 Configuration - Divers
}

alias config.aide {
did -v config 900,901,902
did -o config 7 1 Configuration - Aide
}

on *:dialog:config:sclick:1:{
var %a = $gettok($did(config,1,1),4,32)
var %b = $gettok($did(config,1,1),5,32)
if (!%b) halt

if (%a == 5 && %b == 6) { .timertheme -m 1 1 theme | halt }

config.hide

if (%a == 2 && %b == 2) config.informations
elseif (%a == 2 && %b == 3) config.autoconnect
elseif (%a == 2 && %b == 4) config.autojoin
elseif (%a == 2 && %b == 5) config.autoauth

elseif (%a == 3 && %b == 2) config.antipv
elseif (%a == 3 && %b == 3) config.away
elseif (%a == 3 && %b == 4) config.hl
elseif (%a == 3 && %b == 5) config.modules
elseif (%a == 3 && %b == 6) config.correcteur
elseif (%a == 3 && %b == 7) config.fkeys
elseif (%a == 3 && %b == 8) config.slaps

elseif (%a == 4 && %b == 2) config.messages
elseif (%a == 4 && %b == 3) config.quits
elseif (%a == 4 && %b == 4) config.kicks

elseif (%a == 5 && %b == 2) config.affichage
elseif (%a == 5 && %b == 3) config.couleurs
elseif (%a == 5 && %b == 4) config.ctcp
elseif (%a == 5 && %b == 5) config.sons
elseif (%a == 5 && %b == 7) config.divers

elseif (%a == 6 && %b == 2) config.aide
}

on *:dialog:config:sclick:4,6:config.apply

on *:dialog:config:edit:1604:set %config.nick 1

on *:dialog:config:sclick:202:did -o config 201 1 $$sfile($iif(%hl.exe,$nofile(%hl.exe) $+ *.exe,C:\*.exe),S�lectionnez l'�x�cutable Half-Life)

alias config.apply {
if ($did(config,1000).sel) did -o config 1000 $did(config,1000).sel $replace($did(config,1000).seltext,+fs,+)
if ($did(config,1100).sel) did -o config 1100 $did(config,1100).sel $replace($did(config,1100).seltext,+fs,+)
if ($did(config,1500).sel) did -o config 1500 $did(config,1500).sel $replace($did(config,1500).seltext,+fs,+)
if ($did(config,300).sel) did -o config 300 $did(config,300).sel $replace($did(config,300).seltext,+fs,+)
savebuf -o 2-100 config 300 script/bdd/sons.tbl
savebuf -o 2-100 config 1000 script/bdd/autojoin.tbl
savebuf -o 2-100 config 1100 script/bdd/autoauth.tbl
savebuf -o 2-100 config 1500 script/bdd/autoconnect.tbl
savebuf -o 1-100 config 1800 script/bdd/quits.tbl
savebuf -o 1-100 config 1900 script/bdd/kicks.tbl

if (%config.nick) {
if ($did(config,1604)) scid -a .nick $did(config,1604)
unset %config.nick
}
if ($did(config,1605)) .anick $did(config,1605)
if ($did(config,1606)) .emailaddr $did(config,1606)
if ($gettok($did(config,1606),1,64)) .identd on $gettok($did(config,1606),1,64)
if ($did(config,1607)) .fullname $did(config,1607)
set %invisible $did(config,1608).state

if ($did(config,100).state == 1) set %away.say 1
elseif ($did(config,101).state == 1) set %away.say 2
else set %away.say 3
set %away.all $did(config,103).state
set %away.pager $did(config,104).state
set %nick.default $did(config,109)
set %away.autoaway $did(config,105).state
set %away.mp3 $did(config,112).state
set %away.autoaway.min $did(config,106)
set %away.nick $did(config,111)
autoaway

set %hl.exe $did(config,201)
set %hl.param $did(config,209)
set %hl.away $did(config,203).state
set %hl.mp3 $did(config,204).state
set %hl.pub $did(config,210).state
set %hl.say $did(config,205).sel
set %hl.nick $did(config,207)

set %away.msg $did(config,401)
set %away.retour $did(config,404)
set %mp3.advertise $did(config,407)
set %info $did(config,410)
set %hl.msg $did(config,413)
set %message.quit $did(config,1804).state
set %message.kick $did(config,1904).state

set %correcteur $did(config,505).state

if ($dialog(config)) {
did -i config 1 1 setcolor bkg %couleur.configfond
did -i config 1 1 setcolor line %couleur.configtexte
did -i config 1 1 setcolor text %couleur.configtexte
}

if ($dialog(hl)) {
did -i hl 100,101,102 1 setbkg color %couleur.hlfond
did -i hl 100,101,102 1 settxt color %couleur.hltexte
did -i hl 100,101,102 1 settxt bgcolor %couleur.hlfond
}

if ($dialog(mp3)) {
dll script/mdx/mdx.dll SetColor mp3 1,24,25 background %couleur.mp3fond
dll script/mdx/mdx.dll SetColor mp3 1,24,25 textbg %couleur.mp3fond
dll script/mdx/mdx.dll SetColor mp3 1,24,25 text %couleur.mp3texte
if (%mp3.spectrum < 6) var %a = $fmod(Plugin_Send,1 Set_Colors $replace($rgb(%couleur.mp3spectrum),$chr(44),/) $replace($rgb(%couleur.mp3spectrum),$chr(44),/) $replace($rgb(%couleur.mp3fond),$chr(44),/))
did -i mp3 2 1 settxt bgcolor %couleur.mp3fond
did -i mp3 2 1 setbkg color %couleur.mp3fond
did -i mp3 2 1 settxt color %couleur.mp3texte
mp3.spectrum $+ %mp3.spectrum
}

if ($dialog(buddy)) {
did -i buddy 1 1 setcolor bkg %couleur.buddyfond
did -i buddy 1 1 setcolor line %couleur.buddytexte
did -i buddy 1 1 setcolor text %couleur.buddytexte
}

if ($dialog(buddyd)) {
did -i buddyd 1 1 setcolor bkg %couleur.buddyfond
did -i buddyd 1 1 setcolor line %couleur.buddytexte
did -i buddyd 1 1 setcolor text %couleur.buddytexte
}

if ($dialog(toolbar)) {
dll script/mdx/mdx.dll SetColor toolbar 4,5 text %couleur.lagbartexte
did -a toolbar 3 BGColor %couleur.lagbarfond
did -a toolbar 3 BarColor %couleur.lagbarbarre
}

set %autojoin $did(config,1005).state
set %autojoin.ial $did(config,1006).state
set %autoauth.x $did(config,1103).state
set %autoconnect $did(config,1505).state

set %ctcp.version $did(config,1300).state
set %ctcp.finger $did(config,1302).state
set %ctcp.time $did(config,1304).state
set %ctcp.ping $did(config,1306).state
set %ctcp.version.reply $did(config,1301)
set %ctcp.finger.reply $did(config,1303)
set %ctcp.time.reply $did(config,1305)
set %ctcp.ping.reply $did(config,1307)

set %lagbar $did(config,1403).state
set %titlebar $did(config,1404)

scid $activecid

set %toolbar.a $did(config,1411).state
if (($dialog(toolbar)) && (!%toolbar.a)) dialog -x toolbar
if ((!$dialog(toolbar)) && (%toolbar.a)) toolbar

if (!%lagbar) && ($dialog(toolbar)) did -h toolbar 3,4,5
if (%lagbar) && ($status == connected) && ($dialog(toolbar)) did -v toolbar 3,4,5
titlebar.refresh

var %a = 2
while (%a <= $did(config,1200).lines) {
var %ligne = $did(config,1200,%a)
var %checked = $gettok(%ligne,5,32)
if (%checked == 2) .load -rs script/modules/ $+ $gettok($gettok(%ligne,1,9),6,32)
elseif ($script($gettok($gettok(%ligne,1,9),6,32))) .unload -rs script/modules/ $+ $gettok($gettok(%ligne,1,9),6,32)
inc %a
}

if ($dialog(autojoin)) dialog -x autojoin
if ($dialog(autoauth)) dialog -x autoauth
if ($dialog(autoconnect)) dialog -x autoconnect

set %antipv $did(config,1700).state
set %antipv.message $did(config,1701).state
set %antipv.message.msg $did(config,1702)
set %antipv.demande $did(config,1703).state
set %antipv.informer $did(config,1708).state
set %antipv.repondeur $did(config,1704).state
set %antipv.repondeur.away $did(config,1705).state
set %antipv.repondeur.msg $did(config,1706)

set %antiidle $did(config,2001).state
set %antiidle.sel $did(config,2002).sel

set %buddy.dockside $did(config,2005)

set %nicklist.control $did(config,2008).state
set %nicklist.shift $did(config,2010).state
set %nicklist.control.action $did(config,2009)
set %nicklist.shift.action $did(config,2011)

saveini
}

alias sons.play {
if ($1) {
var %ligne = $read(script/bdd/sons.tbl,$1)
if ($gettok(%ligne,5,32) == 2) {
var %file = $gettok($gettok(%ligne,3,9),5-,32)
if ($isfile(%file)) splay -w " $+ %file $+ "
}
}
}

alias sons.edit {
var %sel = $did(config,300).sel
var %dir = $nofile($gettok($gettok($did(config,300).seltext,3,9),5-,32))
if (!$isdir(%dir)) var %dir = $mircdir
var %a = $sfile(%dir $+ *.wav,Choisissez un nouveau fichier,Ouvrir)
if (%a == $null) halt
if (!$isfile(%a)) { var %z = $input(Le fichier n'a pas �t� trouv�,wo,Erreur) | halt }
if ($right(%a,4) != .wav) { var %z = $input(Le fichier son doit �tre au format .wav,wo,Erreur) | halt }
did -o config 300 %sel 0 0 0 $gettok($gettok($did(config,300).seltext,5-6,32),1,9) $+ $chr(9) $+ 0 0 0 $nopath(%a) $+ $chr(9) $+ 0 0 0 %a
}

on *:dialog:config:dclick:300:sons.edit

on *:dialog:config:sclick:301:sons.edit

on *:dialog:config:sclick:302:{
var %file = $gettok($gettok($did(config,300).seltext,3,9),5-,32)
if (!$isfile(%file)) halt
splay -w " $+ %file $+ "
}

on *:dialog:config:sclick:503:{
if (($did(config,500)) && ($did(config,501))) {
hadd correcteur $did(config,500) $did(config,501)
correcteur.list
did -r config 500,501
did -f config 500
hsave -o correcteur script/bdd/correcteur.tbl
}
}

on *:dialog:config:sclick:504:{
hdel correcteur $$left($gettok($did(config,502).seltext,6,32),-4)
correcteur.list
hsave -o correcteur script/bdd/correcteur.tbl
}

alias correcteur.list {
var %a = 1
did -r config 502
while (%a <= $hget(correcteur,0).data) {
did -a config 502 0 0 0 0 $hmatch(correcteur,*,%a) $+ $chr(9) $+ 0 0 0 $hget(correcteur,%a).data
inc %a
}
}

alias correction {
var %a = 1
while (%a <= $gettok($1-,0,32)) {
var %mot = $gettok($1-,%a,32)
if (($right(%mot,1) == ?) || ($right(%mot,1) == $chr(44)) || ($right(%mot,1) == $chr(46)) || ($right(%mot,1) == $chr(33))) { var %fin = $right(%mot,1) | %mot = $left(%mot,-1) }
if ((%mot !isnum) && (%mot == $hfind(correcteur,%mot))) var %p = $+(%p,$chr(32),$hget(correcteur,%mot),%fin)
else var %p = $+(%p,$chr(32),%mot,%fin)
unset %mot
unset %fin
inc %a
}
return %p
}

on *:input:*:{
if (($left($1,1) == /) || (@ isin $active) || (!%correcteur)) return
say $correction($1-)
halt
}

alias fkeyslist {
var %a = 1
while (%a <= $lines(script/bdd/fkeys.tbl)) {
did -a config 600 0 0 0 $gettok($read(script/bdd/fkeys.tbl,%a),2,157) $+ $chr(9) $+ 0 0 0 $replace($replace($gettok($read(script/bdd/fkeys.tbl,%a),1,157),C,Ctrl+),S,Shift+)
inc %a
}
}

on *:dialog:config:sclick:600: did -o config 601 1 $gettok($gettok($did(config,600).seltext,1,9),6-,32)

on *:dialog:config:sclick:602:{
var %a = $did(config,600).sel
if (!%a) halt
var %touche = $gettok($read(script/bdd/fkeys.tbl,$calc(%a -1)),1,157)
write -l $+ $calc(%a - 1) script/bdd/fkeys.tbl %touche $+ $chr(157) $+ $did(config,601)
did -o config 600 %a 0 0 0 $did(config,601) $+ $chr(9) $+ 0 0 0 $replace(%touche,S,Shift+,C,Ctrl+)
did -c config 600 %a
.alias %touche $did(config,601)
}

alias couleur.return {
if ($1 == 700) return %couleur.mp3fond
elseif ($1 == 701) return %couleur.mp3texte
elseif ($1 == 702) return %couleur.lagbarfond
elseif ($1 == 703) return %couleur.lagbarbarre
elseif ($1 == 705) return %couleur.lagbartexte
elseif ($1 == 706) return %couleur.hlfond
elseif ($1 == 707) return %couleur.hltexte
elseif ($1 == 708) return %couleur.buddyfond
elseif ($1 == 709) return %couleur.buddytexte
elseif ($1 == 710) return %couleur.configfond
elseif ($1 == 723) return %couleur.configtexte
elseif ($1 == 725) return %couleur.mp3spectrum
}

on *:dialog:config:sclick:700,701,702,703,705,706,707,708,709,710,723,725:{
var %a = $did
$iif($dll(script/dll/color.dll,Color,$couleur.return(%a)) != $false,did -i config %a 1 setbkg color $ifmatch,halt)
var %c = $ifmatch
if (%a == 700) set %couleur.mp3fond %c
elseif (%a == 701) set %couleur.mp3texte %c
elseif (%a == 702) set %couleur.lagbarfond %c
elseif (%a == 703) set %couleur.lagbarbarre %c
elseif (%a == 705) set %couleur.lagbartexte %c
elseif (%a == 706) set %couleur.hlfond %c
elseif (%a == 707) set %couleur.hltexte %c
elseif (%a == 708) set %couleur.buddyfond %c
elseif (%a == 709) set %couleur.buddytexte %c
elseif (%a == 710) set %couleur.configfond %c
elseif (%a == 723) set %couleur.configtexte %c
elseif (%a == 725) set %couleur.mp3spectrum %c
}

alias slaps.list {
var %a = 1
while (%a <= $lines(script/bdd/slaps.tbl)) {
var %b = $read(script/bdd/slaps.tbl,%a)
did -a config 800 0 0 0 $gettok(%b,1,58) $+ $chr(9) $+ 0 0 0 $right($gettok(%b,2-,58),-3)
inc %a
}
}

on *:dialog:config:sclick:801:{
var %a = $?="Nom du slap :"
if (!%a) halt
var %b = $?="Slap : $+ $crlf $+ <nick> = pseudo du slap�"
if (!%b) halt
did -a config 800 0 0 0 %a $+ $chr(9) $+ 0 0 0 %b
write script/bdd/slaps.tbl %a : me %b
}

on *:dialog:config:sclick:802:{
if (!$did(config,800).sel) halt
write -dl $+ $calc($did(config,800).sel - 1) script/bdd/slaps.tbl
did -d config 800 $did(config,800).sel
}

on *:dialog:config:sclick:901:{
if ($did(config,901).seltext == -) halt
var %a = $dll(script/dll/nhtml.dll,navigate,$mircdir $+ script\aide\ $+ $did(config,901).seltext $+ .html)
}

on *:dialog:config:sclick:402:var %a = $input(<raison> = Raison du away $crlf <heure> = Heure du d�part,oi,Infos)
on *:dialog:config:sclick:405:var %a = $input(<raison> = Raison du away $crlf <temps> = Temps d'absence,oi,Infos)
on *:dialog:config:sclick:408:var %a = $input(<titre> = Titre du morceau $crlf <artiste> = Artiste $crlf <temps> = Dur�e de la musique $crlf <size> = Taille de la musique $crlf <bitrate> = Qualit� du mp3 $crlf <mode> = stero $+ $chr(44) mono $+ $chr(44) ... $crlf <sample> = sample wave,oi,Infos)
on *:dialog:config:sclick:411:var %a = $input(<nom> = Titre de l'info $crlf <info> = Description,oi,Infos)
on *:dialog:config:sclick:414:var %a = $input(<ip> $+ $chr(44) <nom> $+ $chr(44) <jeu> $+ $chr(44) <ping> $+ $chr(44) <mod> $+ $chr(44) <map> $+ $chr(44) <joueurs>,oi,Serveur)

on *:dialog:config:sclick:1700:{
if ($did(config,1700).state) did -e config 1701,1702,1703,1708
else did -b config 1701,1702,1703,1708
}

on *:dialog:config:sclick:1704:{
if ($did(config,1704).state) did -e config 1705,1706
else did -b config 1705,1706
}

alias antipv.demande {
var %demande = $input($1 aimerait dialoguer en priv� avec vous : $crlf $+ $crlf $+ $2-,qyv,Anti priv�)
if (%demande == $yes) { 
query2 $1
if (%antipv.informer) .msg $1 Le priv� a �t� accept�.
.timer.antipv. $+ $1 off
.timer.antipv.accept. $+ $1 1 600 return
}
else {
if (%antipv.informer) .msg $1 Le priv� a �t� refus�.
}
}

on ^*:open:?:{
if (($nick == $me) && ($1 = antiidle)) halt
if (%antipv) {
if (($len($nick) == 1) || ($nick == -psyBNC) || ($nick == irix)) goto accept
if ($timer(.antipv.accept. $+ $nick)) goto accept
if ($timer(.antipv. $+ $nick)) halt
.timer.antipv. $+ $nick 1 600 return
if ((%antipv.message) && (%antipv.message.msg)) .msg $nick %antipv.message.msg
if (%antipv.demande) .timer.antipv. $+ $nick -m 1 1 antipv.demande $nick $1-
sons.play 2
halt
}
elseif (%antipv.repondeur) {
if (($len($nick) == 1) || ($nick == -psyBNC) || ($nick == irix)) goto accept
if ((!$away) && (%antipv.repondeur.msg)) .timer $+ $ticks -m 1 1 msg $nick %antipv.repondeur.msg
elseif (($away) && (%antipv.repondeur.msg) && (%antipv.repondeur.away)) .timer $+ $ticks 1 1 msg $nick %antipv.repondeur.msg
}
:accept
sons.play 2
}

on !*:kick:#:if ($knick == $me) sons.play 1
on !*:op:*:if (($opnick == $me) && ($len($nick) > 1)) sons.play 3
on !*:deop:*:if ($opnick == $me) sons.play 4
on !*:voice:*:if (($vnick == $me) && ($len($nick) > 1)) sons.play 5
on !*:devoice:*:if ($vnick == $me) sons.play 6
ctcp *:*:*:sons.play 7
on *:invite:#:sons.play 8

alias modules.refresh {
did -r config 1200
var %a = $findfile(script/modules/,*?.exm,0,did -a config 1200 0 0 0 $iif($script($nopath($1-)),2,0) $nopath($1-) $+ $chr(9) $+ 0 0 0 $mid($read($1-,1),2,50))
}

on *:dialog:config:dclick:1000:{
dialog $iif($dialog(autojoin),-v,-m) autojoin autojoin
did -o autojoin 50 1 $did(config,1000).sel
did -i autojoin 6 0 $gettok($gettok($did(config,1000).seltext,1,9),6-,32)
did -o autojoin 4 1 $gettok($gettok($did(config,1000).seltext,2,9),5-,32)
did -o autojoin 5 1 $$gettok($gettok($did(config,1000).seltext,3,9),5-,32)
}

on *:dialog:config:sclick:1003:{
dialog $iif($dialog(autojoin),-v,-m) autojoin autojoin
did -r autojoin 50
}
on *:dialog:config:sclick:1004:did -d config 1000 $$did(config,1000).sel

on *:dialog:config:sclick:1001,1501:{
var %did = $calc($did - 1)
if (($did(config,%did).sel < 3) || (!$did(config,%did).sel)) halt
var %ligne = $did(config,%did).seltext
var %nombre = $did(config,%did).sel
did -d config %did %nombre
did -i config %did $calc(%nombre - 1) $replace(%ligne,+fs,+)
did -c config %did $calc(%nombre - 1)
}

on *:dialog:config:sclick:1002,1502:{
var %did = $calc($did - 2)
if (($did(config,%did).sel == $did(config,%did).lines) || (!$did(config,%did).sel)) halt
var %ligne = $did(config,%did).seltext
var %nombre = $did(config,%did).sel
did -d config %did %nombre
did -i config %did $calc(%nombre + 1) $replace(%ligne,+fs,+)
did -c config %did $calc(%nombre + 1)
}

on *:dialog:config:dclick:1100:{
dialog $iif($dialog(autoauth),-v,-m) autoauth autoauth
did -o autoauth 50 1 $did(config,1100).sel
did -i autoauth 6 0 $gettok($gettok($did(config,1100).seltext,1,9),6-,32)
did -o autoauth 4 1 $gettok($gettok($did(config,1100).seltext,2,9),5-,32)
}

on *:dialog:config:sclick:1101:{
dialog $iif($dialog(autoauth),-v,-m) autoauth autoauth
did -r autoauth 50
}
on *:dialog:config:sclick:1102:did -d config 1100 $$did(config,1100).sel

on *:dialog:config:sclick:1411:{
if ($did(config,1411).state == 0) did -b config 1403
else did -e config 1403
}

dialog autojoin {
title "Auto Join"
size -1 -1 222 120
icon $taskbar
option pixels
combo 6, 95 8 120 130, size edit drop
edit "", 4, 94 32 122 21, autohs
edit "", 5, 94 57 122 21, autohs
button "Ok", 8, 107 94 49 21, default
button "Annuler", 9, 156 94 61 21, cancel
text "R�seau :", 1, 8 10 50 16
text "Channel :", 2, 8 35 50 16
text "Mot de passe :", 3, 8 59 80 16
box "", 7, -14 -14 246 102
edit "", 50, -10 -10 1 1, hide
}

on *:dialog:auto????:init:*:{
dll script/mdx/mdx.dll SetMircVersion $version
dll script/mdx/mdx.dll MarkDialog $dname
var %a = 1
while (%a <= $server(0)) {
var %group = $server(%a).group
if ((%group !isnum) && (!$didwm($dname,6,%group))) did -a $dname 6 $server(%a).group
inc %a
}
did -c $dname 6 1
did -f $dname 4
if ($dname == autojoin) {
did -i autojoin 6 0 %autojoin.reseau
did -a autojoin 4 $chr(35)
}
if ($dname == autoauth) did -i autoauth 6 0 %autoauth.reseau
}

on *:dialog:autojoin:sclick:8:{
if ((!$did(autojoin,6)) || (!$did(autojoin,4))) halt
if (!$did(autojoin,50)) {
did -a config 1000 0 0 0 0 $did(autojoin,6) $+ $chr(9) $+ 0 0 0 $did(autojoin,4) $+ $chr(9) $+ 0 0 0 $did(autojoin,5)
set %autojoin.reseau $did(autojoin,6)
}
else {
did -o config 1000 $did(autojoin,50) 0 0 0 0 $did(autojoin,6) $+ $chr(9) $+ 0 0 0 $did(autojoin,4) $+ $chr(9) $+ 0 0 0 $did(autojoin,5)
}
dialog -x autojoin
dialog -v config
}

dialog autoauth {
title "Auto Auth"
size -1 -1 270 96
icon $taskbar
option pixels
combo 6, 95 8 170 130, size edit drop
edit "", 4, 94 32 172 21, autohs
button "Ok", 8, 155 70 49 21, default
button "Annuler", 9, 204 70 61 21, cancel
text "R�seau :", 1, 8 10 50 16
text "Commande :", 2, 8 34 66 16
box "Group Box", 7, -24 -39 316 102
edit "", 50, -10 -10 1 1, hide
}

on *:dialog:autoauth:sclick:8:{
if ((!$did(autoauth,6)) || (!$did(autoauth,4))) halt
if (!$did(autoauth,50)) {
did -a config 1100 0 0 0 2 $did(autoauth,6) $+ $chr(9) $+ 0 0 0 $did(autoauth,4)
set %autoauth.reseau $did(autoauth,6)
}
else {
did -o config 1100 $did(autoauth,50) 0 0 0 $gettok($did(config,1100,$did(autoauth,50)),5,32) $did(autoauth,6) $+ $chr(9) $+ 0 0 0 $did(autoauth,4)
}
dialog -x autoauth
dialog -v config
}

alias autojoin.liste {
var %a = 1
while (%a <= $lines(script/bdd/autojoin.tbl)) {
var %ligne = $read(script/bdd/autojoin.tbl,%a)
if ($gettok($gettok(%ligne,1,9),6-,32) == $network) {
var %chan = $gettok($gettok(%ligne,2,9),5,32)
var %pass = $gettok($gettok(%ligne,3,9),5,32)
var %channels = %channels $+ $chr(44) $+ %chan
if (%pass) var %password = %password $+ $chr(44) $+ %pass
}
inc %a
}

if (!%channels) halt

var %channels = $right(%channels,-1)
var %password = $right(%password,-1)

return %channels %password
}

on *:connect:{
var %a = 1
while (%a <= $lines(script/bdd/autoauth.tbl)) {
var %ligne = $read(script/bdd/autoauth.tbl,%a)
if (($gettok($gettok(%ligne,1,9),6-,32) == $network) && ($gettok($gettok(%ligne,1,9),5,32) == 2)) $gettok($gettok(%ligne,2,9),5-,32)
inc %a
}

if (%autoauth.x) var %mode = x
if (%invisible) var %mode = %mode $+ i
if (%mode) .mode $me + $+ %mode

if (%autojoin) .timer.autojoin $+ $cid 1 2 join $autojoin.liste
}

alias auth {
var %a = 1
while (%a <= $lines(script/bdd/autoauth.tbl)) {
var %ligne = $read(script/bdd/autoauth.tbl,%a)
if ($gettok($gettok(%ligne,1,9),6-,32) == $network) $gettok($gettok(%ligne,2,9),5-,32)
inc %a
}

if (%autoauth.x) .mode $me +x
}

alias autojoin join $$autojoin.liste

on *:dialog:config:sclick:1400:{
var %icone = $gettok($did(config,1400),5-,32)
set %toolbar %icone
if (!$dialog(toolbar)) halt
var %a = 1
while (%a <= 14) {
did -i toolbar 1 1 setimage %a icon small $calc(%a - 1) $+ ,script/icone/toolbar/ $+ %icone $+ .icl
inc %a
}
did -h toolbar 1
did -v toolbar 1
}

on *:dialog:config:sclick:1401:{
set %taskbar $gettok($did(config,1401),5-,32)
dll script/dll/mircustom.dll SetIcon -m script/icone/taskbar/ $+ %taskbar $+ .ico
var %a = 1
while (%a <= $dialog(0)) {
dll script/mdx/mdx.dll SetDialog $dialog(%a) icon $taskbar
inc %a
}
}

on *:dialog:config:sclick:1402:{
var %icone = $gettok($did(config,1402),5-,32)
set %mp3.icone %icone
if (!$dialog(mp3)) halt
var %a = 1
while (%a <= 6) {
did -i mp3 17 1 setimage %a icon small $calc(%a - 1) $+ ,script/icone/mp3/ $+ %icone $+ .icl
inc %a
}
did -h mp3 17
did -v mp3 17
}

on *:dialog:config:sclick:1801,1901:did -a config $calc($did - 1) $$input(Message de $iif($did == 1901,kick,quit),e,Message)

on *:dialog:config:sclick:1803:did -d config 1800 $$did(config,1800).sel
on *:dialog:config:sclick:1903:did -d config 1900 $$did(config,1900).sel

on *:dialog:config:dclick:1800:did -o config 1800 $did(config,1800).sel $$input(Message de quits,e,Message,$did(config,1800).seltext)
on *:dialog:config:dclick:1900:did -o config 1900 $did(config,1900).sel $$input(Message de quits,e,Message,$did(config,1900).seltext)

on *:dialog:config:sclick:1802:did -o config 1800 $$did(config,1800).sel $$input(Message de quits,e,Message,$$did(config,1800).seltext)
on *:dialog:config:sclick:1902:did -o config 1900 $$did(config,1900).sel $$input(Message de quits,e,Message,$$did(config,1900).seltext)

alias msg.kick if (%message.kick) return $read(script/bdd/kicks.tbl)
alias msg.quit if (%message.quit) return $read(script/bdd/quits.tbl)

on *:dialog:config:sclick:2001:{
if ($did(config,2001).state) did -e config 2002
else did -b config 2002
}

on *:dialog:config:sclick:2008:{
if ($did(config,2008).state) did -e config 2009
else did -b config 2009
}

on *:dialog:config:sclick:2010:{
if ($did(config,2010).state) did -e config 2011
else did -b config 2011
}

alias antiidle {
if (!%antiidle) halt
var %a = 1
while (%a <= $scon(0)) {
if ($scon(%a).status == connected) {
var %away = $scon(%a).away
if (%antiidle.sel == 3) scon %a .raw PRIVMSG $scon(%a).me :antiidle
elseif ((%antiidle.sel == 1) && (%away)) scon %a .raw PRIVMSG $scon(%a).me :antiidle
elseif ((%antiidle.sel == 2) && (!%away)) scon %a .raw PRIVMSG $scon(%a).me :antiidle
}
inc %a
}
}

on ^*:text:antiidle:?:halt

alias titlebar.refresh {
scid $activecid
var %titre = $replace(%titlebar,<net>,$network,<mp3>,$iif($left($nopath($iif($dialog(mp3),$did(mp3,101))),-4),$left($nopath($iif($dialog(mp3),$did(mp3,101))),-4),Pas de mp3),<idle>,$duration($idle),<lag>,%lagbar.ping,<heure>,$time,<nick>,$me)
dll script/dll/mircustom.dll Titlebar -m %titre
}

on *:join:#:if (($nick == $me) && (%autojoin.ial)) .raw who #

on *:dialog:config:sclick:1503:dialog $iif($dialog(autoconnect),-v,-m) autoconnect autoconnect
on *:dialog:config:sclick:1504:did -d config 1500 $$did(config,1500).sel

on *:dialog:config:dclick:1500:{
scid $activecid
var %ligne = $did(config,1500).seltext
.server $iif($status != disconnected,-m) $gettok($gettok(%ligne,1,9),6-,32) $gettok($gettok(%ligne,2,9),5-,32)
}

dialog autoconnect {
title "Favoris"
size -1 -1 270 96
option pixels
icon $taskbar
edit "", 6, 94 7 172 21
edit "", 4, 94 32 172 21, autohs
button "Ok", 8, 155 70 49 21, default
button "Annuler", 9, 204 70 61 21, cancel
text "Adresse :", 1, 8 10 60 16
text "Mot de passe :", 2, 8 34 80 16
box "Group Box", 7, -24 -39 316 102
}

on *:dialog:autoconnect:sclick:8:{
if (!$did(autoconnect,6)) halt
did -a config 1500 0 0 0 0 $did(autoconnect,6) $+ $chr(9) $+ $did(autoconnect,4)
dialog -x autoconnect
}

alias autoconnect {
var %a = 1
var %b = 1
while (%a <= $lines(script/bdd/autoconnect.tbl)) {
var %ligne = $read(script/bdd/autoconnect.tbl,%a)
if ($gettok($gettok(%ligne,1,9),5,32) == 2) {
.server $iif(%b != 1,-m) $gettok($gettok(%ligne,1,9),6-,32) $gettok($gettok(%ligne,2,9),5-,32)
inc %b
}
inc %a
}
}

dialog about {
title "Cr�dits"
size -1 -1 180 164
icon $taskbar
option pixels
button "Ok", 12, 106 139 71 21, Ok
icon 1, 8 3 32 32, script/icone/panel.icl , 13, noborder
text "easy-X 1.5", 2, 49 16 58 16
box "", 3, -14 33 250 100
text "Cr�ateur :", 4, 8 49 54 16
text "PaSsWoRd", 6, 63 49 56 16
link "password@nexmail.ch", 5, 63 64 110 16
text "Site :", 7, 8 87 30 16
link "http://www.easy-X.tk", 8, 63 87 110 16
text "Irc :", 9, 8 110 24 16
text "#easy-X @ QuakeNet", 10, 63 110 110 16
}

alias about dialog $iif($dialog(about),-v,-m) about about

on *:dialog:about:sclick:5:run mailto:password@nexmail.ch
on *:dialog:about:sclick:8:url -an http://www.easy-X.tk
on *:dialog:about:init:*:{
dll script/mdx/mdx.dll SetMircVersion $version
dll script/mdx/mdx.dll MarkDialog about
}

alias vdownload {
if ($isid) {
if ($0 < 5) return Manque des param�tres
if ($1 == _) var %u = $r(a,z) $+ $r(1,9999) $+ $r(a,z) $+ $r(a,z) $+ $r(1,99) $+ $r(a,z)
else { if ($sock(download_ $+ $1)) return Erreur! Socket d�ja ouvert! | var %u = $1 }
if ($2 != _) hadd -m vdownload %u $+ _progs $2
if ($3 != _) hadd -m vdownload %u $+ _fin $3
hadd -m vdownload %u $+ _host $gettok($iif($mid($4,1,7) == http:// && $len($4) > 7,$mid($4,8),$4),1,47)
hadd vdownload %u $+ _file / $+ $gettok($iif($mid($4,1,7) == http:// && $len($4) > 7,$mid($4,8),$4),2-,47)
hadd vdownload %u $+ _dest $5-
hadd vdownload %u $+ _tm $iif($findtok(bin txt,$prop,32),$prop,auto)
sockopen vdownload_ $+ %u $hget(vdownload,%u $+ _host) 80
return OK
}
else {
if (!$1) goto end
sockclose vdownload_ $+ $1-
var %i = 0 , %imax = $fopen(0)
while (%i < %imax) { inc %i | if (vdownload_ $+ $1- iswm $fopen(%i)) { var %o = $fopen(%i) , %u = $fopen(%o).fname | .fclose %o | .remove " $+ %u $+ " | dec %i | dec %imax } }
if ($hget(vdownload)) {
hdel -w vdownload $1- $+ _*
if (!$hget(vdownload,0).item) .hfree vdownload
}
.timervdownload_ $+ $1- off
}
:end
}
on *:sockopen:vdownload_*:{
var %u = $gettok($sockname,2-,95)
if ($sockerr) { echo $color(info)Erreur ! (1) | vdownload %u | halt }
sockwrite -n $sockname GET $hget(vdownload,%u $+ _file) HTTP/1.0
sockwrite -n $sockname HOST: $hget(vdownload,%u $+ _host)
sockwrite -n $sockname $crlf
hadd vdownload %u $+ _header no
hadd vdownload %u $+ _prog 0 | hadd vdownload %u $+ _tt 0
hadd vdownload %u $+ _taux 0
}
on *:sockread:vdownload_*:{
var %u = $gettok($sockname,2,95)
if ($hget(vdownload,%u $+ _header) == no) {
var %a
sockread %a
if (Content-Type: * iswm %a) {
hadd vdownload %u $+ _type $gettok(%a,2-,58)
if ($hget(vdownload,%u $+ _tm) == auto) {
if (text/plain isin $hget(vdownload,%u $+ _type)) || (text/html isin $hget(vdownload,%u $+ _type)) hadd vdownload %u $+ _tm txt
else hadd vdownload %u $+ _tm bin
}
}
if (Content-Length: * iswm %a) hadd vdownload %u $+ _taille $gettok(%a,2-,58)
if (!%a) { hadd vdownload %u $+ _header yes | .timervdownload_ $+ %u 0 1 vdownloadtimer %u }
}
else {
if (!$fopen(vdownload_ $+ %u)) .fopen -no vdownload_ $+ %u " $+ $hget(vdownload,%u $+ _dest) $+ "
hinc vdownload %u $+ _prog $sock($sockname).rq
hinc vdownload %u $+ _tt $sock($sockname).rq
if ($hget(vdownload,%u $+ _progs)) $hget(vdownload,%u $+ _progs) $hget(vdownload,%u $+ _taille) $hget(vdownload,%u $+ _prog) $round($calc(($hget(vdownload,%u $+ _prog) / $hget(vdownload,%u $+ _taille)) *100) ,1) $+ % $hget(vdownload,%u $+ _taux)
if ($hget(vdownload,%u $+ _tm) == txt) {
var %b
:reading | sockread -f %b | if (!$sockbr) return | .fwrite vdownload_ $+ %u %b $crlf | goto reading
}
else { sockread &a | .fwrite -b vdownload_ $+ %u &a }
}
}

alias -l vdownloadtimer {
if ($hget(vdownload,0).item) {
hadd vdownload $1 $+ _taux $hget(vdownload,$1 $+ _tt) | hadd vdownload $1 $+ _tt 0
}
}
on *:sockclose:vdownload_*:{
if ($fopen($sockname)) .fclose $sockname
var %u = $gettok($sockname,2,95) , %fin = $hget(vdownload,$gettok($sockname,2-,95) $+ _fin)
if ($hget(vdownload)) hdel -w vdownload %u $+ _*
if (!$hget(vdownload,0).item) .hfree -w vdownload
.timervdownload_ $+ %u off
if (%fin) %fin
}

on *:dialog:config:sclick:1202:var %i = $vdownload(check.update $+ $ticks,_,.timer.versioncheck -m 1 1 module.versioncheck,http://easy-x.furax.firstream.net/modules/info.txt,script/modules/info.txt)

alias module.versioncheck {
if ($read(script/modules/info.txt,1) != easy-X modules) { var %a = $input(Erreur : fichier corrompu,oi,Mise � jour) | .remove script/modules/info.txt | halt }
if ($read(script/modules/info.txt,2) <= %modules.update) { var %a = $input(Aucun mises � jour disponibles,oi,Mise � jour) | .remove script/modules/info.txt | halt }
var %a = $input(Des mises � jour sont disponibles. $crlf $+ Voulez vous les installer ? $+ $crlf $+ $crlf $+ Infos : $read(script/modules/info.txt,3),qyv,Mise � jour)
if (%a = $yes) {
var %i = $vdownload(download.update $+ $ticks,_,.timer.module.install -m 1 1 module.install,http://easy-x.furax.firstream.net/modules/modules.zip,script/modules.zip)
set %modules.update $read(script/modules/info.txt,2)
did -o config 1201 1 T�l�chargement en cours...
}
else .remove script/modules/info.txt
}

alias module.install {
var %z = $dll(script/dll/szip.dll,SUnZipFile,$mircdir $+ script\modules.zip > $mircdir $+ script\modules)
var %b = 1
while (%b <= $script(0)) {
if ($right($script(%b),4) == .exm) .reload -rs $+ %b $remove($script(%b),$mircdir)
inc %b
}
var %a = $input(Les mises � jour ont correctement �t� install�es.,io,Installation)
if ($read(script/modules/info.txt,4)) { $read(script/modules/info.txt,4) }
modules.refresh
did -o config 1201 1 Mise � jour termin�e
.remove script/modules.zip
.remove script/modules/info.txt
}