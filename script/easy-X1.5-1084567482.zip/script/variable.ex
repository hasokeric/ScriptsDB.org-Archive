%antiidle 0
%antiidle.sel 1
%antipv 0
%antipv.demande 0
%antipv.informer 0
%antipv.message 1
%antipv.message.msg Votre priv� a �t� ignor�.
%antipv.repondeur 0
%antipv.repondeur.away 1
%antipv.repondeur.msg J'arrive 2sec :)
%autoauth.reseau QuakeNet
%autoauth.x 0
%autoconnect 0
%autojoin 0
%autojoin.ial 1
%autojoin.reseau QuakeNet
%away.all 1
%away.autoaway 0
%away.autoaway.min 120
%away.mp3 0
%away.msg est away : <raison>
%away.nick
%away.pager 1
%away.retour est de retour apr�s <temps> : <raison>
%away.say 1
%buddy.dock 0
%buddy.dockside Gauche
%buddy.h 327
%buddy.x 371
%buddy.y 216
%correcteur 0
%couleur.buddyfond 16249584
%couleur.buddytexte 0
%couleur.configfond 11184810
%couleur.configtexte 0
%couleur.hlfond 16777215
%couleur.hltexte 0
%couleur.lagbarbarre 14603723
%couleur.lagbarfond 0
%couleur.lagbartexte 0
%couleur.mp3fond 197379
%couleur.mp3spectrum 6274298
%couleur.mp3texte 13221541
%ctcp.finger 0
%ctcp.finger.reply
%ctcp.ping 0
%ctcp.ping.reply Pong
%ctcp.time 0
%ctcp.time.reply
%ctcp.version 1
%ctcp.version.reply easy-X v1.5 - www.easy-X.tk
%flood.avertir 0
%flood.Ban 0
%flood.Ban.action KickBan
%flood.Ban.fois 3
%flood.Ban.seconde 8
%flood.Ctcp 0
%flood.Ctcp.action Kick
%flood.Ctcp.fois 2
%flood.Ctcp.seconde 6
%flood.Ctcp2 0
%flood.Ctcp2.action Ignorer
%flood.Ctcp2.fois 2
%flood.Ctcp2.seconde 1
%flood.Deop 0
%flood.Deop.action Kick
%flood.Deop.fois 8
%flood.Deop.seconde 2
%flood.Devoice 0
%flood.Devoice.action Kick
%flood.Devoice.fois 18
%flood.Devoice.seconde 3
%flood.Invite 0
%flood.Invite.action Ignorer 10min
%flood.Invite.fois 3
%flood.Invite.seconde 6
%flood.Kick 0
%flood.Kick.action KickBan
%flood.Kick.fois 3
%flood.Kick.seconde 8
%flood.Notice 0
%flood.Notice.action Avertir
%flood.Notice.fois 4
%flood.Notice.seconde 2
%flood.Notice2 0
%flood.Notice2.action Ignorer 10min
%flood.Notice2.fois 50
%flood.Notice2.seconde 2
%flood.op 0
%flood.Pub 0
%flood.Pub.action Avertir
%flood.Pub.fois 1
%flood.Pub.seconde 1
%flood.Texte 0
%flood.Texte.action Avertir
%flood.Texte.fois 8
%flood.Texte.seconde 2
%flood.Texte2 0
%flood.Texte2.action Ignorer 10min
%flood.Texte2.fois 20
%flood.Texte2.seconde 2
%flood.voice 1
%gametiger.plein 0
%gametiger.vide 0
%hl.away 0
%hl.exe
%hl.h 271
%hl.mp3 0
%hl.msg joue � <jeu> sur <ip>
%hl.nick
%hl.param
%hl.pub 1
%hl.say 1
%info 5(<nom>5) <info>
%invisible 1
%lagbar 1
%lagbar.ping 16ms
%lagbar.ticks 189926058
%mail.sender
%mail.smtp
%mask.ban 2
%mask.ignore 5
%message.kick 1
%message.quit 1
%modules.update 1.5
%mp3.advertise 14mp3 �14 <artiste> -14 <titre> �14 (05<temps>14)
%mp3.dir C:\
%mp3.filtre
%mp3.h 385
%mp3.icone Classique
%mp3.playlist.bitrate 1
%mp3.playlist.couleur1 16119285
%mp3.playlist.couleur2 7692365
%mp3.playlist.couleur3 10587255
%mp3.playlist.couleur4 15985380
%mp3.playlist.couleur5 15786205
%mp3.playlist.couleur6 0
%mp3.playlist.mode 0
%mp3.playlist.num 0
%mp3.playlist.taille 1
%mp3.playlist.temps 1
%mp3.repeter 0
%mp3.shuffle 1
%mp3.spectrum 1
%mp3.x 525
%mp3.y 246
%nick.default
%nicklist.control 0
%nicklist.control.action Slaps
%nicklist.shift 0
%nicklist.shift.action Op
%panel 0
%portscan.end 65335
%portscan.nombre 1
%portscan.port 1
%portscan.start 1
%protection.ban 1
%protection.bot 1
%protection.deop 1
%taskbar easy-X
%titlebar easy-X
%toolbar HangOnBlue
%toolbar.a 1
%who 0