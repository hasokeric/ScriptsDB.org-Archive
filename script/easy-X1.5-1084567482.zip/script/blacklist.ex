alias blacklist dialog $iif($dialog(blacklist),-v,-m) blacklist blacklist

dialog blacklist {
title "Blacklist"
size -1 -1 343 210
icon $taskbar
option pixels
box "Liste", 1, 5 1 334 179
list 2, 14 17 316 129, size
button "Ajouter", 3, 181 151 73 21
button "Supprimer", 4, 257 151 73 21
button "Fermer", 5, 272 185 67 21, ok
}

dialog addbl {
title "Blacklist"
size -1 -1 216 88
option pixels
icon $taskbar
text "Masque :", 1, 5 8 48 16
text "Raison :", 2, 10 31 42 16
edit "", 3, 52 5 160 21, autohs
edit "", 4, 52 29 160 21, autohs
box "", 5, -6 50 226 8
button "Ok", 6, 165 63 47 21
button "Annuler", 7, 101 63 61 21, cancel
}

on *:dialog:addbl:sclick:6:{
var %a = $did(addbl,3)
if ((*?!*?@*? !iswm %a) || ($chr(32) isin %a)) { var %a = $input(Format d'adresse non valide !,oh,Blacklist) | halt }
if ($len(%a) < 6) { .echo -q $input(Sois plus precis !,oh,Blacklist) | halt }
blacklist.add %a $did(addbl,4)
dialog -x addbl
}

on *:dialog:blacklist:init:*:{
dll script/mdx/mdx.dll SetMircVersion $version 
dll script/mdx/mdx.dll MarkDialog blacklist
dll script/mdx/mdx.dll SetControlMDX 2 listview infotip showsel report single rowselect nosortheader > script/mdx/views.mdx
did -i blacklist 2 1 headerdims 144 150
did -i blacklist 2 1 headertext Masque $+ $chr(9) $+ Raison
var %a = 1
while (%a <= $hget(blacklist,0).item) {
did -a blacklist 2 0 0 0 $hget(blacklist,%a).item $+ $chr(9) $+ 0 0 0 $hget(blacklist,%a).data
inc %a
}
}

on *:dialog:blacklist:sclick:3:{
dialog $iif($dialog(addbl),-v,-m) addbl addbl
did -r addbl 3,4
}

on *:dialog:blacklist:sclick:4:{
if (!$did(blacklist,2).sel) halt
hdel blacklist $gettok($gettok($did(blacklist,2).seltext,1,9),6-,32)
did -d blacklist 2 $did(blacklist,2).sel
hsave -o blacklist script/bdd/blacklist.tbl
}

on !@*:join:#:{
var %f = 1
while (%f <= $hget(blacklist,0).item) {
var %address = $hget(blacklist,%f).item
var %raison = $hget(blacklist,%f).data
if (%address iswm $address($nick,5)) {
mode $chan +b-o %address $nick
kick $chan $nick %raison
break
}
inc %f
}
}

alias blacklist.add {
if ($hget(blacklist,$1)) { var %a = $input(Cette adresse �xiste d�j� dans la Blacklist,oh,Blacklist) | halt }
hadd blacklist $1 $iif($2,$2-,Blacklist)
if ($dialog(blacklist)) did -a blacklist 2 0 0 0 $1 $+ $chr(9) $+ 0 0 0 $iif($2,$2-,Blacklist)
scid -a blacklist.check
hsave -o blacklist script/bdd/blacklist.tbl
}

alias blacklist.check {
var %f = 1
while (%f <= $hget(blacklist,0).item) {
var %address = $hget(blacklist,%f).item
var %raison = $hget(blacklist,%f).data
var %a = 1
while (%a <= $chan(0)) {
if ($me isop $chan(%a)) {
var %b = 1
while (%b <= $nick($chan(%a),0)) {
if ((%address iswm $address($nick($chan(%a),%b),5)) && ($nick($chan(%a),%b) != $me)) {
mode $chan(%a) +b-o %address $nick($chan(%a),%b)
kick $chan(%a) $nick($chan(%a),%b) %raison
}
inc %b
}
}
inc %a
}
inc %f
}
}

on *:op:#:{
if ($opnick != $me) halt
var %f = 1
while (%f <= $hget(blacklist,0).item) {
var %address = $hget(blacklist,%f).item
var %raison = $hget(blacklist,%f).data
var %b = 1
while (%b <= $nick($chan,0)) {
if ((%address iswm $address($nick($chan,%b),5)) && ($nick($chan,%b) != $me)) {
mode $chan +b-o %address $nick($chan,%b)
kick $chan $nick($chan,%b) %raison
}
inc %b
}
inc %f
}
}

on !*:nick:blacklist.check

on !@*:unban:#:{
if ($hget(blacklist,$banmask) != $null) mode $chan +b $banmask
}