/op /mode # +ooo $$1 $2 $3
/dop /mode # -ooo $$1 $2 $3
/j /join #$$1 $2-
/p /part #
/n /names #$$1
/w /whois $$1
/k /kick # $$1 $2-
/q /query $$1
/send /dcc send $1 $2
/chat /dcc chat $1
/ping /ctcp $$1 ping
/s /server $$1-
F2 /config
F4 /theme
F5 /aw
F6 /back
F7 /mp3
F8 /hl
F9 /pcinfo
F10 /logs
F3 /buddy
F11 /lagbar.check