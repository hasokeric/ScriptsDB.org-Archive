on *:start:{
if ($version < 6.12) {
var %a = $input(mIRC 6.12 ou sup�rieur est requit pour que easy-X fonctionne !,oh,easy-X)
exit
}
dll script/dll/mircustom.dll SetIcon -m script/icone/taskbar/ $+ %taskbar $+ .ico
dll script/dll/motfv3.dll motfv Load
if (%toolbar) toolbar
echo -s easy-X 1.5
}

dialog toolbar {
title "toolbar"
size 0 3 2048 3
option pixels
list 1, 5 4 380 2, size
box "", 2, -4 -5 2400 40
text "lag", 3, 570 6 124 19, hide
text $network $+ , 5, 694 15 100 12, hide
text "Lag:", 4, 694 5 100 11, hide
}

alias toolbar {
if ($dialog(toolbar)) halt
if (!%toolbar.a) halt
dialog -m toolbar toolbar
dll script/dll/mdock.dll DockToolbar $dialog(toolbar).hwnd
dll script/mdx/mdx.dll SetMircVersion $version
dll script/mdx/mdx.dll MarkDialog toolbar
dll script/mdx/mdx.dll SetBorderStyle 1
dll script/mdx/mdx.dll SetDialog toolbar style
dll script/mdx/mdx.dll SetControlMDX 1 ToolBar flat list nodivider arrows > script\mdx\bars.mdx
dll script/mdx/mdx.dll SetControlMDX 3 ProgressBar smooth > script\mdx\ctl_gen.mdx
dll script/mdx/mdx.dll SetFont 4,5 11 400 Tahoma
dll script/mdx/mdx.dll SetColor 4,5 text %couleur.lagbartexte
dll script/dll/tbwin.dll Attach @lagbar
dll script/dll/tbwin.dll OnSize /lagbar.resize
lagbar.resize $calc($window(-2).w - 6)
did -a toolbar 3 BGColor %couleur.lagbarfond
did -a toolbar 3 BarColor %couleur.lagbarbarre
did -i toolbar 1 1 bmpsize 16 16
did -i toolbar 1 1 pad 6 6
did -i toolbar 1 1 setimage +nhd 0 icon small 0,script/icone/toolbar/ $+ %toolbar $+ .icl
did -i toolbar 1 1 setimage +nhd 0 icon small 1,script/icone/toolbar/ $+ %toolbar $+ .icl
did -i toolbar 1 1 setimage +nhd 0 icon small 2,script/icone/toolbar/ $+ %toolbar $+ .icl
did -i toolbar 1 1 setimage +nhd 0 icon small 3,script/icone/toolbar/ $+ %toolbar $+ .icl
did -i toolbar 1 1 setimage +nhd 0 icon small 4,script/icone/toolbar/ $+ %toolbar $+ .icl
did -i toolbar 1 1 setimage +nhd 0 icon small 5,script/icone/toolbar/ $+ %toolbar $+ .icl
did -i toolbar 1 1 setimage +nhd 0 icon small 6,script/icone/toolbar/ $+ %toolbar $+ .icl
did -i toolbar 1 1 setimage +nhd 0 icon small 7,script/icone/toolbar/ $+ %toolbar $+ .icl
did -i toolbar 1 1 setimage +nhd 0 icon small 8,script/icone/toolbar/ $+ %toolbar $+ .icl
did -i toolbar 1 1 setimage +nhd 0 icon small 9,script/icone/toolbar/ $+ %toolbar $+ .icl
did -i toolbar 1 1 setimage +nhd 0 icon small 10,script/icone/toolbar/ $+ %toolbar $+ .icl
did -i toolbar 1 1 setimage +nhd 0 icon small 11,script/icone/toolbar/ $+ %toolbar $+ .icl
did -i toolbar 1 1 setimage +nhd 0 icon small 12,script/icone/toolbar/ $+ %toolbar $+ .icl
did -i toolbar 1 1 setimage +nhd 0 icon small 13,script/icone/toolbar/ $+ %toolbar $+ .icl
did -a toolbar 1 +a 1 	Connexion
did -a toolbar 1 +a -
did -a toolbar 1 +a 3 	Options
did -a toolbar 1 +a -
did -a toolbar 1 +a 4 	Configuration
did -a toolbar 1 +a 5 	Away
did -a toolbar 1 +a 6 	PC Infos
did -a toolbar 1 +a 7 	Th�mes
did -a toolbar 1 +a -
did -a toolbar 1 +a 8 	Mp3 Player
did -a toolbar 1 +a 9 	Half-life
did -a toolbar 1 +a -
did -a toolbar 1 +a 10 	Buddylist
did -a toolbar 1 +a 11 	Blacklist
did -a toolbar 1 +a 12 	Protections
did -a toolbar 1 +a 13 	Logs
did -a toolbar 1 +a -
did -a toolbar 1 +a 14 	Cr�dits
if ($status == connected) && (%lagbar) lagbar.check
}

on *:dialog:toolbar:sclick:1:{
var %a = $did(toolbar,1).sel
if (%a == 2) { 
scid $activecid
if (($status == connected) || ($status == connecting)) quit
else server
toolbar.refresh
}
elseif (%a == 4) dll script/dll/sendkey.dll ALT O
elseif (%a == 6) config
elseif (%a == 7) aw
elseif (%a == 8) pcinfo
elseif (%a == 9) theme
elseif (%a == 11) mp3
elseif (%a == 12) hl
elseif (%a == 14) buddy
elseif (%a == 15) blacklist
elseif (%a == 16) protection
elseif (%a == 17) logs
elseif (%a == 19) about
}

on *:active:*:{
toolbar.refresh
if ($status != connected) && ($dialog(toolbar)) did -h toolbar 3,4,5
if ($status == connected) && (%toolbar) && (%lagbar) did -v toolbar 3,4,5
did -o toolbar 5 1 $$iif($network,$network,$server)
if ($window($active).cid != $window($lactive).cid) lagbar.check
elseif ($active == $lactive) lagbar.check
if ($dialog(toolbar)) did -o toolbar 4 1 $$did(toolbar,4)
buddy.refresh
}

on *:disconnect:{
toolbar.refresh
if ($dialog(toolbar)) did -h toolbar 3,4,5
}
on *:connect:{
if (%lagbar) && ($dialog(toolbar)) did -v toolbar 3,4,5
lagbar.check
toolbar.refresh
dll script/dll/motfv3.dll motfv Sync
}

alias toolbar.refresh {
if (!$dialog(toolbar)) halt
scid $activecid
if ($status == disconnected) did -o toolbar 1 2 +a 1 	Connexion
elseif ($status == connecting) did -o toolbar 1 2 +a 2 	D�connexion
else did -o toolbar 1 2 +a 2 	D�connexion
}

alias lagbar.update {
if ($1 < 1000) var %ping = $1 $+ ms
else var %ping = $calc($1 /1000) $+ s
if (!$1) { var %ping = none | var %num = 1 }
else var %num = $1 / 10
set %lagbar.ping %ping
if (!$dialog(toolbar)) halt
if (%num < 1) %num = 1
if (%num > 100) %num = 100
did -a toolbar 3 $int(%num) 0 100
did -o toolbar 5 1 $iif($network,$network,$server)
did -o toolbar 4 1 Lag: %ping
}

alias lagbar.check {
scid $activecid
if ($status == connected) {
var %ticks = $ticks
set %lagbar.ticks %ticks
.raw ping %ticks
.timer.lagbar 1 8 lagbar.check
}
}

alias lagbar.resize {
if (!$dialog(toolbar)) halt
did -h toolbar 3,4,5
dll script/mdx/mdx.dll MoveControl toolbar 3 $calc($1 - 206) * * *
dll script/mdx/mdx.dll MoveControl toolbar 4 $calc($1 - 77) * * *
dll script/mdx/mdx.dll MoveControl toolbar 5 $calc($1 - 77) * * *
if (%lagbar) && ($status == connected) && ($dialog(toolbar)) did -v toolbar 3,4,5
}

on ^*:pong:{
haltdef
if (($scid($activecid).network == $network) && ($2 isnum)) lagbar.update $calc($ticks - $2)
else lagbar.update $calc($ticks - %lagbar.ticks)
}

alias massmode {
var %a = 1
while (%a <= $gettok($2-,0,32)) {
mode # $1 $gettok($2-,%a $+ - $+ $calc(%a + 6),32)
inc %a 6
}
}

alias masskick {
var %a = 1
while (%a <= $gettok($1,0,44)) {
.raw kick # $gettok($1,%a,44) : $+ $iif($2-,$2-,$msg.kick)
inc %a
}
}

alias masskickban {
var %a = 1
while (%a <= $gettok($1,0,44)) {
.raw mode # +b-o $address($gettok($1,%a,44),%mask.ban) $gettok($1,%a,44)
.raw kick # $gettok($1,%a,44) : $+ $iif($2-,$2-,$msg.kick)
inc %a
}
}

alias masstimeban {
var %minute = $?="Bannir combien de minutes :", %a = 1
while (%a <= $gettok($1,0,44)) {
.raw mode # +b-o $address($gettok($1,%a,44),%mask.ban) $gettok($1,%a,44)
.timer $+ $ticks 1 $calc(%minute * 60) mode # -b $address($gettok($1,%a,44),2)
.raw kick # $gettok($1,%a,44) : $+ $2- %minute $+ min ban
inc %a
}
}

ctcp *:*:{
if ($1 == motfv) {
if ((%ctcp.version) && (%ctcp.version.reply)) { .ctcpreply $nick VERSION %ctcp.version.reply }
halt
}
elseif ($1 == finger) {
if ((%ctcp.finger) && (%ctcp.finger.reply)) { .ctcpreply $nick FINGER %ctcp.finger.reply }
halt
}
elseif ($1 == time) {
if ((%ctcp.time) && (%ctcp.time.reply)) { .ctcpreply $nick TIME %ctcp.time.reply }
halt
}
elseif ($1 == ping) {
if ((%ctcp.ping) && (%ctcp.ping.reply)) { .ctcpreply $nick PING %ctcp.ping.reply }
halt
}
}

alias logs {
scid $activecid
var %b = $remove($logdir,$mircdir) $+ $nopath($window($active).logfile)
if ($window(@logs)) window -c @logs
window -Sak0l17 @Logs
var %a = 1
var %f = $findfile($logdir,*.log,0,aline -l @logs $left($nopath($1-),-4))
if ($isfile(%b)) { .loadbuf -pr @logs %b | renwin @Logs @Logs $nopath(%b) }
}

menu @logs {
dclick {
if ($1) loadbuf -pr @logs logs/ $+ $line(@logs,$1,1) $+ .log
renwin @Logs @Logs $line(@logs,$1,1) $+ .log
}
Fermer:window -c $window($active)
}

alias theme dialog $iif($dialog(kte_load),-v,-m) kte_load theme

alias slaps {
if ($1 == end) return -
if ($1 == begin) return -
if ($1 <= $lines(script/bdd/slaps.tbl)) return $replace($read(script/bdd/slaps.tbl,$1),<nick>,$replace($2,$chr(44),$chr(32)))
}

alias exm.menubar {
if ($1 == end) return -
if ($1 == begin) return -
if ($hget(exm.menubar,$1).data) return $hget(exm.menubar,$1).data
}

alias exm.channel {
if ($1 == end) return -
if ($1 == begin) return -
if ($hget(exm.channel,$1).data) return $hget(exm.channel,$1).data
}

alias exm.nicklist {
if ($1 == end) return -
if ($1 == begin) return -
if ($hget(exm.nicklist,$1).data) return $hget(exm.nicklist,$1).data
}

alias clones {
echo # 
kte_echo # Clonescan pour #
var %clones,%a = 1,%b = 1
while (%a <= $ialchan(*!*@*,#,0)) {
var %host = $gettok($ialchan(*!*@*,#,%a),2,64)
if (($ialchan(*!*@ $+ %host,#,0) > 1) && (!$istok(%clones,%host,44))) {
var %clones = $addtok(%clones,%host,44)
inc %b
kte_echo # ( $+ $gettok($ialchan(*!*@*,#,%a),2,64) $+ ) (Clones : $ialchan(*!*@ $+ %host,#,1).nick $ialchan(*!*@ $+ %host,#,2).nick $ialchan(*!*@ $+ %host,#,3).nick $ialchan(*!*@ $+ %host,#,4).nick $ialchan(*!*@ $+ %host,#,5).nick $ialchan(*!*@ $+ %host,#,6).nick $ialchan(*!*@ $+ %host,#,7).nick $ialchan(*!*@ $+ %host,#,8).nick $+ )
}
inc %a
}
if (%b > 1) kte_echo # Clonescan termin�
else kte_echo # Pas de clones trouv�s
echo # 
}

alias comchan2 {
var %a = 1
while (%a <= $comchan($1,0)) {
if ($1 isreg $comchan($1,%a)) var %prefix = $null
else var %prefix = $left($nick($comchan($1,%a),$1).pnick,1)
var %comchan = %comchan %prefix $+ $comchan($1,%a)
inc %a
}
return %comchan
}

on !*:open:?:{
var %a = 1
var %comchan = $comchan2($nick)
kte_echo $nick Query avec : $nick
if ($address($nick,0)) kte_echo $nick Host : $replace($address($nick,0),*!,)
if (%comchan) kte_echo $nick Channels communs : %comchan
echo $nick 
}

alias query2 {
if (($mouse.key & 4) && (%nicklist.shift)) {
if (%nicklist.shift.action == Op) mode # +o $1
elseif (%nicklist.shift.action == Deop) mode # -o $1
elseif (%nicklist.shift.action == Hop) mode # +h $1
elseif (%nicklist.shift.action == Dehop) mode # -h $1
elseif (%nicklist.shift.action == Voice) mode # +v $1
elseif (%nicklist.shift.action == Devoice) mode # -v $1
elseif (%nicklist.shift.action == Kick) masskick $1
elseif (%nicklist.shift.action == Kickban) masskickban $1
elseif (%nicklist.shift.action == Slaps) me slaps $1 around a bit with a large trout
elseif (%nicklist.shift.action == Whois) whois $1 $1
elseif (%nicklist.shift.action == Buddylist) buddy.add $1
elseif (%nicklist.shift.action == Version) ctcp $1 version
}

elseif (($mouse.key & 2) && (%nicklist.control)) {
if (%nicklist.control.action == Op) mode # +o $1
elseif (%nicklist.control.action == Deop) mode # -o $1
elseif (%nicklist.control.action == Hop) mode # +h $1
elseif (%nicklist.control.action == Dehop) mode # -h $1
elseif (%nicklist.control.action == Voice) mode # +v $1
elseif (%nicklist.control.action == Devoice) mode # -v $1
elseif (%nicklist.control.action == Kick) masskick $1
elseif (%nicklist.control.action == Kickban) masskickban $1
elseif (%nicklist.control.action == Slaps) me slaps $1 around a bit with a large trout
elseif (%nicklist.control.action == Whois) whois $1 $1
elseif (%nicklist.control.action == Buddylist) buddy.add $1
elseif (%nicklist.control.action == Version) ctcp $1 version
}

elseif (!$window($1)) {
var %a = 1
var %comchan = $comchan2($1)
query $1
kte_echo $1 Query avec : $1
if ($address($1,0)) kte_echo $1 Host : $replace($address($1,0),*!,)
if (%comchan) kte_echo $1 Channels communs : %comchan
echo $1 
}
else {
query $1
}
}

alias who {
if ($1 != $null) {
set %who 1
.raw who $1
}
else {
if ($chan != $null) { set %who 1 | .raw who $chan }
}
}

alias whois {
set -u3 %whois 1
.raw whois $1-
}

raw 301:* {
if (%whois == $null) halt
}
raw 318:* {
unset %whois
}

raw 352:* {
if (%who == 0) halt
}

raw 315:* {
if (%who == 0) halt
else set %who 0
blacklist.check
}

on ^*:hotlink:ed2k?//|*|*|*|/:*:return
on *:hotlink:ed2k?//|*|*|*|/:*:url -an $1-