alias mp3 {
dialog $iif($dialog(mp3),-v,-m) mp3 mp3
did -a mp3 1000 show
}

alias fmod return $dll(script\dll\fmod_mirc.dll,$1,$2-)

alias load.spectrum {
var %a = $fmod(FMOD_Connect,script\dll\fmod.dll)
var %a = $fmod(SOUND_Init,44100 64 0)
window -hp @spectrum 0 0 67 31
}

alias mp3.spectrum1 {
var %a = $fmod(Plugin_Load,1 " $+ $mircdir $+ script\dll\fmm_vis_spectrum.dll $+ ")
var %a = $fmod(Plugin_Send,1 Spectrum 1 1 @spectrum 25)
var %a = $fmod(Plugin_Send,1 Set_NumFades 30)
var %a = $fmod(Plugin_Send,1 Set_NumColors 2)
var %a = $fmod(Plugin_Send,1 Set_HeightColoring 0)
var %a = $fmod(Plugin_Send,1 Set_YSpace_Every 2)
var %a = $fmod(Plugin_Send,1 Set_YSpace_Height 1)
var %a = $fmod(Plugin_Send,1 Set_Barwidth 3)
var %a = $fmod(Plugin_Send,1 Set_Barspace 1)
var %a = $fmod(Plugin_Send,1 Set_Start 10)
var %a = $fmod(Plugin_Send,1 Set_End 67)
var %a = $fmod(Plugin_Send,1 Set_Avg 4)
var %a = $fmod(Plugin_Send,1 Set_BounceRate 6.0)
var %a = $fmod(Plugin_Send,1 Set_Dim 0 0 68 31)
var %a = $fmod(Plugin_Send,1 Set_Bgcolor $replace($rgb(%couleur.mp3fond),$chr(44),/))
var %a = $fmod(Plugin_Send,1 Set_Colors $replace($rgb(%couleur.mp3spectrum),$chr(44),/) $replace($rgb(%couleur.mp3spectrum),$chr(44),/) $replace($rgb(%couleur.mp3fond),$chr(44),/))
}

alias mp3.spectrum2 {
var %a = $fmod(Plugin_Load,1 " $+ $mircdir $+ script\dll\fmm_vis_spectrum.dll $+ ")
var %a = $fmod(Plugin_Send,1 Spectrum 1 1 @spectrum 25)
var %a = $fmod(Plugin_Send,1 Set_YSpace_Every 0)
var %a = $fmod(Plugin_Send,1 Set_YSpace_Height 1)
var %a = $fmod(Plugin_Send,1 Set_NumFades 30)
var %a = $fmod(Plugin_Send,1 Set_NumColors 2)
var %a = $fmod(Plugin_Send,1 Set_HeightColoring 0)
var %a = $fmod(Plugin_Send,1 Set_YSpace_Every 0)
var %a = $fmod(Plugin_Send,1 Set_YSpace_Height 1)
var %a = $fmod(Plugin_Send,1 Set_Barwidth 3)
var %a = $fmod(Plugin_Send,1 Set_Barspace 1)
var %a = $fmod(Plugin_Send,1 Set_Start 10)
var %a = $fmod(Plugin_Send,1 Set_End 67)
var %a = $fmod(Plugin_Send,1 Set_Avg 4)
var %a = $fmod(Plugin_Send,1 Set_BounceRate 6.0)
var %a = $fmod(Plugin_Send,1 Set_Dim 0 0 68 31)
var %a = $fmod(Plugin_Send,1 Set_Bgcolor $replace($rgb(%couleur.mp3fond),$chr(44),/))
var %a = $fmod(Plugin_Send,1 Set_Colors $replace($rgb(%couleur.mp3spectrum),$chr(44),/) $replace($rgb(%couleur.mp3spectrum),$chr(44),/) $replace($rgb(%couleur.mp3fond),$chr(44),/))
}

alias mp3.spectrum3 {
var %a = $fmod(Plugin_Load,1 " $+ $mircdir $+ script\dll\fmm_vis_spectrum.dll $+ ")
var %a = $fmod(Plugin_Send,1 Spectrum 1 1 @spectrum 25)
var %a = $fmod(Plugin_Send,1 Set_NumFades 30)
var %a = $fmod(Plugin_Send,1 Set_NumColors 2)
var %a = $fmod(Plugin_Send,1 Set_HeightColoring 0)
var %a = $fmod(Plugin_Send,1 Set_YSpace_Every 1)
var %a = $fmod(Plugin_Send,1 Set_YSpace_Height 1)
var %a = $fmod(Plugin_Send,1 Set_Barwidth 1)
var %a = $fmod(Plugin_Send,1 Set_Barspace 1)
var %a = $fmod(Plugin_Send,1 Set_Start 10)
var %a = $fmod(Plugin_Send,1 Set_End 67)
var %a = $fmod(Plugin_Send,1 Set_Avg 4)
var %a = $fmod(Plugin_Send,1 Set_BounceRate 6.0)
var %a = $fmod(Plugin_Send,1 Set_Dim 0 0 68 31)
var %a = $fmod(Plugin_Send,1 Set_Bgcolor $replace($rgb(%couleur.mp3fond),$chr(44),/))
var %a = $fmod(Plugin_Send,1 Set_Colors $replace($rgb(%couleur.mp3spectrum),$chr(44),/) $replace($rgb(%couleur.mp3spectrum),$chr(44),/) $replace($rgb(%couleur.mp3fond),$chr(44),/))
}

alias mp3.spectrum4 {
var %a = $fmod(Plugin_Load,1 " $+ $mircdir $+ script\dll\fmm_vis_spectrum.dll $+ ")
var %a = $fmod(Plugin_Send,1 Spectrum 1 1 @spectrum 25)
var %a = $fmod(Plugin_Send,1 Set_NumFades 30)
var %a = $fmod(Plugin_Send,1 Set_NumColors 2)
var %a = $fmod(Plugin_Send,1 Set_HeightColoring 0)
var %a = $fmod(Plugin_Send,1 Set_YSpace_Every 0)
var %a = $fmod(Plugin_Send,1 Set_YSpace_Height 1)
var %a = $fmod(Plugin_Send,1 Set_Barwidth 1)
var %a = $fmod(Plugin_Send,1 Set_Barspace 0)
var %a = $fmod(Plugin_Send,1 Set_Start 10)
var %a = $fmod(Plugin_Send,1 Set_End 67)
var %a = $fmod(Plugin_Send,1 Set_Avg 4)
var %a = $fmod(Plugin_Send,1 Set_BounceRate 6.0)
var %a = $fmod(Plugin_Send,1 Set_Dim 0 0 68 31)
var %a = $fmod(Plugin_Send,1 Set_Bgcolor $replace($rgb(%couleur.mp3fond),$chr(44),/))
var %a = $fmod(Plugin_Send,1 Set_Colors $replace($rgb(%couleur.mp3spectrum),$chr(44),/) $replace($rgb(%couleur.mp3spectrum),$chr(44),/) $replace($rgb(%couleur.mp3fond),$chr(44),/))
}

alias mp3.spectrum5 {
var %a = $fmod(Plugin_Load,1 " $+ $mircdir $+ script\dll\fmm_vis_oscilloscope.dll $+ ")
var %a = $fmod(Plugin_Send,1 Oscilloscope 1 1 @spectrum 25)
var %a = $fmod(Plugin_Send,1 Set_NumFades 30)
var %a = $fmod(Plugin_Send,1 Set_NumColors 2)
var %a = $fmod(Plugin_Send,1 Set_YSpace_Every 2)
var %a = $fmod(Plugin_Send,1 Set_YSpace_Height 1)
var %a = $fmod(Plugin_Send,1 Set_Barwidth 4)
var %a = $fmod(Plugin_Send,1 Set_Barspace 1)
var %a = $fmod(Plugin_Send,1 Set_BounceRate 5.0)
var %a = $fmod(Plugin_Send,1 Set_Dim 0 -20 68 71)
var %a = $fmod(Plugin_Send,1 Set_Bgcolor $replace($rgb(%couleur.mp3fond),$chr(44),/))
var %a = $fmod(Plugin_Send,1 Set_Colors $replace($rgb(%couleur.mp3spectrum),$chr(44),/) $replace($rgb(%couleur.mp3spectrum),$chr(44),/) $replace($rgb(%couleur.mp3fond),$chr(44),/))
}

alias mp3.spectrum6 {
mp3pos
if (%mp3.spectrum != 6) {
if ($insong) {
var %pos = $insong.pos
var %pos = $+($int($gmt($calc(%pos / 1000),nn)),$gmt($calc(%pos / 1000),:ss))
}
else var %pos = $fmod(SOUND_Stream_GetTime,1,1)
if (stream isin %pos) var %pos = 0:00
if (error isin %pos) var %pos = 0:00
if ($len(%pos) > 5) var %pos = $right(%pos,5)
if ($did(mp3,101)) did -o mp3 24 1 %pos
}
else {
if ($insong) {
var %pos = $insong.pos
var %pos = $+($int($gmt($calc(%pos / 1000),nn)),$gmt($calc(%pos / 1000),:ss))
}
else var %pos = $fmod(SOUND_Stream_GetTime,1,1)
if (stream isin %pos) var %pos = 0:00
if (error isin %pos) var %pos = 0:00
if ($len(%pos) > 5) var %pos = $right(%pos,5)
drawrect -fr @spectrum %couleur.mp3fond 10 0 0 70 40
var %w = $calc((68 - $width(%pos,tahoma,20,1,0)) / 2)
drawtext -or @spectrum %couleur.mp3spectrum tahoma 20 %w 3 %pos
}
}

alias mp3.save savebuf -o 2-10000 mp3 2 script/bdd/playlist.tbl

alias mp3.load loadbuf 1-10000 -o mp3 2 script/bdd/playlist.tbl

alias mp3.play {
var %file = $gettok($gettok($did(mp3,2).seltext,2,9),5-,32)
if ($isfile(" $+ %file $+ ")) {
splay -p stop
var %a = $dll(script\dll\fmod_mirc.dll,SOUND_Stream_Close,1)
var %a = $dll(script\dll\fmod_mirc.dll,SOUND_Stream_Open,1 " $+ %file $+ " 2 $file(" $+ %file $+ ").size 1)
if (%a == 0 Unknown file format) { 
splay -p " $+ %file $+ "
}
else var %mp3 = $dll(script\dll\fmod_mirc.dll,SOUND_Stream_Play,1 1)
did -o mp3 101 1 %file
did -i mp3 26 1 params 0
mp3.spectrum6
.timermp3pos -o 0 1 mp3.spectrum6
did -o mp3 1 1 $left($nopath(%file),-4)
if (%mp3.spectrum == 6 ) did -o mp3 24 1 $sound(%file).bitrate $+ kbps
did -o mp3 25 1 $sound(%file).mode
did -o mp3 500 1 $did(mp3,2).sel
var %a = $fmod(SOUND_Stream_SetEndCallback,1 mp3.end)
}
else { 
if ($did(mp3,2).sel) { mp3.erreur | mp3.stop }
}
mp3.unpause
}

alias mp3.stop {
splay -p stop
var %a = $fmod(SOUND_Stream_Close,1)
mp3.nombre
did -i mp3 26 1 params 0
if (%mp3.spectrum == 6) did -r mp3 24
did -r mp3 24,25
mp3.unpause
did -r mp3 101
}

alias mp3.pause {
if ($gettok($did(mp3,17,6),1,32) iswm +xca) {
if ($insong) splay -p pause
else var %a = $fmod(SOUND_SetPaused,1,1)
}
else {
if ($insong) splay -p resume
else var %a = $fmod(SOUND_SetPaused,1,0)
}
}

alias mp3.unpause did -o mp3 17 6 +ca 3

alias mp3.prev {
if ($did(mp3,2).lines == 1) { mp3.stop | halt }
if (%mp3.shuffle) { did -c mp3 2 $rand(2,$did(mp3,2).lines) | mp3.play | halt }

if (($did(mp3,2,$calc($did(mp3,500) - 1))) && ($calc($did(mp3,500) - 1) != 1)) { did -c mp3 2 $calc($did(mp3,500) - 1) | mp3.play }
elseif (!$did(mp3,2).sel) { mp3.stop }
}

alias mp3.next {
if ($did(mp3,2).lines == 1) { mp3.stop | halt }
if (%mp3.shuffle) { did -c mp3 2 $rand(2,$did(mp3,2).lines) | mp3.play | halt }

if ($did(mp3,2,$calc($did(mp3,500) + 1))) { did -c mp3 2 $calc($did(mp3,500) + 1) | mp3.play }
elseif ($did(mp3,2).sel == $did(mp3,2).lines) { mp3.stop | did -i mp3 1 1 Playlist termin�e }
}

alias mp3pos {
var %pos = 0
var %end = 0
if ($insong) {
var %pos = $insong.pos
var %end = $insong.length
}
else {
var %end = $fmod(SOUND_Stream_GetLengthMs,1)
var %pos = $fmod(SOUND_Stream_GetTime,1)
}
if ($gettok($did(mp3,26,1),9,32) != track) did -i mp3 26 1 params $round($calc(%pos / %end * 100),0)
}

alias mp3.renommer {
did -o mp3 2 $did(mp3,2).sel 0 0 0 $$input(Renommer,eq,Nouveau nom,$gettok($gettok($did(mp3,2).seltext,1,9),6-,32)) $+ $chr(9) $+ 0 0 0 $gettok($gettok($did(mp3,2).seltext,2,9),5-,32)
mp3.save
}

on *:mp3end:mp3.end

alias mp3.end {
if (%mp3.repeter) { did -c mp3 2 $did(mp3,500) | mp3.play | halt }
mp3.next
}

dialog mp3 {
title "MP3 Player"
size -1 -1 214 $iif(%mp3.h,%mp3.h,400)
icon $taskbar
option pixels
list 2, 1 110 212 201, size extsel
list 17, 2 65 212 24, size
button "", 100, 2 3 69 33
edit "", 24, 73 2 67 19, autohs center
edit "", 25, 141 2 72 19, autohs center
edit "", 101, 141 2 72 19, autohs hide
list 26, 1 39 156 23, size
edit "", 1, 1 90 212 21, autohs center
check "r�p�ter", 4, 74 22 62 16
check "al�atoire", 5, 142 22 70 16
list 3, 157 39 56 23, size
button "", 1000, -20 -20 10 10
edit "", 500, -1 -1 1 1, hide
}

menu @spectrum {
sclick:{
if (%mp3.spectrum == 5) {
did -r mp3 24
if ($sound($did(mp3,101)).bitrate) did -o mp3 24 1 $ifmatch $+ kbps
var %a = $fmod(Plugin_Send,1 Oscilloscope 0)
var %a = $fmod(Plugin_UnLoad,1)
}
elseif (%mp3.spectrum < 5) {
var %a = $fmod(Plugin_Send,1 Spectrum 0)
var %a = $fmod(Plugin_UnLoad,1)
}
inc %mp3.spectrum
if (%mp3.spectrum == 7) set %mp3.spectrum 1
clear @spectrum
mp3.spectrum $+ %mp3.spectrum
}
}

on *:dialog:mp3:close:*:{
mp3.stop
.timermp3pos -o off
.timer.mp3.arret off
set %mp3.x $dialog(mp3).x 
set %mp3.y $dialog(mp3).y
}

on *:dialog:mp3:init:*:{
if ((%mp3.x) && (%mp3.y) && (%mp3.h)) dialog -s mp3 %mp3.x %mp3.y 214 $calc(%mp3.h - 27)
dll script/mdx/mdx.dll SetMircVersion $version
dll script/mdx/mdx.dll MarkDialog mp3
dll script/mdx/mdx.dll SetControlMDX 1000 Positioner size minbox > script\mdx\dialog.mdx
dll script/mdx/mdx.dll SetControlMDX 3,26 TrackBar noticks > script/mdx/bars.mdx
dll script/mdx/mdx.dll SetControlMDX 2 listview showsel report rowselect noheader droptarget > script/mdx/views.mdx
dll script/mdx/mdx.dll SetControlMDX 17 ToolBar flat list nodivider arrows > script\mdx\bars.mdx
dll script/mdx/mdx.dll SetControlMDX 100 Window > script/mdx/dialog.mdx
dll script/mdx/mdx.dll SetBorderStyle 17
var %a = $fmod(FMOD_Connect,script\dll\fmod.dll)
var %a = $fmod(SOUND_Init,44100 64 0)
window -hp @spectrum 0 0 68 31
mp3.spectrum $+ %mp3.spectrum
did -a mp3 100 grab $window(@spectrum).hwnd @spectrum
did -i mp3 17 1 bmpsize 16 16
did -i mp3 17 1 pad 8 8
did -i mp3 17 1 setimage +nhd 0 icon small 0,script/icone/mp3/ $+ %mp3.icone $+ .icl
did -i mp3 17 1 setimage +nhd 0 icon small 1,script/icone/mp3/ $+ %mp3.icone $+ .icl
did -i mp3 17 1 setimage +nhd 0 icon small 2,script/icone/mp3/ $+ %mp3.icone $+ .icl
did -i mp3 17 1 setimage +nhd 0 icon small 3,script/icone/mp3/ $+ %mp3.icone $+ .icl
did -i mp3 17 1 setimage +nhd 0 icon small 4,script/icone/mp3/ $+ %mp3.icone $+ .icl
did -i mp3 17 1 setimage +nhd 0 icon small 5,script/icone/mp3/ $+ %mp3.icone $+ .icl
did -a mp3 17 +a 1 $chr(9)
did -a mp3 17 +a -
did -a mp3 17 +a 2 $chr(9)
did -a mp3 17 +a -
did -a mp3 17 +ac 3 $chr(9)
did -a mp3 17 +a -
did -a mp3 17 +a 4 $chr(9)
did -a mp3 17 +a -
did -a mp3 17 +a 5 $chr(9)
did -a mp3 17 +a -
did -a mp3 17 +a 6 $chr(9)
did -i mp3 2 1 headerdims 190 0
dll script/mdx/mdx.dll SetFont 6,11,14,15,16,17 20 7 webdings
dll script/mdx/mdx.dll SetFont 6 16 8 webdings
dll script/mdx/mdx.dll SetFont 2 11 300 tahoma
dll script/mdx/mdx.dll SetFont 1 +b 12 900 tahoma
dll script/mdx/mdx.dll SetBorderStyle 3,26
dll script/mdx/mdx.dll SetColor 1,24,25 background %couleur.mp3fond
dll script/mdx/mdx.dll SetColor 1,24,25 textbg %couleur.mp3fond
dll script/mdx/mdx.dll SetColor 1,24,25 text %couleur.mp3texte
did -i mp3 2 1 settxt bgcolor %couleur.mp3fond
did -i mp3 2 1 setbkg color %couleur.mp3fond
did -i mp3 2 1 settxt color %couleur.mp3texte
if (!$isfile(script/bdd/playlist.tbl)) write script/bdd/playlist.tbl
mp3.load
if (%mp3.filtre) { mp3.filtre %mp3.filtre | did -a mp3 1 %mp3.filtre }
did -a mp3 500 1
did -c mp3 2 2
if (%mp3.repeter) did -c mp3 4
if (%mp3.shuffle) did -c mp3 5
mp3.spectrum6
.timermp3pos -o 0 1 mp3.spectrum6
if (!$did(mp3,1)) did -a mp3 1 easy-X - Mp3 Player - $calc($did(mp3,2).lines - 1) Musiques
did -i mp3 3 1 params $int($calc($vol(mp3) / 655))
dll script/mdx/mdx.dll MoveControl mp3 2 * * * $calc($dialog(mp3).h - 138)
}

on *:dialog:mp3:dclick:2:mp3.play

on *:dialog:mp3:sclick:6:{
did -a mp3 1000 hide
did -f mp3 1000
}

on *:dialog:mp3:sclick:2:{
if (drop == $gettok($did(mp3,2,1),1,32)) {
var %total = $gettok($did(mp3,2,1),6,32)
var %a = 1
did -i mp3 2 1 page dropinfo
while (%a <= %total) {
var %file = $gettok($did(mp3,2,1),3-,32)
did -i mp3 2 1 getdrop %a
if (($isfile(%file)) && (%file != %last) && ($right(%file,4) == .mp3)) {
did -a mp3 2 0 0 0 0 $left($nopath(%file),-4) $+ $chr(9) $+ 0 0 0 %file
var %last = %file
}
inc %a
}
mp3.save
}
if (($gettok($did(mp3,2,1),1,32) == rclick) && ($did(mp3,2).sel)) var %a = $dll(script/dll/popread.dll,popread,script/bdd/menu.tbl?9?26? $+ $mouse.dx $+ ? $+ $mouse.dy)
}

alias mp3.sort {
if (%mp3.filtre) mp3.filtre
filter -iorct 2-10000 6 32 mp3 2 mp3 2 *
mp3.save
if (%mp3.filtre) mp3.filtre %mp3.filtre
}

alias mp3.arret {
if ($timer(.mp3.arret)) { .timer.mp3.arret off | halt }
var %a = $input(Stopper la lecture du mp3 dans combien de minutes ?,e,Lecteur MP3)
if (%a isnum) .timer.mp3.arret -o 1 $calc(%a * 60) mp3.stop
}

alias mp3.cache did -a $$dialog(mp3) 1000 hide

on *:dialog:mp3:sclick:4:{
set %mp3.repeter $did(mp3,4).state
did -f mp3 1000
}

on *:dialog:mp3:sclick:5:{
set %mp3.shuffle $did(mp3,5).state
did -f mp3 1000
}

on *:dialog:mp3:sclick:17:{
var %a = $did(mp3,17).sel
if (%a == 10) mp3.next
elseif (%a == 8) mp3.stop
elseif (%a == 6) mp3.pause
elseif (%a == 4) mp3.play
elseif (%a == 2) mp3.prev
elseif (%a == 12) var %a = $dll(script/dll/popread.dll,popread,script/bdd/menu.tbl?27?40? $+ $mouse.dx $+ ? $+ $mouse.dy)
}

on *:dialog:mp3:sclick:26:{
did -f mp3 1000
if (($insong) && ($gettok($did(mp3,26).seltext,9,32) == end)) { .splay -p " $+ $insong.fname $+ " $round($calc($insong.length / 100 * $gettok($did(mp3,26).seltext,1,32)),0) | mp3pos | mp3.unpause | mp3.spectrum6 }
elseif (($fmod(SOUND_GetChannelsPlaying,0) > 0) && ($gettok($did(mp3,26).seltext,9,32) == end)) { var %a = $fmod(SOUND_Stream_SetTime,1,$round($calc($fmod(SOUND_Stream_GetLengthMs,1) / 100 * $gettok($did(mp3,26).seltext,1,32)),0)) | mp3pos | mp3.spectrum6 }
}

on *:dialog:mp3:sclick:4:{
set %mp3.repeter $did(mp3,4).state
did -f mp3 1000
}

on *:dialog:mp3:sclick:5:{
set %mp3.shuffle $did(mp3,5).state
did -f mp3 1000
}

alias mp3.nombre if ((!$insong) && ($dialog(mp3)) && (!$did(mp3,101))) did -o mp3 1 1 easy-X - Mp3 Player - $calc($did(mp3,2).lines - 1) Musiques

alias mp3.ad {
if ($did(mp3,101)) {
var %artist = $sound($did(mp3,101)).artist
var %title = $sound($did(mp3,101)).title
var %bitrate = $sound($did(mp3,101)).bitrate $+ kbps
if ($sound($did(mp3,101)).length >= 3600000) var %len = $gmt($calc($sound($did(mp3,101)).length / 1000),h:nn:ss)
else var %len = $int($gmt($calc($sound($did(mp3,101)).length / 1000),nn)) $+ $gmt($calc($sound($did(mp3,101)).length / 1000),:ss)
var %sample = $sound($did(mp3,101)).sample
var %mode = $sound($did(mp3,101)).mode
var %size = $file($did(mp3,101)).size
if (%size > 1000000) var %size = $round($calc(%size / 1000000),2) $+ Mo
elseif (%size > 1000) var %size = $int($calc(%size / 1000)) $+ Ko
if ((%artist == $null) || ($asc(%artist) == 32)) var %artist = $gettok($replace($nopath($did(mp3,101)),.mp3,),1,45)
if ((%title == $null) || ($asc(%title) == 32)) var %title = $gettok($replace($nopath($did(mp3,101)),.mp3,),2-4,45)
var %msg = $replace(%mp3.advertise,<artiste>,%artist,<titre>,%title,<bitrate>,%bitrate,<temps>,%len,<sample>,%sample,<size>,%size,<mode>,%mode)
scid $activecid
say %msg
}
}

alias ajoutermp3 {
var %a = $msfile(%mp3.dir $+ *.mp3,Ajouter un mp3,Ajouter)
if (%a == -1) { var %z = $input(Un nombre de 26 fichiers peux �tre s�l�ctionn�s au maximum.,ow,Lecteur MP3) | halt }
var %b = 1
if (%mp3.filtre) mp3.filtre
while (%b <= %a) {
var %file = $msfile(%b)
if ((%file) && ($right(%file,4) == .mp3)) {
set %mp3.dir $nofile(%file)
if ($isfile(%file)) did -a mp3 2 0 0 0 0 $left($nopath(%file),-4) $+ $chr(9) $+ 0 0 0 %file
else did -a mp3 2 0 0 0 0 $left($nopath(%file),-4) $+ $chr(9) $+ 0 0 0 $shortfn(%file)
}
inc %b
}
mp3.nombre
mp3.save
if (%mp3.filtre) mp3.filtre %mp3.filtre
}

alias ajoutermp3rep {
var %a = $sdir($iif(%mp3.dir,%mp3.dir,C:\),Ajouter un repertoire)
if (%mp3.filtre) mp3.filtre
if (%a) {
var %rep = $findfile(%a,*?.mp3,0,did -a mp3 2 0 0 0 0 $replace($left($nopath($1-),-4),_,$chr(32)) $+ $chr(9) $+ 0 0 0 $1-)
set %mp3.dir %a
}
mp3.save
if (%mp3.filtre) mp3.filtre %mp3.filtre
mp3.nombre
}

alias supprmp3 {
if (%mp3.filtre) { var %a = $input(Un mp3 ne peut �tre supprim� lorsqu'un filtre est activ�.,ow,Lecteur MP3) | halt }
while ($did(mp3,2).sel != $null) {
did -d mp3 2 $did(mp3,2).sel
}
mp3.save
mp3.nombre
}

alias supprmp3all {
if (%mp3.filtre) { var %a = $input(Un mp3 ne peut �tre supprim� lorsqu'un filtre est activ�.,ow,Lecteur MP3) | halt }
did -r mp3 2
if (!$did(mp3,101)) did -r mp3 1,24,25
mp3.save
mp3.nombre
}

alias playlist.import {
var %a = $sfile($iif(%mp3.dir,%mp3.dir,C:\) $+ *.m3u,Playlist,Ouvrir)
if (!$isfile(%a)) halt
var %b = 1
if (%mp3.filtre) mp3.filtre
while (%b <= $lines(%a)) {
%ligne = $read(%a,%b)
if ($left(%ligne,1) != $chr(35)) did -a mp3 2 0 0 0 0 $left($nopath(%ligne),-4) $+ $chr(9) $+ %ligne
inc %b
}
mp3.nombre
mp3.save
if (%mp3.filtre) mp3.filtre %mp3.filtre
set %mp3.dir $nofile(%a)
}

alias playlist.export {
var %save = $sfile(C:\*.m3u,Playlist,Enregistrer)
if (!%save) halt
var %a = 2
window -h @playlist
aline @playlist $chr(35) $+ EXTM3U
while (%a <= $did(mp3,2).lines) {
var %ligne = $did(mp3,2,%a)
var %nom = $gettok($gettok(%ligne,1,9),6-,32)
var %file = $gettok($gettok(%ligne,2,9),5-,32)
if ($isfile(%file)) {
aline @playlist $chr(35) $+ EXTINF: $+ $int($calc($sound(%file).length / 1000)) $+ , $+ %nom
aline @playlist %file
}
inc %a
}
savebuf @playlist " $+ %save $+ "
window -c @playlist
}

on *:dialog:mp3:edit:1:{
mp3.filtre $did(mp3,1)
set %mp3.filtre $did(mp3,1)
}

alias mp3.filtre filter -roc 2-10000 script/bdd/playlist.tbl mp3 2 * $+ $1- $+ *

on *:dialog:mp3:sclick:3:{
vol -p $calc($gettok($did(mp3,3).seltext,1,32) * 655)
did -f mp3 1000
}

alias mp3.erreur var %a = $input(Le fichier n'existe pas !,oh,Mp3)

on *:dialog:mp3:sclick:1000:{
var %h = $gettok($did(mp3,1000),6,32)
if (%h <= 150) did -a mp3 1000 setsize 222 117
elseif ((%h < 195) && (%h > 150)) did -a mp3 1000 setsize 222 117
else did -a mp3 1000 setsize 222 *
dll script/mdx/mdx.dll MoveControl mp3 2 * * * $calc($dialog(mp3).h - 138)
set %mp3.h $dialog(mp3).h
}

alias id3 {
if (!$isfile($1-)) { mp3.erreur | halt }
dialog $iif($dialog(id3),-v,-m) id3 id3
dll script/mdx/mdx.dll SetMircVersion $version
dll script/mdx/mdx.dll MarkDialog id3
var %a = $1-
did -o id3 3 1 %a
did -r id3 6,8,10,12,14
did -u id3 16
if ($sound(%a).title) did -a id3 6 $ifmatch
if ($sound(%a).artist) did -a id3 8 $ifmatch
if ($sound(%a).album) did -a id3 10 $ifmatch
if ($sound(%a).year) did -a id3 12 $ifmatch
if ($sound(%a).comment) did -a id3 14 $ifmatch
if ($sound(%a).track != -1) did -a id3 20 $ifmatch
didtok id3 16 59 Blues;Classic Rock;Country;Dance;Disco;Funk;Grunge;Hip-Hop;Jazz;Metal;New Age;Oldies;Other;Pop;R&B;Rap;Reggae;Rock;Techno;Industrial;Alternative;Ska;Death Metal;Pranks;Soundtrack;Euro-Techno
didtok id3 16 59 Ambient;Trip-Hop;Vocal;Jazz+Funk;Fusion;Trance;Classical;Instrumental;Acid;House;Game;Sound Clip;Gospel;Noise;AlternRock;Bass;Soul;Punk;Space;Meditative;Instrumental Pop;Instrumental Rock;Ethnic;Gothic;Darkwave
didtok id3 16 59 Techno-Industrial;Electronic;Pop-Folk;Eurodance;Dream;Southern Rock;Comedy;Cult;Gangsta;Top 40;Christian Rap;Pop/Funk;Jungle;Native American;Cabaret;New Wave;Psychedelic;Rave;Showtunes;Trailer;Lo-Fi;Tribal;Acid Punk;Acid Jazz;Polka
didtok id3 16 59 Retro;Musical;Rock & Roll;Hard Rock;Folk;Folk/Rock;National Folk;Swing;Fast Fusion;Bebob;Latin;Revival;Celtic;Bluegrass;Avantgarde;Gothic Rock;Progressive Rock;Psychedelic Rock;Symphonic Rock;Slow Rock;Big Band;Chorus;Easy Listening;Acoustic;Humour
didtok id3 16 59 Speech;Chanson;Opera;Chamber Music;Sonata;Symphony;Booty Bass;Primus;Porn Groove;Satire;Slow Jam;Club;Tango;Samba;Folklore;Ballad;Power Ballad;Rhythmic Soul;Freestyle;Duet;Punk Rock;Drum Solo;Acapella;Euro-house;Dance hall
if ($didwm(id3,16,$sound(%a).genre)) did -c id3 16 $ifmatch
if ($sound(%a).length >= 3600000) var %len = $gmt($calc($sound(%a).length / 1000),h:nn:ss)
else var %len = $int($gmt($calc($sound(%a).length / 1000),nn)) $+ $gmt($calc($sound(%a).length / 1000),:ss)
did -a id3 4 Bitrate : $sound(%a).bitrate kbps $crlf $+ Taille : $file(%a).size bytes $crlf $+ Temps : %len $crlf $+ Sample : $sound(%a).sample $+ Hz $sound(%a).mode $crlf $+ Copyright : $iif($sound(%a).copyright,oui,non) $crlf $+ CRCs : $iif($sound(%a).crc,oui,non)
}

dialog id3 {
title "Editeur ID3"
size -1 -1 299 300
option pixels
icon $taskbar
box "ID3", 1, 5 1 289 161
edit "", 3, 13 17 273 20, read autohs
text "Artiste :", 5, 15 42 50 15
edit "", 8, 94 39 192 22, autohs limit 30
text "Titre :", 7, 15 65 50 15
edit "", 6, 94 62 192 22, autohs limit 30
text "Album :", 9, 15 88 40 15
edit "", 10, 94 85 126 22, autohs limit 30
text "Ann�e :", 11, 15 111 50 15
edit "", 12, 94 108 38 22, autohs limit 4
text "Commentaire :", 13, 15 134 70 15
edit "", 14, 94 131 192 22, autohs limit 30
text "Genre :", 15, 136 111 38 15
combo 16, 176 109 109 163, size drop
button "Ok", 17, 170 272 54 23, ok
button "Annuler", 18, 224 272 70 23, cancel
box "Informations", 2, 5 163 289 103
text , 4, 15 180 268 77
text "Track :", 19, 225 88 36 15
edit "", 20, 262 85 24 22, autohs limit 2 center
}

on *:dialog:id3:sclick:17:{
if ($did(id3,3) == $insong.fname) {
var %pos = $insong.pos
splay -p stop
}
var %a = $id3w($did(id3,3),$did(id3,6),$did(id3,8),$did(id3,10),$did(id3,12),$did(id3,14),$did(id3,20),$did(id3,16).sel)
if (%pos) splay -p $did(id3,3) %pos
}

alias id3w {
if ($1 && $isfile($1)) {
var %f = $shortfn($1)
bread %f $calc($file(%f).size - 128) 5 &id3T
bset &id3 125 0
var %i = 1
while (%i <= $len($2)) {
if ($mid($2,%i,1) == $chr(32)) { bset &id3 %i 32 | goto next2 }
bset -t &id3 %i $mid($2,%i,1)
:next2
inc %i
}
set %i 1
while (%i <= $len($3)) {
if ($mid($3,%i,1) == $chr(32)) { bset &id3 $calc(%i + 30) 32 | goto next3 }
bset -t &id3 $calc(%i + 30) $mid($3,%i,1)
:next3
inc %i
}
set %i 1
while (%i <= $len($4)) {
if ($mid($4,%i,1) == $chr(32)) { bset &id3 $calc(%i + 60) 32 | goto next4 }
bset -t &id3 $calc(%i + 60) $mid($4,%i,1)
:next4
inc %i
}
set %i 1
while (%i <= $len($5)) {
if ($mid($5,%i,1) == $chr(32)) { bset &id3 $calc(%i + 90) 32 | goto next5 }
bset -t &id3 $calc(%i + 90) $mid($5,%i,1)
:next5
inc %i
}
set %i 1
while (%i <= $len($6)) {
if ($mid($6,%i,1) == $chr(32)) { bset &id3 $calc(%i + 94) 32 | goto next6 }
bset -t &id3 $calc(%i + 94) $mid($6,%i,1)
:next6
inc %i
}
bset &id3 124 $iif($7,$7,0)
bset &id3 125 $iif($8,$8,255)
bset &genre 1 $iif($8,$calc($8 - 1),255)

if ($bfind(&id3T,1,TAG)) {
bunset &id3T
bset &id3 125 0
bwrite %f $calc($file(%f).size - 125) -1 &id3
bwrite %f $calc($file(%f).size - 1) 1 &genre
}
else {
bunset &id3T
bset &id3f 1 T A G
bcopy &id3f 4 &id3 1 -1
bwrite %f -1 -1 &id3f
bwrite %f $calc($file(%f).size - 1) 1 &genre
}
}
return $true
}

alias playlist.export.html dialog $iif($dialog(playlist.html),-v,-m) playlist.html playlist.html

dialog playlist.html {
title "Playlist Html"
size -1 -1 234 213
option pixels
icon $taskbar
box "Couleurs", 7, 4 0 226 93
box "Champs", 8, 4 94 226 87
list 1, 13 18 18 18, size
list 2, 124 18 18 18, size
list 3, 13 42 18 18, size
list 4, 124 42 18 18, size
list 5, 13 66 18 18, size
list 6, 124 66 18 18, size
text "Fond de page", 15, 36 20 72 16
text "Titre", 16, 148 20 36 16
text "Fond champs 1", 17, 148 44 76 16
text "Haut playlist", 18, 36 44 72 16
text "Texte playlist", 19, 148 68 72 16
text "Fond champs 2", 20, 36 68 78 16
check "Num�rotation", 10, 14 111 94 20
check "Dur�e", 11, 122 111 64 20
check "Bitrate", 12, 14 133 64 20
check "Mode", 13, 122 133 62 20
check "Taille", 14, 14 155 56 20
button "Cr�er", 9, 79 186 75 23, default
button "Annuler", 21, 154 186 75 23, cancel
}

on *:dialog:playlist.html:init:*:{
dll script/mdx/mdx.dll SetMircVersion $version
dll script/mdx/mdx.dll MarkDialog playlist.html
dll script/mdx/mdx.dll SetControlMDX 1,2,3,4,5,6 listview > script/mdx/views.mdx

did -i playlist.html 1 1 setbkg color %mp3.playlist.couleur1
did -i playlist.html 2 1 setbkg color %mp3.playlist.couleur2
did -i playlist.html 3 1 setbkg color %mp3.playlist.couleur3
did -i playlist.html 4 1 setbkg color %mp3.playlist.couleur4
did -i playlist.html 5 1 setbkg color %mp3.playlist.couleur5
did -i playlist.html 6 1 setbkg color %mp3.playlist.couleur6

if (%mp3.playlist.num) did -c playlist.html 10
if (%mp3.playlist.temps) did -c playlist.html 11
if (%mp3.playlist.bitrate) did -c playlist.html 12
if (%mp3.playlist.mode) did -c playlist.html 13
if (%mp3.playlist.taille) did -c playlist.html 14
}

on *:dialog:playlist.html:sclick:9:{
if (!$dialog(mp3)) halt
if ($did(mp3,2).lines < 2) { var %a =$input(Votre playlist est vide,w,Erreur) | halt }

var %couleur1 = $chr(35) $+ $base($gettok($rgb(%mp3.playlist.couleur1),1,44),10,16) $+ $base($gettok($rgb(%mp3.playlist.couleur1),2,44),10,16) $+ $base($gettok($rgb(%mp3.playlist.couleur1),3,44),10,16)
var %couleur2 = $chr(35) $+ $base($gettok($rgb(%mp3.playlist.couleur2),1,44),10,16) $+ $base($gettok($rgb(%mp3.playlist.couleur2),2,44),10,16) $+ $base($gettok($rgb(%mp3.playlist.couleur2),3,44),10,16)
var %couleur3 = $chr(35) $+ $base($gettok($rgb(%mp3.playlist.couleur3),1,44),10,16) $+ $base($gettok($rgb(%mp3.playlist.couleur3),2,44),10,16) $+ $base($gettok($rgb(%mp3.playlist.couleur3),3,44),10,16)
var %couleur4 = $chr(35) $+ $base($gettok($rgb(%mp3.playlist.couleur4),1,44),10,16) $+ $base($gettok($rgb(%mp3.playlist.couleur4),2,44),10,16) $+ $base($gettok($rgb(%mp3.playlist.couleur4),3,44),10,16)
var %couleur5 = $chr(35) $+ $base($gettok($rgb(%mp3.playlist.couleur5),1,44),10,16) $+ $base($gettok($rgb(%mp3.playlist.couleur5),2,44),10,16) $+ $base($gettok($rgb(%mp3.playlist.couleur5),3,44),10,16)
var %couleur6 = $chr(35) $+ $base($gettok($rgb(%mp3.playlist.couleur6),1,44),10,16) $+ $base($gettok($rgb(%mp3.playlist.couleur6),2,44),10,16) $+ $base($gettok($rgb(%mp3.playlist.couleur6),3,44),10,16)

window -h @playlist

aline @playlist <html><head><title>Playlist</title>
aline @playlist <style type=text/css>
aline @playlist #a $chr(123) font-family:Arial; font-size:13px; background-color: $+ %couleur4 $+ ; height:20px; $chr(125)
aline @playlist #b $chr(123) font-family:Arial; font-size:13px; background-color: $+ %couleur5 $+ ; height:20px; $chr(125)
aline @playlist </style></head>
aline @playlist <body bgcolor= $+ %couleur1 text= $+ %couleur6 link= $+ %couleur2 alink= $+ %couleur2 vlink= $+ %couleur2 $+ >
aline @playlist <p><font face=Arial size=5 color= $+ %couleur2 $+ ><b>easy-X playlist</b></font></p>
aline @playlist <table border=0 cellpadding=0 cellspacing=1 width=100%><tr bgcolor= $+ %couleur3 height=20>
aline @playlist <td width=55%><p><font face=arial size=2><b>&nbsp;Titre</b></font></p></td>
if (%mp3.playlist.temps) aline @playlist <td><p align=center><font face=arial size=2><b>Dur�e</b></font></p></td>
if (%mp3.playlist.bitrate) aline @playlist <td><p align=center><font face=arial size=2><b>Bitrate</b></font></p></td>
if (%mp3.playlist.mode) aline @playlist <td><p align=center><font face=arial size=2><b>Mode</b></font></p></td>
if (%mp3.playlist.taille) aline @playlist <td><p align=center><font face=arial size=2><b>Taille</b></font></p></td>
aline @playlist </tr>

var %a = 2
var %num = 1
while (%a <= $did(mp3,2).lines) {
var %z = $did(mp3,2,%a)
var %mp3 = $gettok($gettok(%z,1,9),6-,32)
var %file = $gettok($gettok(%z,2,9),5-,32)

if (%mp3.playlist.temps) {
var %temps = $sound(%file).length
if (%temps >= 3600000) var %temps = $gmt($calc(%temps / 1000),h:nn:ss)
else var %temps = $int($gmt($calc(%temps / 1000),nn)) $+ $gmt($calc(%temps / 1000),:ss)
}

if (%mp3.playlist.bitrate) var %bitrate = $sound(%file).bitrate
if (%mp3.playlist.mode) var %mode = $sound(%file).mode

if (%mp3.playlist.taille) {
var %size = $file(%file).size
if (%size > 1000000) var %size = $round($calc(%size / 1000000),2) Mo
elseif (%size > 1000) var %size = $int($calc(%size / 1000)) Ko
}

if (%bg == a) var %bg = b
else var %bg = a

var %ligne = <tr id= $+ %bg $+ >
var %ligne = %ligne $+ <td>&nbsp; $+ $iif(%mp3.playlist.num,%num $+ .&nbsp;) $+ %mp3 $+ </td>
if (%mp3.playlist.temps) var %ligne = %ligne $+ <td align=center> $+ %temps $+ </td>
if (%mp3.playlist.bitrate) var %ligne = %ligne $+ <td align=center> $+ %bitrate kbps $+ </td>
if (%mp3.playlist.mode) var %ligne = %ligne $+ <td align=center> $+ %mode $+ </td>
if (%mp3.playlist.taille) var %ligne = %ligne $+ <td align=center> $+ %size $+ </td>
var %ligne = %ligne $+ </tr>

aline @playlist %ligne

inc %num
inc %a
}

aline @playlist </table><p align=center><font size=1 face=Arial color= $+ %couleur2 $+ > $+ $calc(%num - 1) musiques - Playlist g�n�r�e avec <a href=http://www.easy-x.tk target=_blank>easy-X 1.5</a></font></p></body></html>
savebuf @playlist playlist.html
url -an " $+ $mircdir $+ playlist.html $+ "
dialog -x playlist.html
window -c @playlist
}

on *:dialog:playlist.html:sclick:1,2,3,4,5,6:{
var %a = $did
if ($did == 1) var %z = %mp3.playlist.couleur1
if ($did == 2) var %z = %mp3.playlist.couleur2
if ($did == 3) var %z = %mp3.playlist.couleur3
if ($did == 4) var %z = %mp3.playlist.couleur4
if ($did == 5) var %z = %mp3.playlist.couleur5
if ($did == 6) var %z = %mp3.playlist.couleur6
$iif($dll(script/dll/color.dll,Color,%z) != $false,did -i playlist.html %a 1 setbkg color $ifmatch,halt)
var %c = $ifmatch
if (%a == 1) set %mp3.playlist.couleur1 %c
elseif (%a == 2) set %mp3.playlist.couleur2 %c
elseif (%a == 3) set %mp3.playlist.couleur3 %c
elseif (%a == 4) set %mp3.playlist.couleur4 %c
elseif (%a == 5) set %mp3.playlist.couleur5 %c
else set %mp3.playlist.couleur6 %c
}

on *:dialog:playlist.html:sclick:10:set %mp3.playlist.num $did(playlist.html,10).state
on *:dialog:playlist.html:sclick:11:set %mp3.playlist.temps $did(playlist.html,11).state
on *:dialog:playlist.html:sclick:12:set %mp3.playlist.bitrate $did(playlist.html,12).state
on *:dialog:playlist.html:sclick:13:set %mp3.playlist.mode $did(playlist.html,13).state
on *:dialog:playlist.html:sclick:14:set %mp3.playlist.taille $did(playlist.html,14).state