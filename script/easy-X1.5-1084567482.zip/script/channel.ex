alias channel2 channel_central $$iif($1,$1,#)

dialog channel_central {
title ""
size -1 -1 371 320
icon $taskbar
option pixels
box "Channel", 1, 5 1 362 314
text "Topic :", 2, 16 16 38 16
edit "", 3, 14 30 344 21, autohs
button "topic", 4, 15 54 305 19
text "Bannis :", 5, 16 78 44 16
list 6, 14 92 276 126, size extsel vsbar
button "Supprimer", 7, 296 93 61 23
button "Editer", 8, 296 122 61 23
check "Only ops set topic", 9, 15 222 110 20
check "Key :", 10, 155 222 48 20
edit "", 11, 202 222 88 21, autohs
check "No external messages", 12, 15 244 130 20
check "Limit to :", 13, 155 244 64 20
check "Invite only", 14, 15 266 74 20
check "Private", 15, 155 266 62 20
check "Secret", 16, 155 288 54 20
check "Moderated", 17, 15 288 76 20
edit "", 20, 218 245 40 21, autohs
text "users", 21, 262 248 30 16
button "OK", 24, 298 252 61 25, default
button "Annuler", 25, 298 282 61 25, cancel
button "<", 27, 323 54 17 19
button ">", 28, 340 54 17 19
}

alias channel_central {
if (!$1) halt
var %d = channel_central
if ($dialog(%d)) dialog -x %d
dialog -mh %d %d
dialog -t %d Channel Central pour $1
if (!$chan($1).ibl) mode $1 +b
else update_ban $1
if ($me !isop $1) did -b %d 7,8,24
if ($chan($1).topic) did -a %d 3 $chan($1).topic
if (t isincs $gettok($chan($1).mode,1,32)) did -c %d 9
if (n isincs $gettok($chan($1).mode,1,32)) did -c %d 12
if (i isincs $gettok($chan($1).mode,1,32)) did -c %d 14
if (m isincs $gettok($chan($1).mode,1,32)) did -c %d 17
if (k isincs $gettok($chan($1).mode,1,32)) {
did -c %d 10
did -a %d 11 $chan($1).key
}
if (l isincs $gettok($chan($1).mode,1,32)) {
did -c %d 13
did -a %d 20 $chan($1).limit
}
if (p isincs $gettok($chan($1).mode,1,32)) did -c %d 15
if (s isincs $gettok($chan($1).mode,1,32)) did -c %d 16
window -h @channel_central 0 0 10000 10000
clear @channel_central
did -a %d 4 grab $window(@channel_central).hwnd @channel_central
window @channel_central 0 0 50000 20
echo $color(topic) -h @channel_central $chan($1).topic 
}

on *:dialog:channel_central:init:*:{
dll script/mdx/mdx.dll SetMircVersion $version
dll script/mdx/mdx.dll MarkDialog channel_central
dll script/mdx/mdx.dll SetControlMDX 4 Window > script/mdx/dialog.mdx
}

on *:dialog:channel_central:edit:3:{
clear @channel_central
echo $color(topic) -h @channel_central $did(channel_central,3) $+ 
}

on *:dialog:channel_central:sclick:24:{
var %chan = $gettok($dialog(channel_central).title,4,32)
if ($did(channel_central,3) !=== $chan(%chan).topic) .raw topic %chan : $+ $did(channel_central,3)

if ($did(channel_central,9).state) var %mode = %mode $+ t
else var %moins = %moins $+ t
if ($did(channel_central,12).state) var %mode = %mode $+ n
else var %moins = %moins $+ n
if ($did(channel_central,14).state) var %mode = %mode $+ i
else var %moins = %moins $+ i
if ($did(channel_central,17).state) var %mode = %mode $+ m
else var %moins = %moins $+ m
if ($did(channel_central,13).state) var %mode = %mode $+ l
else var %moins = %moins $+ l
if ($did(channel_central,15).state) var %mode = %mode $+ p
else var %moins = %moins $+ p
if ($did(channel_central,16).state) var %mode = %mode $+ s
else var %moins = %moins $+ s

.mode %chan + $+ %mode $+ - $+ %moins $did(channel_central,20)

if (($did(channel_central,10).state) && ($did(channel_central,11)) && ($did(channel_central,11) != $chan(%chan).key)) .mode %chan +k $did(channel_central,11)
elseif (($chan(%chan).key) && ($did(channel_central,10).state == 0)) .mode %chan -k $chan(%chan).key

dialog -x channel_central
}

on *:dialog:channel_central:sclick:7:{
if (!$did(channel_central,6).sel) halt
var %chan = $gettok($dialog(channel_central).title,4,32)
var %a = 1
while (%a <= $did(channel_central,6,0).sel) {
mode %chan -bbbb $gettok($did(channel_central,6,$did(channel_central,6,%a).sel),1,32) $gettok($did(channel_central,6,$did(channel_central,6,$calc(%a + 1)).sel),1,32) $gettok($did(channel_central,6,$did(channel_central,6,$calc(%a + 2)).sel),1,32) $gettok($did(channel_central,6,$did(channel_central,6,$calc(%a + 3)).sel),1,32)
inc %a 4
}
}

on *:dialog:channel_central:sclick:8:{
if (!$did(channel_central,6).sel) halt
edit_ban $gettok($did(channel_central,6).seltext,1,32) $$input(Ban,e,Ban,$$gettok($did(channel_central,6).seltext,1,32))
}

on *:dialog:channel_central:sclick:27:{
var %a = $calc($window(@channel_central).x - $dialog(channel_central).x - 18 + 50)
if (%a <= 0) window @channel_central %a 0 20000 20
}

on *:dialog:channel_central:sclick:28:{
var %a = $calc($window(@channel_central).x - $dialog(channel_central).x - 18 - 50)
window @channel_central %a 0 20000 20
}

alias edit_ban {
var %chan = $gettok($dialog(channel_central).title,4,32)
if ($1 == $2) halt
mode %chan -b+b $1 $2
}

alias update_ban {
var %a = 1
did -r channel_central 6
while (%a <= $ibl($1,0)) {
did -a channel_central 6 $ibl($1,%a) Par $gettok($ibl($1,%a).by,1,33)
inc %a
}
}

on *:unban:*:if ($gettok($dialog(channel_central).title,4,32) == $chan) update_ban $chan

on *:ban:*:if ($gettok($dialog(channel_central).title,4,32) == $chan) update_ban $chan

raw 368:* { 
if ($gettok($dialog(channel_central).title,4,32) == $2) update_ban $2
haltdef
}