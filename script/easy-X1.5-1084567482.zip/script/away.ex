alias aw dialog $iif($dialog(away),-v,-m) away away

alias back {
scid $activecid
resetidle
$iif(%away.all == 1,scid -a) nick %nick.default
if ($awaytime >= 3600) var %duration = $duration($awaytime,2)
else var %duration = $duration($awaytime)
if ($away) {
if (%away.say == 1) $iif(%away.all,scid -a) ame $replace(%away.retour,<temps>,%duration,<raison>,$awaymsg)
if (%away.say == 2) describe $active $replace(%away.retour,<temps>,%duration,<raison>,$awaymsg)
$iif(%away.all,scid -a) away
}
if ($dialog(away)) did -b away 11
}

alias away.refresh {
if (!$did(away,7)) did -b away 3
else did -e away 3
}

dialog away {
title "Away"
size -1 -1 251 152
icon $taskbar
option pixels
box "Away syst�me", 1, 5 1 241 51
box "", 13, 5 44 241 103
combo 2, 15 19 108 113, drop
edit "", 7, 63 61 172 22, autohs
edit "", 8, 63 84 172 22, autohs
text "Raison :", 9, 15 65 42 16, right
text "Pseudo :", 10, 15 88 42 16, right
button "Ajouter", 4, 130 19 47 21
button "Supprimer", 5, 177 19 57 21
button "Away", 3, 175 113 59 23, ok
button "Revenir", 11, 118 113 57 23
button "Annuler", 12, 64 113 54 23, cancel
}

on *:dialog:away:init:*:{
dll script/mdx/mdx.dll SetMircVersion $version
dll script/mdx/mdx.dll MarkDialog away
var %a = 1
while (%a <= $lines(script/bdd/away.tbl)) {
var %ligne = $read(script/bdd/away.tbl,%a)
did -a away 2 $gettok(%ligne,1,9)
if (%a == 1) {
did -a away 7 $gettok(%ligne,2,9)
did -a away 8 $gettok(%ligne,3,9)
}
inc %a
}
did -c away 2 1
if (!$away) did -b away 11
away.refresh
}

on *:dialog:away:sclick:2:{
var %ligne = $read(script/bdd/away.tbl,$did(away,2).sel)
did -o away 7 1 $gettok(%ligne,2,9)
did -o away 8 1 $gettok(%ligne,3,9)
away.refresh
}

on *:dialog:away:sclick:3:{
scid $activecid
if (%nick.default == $null) {
set %nick.default $me
var %a = $input(Vous n'avez pas sp�cifi� de pseudo de retour. Le pseudo que vous avez actuellement sera utilis� comme pseudo de retour. Pour le changer allez dans la configuration du script (F2),oh,Away)
}
if (%away.say == 1) $iif(%away.all,scid -a) ame $replace(%away.msg,<raison>,$did(away,7),<heure>,$left($time,5))
elseif (%away.say == 2) describe $active $replace(%away.msg,<raison>,$did(away,7),<heure>,$left($time,5))
$iif(%away.all,scid -a) nick $$did(away,8)
$iif(%away.all,scid -a) away $$did(away,7)
if (($dialog(mp3)) && (%away.mp3)) mp3.stop
}

on *:dialog:away:sclick:4:{
var %a = $$?="Raison :"
if (!%a) halt
write script/bdd/away.tbl $+(%a,$chr(9),%a,$chr(9),$me)
did -a away 2 %a
did -o away 7 1 %a
did -o away 8 1 $me
did -c away 2 $did(away,2).lines
away.refresh
}

on *:dialog:away:sclick:5:{
var %a = $did(away,2).sel
if (!%a) halt
write -dl $+ %a script/bdd/away.tbl
did -d away 2 %a
did -c away 2 1
did -r away 7,8
if (!$did(away,2).seltext) halt
var %ligne = $read(script/bdd/away.tbl)
did -a away 7 $gettok(%ligne,2,9)
did -a away 8 $gettok(%ligne,3,9)
away.refresh
}

on *:dialog:away:edit:7,8:{
write -l $+ $did(away,2).sel script/bdd/away.tbl $+($did(away,2).seltext,$chr(9),$did(away,7),$chr(9),$did(away,8))
away.refresh
}

on *:dialog:away:sclick:11:back

alias away.windowpager {
window -nk0 @Awaypager
kte_echo @Awaypager --------------------------------------------------------
kte_echo @Awaypager * Awaypager - Les highlights seront logg�s ici *
kte_echo @Awaypager --------------------------------------------------------
echo @Awaypager 
}

on !*:text:*:#:{
if (($me isin $1-) && (%away.pager) && ($away)) {
if (!$window(@Awaypager)) away.windowpager
var %texte = $chr(91) $+ $chan $+ $chr(93) < $+ $nick $+ > $1-
kte_echo @Awaypager %texte
}
}

on !*:action:*:#:{
if (($me isin $1-) && (%away.pager) && ($away)) {
if (!$window(@Awaypager)) away.windowpager
var %texte = $chr(91) $+ $chan $+ $chr(93) * $nick $1-
kte_echo @Awaypager %texte
}
}

on !*:notice:*:?:{
if ((%away.pager) && ($away)) {
if (!$window(@Awaypager)) away.windowpager
var %texte = $chr(91) $+ Notice $+ $chr(93) < $+ $nick $+ > $1-
kte_echo @Awaypager %texte
}
}

ctcp *:PAGE:?:{
if ((%away.pager) && ($away)) {
if (!$window(@Awaypager)) away.windowpager
var %texte = $chr(91) $+ Pager $+ $chr(93) < $+ $nick $+ > $2-
kte_echo @Awaypager %texte
haltdef
}
}

on *:connect:if (%away.autoaway) autoaway

alias autoaway .timer.autoaway -i 0 30 autoaway.check

alias autoaway.check {
scid $activecid
if (($idle >= $calc(%away.autoaway.min * 60)) && (!$away) && (%away.autoaway)) {
scid $activecid
if (%nick.default == $null) {
set %nick.default $me
}
resetidle
var %phrase = Auto away apr�s %away.autoaway.min minutes d'inactivit�
if (%away.say == 1) $iif(%away.all == 1,scid -a) ame $replace(%away.msg,<raison>,%phrase,<heure>,$left($time,5))
elseif (%away.say == 2) describe $active $replace(%away.msg,<raison>,%phrase,<heure>,$left($time,5))
if (%away.nick) $iif(%away.all == 1,scid -a) nick %away.nick
$iif(%away.all == 1,scid -a) away %phrase
}
}