alias protection dialog $iif($dialog(protection),-v,-m) protection protection

dialog protection {
title "Protections"
size -1 -1 378 323
icon $taskbar
option pixels
tab "Channels", 1, 5 5 367 289
tab "Personnelle", 2
text "X Fois", 25, 107 38 34 16
text "En X Secondes", 26, 164 38 74 16
text "Action", 51, 252 38 36 16
box "", 13, 243 31 2 226, tab 1
box "", 11, 153 31 2 226, tab 1
box "", 10, 89 31 2 226, tab 1
box "", 65, 89 31 2 126, tab 2
box "", 67, 243 31 2 126, tab 2
box "", 68, 153 31 2 126, tab 2
box "", 87, 15 184 348 8, tab 2
box "", 4, 15 49 348 8
box "", 22, 15 249 348 8, tab 1
box "", 21, 15 224 348 8, tab 1
box "", 19, 15 199 348 8, tab 1
box "", 9, 15 174 348 8, tab 1
box "", 8, 15 149 348 8
box "", 7, 15 124 348 8
box "", 6, 15 99 348 8
box "", 5, 15 74 348 8
check "Texte", 100, 17 59 62 20, tab 1
edit %flood.texte.fois, 101, 92 58 60 21, tab 1 disable
edit %flood.texte.seconde, 102, 156 58 86 21, tab 1 disable
combo 103, 247 58 116 90, tab 1 size drop disable
check "Notice", 110, 17 84 62 20, tab 1
edit %flood.notice.fois, 111, 92 83 60 21, tab 1 disable
edit %flood.notice.seconde, 112, 156 83 86 21, tab 1 disable
combo 113, 247 83 116 90, tab 1 size drop disable
check "Ctcp", 120, 17 109 62 20, tab 1
edit %flood.ctcp.fois, 121, 92 108 60 21, tab 1 disable
edit %flood.ctcp.seconde, 122, 156 108 86 21, tab 1 disable
combo 123, 247 108 116 90, tab 1 size drop disable
check "Devoice", 130, 17 134 62 20, tab 1
edit %flood.devoice.fois, 131, 92 133 60 21, tab 1 disable
edit %flood.devoice.seconde, 132, 156 133 86 21, tab 1 disable
combo 133, 247 133 116 90, tab 1 size drop disable
check "Deop", 140, 17 159 62 20, tab 1
edit %flood.deop.fois, 141, 92 158 60 21, tab 1 disable
edit %flood.deop.seconde, 142, 156 158 86 21, tab 1 disable
combo 143, 247 158 116 90, tab 1 size drop disable
check "Kick", 150, 17 184 62 20, tab 1
edit %flood.kick.fois, 151, 92 183 60 21, tab 1 disable
edit %flood.kick.seconde, 152, 156 183 86 21, tab 1 disable
combo 153, 247 183 116 90, tab 1 size drop disable
check "Ban", 160, 17 209 62 20, tab 1
edit %flood.ban.fois, 161, 92 208 60 21, tab 1 disable
edit %flood.ban.seconde, 162, 156 208 86 21, tab 1 disable
combo 163, 247 208 116 90, tab 1 size drop disable
check "Pub", 170, 17 234 62 20, tab 1
edit %flood.pub.fois, 171, 92 233 60 21, tab 1 disable
edit %flood.pub.seconde, 172, 156 233 86 21, tab 1 disable
combo 173, 247 233 116 90, tab 1 size drop disable
check "Activer pour les voices", 501, 17 263 132 20, tab 1
check "Activer pour les ops", 502, 158 263 118 20, tab 1
text "Flood", 14, 36 38 30 16, tab 1
text "Ignore masque :", 88, 18 202 82 16, tab 2
text "Ban masque :", 90, 32 229 68 16, tab 2
check "Texte", 200, 17 59 62 20, tab 2
edit %flood.texte2.fois, 201, 92 58 60 21, tab 2 disable
edit %flood.texte2.seconde, 202, 156 58 86 21, tab 2 disable
combo 203, 247 58 116 92, tab 2 size drop disable
check "Notice", 210, 17 84 62 20, tab 2
edit %flood.notice2.fois, 211, 92 83 60 21, tab 2 disable
edit %flood.notice2.seconde, 212, 156 83 86 21, tab 2 disable
combo 213, 247 83 116 92, tab 2 size drop disable
check "Ctcp", 220, 17 109 62 20, tab 2
edit %flood.ctcp2.fois, 221, 92 108 60 21, tab 2 disable
edit %flood.ctcp2.seconde, 222, 156 108 86 21, tab 2 disable
combo 223, 247 108 116 92, tab 2 size drop disable
check "Invite", 230, 17 134 62 20, tab 2
edit %flood.invite.fois, 231, 92 133 60 21, tab 2 disable
edit %flood.invite.seconde, 232, 156 133 86 21, tab 2 disable
combo 233, 247 133 116 92, tab 2 size drop disable
check "Deop/Devoice Protection", 503, 17 164 140 20, tab 2
check "Ban Protection", 504, 162 164 90 20, tab 2
check "Avertir le flooder", 505, 258 164 102 20, tab 2
combo 89, 106 199 170 105, tab 2 size drop
combo 91, 106 226 170 105, tab 2 size drop
check "D�sactiver la protection pour les bots (Q, L, X...)", 12, 17 263 260 20, tab 2
box "", 3, 15 248 348 8, tab 2
text "Flood", 15, 36 38 30 16, tab 2
button "Ok", 79, 235 297 67 21, ok
button "Annuler", 78, 306 297 67 21, cancel
}

on *:dialog:protection:init:*:{
dll script/mdx/mdx.dll SetMircVersion $version
dll script/mdx/mdx.dll MarkDialog protection
if (%flood.texte) { did -c protection 100 | did -e protection 101,102,103 }
if (%flood.notice) { did -c protection 110 | did -e protection 111,112,113 }
if (%flood.ctcp) { did -c protection 120 | did -e protection 121,122,123 }
if (%flood.devoice) { did -c protection 130 | did -e protection 131,132,133 }
if (%flood.deop) { did -c protection 140 | did -e protection 141,142,143 }
if (%flood.kick) { did -c protection 150 | did -e protection 151,152,153 }
if (%flood.ban) { did -c protection 160 | did -e protection 161,162,163 }
if (%flood.pub) { did -c protection 170 | did -e protection 171,172,173 }
if (%flood.texte2) { did -c protection 200 | did -e protection 201,202,203 }
if (%flood.notice2) { did -c protection 210 | did -e protection 211,212,213 }
if (%flood.ctcp2) { did -c protection 220 | did -e protection 221,222,223 }
if (%flood.invite) { did -c protection 230 | did -e protection 231,232,233 }

if (%flood.voice) did -c protection 501
if (%flood.op) did -c protection 502
if (%protection.deop) did -c protection 503
if (%protection.ban) did -c protection 504
if (%protection.bot) did -c protection 12
if (%flood.avertir) did -c protection 505

did -a protection 103,113,123,173 Avertir
didtok -a protection 103,113,123,133,143,153,163,173 44 Kick,KickBan
didtok -a protection 133,143,153,163 44 Deop,Blacklist
didtok -a protection 203,213,223,233 44 Ignorer,Ignorer 1min,Ignorer 2min,Ignorer 5min,Ignorer 10min,Ignorer 20min,Ignorer 30min,Ignorer 60min
didtok -a protection 89,91 44 [0] *!ident@host.domaine.com,[1] *!*ident@host.domaine.com,[2] *!*@host.domaine.com,[3] *!*ident@*.domaine.com,[4] *!*@*.domaine.com,[5] nick!ident@host.domaine.com,[6] nick!*ident@host.domaine.com,[7] nick!*@host.domaine.com,[8] nick!*ident@*.domaine.com,[9] nick!*@*.domaine.com

did -c protection 103 $didwm(protection,103,%flood.texte.action,1)
did -c protection 113 $didwm(protection,113,%flood.notice.action,1)
did -c protection 123 $didwm(protection,123,%flood.ctcp.action,1)
did -c protection 133 $didwm(protection,133,%flood.devoice.action,1)
did -c protection 143 $didwm(protection,143,%flood.deop.action,1)
did -c protection 153 $didwm(protection,153,%flood.kick.action,1)
did -c protection 163 $didwm(protection,163,%flood.ban.action,1)
did -c protection 173 $didwm(protection,173,%flood.pub.action,1)
did -c protection 203 $didwm(protection,203,%flood.texte2.action,1)
did -c protection 213 $didwm(protection,213,%flood.notice2.action,1)
did -c protection 223 $didwm(protection,223,%flood.ctcp2.action,1)
did -c protection 233 $didwm(protection,233,%flood.invite.action,1)
did -c protection 89 $calc(%mask.ignore + 1)
did -c protection 91 $calc(%mask.ban + 1)
}

on *:dialog:protection:sclick:100,110,120,130,140,150,160,170,200,210,220,230:{
if ($did(protection,$did).state) did -e protection $calc($did + 1) $+ , $+ $calc($did + 2) $+ , $+ $calc($did + 3)
else did -b protection $calc($did + 1) $+ , $+ $calc($did + 2) $+ , $+ $calc($did + 3)
}

on *:dialog:protection:close:*:{
var %a = 10
while (%a <= 23) {
var %b = $calc(%a * 10)
if ((%a < 20) || (%a == 23)) var %nom = $did(protection,%b)
else var %nom = $did(protection,%b) $+ 2

set %flood. $+ %nom $did(protection,%b).state
set %flood. $+ %nom $+ .fois $did(protection,$calc(%b + 1))
set %flood. $+ %nom $+ .seconde $did(protection,$calc(%b + 2))
set %flood. $+ %nom $+ .action $did(protection,$calc(%b + 3)).seltext

if (%a = 17) var %a = 20
else inc %a
}

set %flood.voice $did(protection,501).state
set %flood.op $did(protection,502).state
set %flood.avertir $did(protection,505).state
set %protection.deop $did(protection,503).state
set %protection.ban $did(protection,504).state
set %protection.bot $did(protection,12).state
set %mask.ignore $calc($did(protection,89).sel - 1)
set %mask.ban $calc($did(protection,91).sel - 1)
}

on @*:text:*:#:{
if (($len($nick) == 1) && (%protection.bot)) halt
if (($nick isvoice $chan) && (%flood.voice != 1)) halt
if (($nick isop $chan) && (%flood.op != 1)) halt
if (%flood.texte) {
if (%flood.texte.fois > 1) {
inc -u $+ %flood.texte.seconde $chr(37) $+ flood.texte. $+ $chan $+ . $+ $nick
if (%flood.texte. [ $+ [ $chan ] $+ . $+ [ $nick ] ] >= %flood.texte.fois) {
if (%flood.texte.action == Avertir) notice $nick Flood pas stp
if (%flood.texte.action == Kick) kick $chan $nick Flood $+ $kick.counter
if (%flood.texte.action == Kickban) { mode $chan +b-o $address($nick,%mask.ban) $nick | kick $chan $nick Flood $+ $kick.counter }
unset %flood.texte. $+ $chan $+ . $+ $nick
}
}
}
if (%flood.pub) {
if ((%flood.pub.fois > 0) && ($chr(35) isin $1-)) {
inc -u $+ %flood.pub.seconde $chr(37) $+ flood.pub. $+ $chan $+ . $+ $nick
if (%flood.pub. [ $+ [ $chan ] $+ . $+ [ $nick ] ] >= %flood.pub.fois) {
var %nombre = %flood.pub. [ $+ [ $chan ] $+ . $+ [ $nick ] ]
if (%flood.pub.action == Avertir) notice $nick $iif(%nombre > 1,Pub Flood,Pas de pub !)
if (%flood.pub.action == Kick) kick $chan $nick $iif(%nombre > 1,Pub Flood,Pas de pub !) $+ $kick.counter
if (%flood.pub.action == Kickban) { mode $chan +b-o $address($nick,%mask.ban) $nick | kick $chan $nick Pas de pub ! $+ $kick.counter }
unset %flood.pub. $+ $chan $+ . $+ $nick
}
}
}
}

on @*:action:*:#:{
if (!%flood.texte) halt
if (($len($nick) == 1) && (%protection.bot)) halt
if (($nick isvoice $chan) && (%flood.voice != 1)) halt
if (($nick isop $chan) && (%flood.op != 1)) halt
if (%flood.texte.fois > 1) {
inc -u $+ %flood.texte.seconde $chr(37) $+ flood.texte. $+ $chan $+ . $+ $nick
if (%flood.texte. [ $+ [ $chan ] $+ . $+ [ $nick ] ] >= %flood.texte.fois) {
if (%flood.texte.action == Avertir) notice $nick Flood pas !
if (%flood.texte.action == Kick) kick $chan $nick Flood $+ $kick.counter
if (%flood.texte.action == Kickban) { mode $chan +b-o $address($nick,%mask.ban) $nick | kick $chan $nick Flood $+ $kick.counter }
unset %flood.texte. $+ $chan $+ . $+ $nick
}
}
}

on @*:notice:*:#:{
if (!%flood.notice) halt
if (($len($nick) == 1) && (%protection.bot)) halt
if (($nick isvoice $chan) && (!%flood.voice)) halt
if (($nick isop $chan) && (!%flood.op)) halt
if (%flood.notice.fois > 1) {
inc -u $+ %flood.notice.seconde $chr(37) $+ flood.notice. $+ $chan $+ . $+ $nick
if (%flood.notice. [ $+ [ $chan ] $+ . $+ [ $nick ] ] >= %flood.notice.fois) {
if (%flood.notice.action == Avertir) notice $nick Flood pas !
if (%flood.notice.action == Kick) kick $chan $nick Notice Flood $+ $kick.counter
if (%flood.notice.action == Kickban) { mode $chan +b-o $address($nick,%mask.ban) $nick | kick $chan $nick Notice Flood $+ $kick.counter }
unset %flood.notice. $+ $chan $+ . $+ $nick
}
}
}

ctcp @*:*:#:{
if ($1 != DCC) {
if (!%flood.ctcp) halt
if (($len($nick) == 1) && (%protection.bot)) halt
if (($nick isvoice $chan) && (!%flood.voice)) halt
if (($nick isop $chan) && (!%flood.op)) halt
if (%flood.ctcp.fois > 1) {
inc -u $+ %flood.ctcp.seconde $chr(37) $+ flood.ctcp. $+ $chan $+ . $+ $nick
if (%flood.ctcp. [ $+ [ $chan ] $+ . $+ [ $nick ] ] >= %flood.ctcp.fois) {
if (%flood.ctcp.action == Avertir) notice $nick Flood pas !
if (%flood.ctcp.action == Kick) kick $chan $nick Ctcp Flood $+ $kick.counter
if (%flood.ctcp.action == Kickban) { mode $chan +b-o $address($nick,%mask.ban) $nick | kick $chan $nick Ctcp Flood $+ $kick.counter }
unset %flood.ctcp. $+ $chan $+ . $+ $nick
}
}
}
}

on !@*:devoice:#:{
if (($len($nick) == 1) && (%protection.bot)) halt
if ((%flood.devoice) && (%flood.devoice.fois)) {
inc -u $+ %flood.devoice.seconde $chr(37) $+ flood.devoice. $+ $chan $+ . $+ $nick
if (%flood.devoice. [ $+ [ $chan ] $+ . $+ [ $nick ] ] >= %flood.devoice.fois) {
if (%flood.devoice.action == Deop) mode $chan $nick -o
if (%flood.devoice.action == Kick) kick $chan $nick Mass Devoice $+ $kick.counter
if (%flood.devoice.action == Kickban) { mode $chan +b-o $address($nick,%mask.ban) $nick | kick $chan $nick Mass Devoice $+ $kick.counter }
if (%flood.devoice.action == Blacklist) blacklist.add $address($nick,%mask.ban)
unset %flood.devoice. $+ $chan $+ . $+ $nick
}
}
}

on !@*:deop:#:{
if (($len($nick) == 1) && (%protection.bot)) halt
if ((%flood.deop) && (%flood.deop.fois)) {
inc -u $+ %flood.deop.seconde $chr(37) $+ flood.deop. $+ $chan $+ . $+ $nick
if (%flood.deop. [ $+ [ $chan ] $+ . $+ [ $nick ] ] >= %flood.deop.fois) {
if (%flood.deop.action == Deop) mode $chan $nick -o
if (%flood.deop.action == Kick) kick $chan $nick Mass Deop $+ $kick.counter
if (%flood.deop.action == Kickban) { mode $chan +b-o $address($nick,%mask.ban) $nick | kick $chan $nick Mass Deop $+ $kick.counter }
if (%flood.devoice.action == Blacklist) blacklist.add $address($nick,%mask.ban)
unset %flood.deop. $+ $chan $+ . $+ $nick
}
}
}

on !@*:kick:#:{
if (($len($nick) == 1) && (%protection.bot)) halt
if ((%flood.kick) && (%flood.kick.fois)) {
inc -u $+ %flood.kick.seconde $chr(37) $+ flood.kick. $+ $chan $+ . $+ $nick
if (%flood.kick. [ $+ [ $chan ] $+ . $+ [ $nick ] ] >= %flood.kick.fois) {
if (%flood.kick.action == Deop) mode $chan $nick -o
if (%flood.kick.action == Kick) kick $chan $nick Mass Kick $+ $kick.counter
if (%flood.kick.action == Kickban) { mode $chan +b-o $address($nick,%mask.ban) $nick | kick $chan $nick Mass Kick $+ $kick.counter }
if (%flood.kick.action == Blacklist) blacklist.add $address($nick,%mask.ban)
unset %flood.kick. $+ $chan $+ . $+ $nick
}
}
}

on !@*:ban:#:{
if (($len($nick) == 1) && (%protection.bot)) halt
if ((%flood.ban) && (%flood.ban.fois) && ($ialchan($banmask,#,0) < 0)) {
inc -u $+ %flood.ban.seconde $chr(37) $+ flood.ban. $+ $chan $+ . $+ $nick
if (%flood.ban. [ $+ [ $chan ] $+ . $+ [ $nick ] ] >= %flood.ban.fois) {
if (%flood.ban.action == Deop) mode $chan $nick -o
if (%flood.ban.action == Kick) kick $chan $nick Mass Ban $+ $kick.counter
if (%flood.ban.action == Kickban) { mode $chan +b-o $address($nick,%mask.ban) $nick | kick $chan $nick Mass Ban $+ $kick.counter }
if (%flood.ban.action == Blacklist) blacklist.add $address($nick,%mask.ban)
unset %flood.ban. $+ $chan $+ . $+ $nick
}
}
}

on *:text:*:?:{
if (($len($nick) == 1) && (%protection.bot)) halt
if ((%flood.texte2) && (%flood.texte2.fois > 1) && ($len($nick) > %protection.bot)) {
inc -u $+ %flood.texte2.seconde $chr(37) $+ flood.texte2. $+ $chan $+ . $+ $nick
if (%flood.texte2. [ $+ [ $chan ] $+ . $+ [ $nick ] ] >= %flood.texte2.fois) {
.ignore - $+ $iif($left($gettok(%flood.texte2.action,2,32),-3),u $+ $calc($left($gettok(%flood.texte2.action,2,32),-3) * 60)) $address($nick,%mask.ignore)
if (%flood.avertir) notice $nick tu a �t� ignor�
unset %flood.texte2. $+ $chan $+ . $+ $nick
}
}
}

on *:action:*:?:{
if (($len($nick) == 1) && (%protection.bot)) halt
if ((%flood.texte2) && (%flood.texte2.fois > 1) && ($len($nick) > %protection.bot)) {
inc -u $+ %flood.texte2.seconde $chr(37) $+ flood.texte2. $+ $chan $+ . $+ $nick
if (%flood.texte2. [ $+ [ $chan ] $+ . $+ [ $nick ] ] >= %flood.texte2.fois) {
.ignore - $+ $iif($left($gettok(%flood.texte2.action,2,32),-3),u $+ $calc($left($gettok(%flood.texte2.action,2,32),-3) * 60)) $address($nick,%mask.ignore)
if (%flood.avertir) .notice $nick tu a �t� ignor�
unset %flood.texte2. $+ $chan $+ . $+ $nick
}
}
}

on *:notice:*:#:{
if (($len($nick) == 1) && (%protection.bot)) halt
if ((%flood.notice2) && (%flood.notice2.fois > 1) && ($len($nick) > %protection.bot)) {
inc -u $+ %flood.notice.seconde $chr(37) $+ flood.notice2. $+ $chan $+ . $+ $nick
if (%flood.notice2. [ $+ [ $chan ] $+ . $+ [ $nick ] ] >= %flood.notice2.fois) {
.ignore - $+ $iif($left($gettok(%flood.notice2.action,2,32),-3),u $+ $calc($left($gettok(%flood.notice2.action,2,32),-3) * 60)) $address($nick,%mask.ignore)
if (%flood.avertir) .notice $nick tu a �t� ignor�
unset %flood.notice2. $+ $chan $+ . $+ $nick
}
}
}

ctcp *:*:?:{
if ($1 != DCC) {
if (($len($nick) == 1) && (%protection.bot)) halt
if ((%flood.ctcp2) && (%flood.ctcp2.fois > 1) && ($len($nick) > %protection.bot)) {
inc -u $+ %flood.ctcp2.seconde $chr(37) $+ flood.ctcp2. $+ $chan $+ . $+ $nick
if (%flood.ctcp2. [ $+ [ $chan ] $+ . $+ [ $nick ] ] >= %flood.ctcp2.fois) {
.ignore - $+ $iif($left($gettok(%flood.ctcp2.action,2,32),-3),u $+ $calc($left($gettok(%flood.ctcp2.action,2,32),-3) * 60)) $address($nick,%mask.ignore)
if (%flood.avertir) .notice $nick tu a �t� ignor�
unset %flood.ctcp2. $+ $chan $+ . $+ $nick
}
}
}
}

on *:invite:#:{
if (($len($nick) == 1) && (%protection.bot)) halt
if ((%flood.invite) && (%flood.invite.fois > 1) && ($len($nick) > %protection.bot)) {
inc -u $+ %flood.invite.seconde $chr(37) $+ flood.invite. $+ $chan $+ . $+ $nick
if (%flood.invite. [ $+ [ $chan ] $+ . $+ [ $nick ] ] >= %flood.invite.fois) {
.ignore - $+ $iif($left($gettok(%flood.invite.action,2,32),-3),u $+ $calc($left($gettok(%flood.invite.action,2,32),-3) * 60)) $address($nick,%mask.ignore)
if (%flood.avertir) .notice $nick tu a �t� ignor�
unset %flood.invite. $+ $chan $+ . $+ $nick
}
}
}

on !@*:ban:*:{
if (($banmask iswm $address($me,5)) && (%protection.ban)) {
.raw mode # +b-ob $address($nick,%mask.ban) $nick $banmask
.raw kick # $nick :Ban protection
}
}

on !*:ban:*:{
if (($banmask iswm $address($me,5)) && (%protection.ban) && ($network == QuakeNet)) {
.ignore -nu5 *!*@*quakenet*
if (Q ison #) { .raw PRIVMSG Q :invite # }
elseif (L ison #) { .timerantiban $+ $ticks 1 1 .raw PRIVMSG L :invite # }
.timerjoin $+ $ticks 1 2 .raw JOIN #
}
}

on !*:deop:*:{
if ((%protection.deop) && ($opnick == $me) && ($network == QuakeNet)) {
.ignore -u5 *!*@*quakenet*
if (Q ison #) .raw PRIVMSG Q :op #
elseif (L ison #) .raw PRIVMSG L :op #
else .raw PRIVMSG O :requestop # $me
}
}

on !*:devoice:*:{
if ((%protection.deop) && ($vnick == $me) && ($network == QuakeNet)) {
.ignore -u5 *!*@*quakenet*
if (Q ison #) .raw PRIVMSG Q :voice #
elseif (L ison #) .raw PRIVMSG L :voice #
}
}