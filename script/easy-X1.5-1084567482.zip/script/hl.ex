alias hl dialog $iif($dialog(hl),-v,-m) hl hl

dialog hl {
title "Half-Life Serveurs Manager"
size -1 -1 525 $iif(%hl.h,%hl.h,222)
icon $taskbar
option pixels
list 50, 8 10 508 20, size
list 100, 9 35 506 185, size
list 101, 9 35 223 185, size hide
list 102, 235 35 280 185, size hide
button , 1000, -1 -1 1 1
box "", 1, 3 -1 519 222
}

on *:dialog:hl:init:*:{
dll script/mdx/mdx.dll SetMircVersion $version
dll script/mdx/mdx.dll MarkDialog hl
dll script/mdx/mdx.dll SetBorderStyle 50
dll script/mdx/mdx.dll SetControlMDX 50 ToolBar list flat nodivider > script\mdx\bars.mdx
dll script/mdx/mdx.dll SetControlMDX 100,101 listview infotip showsel report single rowselect nosortheader > script/mdx/views.mdx
dll script/mdx/mdx.dll SetControlMDX 102 listview sortascending infotip showsel report single rowselect nosortheader > script/mdx/views.mdx
dll script/mdx/mdx.dll SetControlMDX 1000 Positioner size minbox > script\mdx\dialog.mdx
did -i hl 100 1 headerdims 192 42 84 36 132 0
did -i hl 101 1 headerdims 41 160
did -i hl 102 1 headerdims 138 120
did -i hl 100 1 headertext Nom du serveur $+ $chr(9) $+ Place $+ $chr(9) $+ Map $+ $chr(9) $+ Ping $+ $chr(9) $+ Ip $+ $chr(9) $+ Mod
did -i hl 101 1 headertext Score $+ $chr(9) $+ Pseudo
did -i hl 102 1 headertext Variable $+ $chr(9) $+ Valeur
did -i hl 100,101,102 1 setbkg color %couleur.hlfond
did -i hl 100,101,102 1 settxt color %couleur.hltexte
did -i hl 100,101,102 1 settxt bgcolor %couleur.hlfond
did -i hl 50 1 bmpsize 16 16
did -i hl 50 1 bwidth 80 81
did -i hl 50 1 pad 6 6
did -i hl 50 1 setimage +nhd 0 icon small 0,script/icone/panel.icl
did -i hl 50 1 setimage +nhd 0 icon small 1,script/icone/panel.icl
did -i hl 50 1 setimage +nhd 0 icon small 2,script/icone/panel.icl
did -i hl 50 1 setimage +nhd 0 icon small 3,script/icone/panel.icl
did -i hl 50 1 setimage +nhd 0 icon small 4,script/icone/panel.icl
did -i hl 50 1 setimage +nhd 0 icon small 5,script/icone/panel.icl
did -i hl 100 1 seticon list 6,script/icone/panel.icl
did -i hl 100 1 seticon list 7,script/icone/panel.icl
did -a hl 50 +a 1 Connexion
did -a hl 50 +a -
did -a hl 50 +a 2 Ajouter
did -a hl 50 +a 3 Supprimer
did -a hl 50 +a -
did -a hl 50 +a 4 Actualiser
did -a hl 50 +a 5 Actualiser liste
did -a hl 50 +a -
did -a hl 50 +a 6 D�tails
loadbuf -o hl 100 script/bdd/hl.tbl
}

on *:dialog:hl:close:*:{
did -c hl 100 1
;hl.save
set %hl.h $calc($dialog(hl).h - 27)
sockclose hl*
.timer.hl* off
.timer.refresh* off
}

alias hl.save savebuf -o 2-1000 hl 100 script/bdd/hl.tbl

alias hl.timeout {
.sockclose hl.add
var %a = $input(Le serveur ne r�pond pas.,oh,Erreur)
}

on *:dialog:hl:sclick:50:{
if ($did(hl,50).sel == 2) hl.connexion
elseif ($did(hl,50).sel == 4) { hl.add $$input(Ip du serveur :,e,Half-life) | did -h hl 101,102 | did -v hl 100 | did -o hl 50 10 6 D�tails }
elseif ($did(hl,50).sel == 5) { did -h hl 101,102 | did -v hl 100 | did -o hl 50 10 6 D�tails | hl.supp }
elseif ($did(hl,50).sel == 7) {
if ($gettok($did(hl,50,10),3,32) == D�tails) hl.refresh
else {
var %ligne = $did(hl,100).seltext
var %ip = $gettok($gettok(%ligne,5,9),5,32)
did -r hl 101,102
sockudp -nk hl.players $replace(%ip,$chr(58),$chr(32)) ����players
sockudp -nk hl.rules $replace(%ip,$chr(58),$chr(32)) ����rules
}
}
elseif ($did(hl,50).sel == 8) { hl.refresh.all | did -h hl 101,102 | did -v hl 100 | did -o hl 50 10 6 D�tails }
elseif ($did(hl,50).sel == 10) {
if ($gettok($did(hl,50,10),3,32) == D�tails) {
var %a = $did(hl,100).sel
if (!%a) halt
did -h hl 100
did -rv hl 101,102
did -o hl 50 10 6 Retour
var %ligne = $did(hl,100).seltext
var %ip = $gettok($gettok(%ligne,5,9),5,32)
sockudp -nk hl.players $replace(%ip,$chr(58),$chr(32)) ����players
sockudp -nk hl.rules $replace(%ip,$chr(58),$chr(32)) ����rules
}
else {
did -h hl 101,102
did -v hl 100
did -o hl 50 10 6 D�tails
sockclose hl.players
sockclose hl.rules
}
}
}

on *:dialog:hl:sclick:100:{
if (($gettok($did(hl,100,1),1,32) == rclick) && ($did(hl,100).sel)) {
set %temp.ip $gettok($gettok($did(hl,100).seltext,5,9),5,32)
var %a = $dll(script/dll/popread.dll,popread,script/bdd/menu.tbl?1?7? $+ $mouse.dx $+ ? $+ $mouse.dy)
}
}

on *:dialog:hl:sclick:1000:{
var %h = $gettok($did(hl,1000),6,32)
var %h2 = $dialog(hl).h
did -a hl 1000 setsize 533 $iif(%h <= 164,164,%h)
dll script/mdx/mdx.dll MoveControl hl 1 * * * $calc(%h2 - 29)
dll script/mdx/mdx.dll MoveControl hl 100 * * * $calc(%h2 - 71)
dll script/mdx/mdx.dll MoveControl hl 101 * * * $calc(%h2 - 71)
dll script/mdx/mdx.dll MoveControl hl 102 * * * $calc(%h2 - 71)
}

alias hl.add {
if (($gettok($1,1,46) isnum 0-254) && ($gettok($1,2,46) isnum 0-254) && ($gettok($1,3,46) isnum 0-254) && ($gettok($gettok($1,1,46),1,58) isnum 0-254) && ($gettok($1,2,58) isnum 1-65335)) {
if ($didwm(hl,100,* $+ $1 $+ *,0) == 0) { 
sockudp -nk hl.add $replace($1,$chr(58),$chr(32)) ����details 
set -u4 %ping $ticks
.timer.hl.add -o 1 3 hl.timeout
}
else {
did -c hl 100 $didwm(hl,100,* $+ $1 $+ *,0)
var %a = $input(le serveur existe d�j� !,oh,Half-Life)
}
}
else var %a $input(L'ip ne semble pas �tre valide,oh,Half-Life)
}

alias hl.refresh {
var %a = $did(hl,100).sel
if (!%a) halt
.timer.hl.refresh.* off
sockclose hl.refresh.*
unset %hl.sel
var %ip = $gettok($gettok($did(hl,100,%a),5,9),5,32)
sockudp -nk hl.refresh. $+ %a $replace(%ip,:,$chr(32)) ����details
set -u4 %serveur.ping. $+ %a $ticks
.timer.hl.refresh. $+ %a -o 1 3 did -o hl 100 %a 0 1 Le serveur ne r�pond pas $+ $chr(9) $+ ?/? $+ $chr(9) $+ ?? $+ $chr(9) $+ 0 0 0 ?? $+ $chr(9) $+ %ip
}

alias hl.refresh.all.timer {
inc %hl.sel
var %a = $calc(%hl.sel + 1)
did -c hl 100 $calc(%a + 1)
set -u4 %serveur.ping. $+ %a $ticks
var %ip = $gettok($gettok($did(hl,100,%a),5,9),5,32)
sockudp -nk hl.refresh. $+ %a $replace(%ip,:,$chr(32)) ����details
.timer.hl.refresh. $+ %a -o 1 3 did -o hl 100 %a 0 1 Le serveur ne r�pond pas $+ $chr(9) $+ ?/? $+ $chr(9) $+ ?? $+ $chr(9) $+ 0 0 0 ?? $+ $chr(9) $+ %ip
}

alias hl.refresh.all {
var %a = $calc($did(hl,100).lines - 1)
if (%a < 1) halt
set %hl.sel 0
.timer.hl.refresh.* off
sockclose hl.refresh.*
.timer.refresh.liste -mo %a 32 hl.refresh.all.timer
}

alias hl.supp {
if (($did(hl,100).sel < 2) || (!$did(hl,100).sel)) halt
did -d hl 100 $did(hl,100).sel
.timer.hl.refresh* off
hl.save
}

alias hl.connexion {
if (!$did(hl,100).sel) halt
if (!$exists(%hl.exe)) { var %a = $input(L'�x�cutable d'Half-life n'a pas �t� trouv�.,ho,Half-Life) | halt }
scid $activecid

var %ligne = $did(hl,100).seltext
var %nom = $gettok($gettok(%ligne,1,9),6-,32)
var %joueurs = $gettok($gettok(%ligne,2,9),5,32)
var %map = $gettok($gettok(%ligne,3,9),5-,32)
var %ping = $gettok($gettok(%ligne,4,9),5,32)
var %ip = $gettok($gettok(%ligne,5,9),5,32)
var %mod = $gettok($gettok(%ligne,6,9),5-,32)
var %pass = $calc($gettok(%ligne,3,32) - 1)
if (%hl.pub) var %nom = $replace(%nom,$chr(35),)

if (%pass == 1) {
var %password = $?="Mot de passe du serveur :"
if ((%password == $false) || (%password == $null)) halt
}

run -p %hl.exe -console -game %mod %hl.param +connect %ip $$iif((%pass) && (%pass != $false),+password %password,$chr(32))

var %msg = $replace(%hl.msg,<ip>,%ip,<nom>,%nom,<map>,%map,<joueurs>,%joueurs,<ping>,%ping,<pass>,$iif(%pass == 1,oui,non),<mod>,%mod,<jeu>,$hl.mod(%mod),|,/)

if ((%hl.away) && ($status == connected)) {
if ((%hl.say == 2) && ($window($active).type != status)) describe $active %msg
if (%hl.say == 3) $iif(%away.all == 1,scid -a) ame %msg
if (%hl.nick) $iif(%away.all == 1,scid -a) nick %hl.nick
$iif(%away.all,scid -a) away %msg
}

if ((%hl.mp3 == 1) && ($dialog(mp3))) mp3.stop
}

on *:udpread:hl.add:{
.timer.hl.add off
sockread -nf &info
breplace &info 00 254
var %info = $bvar(&info,1,4096).text
var %pass = $iif($len($gettok(%info,6,254)) > 5,2,1)
if (($asc($right($left($gettok(%info,6,254),2),1)) == 46) || ($asc($right($left($gettok(%info,6,254),2),1)) == 47)) { var %players = 0 | var %maxplayers = $asc($left($gettok(%info,6,254),1)) }
else { var %players = $asc($left($gettok(%info,6,254),1)) | var %maxplayers = $asc($right($left($gettok(%info,6,254),2),1)) }
did -a hl 100 0 %pass $replace($gettok(%info,2,254),|,/) $+ $chr(9) $+ %players $+ / $+ %maxplayers $+ $chr(9) $+ $gettok(%info,3,254) $+ $chr(9) $+ 0 0 0 $calc($ticks - %ping) $+ $chr(9) $+ $sock($sockname).saddr $+ : $+ $sock($sockname).sport $+ $chr(9) $+ 0 0 0 $gettok(%info,4,254)
did -c hl 100 $did(hl,100).lines
sockclose hl.add
hl.save
}

on *:udpread:hl.refresh.*:{
var %a = $right($sockname,-11)
var %ping2 = $calc($ticks - %serveur.ping. [ $+ [ %a ] ] )
sockread -nf &info
breplace &info 00 254
var %info = $bvar(&info,1,4096).text
var %pass = $iif($len($gettok(%info,6,254)) > 5,2,1)
var %ligne = $didwm(hl,100,* $+ $sock($sockname).saddr $+ : $+ $sock($sockname).sport $+ *,0)
if (($asc($right($left($gettok(%info,6,254),2),1)) == 46) || ($asc($right($left($gettok(%info,6,254),2),1)) == 47)) { var %players = 0 | var %maxplayers = $asc($left($gettok(%info,6,254),1)) }
else { var %players = $asc($left($gettok(%info,6,254),1)) | var %maxplayers = $asc($right($left($gettok(%info,6,254),2),1)) }
did -o hl 100 %ligne 0 %pass $replace($gettok(%info,2,254),|,/) $+ $chr(9) $+ %players $+ / $+ %maxplayers $+ $chr(9) $+ $gettok(%info,3,254) $+ $chr(9) $+ 0 0 0 %ping2 $+ $chr(9) $+ $sock($sockname).saddr $+ : $+ $sock($sockname).sport $+ $chr(9) $+ 0 0 0 $gettok(%info,4,254)
if (!%hl.sel) did -c hl 100 %ligne
.timer.hl.refresh. $+ $right($sockname,-11) off
sockclose $sockname
hl.save
}

on *:udpread:hl.rules:{
sockread 7 &a
var %a = 1
while (%a < 60) {
sockread -f %rule
if ((���� isin %rule) || (0000 isin %rule) || (!%rule)) sockread -f %rule
if ((���� isin %rule) || (0000 isin %rule) || (!%rule)) sockread -f %rule
sockread -f %rule2
if (($len(%rule) > 4) && (%rule2)) did -a hl 102 0 0 0 $remove(%rule,$chr(18)) $+ $chr(9) $+ 0 0 0 %rule2
inc %a
}
sockclose hl.rules
unset %rule %rule2
}

on *:udpread:hl.players:{
sockread -fn &info
breplace &info 0 254
var %info = $replace($bvar(&info,1,$bvar(&info,0)).text,����,��)
var %a = 1
while (%a <= $gettok(%info,0,254)) {
if ($len($gettok(%info,%a,254)) > 5) did -a hl 101 0 0 0 0 $iif($asc($gettok(%info,$calc(%a + 1),254)) >= 70,0,$asc($gettok(%info,$calc(%a + 1),254))) $+ $chr(9) $+ 0 0 0 $right($gettok(%info,%a,254),-5)
inc %a
}
sockclose hl.players
if ($did(hl,101).lines == 1) did -a hl 101 $chr(9) $+ Pas de joueurs
}

alias hl.mod {
if ($1- == cstrike) return Counter-Strike
elseif ($1- == dod) return Day of Defeat
elseif ($1- == tfc) return Team Fortress Classic
elseif ($1- == dmc) return Death Match Classic
elseif ($1- == esf) return Earth's Special Forces
elseif ($1- == ns) return Natural Selection
elseif ($1- == ahl) return Action Half-Life
elseif ($1- == ricochet) return Ricochet
elseif ($1- == firearms) return Firearms
elseif ($1- == valve) return Half-Life
else return Half-Life/ $+ $1-
}

alias hl.say {
scid $activecid
var %ligne = $did(hl,100).seltext
var %nom = $replace(%info,<info>,$gettok($gettok(%ligne,1,9),6-,32),<nom>,Nom)
var %joueurs = $replace(%info,<info>,$gettok($gettok(%ligne,2,9),5,32),<nom>,Joueurs)
var %map = $replace(%info,<info>,$gettok($gettok(%ligne,3,9),5-,32),<nom>,Map)
var %ping = $replace(%info,<info>,$gettok($gettok(%ligne,4,9),5,32),<nom>,Ping)
var %ip = $replace(%info,<info>,$gettok($gettok(%ligne,5,9),5,32),<nom>,Ip)
var %mod = $replace(%info,<info>,$gettok($gettok(%ligne,6,9),5-,32),<nom>,Mod)
var %pass = $replace(%info,<info>,$iif($gettok(%ligne,3,32) == 2,oui,non),<nom>,Mot de passe)
if (%hl.pub) var %nom = $replace(%nom,$chr(35),)
say %ip %nom %map %joueurs %mod %ping %pass
}

alias nopar return $strip($remove($1-,$chr(40),$chr(41),[,],|,@,/,\,#,>,<),burc)

on ^*:hotlink:?*.?*.?*.?*:*:{
if (($gettok($nopar($1),1,46) isnum 0-255) && ($gettok($1,2,46) isnum 0-255) && ($gettok($1,3,46) isnum 0-255) && (http !isin $1) && (ftp !isin $1)) return
else halt
}

on *:hotlink:?*.?*.?*.?*:*:{
if (($gettok($nopar($1),1,46) isnum 0-255) && ($gettok($1,2,46) isnum 0-255) && ($gettok($1,3,46) isnum 0-255) && (http !isin $1) && (ftp !isin $1)) {
set %temp.ip $nopar($1)
var %a = $dll(script/dll/popread.dll,popread,script/bdd/menu.tbl?47?50? $+ $mouse.dx $+ ? $+ $mouse.dy)
}
else halt
}