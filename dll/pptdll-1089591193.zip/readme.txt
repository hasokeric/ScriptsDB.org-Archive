 PPTDLL.dll By BombStrike
 Muahaha get lamy !
 Build for: PPT MEGADEMO
 Updated for: All picwin.tk coders

 Thx to:
		StanZ my l0vze
		Zerg da gayz0r
		Epsilon for da best ouebsytes ( picwin.tk )
		My brain, for allz my ideas...

 Don't copy this or I will launch a mad cow on your face...

 
 HOW USE THIS SHIT ?

 1. SetRes

    With SetRes you can change your screenmode, how use it:
    //echo -a $dll(pptdll.dll,SetRes,N)
    where N is on of the next screenmodes:
	1. 320x240 256 colors
	2. 320x240  16 bits
	3. 320x240  24 bits
	4. 640x480 256 colors
	5. 640x480  16 bits
	6. 640x480  24 bits
	7. 800x600 256 colors
	8. 800x600  16 bits
	9. 800x600  24 bits

 2. BakRes

    What's that shit ? My screen is totally screwed !
    Don't panic, here is the solution:
    //echo -a $dll(pptdll.dll,BakRes,.)

 3. GetRES

    This function return "S_OK <width> <height> <color depth>" only
    if screen was changed with SetRes function. If not, it return
    "S_ERR - Original resolution"

 4. GetRGB

    This is an un-useful function cause i need to speed it
    ( for the moment, she don't run fastest than mIRC, so use
    mIRC $getdot ) But if you want to test...
    //echo -a $dll(pptdll.dll,GetRGB,hwnd x y)

 Due to the new function GetRES, the DLL stay loaded in memory, but
 if you close mIRC, it will execute BakRes function before close. If
 you want to unload it, use "dll -u pptdll.dll" but it will launch
 BakRes before unload.

 Ok here it goes, sorry for my bad english, but i'm only a little french lost
 in this big universe of picwin coders...