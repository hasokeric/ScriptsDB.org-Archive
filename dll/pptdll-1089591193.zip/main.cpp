// PPTDLL.dll By BombStrike
// Muahaha get lamy !
// Build for: PPT MEGADEMO
// Updated for: All picwin.tk coders
//
// Thx to:
//		StanZ my l0vze
//		Zerg da gayz0r
//		Epsilon for da best ouebsytes ( picwin.tk )
//		My brain, for allz my ideas...
//
// Don't copy this or I will launch a mad cow on your
// shitty face...

// Resolutions:
//
// 1. 320x200 256 colors
// 2. 320x200  16 bits
// 3. 320x200  24 bits
// 4. 640x480 256 colors
// 5. 640x480  16 bits
// 6. 640x480  24 bits
// 7. 800x600 256 colors
// 8. 800x600  16 bits
// 9. 800x600  24 bits

// reduce the DLL size
#pragma check_stack(off)
#pragma comment(linker,"/OPT:NOWIN98")

// include and shortcuts...
#include <windows.h>
#define mFunc(x) int __stdcall WINAPI x(HWND mWnd, HWND, char *data, char, BOOL, BOOL)


typedef struct
{
	DWORD  mVersion;
	HWND   mHwnd;
	BOOL   mKeep;
} LOADINFO;

// 2 little array...
int			w[3];
int			h[3];
bool		setres;
DEVMODE		theres;
HANDLE		hMap;
LPSTR		mData;
HWND		mHWnd;

// how can i see my screen return back ?
mFunc(BakRes)
{

	if (setres == true) {
		// set display setting to regs default...
		long test = ChangeDisplaySettingsEx(NULL, NULL, NULL, 0, NULL);
		wsprintf(data,"S_OK - %d",test);
		setres = false;
	}
	else
		wsprintf(data,"S_ERR - You must change screen resolution before using this function");

	return 3;
}

// muahahahahah, let me bug your screen !
mFunc(SetRes)
{
	// somes vars and reading data
	int r,s,f = 85;
	r = atoi(data)-1;

	// if you don't know reading... set to default..
	if (r<0 || r>8) r = 3;
	if (r>-1 && r<3) f=65;

	// resolutions...
	w[0] = 320;
	w[1] = 640;
	w[2] = 800;
	h[0] = 240;
	h[1] = 480;
	h[2] = 600;

	// a bad calcs, use 100% cpus ;-)
	s = (int)(r/3);

	// set width
	theres.dmPelsWidth = w[s];
	// set height
	theres.dmPelsHeight = h[s];
	// set color depth
	theres.dmBitsPerPel = (int)(((r-(s*3))+1)*8);
	// set frequency
	theres.dmDisplayFrequency = f;
	// last vars and enter to the new world...
	theres.dmSize = sizeof(DEVMODE);
	theres.dmFields = DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT|DM_DISPLAYFREQUENCY;
	long test = ChangeDisplaySettingsEx(NULL,&theres,NULL,0,NULL);
	setres = true;

	// return un-useful infos...
	wsprintf(data,"S_OK - Videomode: %d : Width: %d - Height: %d - Colors: %d",r+1,w[s],h[s],(int)(((r-(s*3))+1)*8));
	return 3;
}

// here is a shitty func, don't use it, i need to speed it
mFunc(GetRGB) {
	long hnd,x,y;
	HDC	hdc;
	COLORREF col;

	hnd = (long)atoi(strtok(data," "));
	x = atoi(strtok(NULL," "));
	y = atoi(strtok(NULL," "));

	HWND hwnd = (HWND)hnd;

	if (IsWindow(hwnd)) {
		hdc = GetWindowDC(hwnd);
		col = GetPixel(hdc,x,y);
		if (col != CLR_INVALID)
			wsprintf(data,"S_OK - %d %d %d",GetRValue(col),GetGValue(col),GetBValue(col));
		else
			wsprintf(data,"S_ERROR - Outside clipping region");
	}


	return 3;
}

mFunc(GetRES) {
	if (setres == true)
		wsprintf(data,"S_OK - %d %d %d",theres.dmPelsWidth,theres.dmPelsHeight,theres.dmBitsPerPel);
	else
		wsprintf(data,"S_ERR - Original resolution");
	return 3;
}

void __stdcall LoadDll(LOADINFO *li)
{

	mHWnd = li->mHwnd;
	li->mKeep = TRUE;

	hMap = CreateFileMapping(INVALID_HANDLE_VALUE,0,PAGE_READWRITE,0,4096,"mIRC");
	mData = (LPSTR)MapViewOfFile(hMap,FILE_MAP_ALL_ACCESS,0,0,0);

}

int WINAPI UnloadDll(int timeout)
{
	if (!timeout)
	{
		if (setres)
			long test = ChangeDisplaySettingsEx(NULL, NULL, NULL, 0, NULL);
		return 1;
	}
	return 0;
}

// hu it's all ? what the fuck ? this useful dll has only 146 lines with comments ?
// let me remedy
//
//
// you are here, ok let's go
//
//
//
//
//
//
//
//
//
//
//
//
// really un-useful, no ?
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
// still here ?
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
// don't scroll anymore !
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
// i love you, stanz, sax, zerg and epsilon
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
// what's that fuck ? muahahahhahah, i will stop at 500 lines, only 231 left...
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
// why are you reading this fucking lmah ?
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
// fiew, only 100 lines to go, we approach the goal
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
// well it's done, the longiest comment in a mIRC DLL...
// i think it's a new world record, yeah 500 lines of comment for 31 lines of code
// so good bye and see you laterz ( omfg, 501 lines... )