DragDropWin.dll

Cette dll � �t� cr��e � partir de la dll DragDrop.dll de RaMzAl_X pr�sente sur le site scriptdb.org
Ce n'est donc pas une cr�ation mais une modification.
Elle permet de draguer n'importe quel fichier sur une fen�tre @window en picwin


Quand vous glissez des fichiers sur une @window enregistr�e, le dll appel l'alias
que vous avez d�fini dans son Initialisation.



Commandes:

autoriser le drag drop sur la fen�tre:

$dll(DragDropWin.dll,EnableDragDrop,<WindowName>  <Alias>)

- WindowName = Nom de la @window � enregistrer;
- Alias = Alias que le dll appel quand vous glissez des fichiers sur la @windowsp�cifi�;




$dll(DragDropWin.dll,DisableDragDrop,NOT_USED)
----------------------------------------------------------------
Aucun param�tre n'est requis mais vous devez mettre n'importe quoi pour que
mIRC appel la function du dll.

Cette function est utilis�e pour d�sactiver le Drag&Drop dans la @window enregistr�e.
Vous n'�tes pas oblig� d'appeler cette function � moins que vous le fassiez pour une
certaine raison (exemple: d�sactiver le Drag&Drop dans une certaine situation).
Quand vous fermez la @window ou mIRC, la function de Drag&Drop sera automatiquement
d�sactiv�e.




$dll(DragDropWin.dll,GetDroppedFiles,<N>)
----------------------------------------------------------------
O�:
- N = Index du fichier � percevoir; si N = 0, retourne le nombre de fichiers gliss�s.

Cette function DOIT �tre appel�e dans le Alias d�fini dans EnableDragDrop ou
apr�s avoir gliss� des fichiers sur la @window. Permet de percevoir les noms des
fichiers gliss�s sur le @window.


$dll(DragDropWin.dll,version,NOT_USED)
----------------------------------------------------------------
retourne les information de version pour le dll.


Bug connu: un son est �mis lorsqu'on lache des fichiers sur la fen�tre.

exemple:

alias drag {
 var %a $dll($scriptdirplugins\DragDropWin.dll,EnableDragDrop,@myWIndow dragGEt)
}


alias dragGEt {
  var %a $gettok($dll($scriptdirplugins\DragDropWin.dll,GetDroppedFiles,0),2,32)
  var %x 1
  while %x <= %a {
    echo a $gettok($dll($scriptdirplugins\DragDropWin.dll,GetDroppedFiles,%x),2-,32)
    inc %x 1
  }
}
