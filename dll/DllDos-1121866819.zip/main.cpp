#include <windows.h>

PROCESS_INFORMATION pi;
char Cmd[MAX_PATH];
bool ReadOK;
HWND mainWnd;
HANDLE OUTwrite = NULL, OUTread = NULL;
HANDLE INwrite = NULL, INread = NULL;
HANDLE hFileMap;
LPSTR mData;

typedef struct {
  DWORD mVersion;
  HWND mhWnd;
  BOOL mKeep;
} LOADINFO;

void __stdcall LoadDll(LOADINFO *loadInfo)
{
	hFileMap = CreateFileMapping(INVALID_HANDLE_VALUE,0,PAGE_READWRITE,0,4096,"mIRC");
	mData = (LPSTR)MapViewOfFile(hFileMap,FILE_MAP_ALL_ACCESS,0,0,0);
	loadInfo->mKeep=TRUE;
}

void __stdcall UnloadDll(int states)
{
	UnmapViewOfFile(mData);
	CloseHandle(hFileMap);
	ReadOK=FALSE;
	CloseHandle(OUTwrite);
	CloseHandle(OUTread);
	CloseHandle(INwrite);
	CloseHandle(INread);
	CloseHandle( pi.hProcess );
	CloseHandle( pi.hThread );
}
DWORD WINAPI readinfo(LPVOID Param) 
{
	DWORD lenght=0;
	char buf[900];

	while ( ReadOK==TRUE )
	{
		memset(buf, 0, sizeof(buf));
		ReadFile(OUTread, buf, sizeof(buf) - 1, &lenght,NULL);
		strcpy(mData,"//.signal -n Dos ");
		strcat(mData,buf);
		if ( strlen(mData) > 0 )
			SendMessage(mainWnd,WM_USER + 200,0,0);
		Sleep(10);
	}
	return 0;
}

DWORD WINAPI ExeDos(LPVOID Param)
{
	SECURITY_ATTRIBUTES secu;
	STARTUPINFO si;

	ZeroMemory(&si,sizeof(si));
	ZeroMemory(&secu,sizeof(secu));

	secu.nLength = sizeof(SECURITY_ATTRIBUTES);
	secu.lpSecurityDescriptor = NULL;
	secu.bInheritHandle = TRUE;

	CreatePipe( &OUTread, &OUTwrite, &secu,0);
	CreatePipe( &INread, &INwrite, &secu,0);

	si.cb = sizeof( si );
	si.wShowWindow = SW_SHOW;
	si.dwFlags = STARTF_USESTDHANDLES;

	si.hStdError   = OUTwrite;
	si.hStdOutput  = OUTwrite;
	si.hStdInput   = INread;

	CreateProcess(0, Cmd,&secu, 0, TRUE, DETACHED_PROCESS, 0, 0, &si, &pi);
	ReadOK=TRUE;
	CreateThread(NULL, 0, &readinfo, (LPVOID)0, 0, 0);
	WaitForSingleObject( pi.hProcess, INFINITE );
	Sleep(10);
	ReadOK=FALSE;

	CloseHandle(OUTwrite);
	CloseHandle(OUTread);
	CloseHandle(INwrite);
	CloseHandle(INread);
	CloseHandle( pi.hProcess );
	CloseHandle( pi.hThread );

	return 0;
}

extern "C" int WINAPI DosRun(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
{
  mainWnd=mWnd;
  strcpy(Cmd,data);
  CreateThread(NULL, 0, &ExeDos, (LPVOID)0, 0, 0);
  return 1;
}

extern "C" int WINAPI DosInput(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
{
  DWORD lenght=0;
  strcat(data,"\n\0");
  WriteFile(INwrite, data, strlen(data), &lenght,0);
  return 1;
}