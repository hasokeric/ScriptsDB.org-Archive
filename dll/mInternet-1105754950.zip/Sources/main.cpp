/*
    mIRC's Internet and IP Helper Layer DLL
    for mIRC v6+
    (c) 2004-2005 EmiZ, el_emiz@yahoo.com.ar
    
    released under the GNU/GPL terms.
*/

/* pre-processor */

#pragma check_stack(off)
#pragma comment(linker,"/OPT:NOWIN98")

#define WIN32_LEAN_AND_MEAN
#ifndef _WIN32_IE
#define _WIN32_IE	0x0400
#endif

#define DLLVER "mInternet 1.5 (c) 2004 - 2005 EmiZ, el_emiz@yahoo.com.ar"

#include <windows.h>
#include <stdlib.h>
#include <ctype.h>
#include <wininet.h>
#include <winsock2.h>
#include <iphlpapi.h>

#define mIRC(defFnc) extern "C" _declspec(dllexport) int __stdcall defFnc(HWND mWnd,HWND aWnd,char *data,char *parms,BOOL bShow,BOOL bNoPause)
#define WProc(x) LRESULT CALLBACK x(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
#define Ret(x) { lstrcpy(data,x); lstrcat(data,"\0"); return 3; }
#define RetCmd(x) { lstrcpy(data,x); lstrcat(data,"\0"); return 2; }

#define MIRCSTRING 900

/* Some Fixes for Dev-C++ */
#ifndef InternetCheckConnection
extern "C" BOOL WINAPI InternetCheckConnectionA(LPCSTR,DWORD,DWORD);
#define InternetCheckConnection InternetCheckConnectionA
#endif

/* Variables */

HANDLE hFileMap;
LPSTR mData;
HWND mWnd, mdiWnd;
HINSTANCE mInst;

typedef struct {
    DWORD  mVersion;
    HWND   mHwnd;
    BOOL   mKeep;
} LOADINFO;

/* Internal Functions */

bool IsFlag(char *szFlags, char szFlag, bool bMustPrefix = TRUE)
{
    
    if ((bMustPrefix) && (szFlags[0] != 0x2B)) return FALSE;
    
    int i;
    for (i = 0; i <= strlen(szFlags)-1; i++) {
        if (toupper(szFlags[i]) == toupper(szFlag)) return TRUE;
    }

    return FALSE;
}    

char* GetTok(char *szText, int iPos, char *szSep = " ", bool bAll = FALSE)
{
    char*  szToken;
    int    iCount;
    char   szText2[1024];

    lstrcpy(szText2,szText);
    szToken = strtok(szText2,szSep);

    for (iCount = 1; szToken && (iCount < iPos); iCount++)
    {
      if (iCount == (iPos-1) && bAll) return strtok(NULL,"");
      else szToken = strtok(NULL,szSep);
    }

    if (bAll) return strtok(szText2,"");

    return szToken;
}

int NumTok(char *szText, char *szSep = " ")
{
    char* szToken;
    char szText2[1024];
    int iPos = 0;

    lstrcpy(szText2,szText);
    szToken = strtok(szText2,szSep);
    
    while (szToken) {
      szToken = strtok(NULL,szSep);
      iPos++;
    }
    return iPos;
}

void SendCommand(char* szOne, char* szTwo = "", char* szThree = "", char* szFour = "")
{
	wsprintf(mData,"//%s %s %s %s",szOne,szTwo,szThree,szFour);
	SendMessage(mWnd, WM_USER + 200,0,0);
	return;    
}

char* EvalText(char* szOne, char* szTwo = "", char* szThree = "", char* szFour = "")
{
	wsprintf(mData,"%s%s%s%s",szOne,szTwo,szThree,szFour);
	SendMessage(mWnd, WM_USER + 201,0,0);
	return mData;    
}

/* LoadDll */
extern "C" _declspec(dllexport) void __stdcall LoadDll(LOADINFO *li)
{
  mWnd = li->mHwnd;
  mInst = (HINSTANCE)GetWindowLong(mWnd,GWL_HINSTANCE);
  hFileMap = CreateFileMapping(INVALID_HANDLE_VALUE,0,PAGE_READWRITE,0,4096,"mIRC");
  mData = (LPSTR)MapViewOfFile(hFileMap,FILE_MAP_ALL_ACCESS,0,0,0);

  li->mKeep = FALSE;
}

/* UnloadDll */
extern "C" _declspec(dllexport) int __stdcall UnloadDll(int timeout)
{
  UnmapViewOfFile(mData);
  CloseHandle(hFileMap);
  return 1;
}

/*
    -------------------- mIRC Functions
*/

mIRC(TryConnect)
{
  if (bNoPause) { Ret("ERROR CANT_PAUSE"); }
  DWORD dwTry = InternetAttemptConnect(0);
  if (dwTry == ERROR_SUCCESS) { Ret("OK"); }
  else { Ret("ERROR ATTEMPT_CONNECT"); }
}

mIRC(IsConnected)
{
  DWORD dwErr;
  bool bCheck = InternetCheckConnection(NULL,0,0);
 
  if (bCheck) { Ret("OK CONNECTED"); }
  else {
    dwErr = GetLastError();
    if (dwErr = ERROR_NOT_CONNECTED) {
      Ret("OK DISCONNECTED");
    }
    else { Ret("ERROR CHECK_CONNECTION"); }    
  }
}

mIRC(GetProxy)
{
  HKEY hKey;
  LONG lRet;
  DWORD dwBufLen = 4;    /* 4 bytes = 32 bits (DWORD!) */
  char szValue[dwBufLen];
  
  lRet = RegOpenKeyEx(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings",0,KEY_QUERY_VALUE,&hKey);
  if (lRet != ERROR_SUCCESS) { Ret("ERROR OPENING_KEY"); }
  lRet = RegQueryValueEx(hKey,"ProxyEnable",NULL,NULL,(LPBYTE)szValue,&dwBufLen);

  dwBufLen = 800;
  char szString[dwBufLen];
  lRet = RegQueryValueEx(hKey,"ProxyServer",NULL,NULL,(LPBYTE)szString,&dwBufLen);
  RegCloseKey(hKey);

  if (szValue[0] != 1) {
    wsprintf(data,"OK PROXY_OFF %s",szString);
  }
  else {
    wsprintf(data,"OK PROXY_ON %s",szString);
  }

  return 3;
}

mIRC(ParseUrl)
{
  if (strlen(data) < 1) { Ret("ERROR NO_PARAMETERS"); }
  char szRes[MIRCSTRING-4];
  DWORD dwBufLen = MIRCSTRING-4;
  if (!InternetCanonicalizeUrl(data,szRes,&dwBufLen,0)) {
    Ret("ERROR PARSE_URL");
  }
  
  wsprintf(data,"OK %s",szRes);  
  return 3;
}

/* Ye old� mIPHelper */

// GetNetworkData
// returns: <nodetype> <hostname> <domain> <routing> <proxy> <dns>
mIRC(GetNetworkData)
{
  FIXED_INFO * FixedInfo;
  ULONG    ulOutBufLen;
  DWORD    dwRetVal;
  IP_ADDR_STRING * pIPAddr;
  
  FixedInfo = (FIXED_INFO *) GlobalAlloc( GPTR, sizeof( FIXED_INFO ) );
  ulOutBufLen = sizeof(FIXED_INFO);
  
  if( ERROR_BUFFER_OVERFLOW == GetNetworkParams( FixedInfo, &ulOutBufLen ) ) {
    GlobalFree( FixedInfo );
    FixedInfo = (FIXED_INFO *) GlobalAlloc( GPTR, ulOutBufLen );
  }
  
  if ( dwRetVal = GetNetworkParams( FixedInfo, &ulOutBufLen ) ) {
      Ret("ERR GET_NETWORK_DATA");
  }
  else {
    char szNodeType[16];
    char szDomain[256];
    lstrcpy(szDomain,FixedInfo -> DomainName);

    if (strlen(szDomain) < 1)
      { lstrcpy(szDomain,"no_domain"); }

    switch(FixedInfo -> NodeType)
    {
      case BROADCAST_NODETYPE:
        {
          lstrcpy(szNodeType,"broadcast");
          break;
        }  
      case PEER_TO_PEER_NODETYPE:
        {
          lstrcpy(szNodeType,"p2p");
          break;
        }  
      case MIXED_NODETYPE:
        {
          lstrcpy(szNodeType,"mixed");
          break;
        }  
      case HYBRID_NODETYPE:
        {
          lstrcpy(szNodeType,"hybrid");
          break;
        }  
      default:
        {
          lstrcpy(szNodeType,"unk_nodetype");
          break;
        }  
    }  

    wsprintf(data,"OK %s %s %s %d %d %d",
      szNodeType,FixedInfo -> HostName,szDomain,
      FixedInfo -> EnableRouting,FixedInfo -> EnableProxy,
      FixedInfo -> EnableDns);
    return 3;
  }  
}  

// GetIPList
// returns ip list
mIRC(GetIPList)
{
  MIB_IPADDRTABLE  *pIPAddrTable;
  DWORD            dwSize = 0;
  DWORD            dwRetVal;

  pIPAddrTable = (MIB_IPADDRTABLE*) malloc( sizeof(MIB_IPADDRTABLE) );

  if (GetIpAddrTable(pIPAddrTable, &dwSize, 0) == ERROR_INSUFFICIENT_BUFFER) {
    GlobalFree( pIPAddrTable );
    pIPAddrTable = (MIB_IPADDRTABLE *) malloc ( dwSize );
  }

  if ( (dwRetVal = GetIpAddrTable( pIPAddrTable, &dwSize, 0 )) != NO_ERROR ) { 
      Ret("ERR GET_IP_TABLE");
  }

  int i;
  int t = (UINT)pIPAddrTable->dwNumEntries;

  lstrcpy(data,"OK");
  in_addr iaDotted;
  char szDotted[15];
  
  for(i=0;i<t;i++)
  {
    iaDotted.s_addr = (LONG)pIPAddrTable->table[i].dwAddr;
    lstrcpy(szDotted,inet_ntoa(iaDotted));
    wsprintf(data,"%s %s",data,szDotted);
  }  

  if (t < 1) { Ret("ERR CANT_FIND_IP"); }
  else {
    return 3;
  }  
}

mIRC(GetTCPStats)
{
  PMIB_TCPSTATS pTCPStats;
  DWORD dwRetVal = 0;
  
  pTCPStats = (MIB_TCPSTATS*) malloc (sizeof(MIB_TCPSTATS));
  
  if ((dwRetVal = GetTcpStatistics(pTCPStats)) != NO_ERROR) {
    Ret("ERR GET_TCP_STATS");
  }

  wsprintf(data,"OK %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld",
    pTCPStats->dwMaxConn,pTCPStats->dwActiveOpens,
    pTCPStats->dwPassiveOpens,pTCPStats->dwAttemptFails,
    pTCPStats->dwEstabResets,pTCPStats->dwCurrEstab,
    pTCPStats->dwInSegs,pTCPStats->dwOutSegs,
    pTCPStats->dwRetransSegs,pTCPStats->dwInErrs,
    pTCPStats->dwNumConns);
  return 3;
}  
  
mIRC(GetUDPStats)
{
  PMIB_UDPSTATS pUDPStats;
  DWORD dwRetVal = 0;
  
  pUDPStats = (MIB_UDPSTATS*) malloc (sizeof(MIB_UDPSTATS));
  
  if ((dwRetVal = GetUdpStatistics(pUDPStats)) != NO_ERROR) {
    Ret("ERR GET_UDP_STATS");
  }
  wsprintf(data,"OK %ld %ld %ld %ld %ld",
    pUDPStats->dwInDatagrams,pUDPStats->dwNoPorts,
    pUDPStats->dwInErrors,pUDPStats->dwOutDatagrams,
    pUDPStats->dwNumAddrs);
  return 3;
}  

mIRC(GetIPStats)
{
  PMIB_IPSTATS pIPStats;
  DWORD dwRetVal = 0;
  
  pIPStats = (MIB_IPSTATS*) malloc (sizeof(MIB_IPSTATS));
  
  if ((dwRetVal = GetIpStatistics(pIPStats)) != NO_ERROR) {
    Ret("ERR GET_IP_STATS");
  }

  wsprintf(data,"OK %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld",
    pIPStats->dwForwarding,pIPStats->dwDefaultTTL,
    pIPStats->dwInReceives,pIPStats->dwInHdrErrors,
    pIPStats->dwInAddrErrors,pIPStats->dwForwDatagrams,
    pIPStats->dwInUnknownProtos,pIPStats->dwInDiscards,
    pIPStats->dwInDelivers,pIPStats->dwOutRequests,
    pIPStats->dwRoutingDiscards,pIPStats->dwOutDiscards,
    pIPStats->dwOutNoRoutes,pIPStats->dwReasmTimeout,
    pIPStats->dwReasmReqds,pIPStats->dwReasmOks,
    pIPStats->dwReasmFails,pIPStats->dwFragOks,
    pIPStats->dwFragFails,pIPStats->dwFragCreates,
    pIPStats->dwNumIf,pIPStats->dwNumAddr,
    pIPStats->dwNumRoutes);

  return 3;
}  

//// Interfaces
//
//void GetInterEmi(char data[900])
//{
//  PIP_INTERFACE_INFO pInfo;
//  pInfo = (IP_INTERFACE_INFO *) malloc( sizeof(IP_INTERFACE_INFO) );
//  ULONG ulOutBufLen = 0;
//  DWORD dwRetVal = 0;
//  
//  
//  if ( GetInterfaceInfo(pInfo, &ulOutBufLen) == ERROR_INSUFFICIENT_BUFFER) {
//    GlobalFree(pInfo);
//    pInfo = (IP_INTERFACE_INFO *) malloc (ulOutBufLen);
//  }
//  
//  if ((dwRetVal = GetInterfaceInfo(pInfo, &ulOutBufLen)) != NO_ERROR ) {
//    lstrcpy(data,"ERR GET_INTERFACES_INFO");
//  }
//
//  int i;
//  int t = (UINT)pInfo->NumAdapters;
//
//  lstrcpy(data,"OK");
//  
//  for(i=0;i<t;i++)
//  {
//    wsprintf(data,"%s #%d %s",data,
//    pInfo->Adapter[i].Index,pInfo->Adapter[i].Name);
//  }  
//
//  if (t < 1) { lstrcpy(data,"ERR THERE_ARE_NO_INTERFACES"); }
//  return;
//}  
//
//mIRC(GetInterfaces)
//{
//  GetInterEmi(data);
//  return 3;
//}
//
//// Adapters
//
//void GetAdapEmi(char data[900])
//{
//  PIP_ADAPTER_INFO pAdapterInfo;
//  PIP_ADAPTER_INFO pAdapter = NULL;
//  DWORD dwRetVal = 0;
//  
//  pAdapterInfo = (IP_ADAPTER_INFO *) malloc( sizeof(IP_ADAPTER_INFO) );
//  ULONG ulOutBufLen = sizeof(IP_ADAPTER_INFO);
//  
//  if (GetAdaptersInfo( pAdapterInfo, &ulOutBufLen) == ERROR_BUFFER_OVERFLOW) {
//    GlobalFree (pAdapterInfo);
//    pAdapterInfo = (IP_ADAPTER_INFO *) malloc ( sizeof(ulOutBufLen) );
//  }
//  
//  if ((dwRetVal = GetAdaptersInfo( pAdapterInfo, &ulOutBufLen)) != NO_ERROR)
//  {
//    lstrcpy(data,"ERR GET_ADAPTERS_INFO");
//    return;
//  }  
//
//  lstrcpy(data,"OK");
//
//  pAdapter = pAdapterInfo;
//  char* szDHCP;
//  char* szWins1;
//  char* szWins2;
//  char* szType;
//
//  while (pAdapter) {
//
//    switch(pAdapter->Type)
//    {
//      case MIB_IF_TYPE_ETHERNET:
//        {
//          szType = "ethernet";
//          break;
//        }
//      case MIB_IF_TYPE_TOKENRING:
//        {
//          szType = "tokenring";
//          break;
//        }
//      case MIB_IF_TYPE_FDDI:
//        {
//          szType = "fddi";
//          break;
//        }
//      case MIB_IF_TYPE_PPP:
//        {
//          szType = "ppp";
//          break;
//        }
//      case MIB_IF_TYPE_LOOPBACK:
//        {
//          szType = "loopback";
//          break;
//        }
//      case MIB_IF_TYPE_SLIP:
//        {
//          szType = "slip";
//          break;
//        }
//      default:
//        {
//          szType = "other";
//          break;
//        }
//    }  
//
//    if (pAdapter->DhcpEnabled) { lstrcpy(szDHCP,pAdapter->DhcpServer.IpAddress.String); }
//    else { lstrcpy(szDHCP,"no_dhcp"); }
//
//    if (pAdapter->HaveWins)
//    {
//      lstrcpy(szWins1,pAdapter->PrimaryWinsServer.IpAddress.String);
//      lstrcpy(szWins2,pAdapter->SecondaryWinsServer.IpAddress.String);
//    }  
//    else
//    {
//      lstrcpy(szWins1,"no_wins");
//      lstrcpy(szWins2,"no_wins");
//    }  
//
//    wsprintf(data,"%s #%d %s %ld %s %s \\ %s \\ %s \\ %s",data,
//      pAdapter->Index,szType,pAdapter->Address,
//      szWins1,szWins2,pAdapter->IpAddressList.IpAddress.String,
//      szDHCP, pAdapter->GatewayList.IpAddress.String);
//    return;
//  }  
//}  
//mIRC(GetAdapters)
//{
//  GetAdapEmi(data);
//  return 3;
//}

mIRC(DLLInfo)
{
  Ret(DLLVER);
}

/*
    --------------------- EOF
*/
