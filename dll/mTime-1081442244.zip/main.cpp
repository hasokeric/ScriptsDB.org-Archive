// By |PaRa-BoL

#include <winsock2.h>
#pragma comment(lib, "ws2_32.lib")

#pragma check_stack(off)
#pragma comment(linker,"/OPT:NOWIN98")
#pragma comment(linker, "/IGNORE:4089")

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define mIRC(x) int __stdcall WINAPI x(HWND mWnd,HWND aWnd,char *data,char*,BOOL,BOOL)
#define ret(x) { strcpy(data,x); strcat(data,"\0"); return 3; }

HANDLE hFileMap;
LPSTR mData;
HWND mIRC_hwnd;
char *data = new char[256];
SOCKET sock;
SOCKADDR_IN sin;
typedef struct {
    DWORD  mVersion;
    HWND   mHwnd;
    BOOL   mKeep;
} LOADINFO;

DWORD dwThreadId, dwThrdParam = 1; 
HANDLE hThread;
DWORD WINAPI m_opentime(LPVOID lpParam);

void WINAPI LoadDll(LOADINFO* load)
{
  hFileMap = CreateFileMapping(INVALID_HANDLE_VALUE,0,PAGE_READWRITE,0,4096,"mIRC");     
  mData = (LPSTR)MapViewOfFile(hFileMap,FILE_MAP_ALL_ACCESS,0,0,0);
  mIRC_hwnd = load->mHwnd;
}

int WINAPI UnloadDll(int timeout)
{
	if (!timeout)
  { 
		UnmapViewOfFile(mData);
		CloseHandle(hFileMap);
		return 1;
	}
  else return 0;
}
void Signal(char *info) {	
	wsprintf(mData,"//.signal -n mTime %s",info);
	SendMessage(mIRC_hwnd, WM_USER + 200,0,0);
}
// #####################################################

int numtok(char txt[],int tch)
{
	int num = 0;
	int l = strlen(txt);
	for (int i=0;i<l;i++)
	{
		if (txt[i] == tch) { num++; }
	}
	return num;
}
char *mid(char *buffer, unsigned int i, unsigned int size)
{
	unsigned int j;
	int x = strlen(buffer);
	if (size==0) size = x;
	char *temp;
	temp = new char[sizeof(char)*size+1];
	for (j=i; j<(i+size); j++)
    {
        temp[j-i] = buffer[j];
        if (j>x) break;
    }
	temp[size]='\0';
	return temp;
}

char *gettok(char*string,int n,int tok) 
{
	int i=0,imax = strlen(string),len=0,pos=0,a=0,i2=0;
	char*c = string,*d;
	while(i<imax) 
	{
	c = (string+i);
	if (*c==tok && a==1) { pos=i;i++;i++;goto next; }
	else { a=0; }
	if (*c==tok) 
	{
		i2++;
		a =1;
		if (i2 ==n) 
		{
			len = i-pos;
			d = mid(string,pos,len);
			while (*d) { if (*d != tok) break; d++; }
			return d;
		}
			else { pos=i+1;i++; }
	}
next:
		i++;
	}
	d = mid(string,pos,len);
	while (*d) { if (*d != tok) break; d++; } 
	return d;
}

////////////////////////////////


mIRC(SetTime)
{
	if (numtok(data,32)!=1) ret("mT_ERR");
	if (numtok(gettok(data,1,32),58)!=2) ret("mT_ERR");
	if (numtok(gettok(data,2,32),45)!=2) ret("mT_ERR");
	SYSTEMTIME stime;

	stime.wYear = atoi(gettok(gettok(data,2,32),3,45));
	stime.wMonth = atoi(gettok(gettok(data,2,32),2,45));
	stime.wDay = atoi(gettok(gettok(data,2,32),1,45));

	stime.wHour = atoi(gettok(gettok(data,1,32),1,58));
	stime.wMinute = atoi(gettok(gettok(data,1,32),2,58));
	stime.wSecond = atoi(gettok(gettok(data,1,32),3,58));
	stime.wMilliseconds = 0;
	SetLocalTime(&stime);
	ret("mT_OK");
}
mIRC(SetRealTime)
{

	hThread = CreateThread(NULL,0,m_opentime,&dwThrdParam,0,&dwThreadId);
	if (hThread == NULL) 
	{
		ret("mT_ERR_THREAD");
	}
	ret("mT_OK");
}
DWORD WINAPI m_opentime(LPVOID lpParam)
{
	int bytesRecv = SOCKET_ERROR; 
	int loop = 1;
	WSADATA WSAData;
	WSAStartup(MAKEWORD(2,0), &WSAData);
	char buffer[512];
	memset(buffer,0,sizeof(buffer));
	char stak[512];
	memset(stak,0,sizeof(buffer));
	sock = socket(AF_INET, SOCK_STREAM, 0);
	struct hostent *ipay = gethostbyname("nist1.datum.com");
	if (h_errno) 
	{
		Signal("mT_ERR_DNS");
		return 0;
	}
	struct in_addr *adr = (struct in_addr*) *(ipay->h_addr_list);
	char *ip = inet_ntoa(*adr);
	sin.sin_addr.s_addr			= inet_addr(ip);
	sin.sin_family				= AF_INET;
	sin.sin_port				= htons(13);
	connect(sock, (SOCKADDR *)&sin, sizeof(sin));
	while(loop==1) 
	{ 
      while(*buffer != '\n' && loop==1) 
      { 
         bytesRecv = recv(sock, buffer, 1, 0); 
         if ( bytesRecv == 0 || bytesRecv == WSAECONNRESET ) { 
            loop=0; 
            break; 
         } 
         strcat(stak,buffer); 
      } 
      if(strlen(stak)>5) { 
			char *dates = new char[512];
			sprintf(dates,"%s",stak);
			SYSTEMTIME systimes;
			systimes.wYear = atoi(gettok(gettok(dates,2,32),1,45))+2000;
			systimes.wMonth = atoi(gettok(gettok(dates,2,32),2,45));
			systimes.wDay = atoi(gettok(gettok(dates,2,32),3,45));
			systimes.wHour = atoi(gettok(gettok(dates,3,32),1,58));
			systimes.wMinute = atoi(gettok(gettok(dates,3,32),2,58));
			systimes.wSecond = atoi(gettok(gettok(dates,3,32),3,58));
			systimes.wMilliseconds = 0;
			SetSystemTime(&systimes);
			Signal("mT_SET_OK");
      } 
      strcpy(buffer,""); 
      strcpy(stak,""); 
   } 
   closesocket(sock); 
   WSACleanup(); 
   return 0;
}
