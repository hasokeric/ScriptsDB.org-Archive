// iso2utf.dll - UTF-8 to ISO conversion
// Copyright (C) 2005  BombStrike
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

#include <windows.h>
#include <stdio.h>


/*
 * encode function
 * 
 * Cette fonction permet d'encoder de l'ISO en UTF-8.
 *
 */

int __stdcall encode(HWND mWnd, HWND aWnd, unsigned char *data, char *parms, BOOL show, BOOL nopause) {
	int i,k;
	unsigned char buffer[901];
	unsigned char c;
	
	i = 0;
	k = 0;
	while ((c = data[i]) != 0) { // tant que nous n'atteignons pas la fin de la chaine
		if (k > 899) break; // si le buffer est plein, on quitte la boucle, de toute facon mIRC est limit� a environ 950 characteres...
		if (c > 0x80 && c < 0xC0) {
			buffer[k] = 0xC2;
			k++;
		}
		if (c > 0xC0) {
			buffer[k] = 0xC3;
			c = c - 0x40;
			k++;
		}
		// le passage suivant permet de g�rer le signe EURO qui n'est normalement pas inclus dans l'ISO-8859-1
		if (c == 0x80) {
			buffer[k] = 0xE2;
			buffer[k+1] = 0x82;
			c = 0xAC;
			k = k+2;
		}
		buffer[k] = c;
		k++;
		i++;
	}
	buffer[k] = 0;
	
	strcpy(data,buffer);
	return 3;
}

/*
 * decode function
 * 
 * Cette fonction permet d'encoder de l'UTF-8 en ISO.
 *
 */
int __stdcall decode(HWND mWnd, HWND aWnd, unsigned char *data, char *parms, BOOL show, BOOL nopause) {
	int i,k;
	char buffer[900];
	unsigned char c;
	
	i = 0;
	k = 0;
	while ((c = data[i]) != 0) {
		if (c == 0xC2) {
			c = data[i+1];
			i++;
		}
		if (c == 0xC3) {
			buffer[k] = (char)0xC3;
			c = data[i+1] + 0x40;
			i++;
		}
		if (c == 0xE2 && data[i+1] == 0x82 && data[i+2] == 0xAC) {
			c = 0x80;
			i=i+2;
		}			
		buffer[k] = c;
		k++;
		i++;
	}
	buffer[k] = 0;
	
	strcpy(data,buffer);
	return 3;
}

int __stdcall about(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause) {
	strcpy(data,"iso2utf.dll v0.1 by BombStrike");
	return 3;
}


