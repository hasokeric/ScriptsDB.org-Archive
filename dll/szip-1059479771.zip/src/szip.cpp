/*
	SZip DLL v0.1
	by ClickHeRe
	panodude@videotron.ca

	This DLL lets the user zip/unzip files and folders with a mIRC extension DLL

	Zlib by Jean-loup Gailly and Mark Adler
	Zlib API by Gilles Voliant
	Zip/Unzip API Classes by Dang
	The rest is me !
*/
#pragma check_stack(off)
#pragma comment(linker,"/OPT:NOWIN98")
#pragma comment(linker, "/IGNORE:4089")

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <stdlib.h>
#include <process.h>
#include <string>

#include "Zipper.h"
#include "Unzipper.h"
#include "filemisc.h"

using namespace std;


// alias to define an External DLL Command
#define mIRC(x) int __stdcall WINAPI x(HWND mWnd,HWND aWnd,char *data,char*,BOOL,BOOL)
// alias to define a WNDPROC function
#define Proc(x) LRESULT CALLBACK x(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
#define ret(x) { strcpy(data,x); strcat(data,"\0"); return 3; }


void TrimLeft(string& Target, const string& CmpTo);
void TrimRight(string& Target, const string& CmpTo);
//char *Trim(char *str);
void Trim(char *str);


DWORD WINAPI Z_UnZipFile(LPVOID lpParam);
DWORD WINAPI Z_ZipFile(LPVOID lpParam);
DWORD WINAPI Z_ZipFolder(LPVOID lpParam);

// ##################################################################################################

// Global Vars
HANDLE hFileMap;
LPSTR mData;
char signal[900];
HWND mIRC_hwnd;

char szDir[900], szZipFile[900];
char szFold[900], szFile[900];

// threading variables
DWORD dwThreadId, dwThrdParam = 1; 
HANDLE hThread; 


// ##################################################################################################

// default Load DLL structure
typedef struct {
    DWORD  mVersion;
    HWND   mHwnd;
    BOOL   mKeep;
} LOADINFO;


// ##################################################################################################

void Signal() {	
	wsprintf(mData,"//.signal -n SZIP %s",signal);
	SendMessage(mIRC_hwnd, WM_USER + 200,0,0);
}

void mIRCCom() {	
	wsprintf(mData,"//%s",signal);
	SendMessage(mIRC_hwnd, WM_USER + 200,0,0);
}

void TrimLeft(string& Target, const string& CmpTo)
{
    while(!Target.find(CmpTo))
    {
         Target.erase(Target.begin(), Target.begin()+CmpTo.size());
    }
}

// Trim right function
void TrimRight(string& Target, const string& CmpTo)
{
    size_t p = string::npos;
    for(;;)
    {
         p = Target.find(CmpTo);
         if (p == string::npos || p != Target.size() - CmpTo.size()) break;
         Target.erase(Target.end()-CmpTo.size(), Target.begin());
    }
}


//Trim leading and ending spaces
void Trim(char *str)
{
  string com(str);
  TrimLeft(com, " ");
	TrimRight(com, " ");
  char *com2 = (char *) com.c_str();
	lstrcpy(str,com2);
}



// ##################################################################################################
// Load DLL command
void WINAPI LoadDll(LOADINFO* load)
{
	hFileMap = CreateFileMapping(INVALID_HANDLE_VALUE,0,PAGE_READWRITE,0,4096,"mIRC");     
  mData = (LPSTR)MapViewOfFile(hFileMap,FILE_MAP_ALL_ACCESS,0,0,0);
  mIRC_hwnd = load->mHwnd;
}

// Unload DLL command
int WINAPI UnloadDll(int timeout)
{
	if (!timeout)
  { 
		UnmapViewOfFile(mData);
		CloseHandle(hFileMap);
		return 1;
	}
  else return 0;
}

// ##################################################################################################
// External DLL Commands
mIRC(Version) 
{
	ret("SZip DLL v0.1 by ClickHeRe �2003 - http://metax.scriptsdb.org");
}

// ZipFolder Thread Function
DWORD WINAPI Z_ZipFolder(LPVOID lpParam) {

	CZipper zip;

	if (zip.OpenZip(szZipFile,NULL,TRUE))
	{
		if (zip.AddFolderToZip(szFold))
		{
			wsprintf(signal,"Z_OK %s",szZipFile);
		}
		else 
		{
			lstrcpy(signal,"Z_ERROR In Zip Operation");
		}
	}
	else 
	{ 
	  lstrcpy(signal,"Z_ERROR Opening Zip File");
	}

	zip.CloseZip();
	Signal();
	return 0;
}

mIRC(SZipFolder)
{

	lstrcpy(szFold,strtok(data,">"));
	lstrcpy(szZipFile,strtok(NULL,""));

	Trim(szFold);
	Trim(szZipFile);

	hThread = CreateThread( 
        NULL,                        // default security attributes 
        0,                           // use default stack size  
        Z_ZipFolder,                  // thread function 
        &dwThrdParam,                // argument to thread function 
        0,                           // use default creation flags 
        &dwThreadId);                // returns the thread identifier 

	if (hThread == NULL) 
  {
		ret("Z_ERROR Zip Thread Creation Failed");
  }
	ret("Z_OK");
}

// ZipFile Thread Function
DWORD WINAPI Z_ZipFile(LPVOID lpParam) {

	CZipper zip;

	if (zip.OpenZip(szZipFile,NULL,TRUE))
	{
		if (zip.AddFileToZip(szFile))
		{
			wsprintf(signal,"Z_OK %s",szZipFile);
		}
		else 
		{
			lstrcpy(signal,"Z_ERROR In Zip Operation");
		}
	}
	else 
	{ 
	  lstrcpy(signal,"Z_ERROR Opening Zip File");
	}

	zip.CloseZip();
	Signal();
	return 0;
}

mIRC(SZipFile)
{

	lstrcpy(szFile,strtok(data,">"));
	lstrcpy(szZipFile,strtok(NULL,""));

	Trim(szFile);
	Trim(szZipFile);

	hThread = CreateThread( 
        NULL,                        // default security attributes 
        0,                           // use default stack size  
        Z_ZipFile,                  // thread function 
        &dwThrdParam,                // argument to thread function 
        0,                           // use default creation flags 
        &dwThreadId);                // returns the thread identifier 

	if (hThread == NULL) 
  {
		ret("Z_ERROR Zip Thread Creation Failed");
  }
	ret("Z_OK");
}

// UnZipFile Thread Function
DWORD WINAPI Z_UnZipFile(LPVOID lpParam) {

	CUnzipper zip;

	if (zip.OpenZip(szZipFile))
	{
		if (zip.UnzipTo(szDir, FALSE))
		{
			wsprintf(signal,"Z_OK %s",szZipFile);
		}
		else 
		{
			lstrcpy(signal,"Z_ERROR In UnZip Operation");
		}
	}
	else 
	{ 
	  lstrcpy(signal,"Z_ERROR Opening Zip File");
	}

	zip.CloseZip();
	Signal();
  return 0;
}

mIRC(SUnZipFile)
{

	lstrcpy(szZipFile,strtok(data,">"));
	lstrcpy(szDir,strtok(NULL,""));
	
	Trim(szDir);
	Trim(szZipFile);

	hThread = CreateThread( 
        NULL,                        // default security attributes 
        0,                           // use default stack size  
        Z_UnZipFile,                  // thread function 
        &dwThrdParam,                // argument to thread function 
        0,                           // use default creation flags 
        &dwThreadId);                // returns the thread identifier 
 
  if (hThread == NULL) 
  {
	  ret("Z_ERROR Unzip Thread Creation Failed");
  }
	ret("Z_OK");
}

mIRC(SZipFileInfo)
{
	char fileinfo[900];
	DWORD m_nTotalCompSize = 0;
	DWORD m_nTotalUncompSize = 0;
	int m_nFileCount = 0;
	int m_nFolderCount = 0;


	lstrcpy(szZipFile,strtok(data,">"));
	
	Trim(szZipFile);

	//wsprintf(signal,"|%s||%s|",szDir,szZipFile);
	//ret(signal);

	CUnzipper zip;
	UZ_FileInfo info;

	if (zip.OpenZip(szZipFile))
	{
		if (zip.GotoFirstFile(NULL))
		{
			do
			{
				zip.GetFileInfo(info);
		
				if (!info.bFolder)
					m_nFileCount++;
				else
					m_nFolderCount++;

				m_nTotalCompSize += info.dwCompressedSize;
				m_nTotalUncompSize += info.dwUncompressedSize;

				//wsprintf(signal,"%d %d",info.dwCompressedSize,info.dwUncompressedSize);
				//Signal();
			}
			while (zip.GotoNextFile(NULL));
		}

		zip.CloseZip();
		
		wsprintf(fileinfo,"%d\t%d\t%d\t%d",m_nFileCount,m_nFolderCount,m_nTotalCompSize,m_nTotalUncompSize);
		ret(fileinfo);
	}
	else 
	{ 
		zip.CloseZip();
	  ret("Z_ERROR Opening Zip File");
	}
}

mIRC(SZipFileData)
{

	char cN[10], fileinfo[900];
	int m_nFileCount = 0;
	int N = NULL;
	bool m_File = FALSE;

	lstrcpy(szZipFile,strtok(data,">"));
	lstrcpy(cN,strtok(NULL,""));
	
	Trim(szZipFile);
	Trim(cN);

	N = (int) atoi(cN);

	//wsprintf(signal,"|%s||%s|",szDir,szZipFile);
	//ret(signal);

	CUnzipper zip;

	UZ_FileInfo info;

	if (zip.OpenZip(szZipFile))
	{
		if (zip.GotoFirstFile(NULL))
		{
			do
			{
				zip.GetFileInfo(info);
		
				if (!info.bFolder)
					m_nFileCount++;

				// file found, exit loop
				if (N == m_nFileCount) 
				{
					m_File = TRUE;
					break;
				}
			}
			while (zip.GotoNextFile(NULL));
		}

		zip.CloseZip();

		if (m_File) 
		{
			// Get File info and return Info
			//wsprintf(fileinfo,"%s\t%d\t%d\t%08x\t%x\t%x",info.szFileName,info.dwCompressedSize,info.dwUncompressedSize,info.dwCRC,info.dwDosDate,info.dwExternalAttrib);
			wsprintf(fileinfo,"%s\t%d\t%d\t%08x",info.szFileName,info.dwCompressedSize,info.dwUncompressedSize,info.dwCRC);
			ret(fileinfo);
		}
		else 
			ret("Z_ERROR Invalid File In Zip");
	}
	else 
	{ 
		zip.CloseZip();
	  ret("Z_ERROR Opening Zip File");
	}
}

mIRC(SZipFileList)
{
	char command[900];
	
	lstrcpy(szZipFile,strtok(data,">"));
	lstrcpy(command,strtok(NULL,""));
	
	Trim(szZipFile);
	Trim(command);

	CUnzipper zip;

	UZ_FileInfo info;

	if (zip.OpenZip(szZipFile))
	{
		if (zip.GotoFirstFile(NULL))
		{
			do
			{
				zip.GetFileInfo(info);
		
				if (!info.bFolder)
				{
					wsprintf(signal,"//%s %s\t%d\t%d\t%08x",command,info.szFileName,info.dwCompressedSize,info.dwUncompressedSize,info.dwCRC);
					mIRCCom();
				}
			}
			while (zip.GotoNextFile(NULL));
		}
		zip.CloseZip();
		ret("Z_OK");
	}
	else 
	{ 
		zip.CloseZip();
	  ret("Z_ERROR Opening Zip File");
	}
}