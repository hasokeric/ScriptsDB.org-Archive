struct fsel
{ 
	//1024 2048 4096 8192 16384 32768
	OPENFILENAME ofn;
	HWND Owner;
	HWND hdlg;
	HWND hident;
	char id[128];
	char titre[512];
	char rep[MAX_PATH];
	char in_name[MAX_PATH];
	char filtre[900];
	char alias[512];
	char last[MAX_PATH];
	char btn_ok[128];
	char btn_ca[128];
	char def_ext[32];
	char *buffer;
	DWORD selF;
	DWORD in_selF;
	DWORD bsize;
	//LONG SelProc;
	bool flags[5];
	bool opened;
	int pos[4];
	RECT rh;
	RECT rl;
	struct xsv {
		HWND dock;
		RECT r;
	} bottom,top,left,right;
	struct xtv {
		int cw;
		int ch;
		int lcw;
		int lch;
	} size;

	fsel *next;
} *list;



fsel *Add(char *c)
{
	fsel *elm;
	elm = (fsel *) HeapAlloc(GetProcessHeap(),0,sizeof(fsel) + 1024);
	for (int i = 0;*c && i < 128;i++) elm->id[i] = *c++;
	elm->buffer = (char*)HeapAlloc(GetProcessHeap(),0,1024);
	elm->bsize = 1024;
	if (!elm) return NULL;
	*elm->buffer = 0;
	elm->id[i] = 0;
	elm->alias[0] = 0, elm->filtre[0] = 0, elm->in_name[0] = 0, elm->hdlg = 0;
	elm->opened = false, elm->rep[0] = 0,	elm->selF = 0;
	elm->titre[0] = 0 , elm->filtre[0] = 0 ,elm->ofn.lpstrFilter = 0;
	elm->next = list, elm->flags[0] = true, elm->ofn.lpstrDefExt = elm->def_ext;
	elm->left.dock = NULL, elm->top.dock = NULL;
	elm->right.dock = NULL, elm->bottom.dock = NULL; //elm->SelProc = NULL;
	list = elm;
	return elm;
}

fsel *Search(char *c)
{
	fsel *elm = list;
	while(elm && lstrcmp(elm->id,c)) elm = elm->next; 
	return elm;
} 


