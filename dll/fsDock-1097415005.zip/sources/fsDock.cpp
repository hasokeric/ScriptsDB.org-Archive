#include "fsDock.h"

extern "C" int WINAPI _DllMainCRTStartup(HANDLE hinst,DWORD,void*) {
	hInstance = (HINSTANCE)hinst;
	return 1;
 }
typedef struct {
    DWORD  mVersion;
    HWND   mHwnd;
    BOOL   mKeep;
  } LOADINFO;

void WINAPI LoadDll(LOADINFO* load)
{
	hmIRC = load->mHwnd;
	//FileMapping servnt � envoyer des commandes � mIRC
	hFileMap = CreateFileMapping(INVALID_HANDLE_VALUE,0,PAGE_READWRITE,0,4096,"mIRC");
	mData = (LPSTR)MapViewOfFile(hFileMap,FILE_MAP_ALL_ACCESS,0,0,0);
	psel = NULL;
	hfree = NULL;
	list = NULL;
}
int WINAPI UnloadDll(int timeout)
{
	if (!timeout) {
		UnmapViewOfFile(mData);
		CloseHandle(hFileMap);
		fsel *elm = NULL;
		while ((elm = Search_wild("*"))) Del(elm); //Supression de tous les identifiants
	}
	return 0;
}

com(create)
{
	char name[128], handle[24];
	if (!gettok(data,1,32,name)) err(MP);
	gettok(data,2,32,handle);
	fsel *e;
	e = Search(name); /*pour voir si l'identifiant existe d�j�*/
	if (e) err(ID);
	psel = Add(name);
	if (!psel) err(MM);
	if (handle[0]) psel->Owner = (HWND)atol(handle); //si aucun handle n'est d�fini, on en met un par d�faut: celui de la fen�tre principale de mIRC
	else psel->Owner = hmIRC;
	psel->btn_ca[0] = 0, psel->btn_ok[0] = 0, psel->def_ext[0] = 0;
	ok(" create");
	return 3;
}

com(ident)
{
	char wild[512], id[64];
	int num, i;
	gettok(data,1,32,wild);
	if (!gettok(data,-2,32,id)) err(MP);
	char *c = id;
	while (*c && (*c < '0' || *c > '9')) c++; //on passe le caract�re non num�riques
	if (!*c) err(IV); //erreur, aucun nombre n'a �t� donn�
	num = atoi(c);
	fsel *elm = list;
	if (num < 0) err(IV);
	if (num == 0) {
		//on compte le nombre d'occurences
		for (i = 0;elm;elm = elm->next) if (wild_match(wild,elm->id)) i++;
		bnultoa(i,data); //transforme int en char
		return 3;
	}
	i = 0;
	while (elm) {
		if (wild_match(wild,elm->id)) {
			i++;
			if (num == i) {
				//on retourne le nom de l'identifiant trouv�
				lstrcpy(data,elm->id);
				return 3;
			}
		}
		elm = elm->next;
	}
	data[0] = '\0';
	return 3;
}
com(free) {
	if (data[0] == 0) err(MP);
	char *c, *d;
	unsigned int i = 0;
	fsel *elm = NULL;
	while ((elm = Search_wild(data))) { i++; Del(elm); } //on efface toutes les occurences
	//mise en forme rapide
	LoadString(hInstance,IDS_OK,data,768);
	c = data;
	while (*c) c++;
	*c++ = 32; lstrcpy(c," free "); while (*c) c++;
	d = bnultoa(i,c);
	while (*d) d++;
	*d++ = 32;
	LoadString(hInstance,IDS_IS,d,128);
	return 3;
}

com(set)
{
	char name[128], parm[128], val[644] ,*p;
	val[0] = 0;
	if (!gettok(data,1,32,name) || !(p = gettok(data,2,32,parm))) err(MP);
	gettok(p,-2,32,val);
	if (!Select(name)) err(II);
	p = val;
	if (!lstrcmp(parm,"title")) lstrcpy(psel->titre,val);
	else if (!lstrcmp(parm,"file")) {
		lstrcpy(psel->in_name,val);
	}
	else if (!lstrcmp(parm,"filter")) {
		bool com = true, ecr = false; char *m = psel->filtre;
		while (*p) {
			switch (*p) {
			case 61:
				if (ecr && com)	{ *p = 0; *m++ = 0;	ecr = false; com = false; }break;
			case 124:
				if (ecr && !com) { *p = 0; *m++ = 0; ecr = false; com = true; }break;
			default:
				*m++ = *p;
				if (!ecr) ecr = true;
			}
			p++;
		}
		*++p = 0; *m++ = 0; *m = 0; 
	}
	else if (!lstrcmp(parm,"owner")) {
		if (val[0] > 57 || val[0] < 48) psel->Owner = NULL;
		else psel->Owner = (HWND)atol(val);
	}
	else if (!lstrcmp(parm,"fselect")) psel->in_selF = atoi(val);
	else if (!lstrcmp(parm,"ipath")) lstrcpy(psel->rep,val);
	else if (!lstrcmp(parm,"flags")) {
			psel->flags[0] = false, psel->flags[1] = false, psel->flags[2] = false,
				psel->flags[3] = false, psel->flags[4] = false;
			while (*p) {
				switch (*p) {
				case 'F':psel->flags[0] = true;break;
				case 'L':psel->flags[1] = true;break;
				case 'M':psel->flags[2] = true;break;
				case 'O':psel->flags[3] = true;break;
				case 'C':psel->flags[4] = true;
				}
				p++;
			}
	}
	else if (!lstrcmp(parm,"size")) {
		DWORD size = 0;
		size = atoi(val);
		if (size < 256 || size > 262144) err(RI);
		char *d = psel->buffer;
		psel->buffer = (char *)HeapReAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,psel->buffer,size);
		if (!psel->buffer) {
			psel->buffer = d;
			err(MM);
		}
		psel->bsize = size;
	}
	else if (!lstrcmp(parm,"alias")) lstrcpy(psel->alias,val);
	else if (!lstrcmp(parm,"ok")) lstrcpy(psel->btn_ok,val);
	else if (!lstrcmp(parm,"cancel")) lstrcpy(psel->btn_ca,val);
	else if (!lstrcmp(parm,"defext")) lstrcpy(psel->def_ext,val);
	else err(IV);
	ok(" set");
}

com(get)
{
	char name[128], parm[128];
	int i = 0;
	if (!gettok(data,1,32,name) || !gettok(data,2,32,parm)) err(MP);
	if (!Select(name)) err(II);
	if (!lstrcmp(parm,"title")) lstrcpyn(data,psel->titre,900);
	else if (!lstrcmp(parm,"file")) lstrcpyn(data,psel->in_name,900);
	else if (!lstrcmp(parm,"filter")) {
		char *p = psel->filtre;
		bool com = false , zero = false; 
Loop:
		if (!*p) {
			if (zero) { i--;  goto endLoop; } //2 zero de suites = fin de la cha�ne
			data[i++] = com ? 124 : 61;
			com = com ? false : true;
			zero = true;
		}
		else {
			data[i++] = *p;
			if (zero) zero = false;
		}
		p++;
		goto Loop;
endLoop: //on boucle la boucle ;)
		data[i] = 0;
		return 3;
	}
	else if (!lstrcmp(parm,"owner")) {
		if (!psel->Owner) data[0] = 0;
		else bnultoa((long)psel->Owner,data);
	}
	else if (!lstrcmp(parm,"ipath")) lstrcpyn(data,psel->rep,900);
	else if(!lstrcmp(parm,"fselect")) {
		if (!psel->in_selF) data[0] = 0;
		bnultoa(psel->in_selF,data);
	}
	else if (!lstrcmp(parm,"flags")) {
		if (psel->flags[0]) data[i++] = 'F';
		if (psel->flags[1]) data[i++] = 'L';
		if (psel->flags[2]) data[i++] = 'M';
		if (psel->flags[3]) data[i++] = 'O';
		if (psel->flags[4]) data[i++] = 'C';
		data[i] = 0;
	}
	else if (!lstrcmp(parm,"size")) bnultoa(psel->bsize,data);
	else if (!lstrcmp(parm,"alias")) lstrcpy(data,psel->alias);
	else if (!lstrcmp(parm,"ok")) lstrcpy(data,psel->btn_ok);
	else if (!lstrcmp(parm,"cancel")) lstrcpy(data,psel->btn_ca);
	else if (!lstrcmp(parm,"defext")) lstrcpy(data,psel->def_ext);
	else err(IV);
	return 3;
}

com(fsOpen) {
	char name[128], parm[32]; name[0] = 0, parm[0] = 0;
	gettok(data,1,32,name);  gettok(data,-2,32,parm);
	if (!name[0]) err(MP);
	if (!Select(name)) err(II);
	erpos(parm,psel);
	if (psel->opened) err (DE); //si bo�te d�j� ouverte, erreur
	if (!GetFileName(0)) {
		if (CommDlgExtendedError() == FNERR_BUFFERTOOSMALL) err(BS);
	}
	if (!hfree) lstrcpyn(data,psel->ofn.lpstrFile,900);
	hfree = NULL;
	return 3;
}
com(fsSave) {
	char name[128], parm[32]; name[0] = 0, parm[0] = 0;
	gettok(data,1,32,name); gettok(data,-2,32,parm);
	if (!name[0]) err(MP);
	if (!Select(name)) err(II);
	erpos(parm,psel);
	if (psel->opened) err (DE);
	if (GetFileName(1)) {
		if (CommDlgExtendedError() == FNERR_BUFFERTOOSMALL) err(BS);
	}
	if (!hfree) lstrcpyn(data,psel->ofn.lpstrFile,900);
	hfree = NULL;
	return 3;
}
com(fsGet) {
	//powered by goto technologies ;)
	char name[128], parm1[128], parm2[128] ,*p;
	if (!gettok(data,1,32,name) || !(p = gettok(data,2,32,parm1))) err(MP);
	if (!Select(name)) goto II;
	if (!lstrcmp(parm1,"hidden")) {
		if (GetWindowLong(psel->hdlg,GWL_STYLE) & WS_VISIBLE) goto T;
		else goto F;
	}
	else if (!lstrcmp(parm1,"opened")) {
		if (psel->opened) goto T;
		else goto F;
	}
	else if (!lstrcmp(parm1,"docked")) {
		if (!gettok(p,2,32,parm2)) goto II;
		if (!lstrcmp(parm2,"bottom")) {
			if (psel->bottom.dock) goto T;
			else goto F;
		}
		if (!lstrcmp(parm2,"top")) {
			if (psel->top.dock) goto T;
			else goto F;
		}
		if (!lstrcmp(parm2,"right")) {
			if (psel->right.dock) goto T;
			else goto F;
		}
		if (!lstrcmp(parm2,"bottom")) {
			if (psel->left.dock) goto T;
			else goto F;
		}
	}
	LoadString(hInstance,IDS_IV,data,900);
	goto end;
T:
	lstrcpy(data,"$true");
	goto end;
F:
	lstrcpy(data,"$false");
	goto end;
II:
	LoadString(hInstance,IDS_II,data,900);
end:
	return 3;
}
	

//Flags: FLMOC
com(Dock) {
	char name[128], parm[32], handle[24] ,*p;
	char i;
	HWND h;
	if (!gettok(data,1,32,name) || !(p = gettok(data,2,32,parm)) ||
		!gettok(p,2,32,handle)) err(MP);;
	if (!Select(name)) err(II);
	if (!lstrcmp(parm,"bottom")) i = 1;
	else if (!lstrcmp(parm,"top")) i = 2;
	else if (!lstrcmp(parm,"right")) i = 3;
	else if (!lstrcmp(parm,"left")) i = 4;
	else err(IV);
	h = (HWND)atol(handle);
	if (h == hmIRC || !IsWindow(h)) err(HI);
	if (!psel->opened) err(NO);

	if (psel->opened) {
		if (i == 1) { 
			if (psel->bottom.dock) err(DD);
			if (!DockBottom(psel,psel->hdlg,h)) err(DI); 
		}
		else if (i == 2) { 
			if (psel->top.dock) err(DD);
			if (!DockTop(psel,psel->hdlg,h)) err(DI); 
		}
		else if (i == 3) {
			if (psel->right.dock) err(DD);
			if (!DockRight(psel,psel->hdlg,h)) err(DI);
		}
		else if (i == 4) {
			if (psel->left.dock) err(DD);
			if (!DockLeft(psel,psel->hdlg,h)) err(DI);
		}
	}
	/*else {
		if (i == 1) psel->bottom.dock = h;
		else if (i == 2) psel->top.dock = h;
		else if (i == 3) psel->right.dock = h;
		else if (i == 4) psel->left.dock = h;
	}*/
	SetWindowPos(psel->hdlg,HWND_TOP,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE);
	ok(" Dock");
}

/*com(Move) {
	HWND a;
	a = (HWND)atol(data);
	LONG S;
	S = GetWindowLong(a,GWL_STYLE);
	S &= ~WS_DISABLED;
	SetWindowLong(a,GWL_STYLE,S);
	ok(" Move");
}*/


com(Move) {
	char name[128], parm[128], id[24], pos[16] ,*p;
	int x,y,cw,ch,a;
	RECT r,h;
	HWND hh;
	p = data;
	if (!gettok(data,1,32,name) || !(p = gettok(data,2,32,parm)))  goto mp;
	if (!Select(name)) err(II);
	if (!psel->opened) err(NO);

	if (!lstrcmp(parm,"main")) {
		if (!(p = gettok(p,2,32,pos))) goto mp;
		x = atoi(pos);
		if (!(p = gettok(p,2,32,pos))) goto mp;
		y = atoi(pos);
		if (!(p = gettok(p,2,32,pos))) goto mp;
		cw = atoi(pos);
		if (!(p = gettok(p,2,32,pos))) goto mp;
		ch = atoi(pos);

		GetWindowRect(psel->hdlg,&h);
		//GetWindowCoords(psel->hdlg,GetDlgItem(psel->hdlg,0x461),&r);
		r = psel->rl;
		if (x < 0) x = h.left;
		if (y < 0) y = h.top;
		if (cw < 0) cw = r.right - r.left;
		else if (cw < 486 || cw > 800) err(MI);
		if (ch < 0) ch = r.bottom - r.top;
		else if (ch < 138 || ch > 300) err(MI);
		MoveDlg(psel->hdlg,x,y,cw - (r.right - r.left),ch - (r.bottom - r.top),&h,psel);
		GetWindowCoords(psel->hdlg,GetDlgItem(psel->hdlg,0x461),&psel->rl);
		goto end;
	}

	id[0] = 0;
	if (!(p = gettok(p,2,32,id))) goto mp;
	a = atoi(id);
	if (!(p = gettok(p,2,32,pos))) goto mp;
	x = atoi(pos);
	if (!(p = gettok(p,2,32,pos))) goto mp;
	y = atoi(pos);
	if (!(p = gettok(p,2,32,pos))) goto mp;
	cw = atoi(pos);
	if (!(p = gettok(p,2,32,pos))) goto mp;
	ch = atoi(pos);


	if (!lstrcmp(parm,"bottom")) {
		if ((hh = GetDlgItem(psel->bottom.dock,6000 + a))) {
			MoveCtrl(psel->bottom.dock,hh,0,NULL,x,y,cw,ch,MV_HWND);
			goto end;
		}
	}
	else if (!lstrcmp(parm,"top")) {
		if ((hh = GetDlgItem(psel->top.dock,6000 + a))) {
			MoveCtrl(psel->top.dock,hh,0,NULL,x,y,cw,ch,MV_HWND);
			goto end;
		}
	}
	else if (!lstrcmp(parm,"left")) {
		if ((hh = GetDlgItem(psel->left.dock,6000 + a))) {
			MoveCtrl(psel->left.dock,hh,0,NULL,x,y,cw,ch,MV_HWND);
			goto end;
		}
	}
	else if (!lstrcmp(parm,"right")) {
		if ((hh = GetDlgItem(psel->right.dock,6000 + a))) {
			MoveCtrl(psel->right.dock,hh,0,NULL,x,y,cw,ch,MV_HWND);
			goto end;
		}
	}
	err(IH);
mp:
	err(MP);
end:
	ok(" Move");
}

com(Pos) {
	char name[128], parm[128] , id[24] , *p;
	RECT r; DWORD a = NULL; HWND h;
	if (!gettok(data,1,32,name) || !gettok(data,2,32,parm)) err(MP);
	if (!Select(name)) err(II);
	if (!psel->opened) err(NO);
	p = data;
	if (!lstrcmp(parm,"main")) {
		data[0] = 0;
		GetWindowRect(psel->hdlg,&r);
		p = bnultoa(r.left,p);
		*p++ = 32; p = bnultoa(r.top,p); *p++ = 32;
		//GetWindowCoords(psel->hdlg,GetDlgItem(psel->hdlg,0x460),&r);
		r = psel->rl;
		p = bnultoa(r.right - r.left,p);
		*p++ = 32; bnultoa(r.bottom - r.top,p);
		return 3;
	}
	id[0] = 0;
	if (!gettok(data,3,32,id)) err(MP);
	a = atoi(id);
	if (!lstrcmp(parm,"bottom")) {
		if ((h = GetDlgItem(psel->bottom.dock,6000 + a))) {
			GetWindowCoords(psel->bottom.dock,h,&r);
			strpos(p,&r);
			return 3;
		}
	}
	else if (!lstrcmp(parm,"top")) {
		if ((h = GetDlgItem(psel->top.dock,6000 + a))) {
			GetWindowCoords(psel->top.dock,h,&r);
			strpos(p,&r);
			return 3;
		}
	}
	else if (!lstrcmp(parm,"left")) {
		if ((h = GetDlgItem(psel->left.dock,6000 + a))) {
			GetWindowCoords(psel->left.dock,h,&r);
			strpos(p,&r);
			return 3;
		}
	}
	else if (!lstrcmp(parm,"right")) {
		if ((h = GetDlgItem(psel->right.dock,6000 + a))) {
			GetWindowCoords(psel->right.dock,h,&r);
			strpos(p,&r);
			return 3;
		}
	}
	else err(IV);
	err(IH);
}

com(Hide) {
	if (!Select(data)) err(II);
	if (!psel->opened) err(NO);
	//HideWindow(psel->hdlg);
	ShowWindow(psel->hdlg,SW_HIDE);
	ok(" Hide");
}
com(Show) {
	if (!Select(data)) err(II);
	if (!psel->opened) err(NO);
	//UnHideWindow(psel->hdlg);
	ShowWindow(psel->hdlg,SW_SHOW);
	ok(" Show");
}

com(Send) {
	char name[128] , parm[128], dext[256];
	if (!gettok(data,1,32,name) || !gettok(data,2,32,parm) || !gettok(data,3,32,dext)) err(MP);
	if (!Select(name)) err(II);
	if (!psel->opened) err(NO);
	if (!lstrcmp(parm,"def_ext")) {
		lstrcpy(psel->def_ext,dext);
		SendMessage(psel->hdlg,(UINT) CDM_SETDEFEXT, 0,(LPARAM)psel->def_ext); 
	}
	else if (!lstrcmp(parm,"title")) SendMessage(psel->hdlg,(UINT) WM_SETTEXT,0,(long)dext);  
	else if (!lstrcmp(parm,"ok")) SetDlgItemText(psel->hdlg,1,dext);
	else if (!lstrcmp(parm,"cancel")) SetDlgItemText(psel->hdlg,2,dext);
	else err(IV);
		// returns LRESULT in lResult     (HWND) hWndControl, 
		// handle to destination control     (UINT) CDM_SETDEFEXT,      // message ID     (WPARAM) wParam,      // = 0; not used, must be zero    (LPARAM) lParam      // = (LPARAM) () lParam; );  
	ok(" Send");
}

com(version) {
	lstrcpy(data,"fsDock v1.2 by Had`S �2004");
	return 3;
}
