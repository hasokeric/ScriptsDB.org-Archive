//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by fsDock.rc
//
#define IDS_MP                          1
#define IDS_ID                          2
#define IDS_OK                          3
#define IDS_II                          4
#define IDS_IV                          5
#define IDS_IS                          6
#define IDS_HI                          7
#define IDS_NO                          8
#define IDS_MM                          9
#define IDS_RI                          10
#define IDS_DI                          11
#define IDS_DE                          12
#define IDS_DD                          13
#define IDS_MI                          14
#define IDS_IH                          15
#define IDS_BS                          16

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
