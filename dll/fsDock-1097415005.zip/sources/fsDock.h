#include <windows.h>
#include "fsel.h"
#include "resource.h"

//ok je sais, c'est un peu le bordel, j'essairai de faire un code plus modulaire la prochaine fois ;)

#pragma comment(linker,"/OPT:NOWIN98")
#define com(bleh) int WINAPI bleh(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
#define err(blah) { LoadString(hInstance,IDS_##blah,data,900); return 3; }
#define ok(bleh) { LoadString(hInstance,IDS_OK,data,768); lstrcat(data,bleh); return 3; }
#define mSignal(blah) { lstrcpyn(mData,blah,900); SendMessage(hmIRC, WM_USER + 200,0,0); }
#define Signal SendMessage(hmIRC, WM_USER + 200,0,0);

#define MV_ID 1   //
#define MV_HWND 2
#define MV_RECT 4

//variables globales
HANDLE hFileMap,aheap;
LPSTR mData;
fsel *psel;
HINSTANCE hInstance;
HWND hmIRC;
HWND hfree;
HWND hdes;

char *gettok(char *subject, int num, char sep, char *dszt) {
	if (!subject) return NULL;
    char *c, *d , *e; /*deux pointeurs sur subject +1 en offset*/
    int i = 0; bool cont;
    if (num < 0) { cont = true; num *= -1; } /*si num est n�gatif*/
    else    cont = false;
    c = d = subject;
    /*si il y en a, on pase les s�parateurs du d�but, afin de
    ne pas retourner un token vide */
    while (*c == sep) c++; d = c;
    //tant que le chaine n'est pas parcourue enti�rement par c..
    while (*c) {
        //si on rencontre le caract�re de s�paration...
        if (*c == sep) {
                i++;
                if (i == num) {
					e = d;
                    if (!cont) while (d < c) *dszt++ = *d++;
                    else while (*d) *dszt++ = *d++;
                    *dszt = 0;
                    //retourne l'offset du token
                    return e;
                }
                //comme d = c, on incr�mente of de r qu'on remet � 0
                while (*c == sep) c++; d = c;
        }
        else c++; 
    }
    //c arriv� � la fin de la cha�ne, on v�rifie si il reste un token...
    if (d < c) { 
        i++;
        if (i == num) {
			e = d;
            while (*d)  *dszt++ = *d++;
            *dszt = 0;
            return e;
        }
    }
    //le token recherch� n'existe pas, on retourne -1
    return NULL;
}
bool wild_match(char *wildcard, char *string) {
    char *c, *d; /*deux pointeurs qui serviront en cas d'�chec de matching*/
    while (*wildcard != 42 && *wildcard != 0) {
        if (!*string) return 0; /*string est nulle et wildcard ne l'est pas on retourne 0*/
        /*si le caract�re *string est le m�me que *wildcard ou si *wildcard est
        un point d'interrogation (?=n'importe quel caract�re)...*/
        if ((*string == *wildcard) || (*wildcard == 63)) { string++; wildcard++; }
        else return 0;
    }
    //si il reste des caract�res � v�rifier dans string et que il n'y en a plus aucun dans  wildcard..
    if (*string && !*wildcard) return 0;
    while (*wildcard == 42) wildcard++; /*pour permettre de passer les * en trop (**,***,etc.)*/
    if (!*wildcard) return 1; /*le dernier caract�re du wildcard est un * et comme les caract�res d'avant on �t� v�rifi�s
                                le wildcard valide donc la cha�ne*/
    /*d�but du motif, on configure les pointeurs*/
    c = wildcard; d = string;
    while (*string) {
        if (*wildcard == 42) {
            while (*wildcard == 42) wildcard++; /*pour permettre de passer les * en trop (**,***,etc.)*/
            if (!*wildcard) return 1;
            /*d�but du motif, on configure les pointeurs*/
            c = wildcard; d = string;
        }
        else if ((*string == *wildcard) || (*wildcard == 63)) { string++; wildcard++; }
        /*en cas d'�chec du matching du motif , on remettra wildcard � sa position de d�part (d�but du motif)
        ainsi que string, qu'on avancera de 1 afin de tester toutes les combinaisons*/
        else { string = ++d; wildcard = c; }
    }
    while (*wildcard == 42) wildcard++;
    if (!*wildcard) return 1; 
    /* si wildcard contient un caract�re autre que * et '\0', il ne v�rifie donc pas la cha�ne*/
    return 0;
}


__declspec(naked) char* __fastcall bnultoa(unsigned int dwnum, char* szdst) 
{ 
  __asm {
    or       ecx, ecx
    jnz      short L1
    lea      eax, [edx+1]
    mov      byte ptr[edx], 48
    mov      byte ptr[eax], cl
    ret      0
 L1:
    mov      [esp-4], edi
    mov      [esp-8], edx
    mov      edi, edx
 L2:
    mov      eax, -858993459
    mul      ecx
    mov      eax, edx
    shr      eax, 3
    mov      edx, ecx
    lea      ecx, [eax+eax*8]
    add      ecx, eax
    sub      edx, ecx
    add      dl, 48
    mov      [edi], dl
    mov      ecx, eax
    inc      edi
    test     eax, eax
    jnz      short L2
    mov      byte ptr[edi], al
    mov      [esp-12], edi
    mov      eax, [esp-8]
 L3:
    dec      edi
    mov      dl, [eax]
    mov      cl, [edi]
    mov      [edi], dl
    mov      [eax], cl
    inc      eax
    cmp      eax, edi
    jb       short L3
    mov      eax, [esp-12]
    mov      edi, [esp-4]
    ret      0
  }
}
fsel *Search(HANDLE hsearch)
{
	if (psel->hident == hsearch) return psel;
	fsel *elm = list;
	while(elm && elm->hident != hsearch) elm = elm->next; 
	return elm;
} 

fsel *_Search(HANDLE hsearch)
{
	if (psel->hdlg == hsearch) return psel;
	fsel *elm = list;
	while(elm && elm->hdlg != hsearch) elm = elm->next; 
	return elm;
} 

fsel *Search_wild(char *c)
{
	fsel *elm = list;
	while(elm && !wild_match(c,elm->id)) elm = elm->next; 
	return elm;
} 

int atoi(char *c)
{
	int a; bool neg = false;
	if (*c == 45) {
		c++;
		neg = true;
	}
	a = 0;
	/*comme dans n'importe quel version du code ASCII 0 < 9, nous pouvons
	alors convertir simplement un char en int en s'appuyant sur une multiplication par 10*/
	while (*c > 47 && *c < 58) a = a * 10 + *c++ - 48;
	return neg ? -a : a;
}

long atol(char *c)
{
	long a; bool neg = false;
	if (*c == 45) {
		c++;
		neg = true;
	}
	a = 0;
	while (*c > 47 && *c < 58) a = a * 10 + *c++ - 48;
	return neg ? -a : a;
}

BOOL CALLBACK CancelWin(HWND hwnd, LPARAM lParam)
{
	if (GetDlgCtrlID(hwnd) == IDCANCEL){ 
		SendMessage(hwnd,WM_COMMAND,NULL,NULL);
		return FALSE;
	}
	return TRUE;
}
void CancelWindow(HWND hwnd)
{
	SendMessage(hwnd, WM_COMMAND, 2, 0);
}

bool Select(char *c)
{	
	if (!psel) return false;
	fsel *f;
	if (lstrcmp(c,psel->id)) {
		f = Search(c);
		if (!f) return false;
		psel = f;
	}
	return true;
}


/*void Del(fsel *elm)
{
	fsel *prev = list;
	hfree = NULL;
	if (psel == elm) psel = NULL;
	if (!&elm) return;
	if(elm == list)
	{
		list = prev->next;
		if (elm->opened == true && elm->hdlg != hmIRC) {
			MessageBox (NULL, TEXT ("Hello, Windows 98 (1)!"), TEXT ("HelloMsg"), 0) ;
			hfree = elm->hident;
			CancelWindow(elm->hdlg);
		}
		HeapFree(GetProcessHeap(),0,&elm->buffer);
		HeapFree(GetProcessHeap(),0,elm);
		return; 
	} 
	while (prev && prev->next != elm) prev = prev->next;
	if (!prev) return;
	prev->next = elm->next;
	if (elm->opened == true && elm->hdlg != hmIRC) { 
		MessageBox (NULL, TEXT ("Hello, Windows 98 (2)!"), TEXT ("HelloMsg"), 0) ;
		hfree = elm->hident; 
		CancelWindow(elm->hdlg);
	}
	HeapFree(GetProcessHeap(),0,&elm->buffer);
	HeapFree(GetProcessHeap(),0,elm);
}*/

void Del(fsel *elm)
{
	fsel *prev = list;
	hfree = NULL;
	if (psel == elm) psel = NULL;
	if(elm == list)
	{
		list = prev->next;
		if (elm->opened && elm->hdlg != hmIRC) {
			hfree = elm->hident;
			CancelWindow(elm->hdlg);
		}
		HeapFree(GetProcessHeap(),0,elm->buffer);
		HeapFree(GetProcessHeap(),0,elm);
		return; 
	} 
	while (prev && prev->next != elm) prev = prev->next;
	if (!prev) return;
	prev->next = elm->next;
	if (elm->opened && elm->hdlg != hmIRC) { 
		hfree = elm->hident; 
		CancelWindow(elm->hdlg);
	}
	HeapFree(GetProcessHeap(),0,elm->buffer);
	HeapFree(GetProcessHeap(),0,elm);
}
void ZeroOFN(OPENFILENAME *ofn)
{
	ofn->Flags = 0;
	ofn->hwndOwner = 0;
	ofn->lCustData = 0;
	ofn->lpfnHook = 0;
	ofn->lpstrCustomFilter = 0;
	ofn->lpstrDefExt = 0;
	ofn->lpstrFile = 0;
	ofn->lpstrFileTitle = 0;
	ofn->lpstrFilter = 0;
	ofn->lpstrInitialDir = 0;
	ofn->lpstrTitle = 0;
	ofn->lpTemplateName = 0;
	ofn->lStructSize = 0;
	ofn->nFileExtension = 0;
	ofn->nFileOffset = 0;
	ofn->nFilterIndex = 0;
	ofn->nMaxCustFilter = 0;
	ofn->nMaxFile = 0;
	ofn->nMaxFileTitle = 0;
}
void AdjustRectCoords(HWND hParent,LPRECT rect)
{
	POINT P, D;
	P.x = rect->left, P.y = rect->top;
	D.x = rect->right, D.y = rect->bottom;
	ScreenToClient(hParent,&P);
	ScreenToClient(hParent,&D);
	rect->left = P.x, rect->top = P.y;
	rect->right = D.x, rect->bottom = D.y;
}
void GetWindowCoords(HWND hParent, HWND hwin,LPRECT rect)
{ //plus pr�cis que GetClientRect()...
	GetWindowRect(hwin,rect);
	AdjustRectCoords(hParent,rect);
}
//Permet de bouger avec pr�cision un contr�le
void MoveCtrl(HWND hParent,HWND hChild, int ID, LPRECT re ,int x, int y, int cw, int ch, WORD Flags) {
	RECT r;
	HWND hctrl;
	if (Flags & MV_ID) hctrl = GetDlgItem(hParent,ID);
	else hctrl = hChild;
	if (Flags & MV_RECT) {
		r.left = re->left, r.top = re->top;
		r.right = re->right, r.bottom = re->bottom;
	}
	else GetWindowCoords(hParent,hctrl,&r);
	MoveWindow(hctrl,r.left + x,r.top + y,(r.right - r.left) + cw,(r.bottom - r.top) + ch,TRUE);
	if (re) {
		re->left += x, re->top += y;
		re->right += cw + x, re->bottom += ch + y;
	}
}

//Permet de bouger tous les contr�les de la bo�te de s�lection
void MoveAWindow(HWND hwin,int y,fsel *f) 
{
	HWND hctrl;
	UINT dir;
	/*on bougera les contr�les en fonction du sens - ou +
	on ne va pas faire un truc de barbare qui d�place les contr�les, suivant aucun ordre*/
	if (y > 0) {
		hctrl = GetDlgItem(hwin,0x40E);
		dir = GW_HWNDPREV;
	}
	else {
		hctrl = GetDlgItem(hwin,0x443);
		dir = GW_HWNDNEXT;
	}
	char i = 0;
Loop:
	/*GetWindowRect(hctrl,&r);
	AdjustRectCoords(hwin,&r);
	MoveWindow(hctrl,r.left,r.top + y,r.right - r.left,r.bottom - r.top,TRUE);*/
	MoveCtrl(hwin,hctrl,0,NULL,0,y,0,0,MV_HWND);

	i++;
	if (i < 14) {
		hctrl = GetNextWindow(hctrl,dir);
		goto Loop;
	}
	GetWindowCoords(hwin,GetDlgItem(hwin,0x461),&f->rl);
	//ShowWindow(hwin,SW_SHOW);
}

//Permet de redimensionner la bo�te la liste
void MoveList(fsel *f,int x,int y,int cw, int ch) {
	HWND hlist;
	RECT r;
	//GetWindowRect(hlist,&r); AdjustRectCoords(hwin,&r);
	if (ch) {
		MoveWindow(psel->hdlg,f->rh.left,f->rh.top,f->rh.right - f->rh.left,(f->rh.bottom - f->rh.top) + ch,TRUE);
		if (f->bottom.dock) MoveWindow(f->bottom.dock,f->bottom.r.left,f->bottom.r.top + ch,f->bottom.r.right - f->bottom.r.left,f->bottom.r.bottom - f->bottom.r.top,TRUE);
		//GetWindowRect(hwin,&r);
		char i = 0;
		hlist = GetDlgItem(f->hdlg,2);
		Loop:
		GetWindowCoords(psel->hdlg,hlist,&r);
		MoveWindow(hlist,r.left,r.top + ch,r.right - r.left,r.bottom - r.top,TRUE);
		i++;
		if (i < 7) {
			hlist = GetNextWindow(hlist,GW_HWNDPREV);
			goto Loop;
		}
	}
	r.left = f->rl.left, r.top = f->rl.top;
	r.right = f->rl.right, r.bottom = f->rl.bottom;
	hlist = GetDlgItem(f->hdlg,0x460);
	MoveWindow(hlist,r.left + x,r.top + y,(r.right + cw) - r.left,(r.bottom + ch) - r.top,TRUE);
	hlist = GetNextWindow(hlist,GW_HWNDNEXT);
	MoveWindow(hlist,r.left + x,r.top + y,(r.right + cw) - r.left,(r.bottom + ch) - r.top,TRUE);
	f->rl.left += x; f->rl.top += y;
	f->rl.right += cw + x; f->rl.bottom += ch + y;

	//UpdateWindow(hwin);
	//ShowWindow(hwin,SW_SHOW);
}
/*void MoveList(fsel *f,int x,int y,int cw, int ch) {
	RECT r;
	HWND htmp;
	r = f->rl;
	int p_cx = r.left + x, p_cy = r.top + y;
	int p_cw = (r.right - r.left) + cw, p_ch = (r.bottom - r.top) + ch;
	if (ch > 0) {
		SetWindowPos(f->hdlg,0,0,0,p_cw,p_ch,SWP_NOZORDER|SWP_NOMOVE);
		if (f->bottom.dock) {
			SetWindowPos(f->bottom.dock,0,f->bottom.r.left,f->bottom.r.top + ch,0,0,SWP_NOZORDER|SWP_NOSIZE);
			GetWindowCoords(f->hdlg,f->bottom.dock,&f->bottom.r);
		}
		char i = 0;
		htmp = GetDlgItem(f->hdlg,2);
		Loop:
		GetWindowCoords(psel->hdlg,htmp,&r);
		MoveWindow(htmp,r.left,r.top + ch,r.right - r.left,r.bottom - r.top,TRUE);
		i++;
		if (i < 7) {
			htmp = GetNextWindow(htmp,GW_HWNDPREV);
			goto Loop;
		}
	}
	MoveCtrl(f->hdlg,NULL,0x461,0,p_cx,p_cy,p_cw,p_ch,MV_ID);
	MoveCtrl(f->hdlg,NULL,0x460,0,p_cx,p_cy,p_cw,p_ch,MV_ID);
	GetWindowCoords(f->hdlg,GetDlgItem(f->hdlg,0x461),&f->rl);
}*/

//Permet de redimensioner la bo�te de s�lection par rapport � la liste
void MoveDlg(HWND hwin,int x, int y, int cw, int ch,LPRECT rect, fsel *f) {
	RECT r;
	MoveWindow(hwin,x,y,(rect->right - rect->left) + cw,(rect->bottom - rect->top) + ch,TRUE);
	rect->left = x, rect->top = y;
	rect->right += cw, rect->bottom += ch;
	MoveCtrl(hwin,FindWindowEx(hwin, NULL, "ToolbarWindow32", NULL),0,NULL,cw,0,0,0,MV_HWND); MoveCtrl(hwin,0,0x471,NULL,0,0,cw,0,MV_ID);
	MoveCtrl(hwin,0,1,NULL,cw,ch,0,0,MV_ID); MoveCtrl(hwin,0,2,NULL,cw,ch,0,0,MV_ID);
	MoveCtrl(hwin,0,0x442,NULL,0,ch,0,0,MV_ID); MoveCtrl(hwin,0,0x441,NULL,0,ch,0,0,MV_ID);
	MoveCtrl(hwin,0,0x480,NULL,0,ch,cw,0,MV_ID); MoveCtrl(hwin,0,0x470,NULL,0,ch,cw,0,MV_ID);
	MoveCtrl(hwin,0,0x460,NULL,0,0,cw,ch,MV_ID);MoveCtrl(hwin,0,0x461,NULL,0,0,cw,ch,MV_ID);

	if (f->right.dock) {
		r = f->right.r;
		MoveWindow(f->right.dock,r.left + cw,r.top,r.right - r.left,(r.bottom - r.top) + ch,TRUE);
		f->right.r.bottom += ch; f->right.r.left += cw; f->right.r.right += cw;
	}
	if (f->left.dock) {
		r = f->left.r;
		MoveWindow(f->left.dock,r.left,r.top,r.right - r.left,(r.bottom - r.top) + ch,TRUE);
		f->left.r.bottom += ch;
	}
	if (f->top.dock) {
		r = f->top.r;
		MoveWindow(f->top.dock,r.left,r.top,rect->right - rect->left - 5,r.bottom - r.top,TRUE);
		f->top.r.right += cw;
	}
	if (f->bottom.dock) {
		r = f->bottom.r;
		MoveWindow(f->bottom.dock,r.left,r.top + ch,rect->right - rect->left - 5,r.bottom - r.top,TRUE);
		f->bottom.r.right += cw; f->bottom.r.top += ch; f->bottom.r.bottom += ch;
	}
	GetWindowRect(hwin,&f->rh);

}

bool DockBottom(fsel *f, HWND hwin,HWND hmirc);
bool DockTop(fsel *f, HWND hwin,HWND hmirc);
bool DockRight(fsel *f, HWND hwin,HWND hmirc);
bool DockLeft(fsel *f, HWND hwin,HWND hmirc);

/*LRESULT CALLBACK fProc(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam){
	int ID;
	HWND hnd;
	switch(uMsg) {
	case WM_COMMAND:
		 ID = GetDlgCtrlID((HWND)lParam);
		 break;
	case WM_SIZE:
		hnd = GetDlgItem(hwnd,0xFFFFFFFF);
		RECT l;
		psel = _Search(hwnd);
		GetWindowCoords(hwnd,GetDlgItem(hwnd,0x461),&l); 
		return 0;
	case WM_DESTROY:
		hdes = hwnd;
		SetWindowLong(hwnd,GWL_WNDPROC,(LONG)psel->SelProc);
		return CallWindowProc((WNDPROC)psel->SelProc,hwnd,uMsg,wParam,lParam);

	}

	psel = _Search(hwnd);
	if (psel) 	return CallWindowProc((WNDPROC)psel->SelProc,hwnd,uMsg,wParam,lParam);
	return 0;
}*/

UINT_PTR CALLBACK hookp(HWND hwnd,UINT mssg,WPARAM wParam,LPARAM lParam,fsel *f)
{
	switch (mssg) {
	case WM_INITDIALOG:
			psel->hident = hwnd;
			psel->hdlg = GetParent(hwnd); 
			//psel->SelProc = SetWindowLong(psel->hdlg,GWL_WNDPROC,(LONG)fProc);
			break;
	case WM_DESTROY:
		//if (hdes == GetParent(hwnd)) return 1;
		if (hfree == hwnd) return 0;
		psel = Search(hwnd);
		psel->hdlg = 0;
		char bt[512]; lstrcpyn(bt,psel->buffer,512);
		wsprintf(mData,"/.signal fsDock %s close %s",psel->id,bt);
		SendMessage(hmIRC, WM_USER + 200,0,0); 
		if (psel->alias[0] && psel->buffer[0]) {
			if (psel->flags[2]) {
				bool zero = false;
				char *c = psel->buffer , *d;
				while (*c) c++;
				c++;
				if (!*c) goto ocase;
				//si il y a un anti-slash, on l'enl�ve car nous le rajoutons automatiquement
				if (*(c - 2) == 92) *(c - 2) = 0;
				d = c;
Loop: //oui un goto label et alors !? ;)
				if (!*c) {
					if (zero)  {
						if (d < c) {
							wsprintf(mData,"/%s %s\\%s",psel->alias,psel->buffer,d);
							Signal;
						}
						return 0;
					}
					zero = true;
					wsprintf(mData,"/%s %s\\%s",psel->alias,psel->buffer,d);
					Signal;
					d = ++c;
				}
				else { zero = false; c++; }
				goto Loop;
			}
			else { 
ocase:	
			wsprintf(mData,"/%s %s",psel->alias,psel->buffer); Signal 
			}
		}	
		break;
	case WM_NOTIFY:
		psel = Search(hwnd);
		LPOFNOTIFY lpfn;
		long a;
		lpfn = (LPOFNOTIFY)lParam;
		if(lpfn->hdr.code == CDN_SELCHANGE) {
			char szbuffer[MAX_PATH]; szbuffer[0] = 0;
			a = SendMessage(lpfn->hdr.hwndFrom, CDM_GETFILEPATH, MAX_PATH, (long) szbuffer);
			wsprintf(mData,"/.signal fsDock %s sel %s",psel->id,szbuffer);
			SendMessage(hmIRC, WM_USER + 200,0,0);
		}
		else if (lpfn->hdr.code == CDN_INITDONE) {
					GetWindowRect(psel->hdlg,&psel->rh);
			GetWindowCoords(psel->hdlg,GetDlgItem(psel->hdlg,0x460),&psel->rl);
		

			if (psel->pos[0] < 0) psel->pos[0] = psel->rh.left;
			if (psel->pos[1] < 0) psel->pos[1] = psel->rh.top;
			MoveDlg(psel->hdlg,psel->pos[0],psel->pos[1],psel->pos[2] - (psel->rl.right - psel->rl.left),psel->pos[3] - (psel->rl.bottom - psel->rl.top),&psel->rh,psel);
			if (psel->btn_ok[0])  SetDlgItemText(psel->hdlg,1,psel->btn_ok);
			if (psel->btn_ca[0])  SetDlgItemText(psel->hdlg,2,psel->btn_ca);
					GetWindowRect(psel->hdlg,&psel->rh);
			GetWindowCoords(psel->hdlg,GetDlgItem(psel->hdlg,0x460),&psel->rl);
		
			wsprintf(mData,"/.signal fsDock %s init",psel->id);
			SendMessage(hmIRC, WM_USER + 200,0,0);
		}
		else if (lpfn->hdr.code == CDN_TYPECHANGE) {
			wsprintf(mData,"/.signal fsDock %s type %d",psel->id,psel->ofn.nFilterIndex);
			SendMessage(hmIRC, WM_USER + 200,0,0);
		}
	}
	return 0;
}

bool GetFileName(bool type)
{
	ZeroOFN(&psel->ofn);
	psel->ofn.lStructSize = sizeof(OPENFILENAME);
	lstrcpy(psel->buffer,psel->in_name);
	psel->selF = psel->in_selF;
	psel->ofn.lpstrFile = psel->buffer;
	psel->ofn.nMaxFile = psel->bsize;;
	if (psel->titre[0]) psel->ofn.lpstrTitle = psel->titre;
	if (psel->rep[0]) psel->ofn.lpstrInitialDir = psel->rep;
	if (psel->filtre[0]) psel->ofn.lpstrFilter = psel->filtre;
	if (psel->def_ext[0]) psel->ofn.lpstrDefExt = psel->def_ext;

	if (IsWindow(psel->Owner)) psel->ofn.hwndOwner = psel->Owner;
	else psel->ofn.hwndOwner = hmIRC;
	psel->opened = true;
	//psel->ofn.Flags = 0x81824|OFN_ENABLESIZING;
	psel->ofn.lpfnHook =  (LPOFNHOOKPROC)hookp;
	psel->ofn.Flags =  OFN_EXPLORER|OFN_ENABLEHOOK|OFN_HIDEREADONLY;//|OFN_ENABLESIZING;
	if (psel->flags[0]) psel->ofn.Flags |= OFN_FILEMUSTEXIST;
	if (psel->flags[1]) psel->ofn.Flags |= OFN_NODEREFERENCELINKS;
	if (psel->flags[2]) psel->ofn.Flags |= OFN_ALLOWMULTISELECT;
	if (psel->flags[3]) psel->ofn.Flags |= OFN_OVERWRITEPROMPT;
	if (psel->flags[4]) psel->ofn.Flags |= OFN_CREATEPROMPT;
	bool B;
	if (!type) B = GetOpenFileName(&psel->ofn) ? true : false;
	else B = GetSaveFileName(&psel->ofn) ? true : false;
	if (!hfree){
		psel->opened = false;
		psel->bottom.dock = NULL;
		psel->left.dock = NULL;
		psel->right.dock = NULL;
		psel->top.dock = NULL;
	}
	return B;
}



	/*
0x443
0x471
0x440
0x460
0x461
0x442
0x480
0x441
0x470
0x1
0x2
0x0
*/

//Permet de rendre une bo�te de dialogue adaptable au Docking
bool AdaptDlg(HWND hdlg) {
	LONG S;
	S = GetWindowLong(hdlg,GWL_STYLE);
	if (S & WS_CHILD || S & WS_CHILDWINDOW) return false;
	S &= ~(WS_CAPTION | DS_FIXEDSYS | DS_SETFONT | DS_MODALFRAME | WS_POPUP | WS_OVERLAPPED | WS_SYSMENU|DS_3DLOOK|WS_CLIPSIBLINGS);
	S |= WS_CHILD;
	SetWindowLong(hdlg,GWL_STYLE,S);
	S = GetWindowLong(hdlg,GWL_EXSTYLE);
	S &= ~(WS_EX_CONTROLPARENT | WS_EX_CLIENTEDGE | WS_EX_DLGMODALFRAME | WS_EX_WINDOWEDGE | WS_EX_STATICEDGE);
	SetWindowLong(hdlg,GWL_EXSTYLE,S);
	//ShowWindow(hdlg,SW_SHOW);
	return true;
}
bool DockBottom(fsel *f, HWND hwin,HWND hmirc)
{
	RECT rm,ro;
	GetClientRect(hmirc,&rm);
	if (!AdaptDlg(hmirc)) return false;
	MoveWindow(hmirc,rm.left,rm.top,f->rh.right - f->rh.left - 2,rm.bottom,TRUE);
	rm.right = f->rh.right - f->rh.left - 5;
	if (rm.bottom > 300) { MoveWindow(hmirc,rm.left,rm.top,rm.right,300,TRUE); rm.bottom = 300; }
	SetParent(hmirc,hwin);
	GetWindowRect(hwin,&ro);
	MoveWindow(hwin,ro.left,ro.top,ro.right - ro.left,(ro.bottom - ro.top) + (rm.bottom - rm.top),TRUE); 
	GetWindowRect(hwin,&ro);
	MoveWindow(hmirc,0,(ro.bottom - ro.top) - (rm.bottom - rm.top) - (GetSystemMetrics(SM_CYCAPTION) + 6) ,rm.right - rm.left,rm.bottom - rm.top,TRUE); 
	GetWindowRect(hwin,&f->rh); GetWindowCoords(hwin,hmirc,&f->bottom.r);
	f->bottom.dock = hmirc;
	//ShowWindow(hmirc,SW_SHOW);
	//ShowWindow(hwin,SW_SHOW);
	return true;
}

bool DockTop(fsel *f, HWND hwin,HWND hmirc) {
	RECT rm;
	GetClientRect(hmirc,&rm);
	if (!AdaptDlg(hmirc)) return false;
	MoveWindow(hmirc,rm.left,rm.top,f->rh.right - f->rh.left - 2,rm.bottom,TRUE);
	rm.right = f->rh.right - f->rh.left - 5;
	if (rm.bottom > 300) { MoveWindow(hmirc,rm.left,rm.top,rm.right,300,TRUE); rm.bottom = 300; }
	f->rh.bottom += (rm.bottom - rm.top); //Augmente la taille du dialog
	MoveAWindow(hwin,rm.bottom - rm.top,f); //D�placement des contr�les du dialog de s�lection
	if (f->bottom.dock) { //Si un dialog est dock� en bas, il faut le d�placer
		MoveCtrl(hwin,f->bottom.dock,0,&f->bottom.r,0,rm.bottom + rm.top,0,0,MV_HWND|MV_RECT);
		//MoveWindow(f->bottom.dock,f->bottom.r.left,f->bottom.r.top + (rm.bottom - rm.top),
		//	f->bottom.r.right - f->bottom.r.left,f->bottom.r.bottom - f->bottom.r.top,TRUE);
		//GetWindowCoords(hwin,f->bottom.dock,&f->bottom.r); 
	}
	if (f->right.dock) MoveCtrl(hwin,f->right.dock,0,&f->right.r,0,rm.bottom - rm.top,0,0,MV_HWND|MV_RECT);
	if (f->left.dock) MoveCtrl(hwin,f->left.dock,0,&f->left.r,0,rm.bottom - rm.top,0,0,MV_HWND|MV_RECT);
	SetParent(hmirc,hwin);

	MoveWindow(hwin,f->rh.left,f->rh.top,f->rh.right - f->rh.left,f->rh.bottom - f->rh.top,TRUE);
	MoveWindow(hmirc,0,0,rm.right - rm.left,rm.bottom - rm.top,TRUE);

	GetWindowRect(hwin,&f->rh); GetWindowRect(hmirc,&f->top.r); AdjustRectCoords(hwin,&f->top.r);
	f->top.dock = hmirc;
	//ShowWindow(hmirc,SW_SHOW);
	//ShowWindow(hwin,SW_SHOW);
	return true;
}

bool DockRight(fsel *f, HWND hwin,HWND hmirc) {
	RECT rm, *rl;
	GetClientRect(hmirc,&rm);
	rl = &f->rl;
	if (!AdaptDlg(hmirc)) return false;
	if ((rl->right - rl->left) == 80) return false;
	if ((rl->right - rl->left) - rm.right < 80) {
		MoveWindow(hmirc,rm.left,rm.top,(rl->right - rl->left) - (rm.right - 80 + ((rl->right - rl->left) - rm.right)),rm.bottom,FALSE);
		GetClientRect(hmirc,&rm);
	}

	if (rm.bottom > 300) { MoveWindow(hmirc,rm.left,rm.top,rm.right,300,FALSE); GetClientRect(hmirc,&rm); }
	else if (rm.bottom < 138) { MoveWindow(hmirc,rm.left,rm.top,rm.right,138,FALSE); GetClientRect(hmirc,&rm); }
	if (f->left.dock && (f->left.r.bottom - f->left.r.top) > rm.bottom) {
		rm.bottom = f->left.r.bottom - f->left.r.top;
		MoveWindow(hmirc,rm.left,rm.top,rm.right,rm.bottom,FALSE);
	}
	if (rm.bottom < rl->bottom - rl->top) {
		MoveWindow(hmirc,rm.left,rm.top,rm.right,rl->bottom - rl->top,FALSE);
		GetClientRect(hmirc,&rm);
	}
	SetParent(hmirc,hwin);
	MoveList(f,0,0,-rm.right,(rm.bottom - rm.top) - (rl->bottom - rl->top));
	rl = &f->rl;
	MoveWindow(hmirc,rl->right,rl->top,rm.right,rm.bottom,TRUE);
	GetWindowRect(hwin,&f->rh); GetWindowRect(hmirc,&f->right.r); AdjustRectCoords(hwin,&f->right.r);
	f->right.dock = hmirc;
	//ShowWindow(hmirc,SW_SHOW);
	//ShowWindow(hwin,SW_SHOW);
	return true;
}

bool DockLeft(fsel *f, HWND hwin,HWND hmirc) {
	RECT rm, *rl;
	GetClientRect(hmirc,&rm);
	rl = &f->rl;
	if (!AdaptDlg(hmirc)) return false;
	if ((rl->right - rl->left) == 80) return false;
	if ((rl->right - rl->left) - rm.right < 80) {
		MoveWindow(hmirc,rm.left,rm.top,(rl->right - rl->left) - (rm.right - 80 + ((rl->right - rl->left) - rm.right)),rm.bottom,FALSE);
		GetClientRect(hmirc,&rm);
	}
	if (rm.bottom > 300) { MoveWindow(hmirc,rm.left,rm.top,rm.right,300,TRUE); GetClientRect(hmirc,&rm); }
	else if (rm.bottom < 138) { MoveWindow(hmirc,rm.left,rm.top,rm.right,138,TRUE); GetClientRect(hmirc,&rm); }
	if (f->right.dock && (f->right.r.bottom - f->right.r.top) > rm.bottom) {
		rm.bottom = f->right.r.bottom - f->right.r.top;
		MoveWindow(hmirc,rm.left,rm.top,rm.right,rm.bottom,TRUE);
	}
	SetParent(hmirc,hwin);
	MoveList(f,rm.right,0,-rm.right,rm.bottom - (rl->bottom - rl->top));
	rl = &f->rl;
	MoveWindow(hmirc,rl->left - rm.right,rl->top,rm.right,rm.bottom,TRUE);

	GetWindowRect(hwin,&f->rh); GetWindowRect(hmirc,&f->left.r); AdjustRectCoords(hwin,&f->left.r);
	f->left.dock = hmirc;
	return true;
}

void strpos(char *p, LPRECT r)  {
	p = bnultoa(r->left,p);	*p++ = 32; 
	p = bnultoa(r->top,p); *p++ = 32;
	p = bnultoa(r->right - r->left,p); *p++ = 32;
	p = bnultoa(r->bottom - r->top,p); *p++ = 0;
}

void erpos(char *parm, fsel *f) {
	int a; char num[8], *p; num[0] = 0;
	gettok(parm,1,32,num); a = atoi(num);
	if (a < 0) f->pos[0] = -1; else f->pos[0] = a;
	num[0] = 0;
	p = gettok(parm,2,32,num); a = atoi(num);
	if (a < 0) f->pos[1] = -1; else f->pos[1] = a;
	num[0] = 0;
	p = gettok(p,2,32,num);  a = atoi(num);
	if (a < 486 || a > 800) f->pos[2] = 486;
	else f->pos[2] = a;
	num[0] = 0;
	p = gettok(p,2,32,num); a = atoi(num);
	if (a < 138 || a > 300) f->pos[3] = 138;
	else f->pos[3] = a;
}