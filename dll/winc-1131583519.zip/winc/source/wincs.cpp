#include <windows.h>
#include <winuser.h>

extern "C" int __declspec(dllexport) FAR PASCAL SetTitle(HWND mWnd, HWND aWnd,char* data,char*,BOOL,BOOL) {
    char buf[900]; //This is a buffer that will hold the current title
    GetWindowText(aWnd, buf, 900); //This function sets the buffer to the current title of the active window
    SetWindowText(aWnd, data); //This function sets the active window to the data parameters that was sent
    lstrcpy(data, buf); //This sets data to the old title, for return value
    return 3;
}
extern "C" int __declspec(dllexport) FAR PASCAL MinWin(HWND mWnd, HWND aWnd,char* data,char*,BOOL,BOOL) {
CloseWindow(aWnd);
return 3;
}
extern "C" int __declspec(dllexport) FAR PASCAL Show(HWND mWnd, HWND aWnd,char* data,char*,BOOL,BOOL) {
ShowWindow(aWnd,SW_RESTORE);
return 3;
}
extern "C" int __declspec(dllexport) FAR PASCAL Max(HWND mWnd, HWND aWnd,char* data,char*,BOOL,BOOL) {
ShowWindow(aWnd,SW_MAXIMIZE);
return 3;
}
extern "C" int __declspec(dllexport) FAR PASCAL Min(HWND mWnd, HWND aWnd,char* data,char*,BOOL,BOOL) {
ShowWindow(aWnd,SW_RESTORE);
return 3;
}
extern "C" int __declspec(dllexport) FAR PASCAL Destroy(HWND mWnd, HWND aWnd,char* data,char*,BOOL,BOOL) {
DestroyWindow(aWnd);
return 3;
}
extern "C" int __declspec(dllexport) FAR PASCAL Wind(HWND mWnd, HWND aWnd,char* data,char*,BOOL,BOOL) {
GetParent(aWnd);
return 3;
}
extern "C" int __declspec(dllexport) FAR PASCAL BringWindTop(HWND mWnd, HWND aWnd,char* data,char*,BOOL,BOOL) {
BringWindowToTop(aWnd);
return 3;
}
extern "C" int __declspec(dllexport) FAR PASCAL Parent(HWND mWnd, HWND aWnd,char* data,char*,BOOL,BOOL) {
SetParent(aWnd,"%s");
return 3;
}
//These are know not to work
extern "C" int __declspec(dllexport) FAR PASCAL GetLen(HWND mWnd, HWND aWnd,char* data,char*,BOOL,BOOL) {
lstrcpy(data,(const char *)GetWindowTextLength(aWnd));
return 3;
}
//Active Window
extern "C" int __declspec(dllexport) FAR PASCAL SetTitle2(HWND mWnd, HWND aWnd,char* data,char*,BOOL,BOOL) {
    char buf[900]; //This is a buffer that will hold the current title
    GetWindowText(mWnd, buf, 900); //This function sets the buffer to the current title of the active window
    SetWindowText(mWnd, data); //This function sets the active window to the data parameters that was sent
    lstrcpy(data, buf); //This sets data to the old title, for return value
    return 3;
}
extern "C" int __declspec(dllexport) FAR PASCAL MinWin2(HWND mWnd, HWND aWnd,char* data,char*,BOOL,BOOL) {
CloseWindow(mWnd);
return 3;
}
extern "C" int __declspec(dllexport) FAR PASCAL Show2(HWND mWnd, HWND aWnd,char* data,char*,BOOL,BOOL) {
ShowWindow(mWnd,SW_RESTORE);
return 3;
}
extern "C" int __declspec(dllexport) FAR PASCAL Max2(HWND mWnd, HWND aWnd,char* data,char*,BOOL,BOOL) {
ShowWindow(mWnd,SW_MAXIMIZE);
return 3;
}
extern "C" int __declspec(dllexport) FAR PASCAL Min2(HWND mWnd, HWND aWnd,char* data,char*,BOOL,BOOL) {
ShowWindow(mWnd,SW_RESTORE);
return 3;
}
extern "C" int __declspec(dllexport) FAR PASCAL Destroy2(HWND mWnd, HWND aWnd,char* data,char*,BOOL,BOOL) {
DestroyWindow(mWnd);
return 3;
}
extern "C" int __declspec(dllexport) FAR PASCAL Wind2(HWND mWnd, HWND aWnd,char* data,char*,BOOL,BOOL) {
GetParent(mWnd);
return 3;
}
extern "C" int __declspec(dllexport) FAR PASCAL BringWindTop2(HWND mWnd, HWND aWnd,char* data,char*,BOOL,BOOL) {
BringWindowToTop(mWnd);
return 3;
}
extern "C" int __declspec(dllexport) FAR PASCAL Parent2(HWND mWnd, HWND aWnd,char* data,char*,BOOL,BOOL) {
SetParent(mWnd,"%s");
return 3;
}
extern "C" int __declspec(dllexport) FAR PASCAL GetLen2(HWND mWnd, HWND aWnd,char* data,char*,BOOL,BOOL) {
lstrcpy(data,(const char *)GetWindowTextLength(mWnd));
return 3;
}
int WINAPI DllInfo(HWND,HWND,char *data,char*,BOOL,BOOL)
{
MessageBox(NULL, "Window Control 2", "Window control 2 by IcyFlamez. Please see the readme for more info", MB_OK);
return 0;
}


extern "C" int __declspec(dllexport) FAR PASCAL MakeDrgable(HWND mWnd, HWND aWnd,char* data,char*,BOOL,BOOL) {
        SetWindowLong(aWnd,GWL_EXSTYLE,WS_EX_ACCEPTFILES);
        return 3;
}

extern "C" int __declspec(dllexport) FAR PASCAL LeftSB(HWND mWnd, HWND aWnd,char* data,char*,BOOL,BOOL) {
        SetWindowLong(aWnd,GWL_EXSTYLE,WS_EX_LEFTSCROLLBAR);
        return 3;
}
extern "C" int __declspec(dllexport) FAR PASCAL RightAlg(HWND mWnd, HWND aWnd,char* data,char*,BOOL,BOOL) {
        SetWindowLong(aWnd,GWL_EXSTYLE,WS_EX_RIGHT);
        return 3;
}

extern "C" int __declspec(dllexport) FAR PASCAL Toolw(HWND mWnd, HWND aWnd,char* data,char*,BOOL,BOOL) {
        SetWindowLong(aWnd,GWL_EXSTYLE,WS_EX_TOOLWINDOW);
        return 3;
}

extern "C" int __declspec(dllexport) FAR PASCAL LeftAlg(HWND mWnd, HWND aWnd,char* data,char*,BOOL,BOOL) {
        SetWindowLong(aWnd,GWL_EXSTYLE,WS_EX_LEFT);
        return 3;
}
