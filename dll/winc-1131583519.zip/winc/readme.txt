=========================================
====== _Window Control 1.0 _________________________=X=
=========================================
==                                          By |cyF|amez                            ==
=========================================
AKA mWinUt
Control your windows state, title, parent window, etc.

Changes
--------
v2
MakeDrgable, LeftSB, RightAlg, Toolw, LeftAlg added
Fixed 2 bugs.

help
-----

Functions:
Note:The functions with "2" is the main window of mirc that it controls.

SetTitle <new title>
What does this do?:Changes the ACTIVE window's title
Example:
//dll winc.dll SetTitle Hi, im changing the window text!

SetTitle2 <new title>
What does this do?:Changes the mIRC's title
Example:
//dll winc.dll SetTitle2 Hi, im changing the mirc's title!

MinWin
What does this do?:Minimizes the active window to the bottom of the screen, not
                            the switchbar
Example:
//dll winc.dll MinWin

MinWin2
What does this do?:Minimizes mIRC
Example:
//dll winc.dll MinWin2

Show & Show2
What does this do?:Shows destroyed (See Destro function) windows or minimized windows.
                            If its Show2 it will show the destroyed mirc window.
Example:
/dll winc.dll Show
/dll winc.dll Show2

Max & Max2
What does this do?:Maximizes the mirc or active window.
Example:
/dll winc.dll Max
/dll winc.dll Max2

Min & Min2
What does this do?:Minimizes the active or main window of mIRC (to normal size)
Example:
/dll winc.dll Min
/dll winc.dll Min2

Destroy/Destroy2
WARNING!!:If you destroy the status window, you will never get it back, unless you
have a channel, widnow w/ editbox open to show it. Which i dont think it can do in
this version
It does what?:Destroy the window, it will appear in the switchbar, but you need to use Or destroy
                    mircs window - NOT RECOMENDED.
show/show2 to open it. if not, i will add the showwin in the next version :).
Example:
/dll winc.dll Destroy
/dll winc.dll Destroy2

These still in testing,i have tested them, but they probally have no use right this minute.
Plese test these next 3 ones plz!

BringWindTop/BringWindTop2
It does:Bring the window to the top of the screen.
Examples:
/dll winc.dll BringWindTop
/dll winc.dll BringWindTop2

Note:Parent may not work, i pretty sure Parent2 works
Parent/Parent2
It does:Change the parent reply of the windows.
See also Wind/Wind2
Examples:
/dll winc.dll Parent i  changed the parent reply!
/dll winc.dll Parent2 i changed the parent reply!

GetLen/GetLen2
Note:This needs alot of attention.
It does:Get how much length the title is
Examples:
echo -a $dll(winc,GetLen,)
echo $dll(winc,GetLen2,)
This one dosnt need testing!

Wind/Wind2
It does:Get the parent of the window.
Examples:
//dialog $dname -t $dll(winc,Wind,)
//dialog $dname -t $dll(winc,Wind2,)

MakeDrgable
It does: Makes active window able to drag files into it.
Kinda pointless, but I thought it was neat, so I added it.
Note: Not supposed to return file ;) If you wish to get it,
write your own function (or send it to me and ill include
it and youll be in the thanks section, and give credit in
source.)
Examples: /dll winc.dll MakeDrgable

LeftSB
It does: Can't explain the effect in words... heh. Supposed to create
a scoolbar on left side.
Examples: /dll winc.dll LeftSB

RightAlg/LeftAlg
RightAlg - right aligns the text in the titlebar on active window.
LeftAlg - right aligns the text in the titlebar on active window.
LeftAlg returns text to default alignment.
Examples:
/dll winc.dll LeftAlg
/dll winc.dll RightAlg

Toolw
Turns active window to a toolwindow, like +l in custom windows.
/dll winc.dll Toolw


�2003-2005 |cySoft. All rights reserved.