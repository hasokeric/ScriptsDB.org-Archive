#include <windows.h>
#include <stdarg.h>
#pragma comment(linker,"/OPT:NOWIN98")

char *invloup(char *data, int chars) {
	char *res = data;
	int i = 0;
	while (i < chars) {
		if (*data > 96 && *data < 123) *data -= 32;
		else if (*data > 64 && *data < 91) *data += 32;
		data++;
		i++;
	}
	return res;
}
size_t _findfilestr(const char *buf, size_t buf_size, size_t size, HANDLE handle, int occur, bool ucs, int &code) {
	char *buffer = (char*)HeapAlloc(GetProcessHeap(),NULL,size), *buf2 = NULL;
	int o = 0;
	if (!buffer) {
		code = -2;
		return 0;
	}
	if (ucs == true) {
		buf2 = (char *)HeapAlloc(GetProcessHeap(),NULL,buf_size);
		for (int i = 0;i < (signed)buf_size;i++) buf2[i] = buf[i];
		buf2 = invloup(buf2,buf_size);
	}
	size_t index = 0, block = 0,pos, taille; 
	DWORD val;
	char *ptr;
	if ((taille = SetFilePointer(handle,0,NULL,FILE_CURRENT)) == -1) goto End;
	while (ReadFile(handle, buffer, size, &val, 0) ) {
	  if (!val) break;
		ptr = buffer;
		pos = 0;
		while (pos < val) {
			if (buf[index] == *ptr || (ucs == true && buf2[index] == *ptr)) {
				index++;
				if (index == buf_size) { 
					o++;
					if (o == occur) {
						HeapFree(GetProcessHeap(),NULL,buffer);
						code = 0;
						return block*size+pos-buf_size+1+taille;
					}
					else index = 0;
				}
			}
			else if (index != 0) index = 0;
			ptr++;
			pos++;
		}
		block++;
	}
End:
	HeapFree(GetProcessHeap(),NULL,buffer);
	if (buf2 != NULL) HeapFree(GetProcessHeap(),NULL,buf2);
	code = -1;
	return 0;
}

size_t __findfilestr(const char *buf, size_t buf_size, size_t size, HANDLE handle, int occur, bool ucs, int &code) {
	char *buffer = (char*)HeapAlloc(GetProcessHeap(),NULL,size), *buf2 = NULL;
	int o = 0;
	if (!buffer) {
		code = -2;
		return 0;
	}
	if (ucs == true) {
		buf2 = (char *)HeapAlloc(GetProcessHeap(),NULL,buf_size);
		for (int i = 0;i < (signed)buf_size;i++) buf2[i] = buf[i];
		buf2 = invloup(buf2,buf_size);
	}
	size_t index = buf_size-1 ,pos;
	DWORD Pos, taille, value;
	char *ptr;
	value = size;
	if ((taille = SetFilePointer(handle,0,NULL,FILE_CURRENT)) == -1) goto End;
	Pos = taille - size;
Loop:
	taille = SetFilePointer(handle,Pos,NULL,FILE_BEGIN);
  if (taille != -1) {
	  ReadFile(handle,buffer,value,&value,NULL);
	  ptr = &buffer[value-1];
	  pos = 0;
	  while (pos < value) {
		  if (buf[index] == *ptr || (ucs == true && buf2[index] == *ptr)) {
			  index--;
			  if (index == -1) { 
				  o++;
				  if (o == occur) {
					  HeapFree(GetProcessHeap(),NULL,buffer);
					  code = 0;
					  return Pos+value-pos-1;
				  }
				  else index = buf_size-1;
			  }
		  }
		  else if (index != (buf_size-1)) index = buf_size-1;
		  ptr--;
		  pos++;
	  }
	  if (taille != 0) {
		  if (Pos < value)  value = Pos;
		  Pos -= value;
		  goto Loop;
	  }
  }
End:
  	HeapFree(GetProcessHeap(),NULL,buffer);
	if (buf2 != NULL) HeapFree(GetProcessHeap(),NULL,buf2);
	code = -1;
	return 0;
}
struct TRANSLATION
{
	WORD langID;
	WORD charset;
} translation;

int tokenize(char sep, char *subject, char *str1, ...) {
	int ret = 0, i = 0;
	char *str = str1 ,*old;
	va_list token;
	va_start(token,str1);
	do {
		while (*subject == sep) subject++;
		if (!*subject) return ret;
		while (*subject != sep && *subject != NULL) *str++ = *subject++;
		*str = 0;
		old = str;
		ret++;
		str = (char *)va_arg(token,char *);
	} while (str != NULL && (int)str != -1);
	if ((int)str == -1 && *subject) { while (*subject) *old++ = *subject++; *old = 0;}
	va_end(token);
	return ret;
}
int numtok(const char *subject, const char sep) {
	int res = 0;
	bool status = false;
Loop:
	if (*subject == sep) { status = false; }
	else if (*subject == 0) goto End;
	else if (status == false) {
		status = true;
		res++;
	}
	subject++;
	goto Loop;
End:
	return res;
}

//Fonction permettant d'enlever les caract�res en trop dans un motif "tokeniz�"
char *stripex(char *subject,char ex,char tok) {
	char *c = subject, *ref = NULL ,*in; int i = 0; bool stat = false;
	while (*c) {
		if (*c == ex) {
			if (!ref) ref = c;
		}
		else if (*c == tok)	{
			if (ref) {
				for (i = 0, in = c;*c;i++) *ref++ = *c++; 
				*ref = 0;
				c -= i + (c - ref);
			}
			ref = NULL;
			stat = true;
		}
		else {
			if (ref && stat) {
				for (i = 0, in = c;*c;i++) *ref++ = *c++;
				*ref = 0;
				c -= i + (c - ref);
			}	
			ref = NULL;
			stat = false;
		}
		c++;
	}
	return subject;
}
unsigned long atol(char *c)
{
	unsigned long a;
	if (*c == 45) c++;
	a = 0;
	/*comme dans n'importe quel version du code ASCII 0 < 9, nous pouvons
	alors convertir simplement un char en int en s'appuyant sur une multiplication par 10*/
	while (*c > 47 && *c < 58) a = a * 10 + *c++ - 48;
	return a;
}
DWORD ahextoi(const char *str) {
	DWORD res = 0, hex;
	int puissance = lstrlen(str) - 1, i = 0;
	while (*str) {
		if (*str > 47 && *str < 58) hex = *str - 48;
		else if (*str > 96 && *str < 103) hex = 10 + (*str - 97);
		else if (*str > 64 && *str < 71) hex = 10 + (*str - 65);
		else break;
		for (i = puissance;i > 0;i--) hex *= 16;
		puissance--;
		res += hex;
		*str++;
	}
	return res;
}
__declspec(naked) char* __fastcall bnultoa(unsigned int dwnum, char* szdst) 
{
  __asm {
    or       ecx, ecx
    jnz      short L1
    lea      eax, [edx+1]
    mov      byte ptr[edx], 48
    mov      byte ptr[eax], cl
    ret      0
 L1:
    mov      [esp-4], edi
    mov      [esp-8], edx
    mov      edi, edx
 L2:
    mov      eax, -858993459
    mul      ecx
    mov      eax, edx
    shr      eax, 3
    mov      edx, ecx
    lea      ecx, [eax+eax*8]
    add      ecx, eax
    sub      edx, ecx
    add      dl, 48
    mov      [edi], dl
    mov      ecx, eax
    inc      edi
    test     eax, eax
    jnz      short L2
    mov      byte ptr[edi], al
    mov      [esp-12], edi
    mov      eax, [esp-8]
 L3:
    dec      edi
    mov      dl, [eax]
    mov      cl, [edi]
    mov      [edi], dl
    mov      [eax], cl
    inc      eax
    cmp      eax, edi
    jb       short L3
    mov      eax, [esp-12]
    mov      edi, [esp-4]
    ret      0
  }
}
extern "C" int WINAPI _DllMainCRTStartup(HANDLE hinst,DWORD,void*) {
	//hInstance = (HINSTANCE)hinst;
	return 1;
}
extern "C" int __stdcall fileversion(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause) {
	stripex(data,32,62);
	DWORD handle;
	unsigned int size, len;
	char *file, *version, *pData, *ptr, *str, *lpBuffer;
	VS_FIXEDFILEINFO* lpvi;
	file = (char *)HeapAlloc(GetProcessHeap(),NULL,MAX_PATH);
	version = (char *)HeapAlloc(GetProcessHeap(),NULL,128);
	str = (char *)HeapAlloc(GetProcessHeap(),NULL,512);
	lpBuffer = (char *)HeapAlloc(GetProcessHeap(),NULL,512);
	if (tokenize(62,data,file,version,NULL) < 2) {
		data[0] = 0;
		goto end;
	}
	data[0] = 0;
	size = GetFileVersionInfoSize(file,&handle);
	if (!size) goto end;
	pData = (char *)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,size);
	if (!GetFileVersionInfo(file, handle, size, pData) || !VerQueryValue(pData, "\\VarFileInfo\\Translation", (void **)&lpvi, &len)) {
		data[0] = 0;
		goto aend;
	}
	if (!lstrcmpi(version,"Language")) {
		pData[139] = pData[140];
		pData[140] = 0;
		GetLocaleInfo(ahextoi(&pData[138]), LOCALE_SNATIVELANGNAME, data, 900);
		/*Ces enfoir�s de chez Microsoft ne mettent pas de majuscules au d�but quand la langue
		  est le fran�ais, alors qu'il en mette une avec l'anglais ! La ligne du dessous sert �
		  enlever ce racisme ;) */
		if (*data > 96 && *data < 122) *data -= 32;
		goto aend;
	}
	translation = *(TRANSLATION*)lpvi;
	ptr = lpBuffer;
	len = 900;
	wsprintf(str, "\\StringFileInfo\\%04x%04x\\%s", translation.langID, translation.charset,version);
	if (VerQueryValue((LPVOID)pData, str,(void**)&ptr, &len)) {
		lstrcpy(data,ptr);
	}
aend:
	HeapFree(GetProcessHeap(),NULL,pData);
end:
	HeapFree(GetProcessHeap(),NULL,file);
	HeapFree(GetProcessHeap(),NULL,version);
	HeapFree(GetProcessHeap(),NULL,str);
	HeapFree(GetProcessHeap(),NULL,lpBuffer);
	return 3;
}

extern "C" int __stdcall findbinseq(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause) {
	stripex(data,32,62);
	char *file, *seq  ,*c ,*d;
	size_t size = 0, res, pos = 0;
	bool sens = false, ucs = false;
	int i, r, occur = 1;
	HANDLE handle;
	file = (char *)HeapAlloc(GetProcessHeap(),NULL,MAX_PATH);
	d = c = data;
	while (*c != 62 && *c) c++;
	if (!*c) {
		data[0] = 0;
		goto End;
	}
	i = 0;
	while (d < c) file[i++] = *d++;
	file[i] = 0;
	c++;
	d = c;
	while (*c != 62 && *c) c++;
	if (!*c) {
		data[0] = 0;
		goto End;
	}
	occur = atol(d);
	c++;
	d = c;
	if (*c != 42) {
		char C;
		while (*d && *d != 62) d++;
		C = *d;
		*d = 0;
		size = numtok(c,32);
		*d = C;
		if (!size) {
			data[0] =0;
			goto End;
		}
		i = 0;
		seq = (char *)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,size);
Loop:
		while (*c == 32) c++;
		d = c;
		while (*c != 32 && *c != 62 && *c) c++;
		seq[i] = atol(d);
		i++;
		if (*c && *c != 62) goto Loop;
	}
	else {
		c++;
		d = c;
		while (*c && *c != 62) {
			c++;
			size++;
		}
		if (!size) {
			data[0] =0;
			goto End;
		}
		seq = (char *)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,size);
		for (i = 0;i < size;i++) seq[i] = *d++;
	}
		handle = CreateFile(file, GENERIC_READ, FILE_SHARE_READ, 0,
		OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, 0);
	if (handle == INVALID_HANDLE_VALUE) { 
		data[0] = 0;
		goto aEnd;
	}
	if (*c == 62) {
		do {
			c++;
		} while (*c == 62);
		if (*c == 32) c++;
		pos = atol(c);
		while (*c && *c != 32) c++;
		if (*c == 32) c++;
		sens = atol(c) == 1 ? true : false;
		while (*c && *c != 32) c++;
		if (*c == 32) c++;
		ucs = atol(c) == 1 ? true : false;
	}
	if (sens == false) {
		if (SetFilePointer(handle,pos,NULL,FILE_BEGIN) == -1) SetFilePointer(handle,0,NULL,FILE_BEGIN);
		res = _findfilestr(seq,size,0x1000,handle,occur,ucs,r);
	}
	else {
		if (pos == 0 || (SetFilePointer(handle,pos,NULL,FILE_BEGIN) == -1)) SetFilePointer(handle,0,NULL,FILE_END);
		res =  __findfilestr(seq,size,0x1000,handle,occur,ucs,r);
	}
	if (!r) {
		bnultoa(res,data);
	}
	else wsprintf(data,"%d",r);
aEnd:
	HeapFree(GetProcessHeap(),NULL,seq);
	CloseHandle(handle);
End:
	HeapFree(GetProcessHeap(),NULL,file);
	return 3;
}
extern "C" int __stdcall version(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause) {
	lstrcpy(data,"fileversion v1.2 by Had`S - Hades53@wanadoo.fr");
	return 3;
}

