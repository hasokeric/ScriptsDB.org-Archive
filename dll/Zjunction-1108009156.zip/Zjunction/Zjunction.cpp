#define Zfunction(x) extern "C" int WINAPI x (HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)

#include "../FSLinks/FSLinks.h"
#include <cstdio>
#include <cstdlib>
#include <winioctl.h>
#include <tchar.h>


using namespace FSLinks;


Zfunction(Create){
	char in[2048], out[2048], szVol[4];
	
	char *tokReturn;
	DWORD dwCompLen;
	DWORD dwFsFlags;



	if(!strcmp(data,"")){
		strcpy(data,"ERR:MISSING_PARAMETERS");
		return 3;
	}
	strcpy(in,strtok(data," --> "));
	tokReturn = strtok(NULL," --> ");

	if(tokReturn==NULL){
		strcpy(data,"ERR:MISSING_PARAMETER_2");
		return 3;
	}
	strcpy(out,tokReturn);
	const DWORD dwFA = GetFileAttributes(in);
	if (dwFA == 0xffffffff) {
		sprintf(data,"ERR:PARAMETER_1_DOES_NOT_EXIST");
		return 3;
	}


	const DWORD dwFB = GetFileAttributes(out);
	if (dwFB == 0xffffffff) {
		sprintf(data,"ERR:PARAMETER_2_DOES_NOT_EXIST");
		return 3;
	}

	szVol[0] = in[0];
	szVol[1] = 58;
	szVol[2] = 92;
	szVol[3] = 0;

	if (!GetVolumeInformation(szVol, 0, 0, 0, &dwCompLen, &dwFsFlags, 0, 0)) {
		sprintf(data,"ERR:FAILED_TO_GET_VOLUME_INFORMATION");
		return 3;
	}

	if (!(dwFsFlags & FILE_SUPPORTS_REPARSE_POINTS)) {
		sprintf(data,"ERR:PARAMETER_1_DOES_NOT_SUPPORT_REPARSE_POINTS");
		return 3;
	}


	if (!CreateJunctionPoint(in, out)) {
		sprintf(data,"ERR:COULDN_T_CREATE_LINK");
		return 3;
	}


	strcpy(data,"S_OK");
	return 3;
}


Zfunction(Delete){
	if(!strcmp(data,"")){
		sprintf(data,"ERR:MISSING_PARAMETERS");
		return 3;
	}

	if (!DeleteJunctionPoint(data)) {
		sprintf(data,"ERR:COULDN_T_DELETE_JUNCTION_POINT");
	}
	sprintf(data,"S_OK");
	return 3;
}


Zfunction(GetLink){
	char szSrc[2048];
	const int cchDest = 2048;
	TCHAR szDest[cchDest];
	sprintf(szSrc,"%s","c:\\test\\");
	const DWORD dwRet = GetJunctionPointInfo(szSrc, szDest, cchDest);
	if (dwRet == 0 || dwRet > cchDest) {
		sprintf(data,"ERR:PARAMETER_1_DOES_NOT_A_JUNCTION");
		return 3;
	}
	sprintf(data,"%s",szDest);
	return 3;
}

