Fichier d'exemple de la DLL cwnd.

Pour commencer, chargez le fichier "cwnd_exemple.mrc"

Deux DLL ont �t� fournies pour enrichir le fichier d'exemple.
Merci � ClickHeRe, l'auteur de la DLL MPopup.
Merci � DragonZap l'auteur de la DLL MDX.

Une fois que vous avez test� les diff�rents exemples, vous pouvez d�charger le ficher "cwnd_exemple.mrc".