#include "cwnd.h"

/*extern "C" int WINAPI _DllMainCRTStartup(HANDLE hinst,DWORD,void*) {
	hInstance = (HINSTANCE)hinst;
	return 1;
} */
extern "C" void __stdcall LoadDll(LOADINFO* load)
{
	hmIRC = load->mHwnd;
	//FileMapping servant � envoyer des commandes � mIRC
	hFileMap = CreateFileMapping(INVALID_HANDLE_VALUE,0,PAGE_READWRITE,0,4096,"mIRC");
	mData = (LPSTR)MapViewOfFile(hFileMap,FILE_MAP_ALL_ACCESS,0,0,0);
	totMsg = 0;
	ff = false;
}
extern "C" int __stdcall UnloadDll(int timeout)
{
	if (!timeout) {
		if (ff) FindFileStruct.Continue = 0;
		listc<wproc>::iterator elm;
		while (_list.size()) {
			elm = _list.begin();
			Del(elm,1); //Supression de tous les identifiants
		}
		strptr.clear();
		messages.clear();
		UnmapViewOfFile(mData);
		CloseHandle(hFileMap);
	}
	return 0;
}
com(listing) {
	alias[0] = 0;
	if (!data[0]) {
		lstrcpy(data,e_miss);
		return 3;
	}
	strcpy(alias,data);
	SendEnum(GetDesktopWindow());
	EnumWindows(Enum,0);
	lstrcpy(data,"+OK");
	return 3;
}
com(getClassName) {
	if (!GetClassName((HWND)atol(data),data,900)) data[0] = 0;
	return 3;
}
com(getWindowText) {
	if (!iswin(data)) data[0] = 0;
	GetWindowText((HWND)atol(data),data,900);
	return 3;
}
com(getWindowRect) {
	char win[64], plus[16];
	tokenize(32,data,64,win,16,plus,NULL);
	if (!iswin(win)) {
		lstrcpy(data,e_handle);
		return 3;
	}
	RECT r;
	fzero(&r);
	GetWindowRect((HWND)atol(win),&r);
	wsprintf(data,"%d %d %d %d",r.left,r.top,plus[0] == '1' ? r.right - r.left : r.right,plus[0] == '1' ? r.bottom - r.top : r.bottom);
	return 3;
}
com(getClientRect) {
	if (!iswin(data)) {
		lstrcpy(data,e_handle);
		return 3;
	}
	RECT r;
	fzero(&r);
	GetClientRect((HWND)atol(data),&r);
	wsprintf(data,"%d %d %d %d",r.left,r.top,r.right,r.bottom);
	return 3;
}
com(getWindowThreadProcessId) {
	if (!iswin(data)) data[0] = 0;
	DWORD ID = 0;
	GetWindowThreadProcessId((HWND)atol(data),&ID);
	bnultoa((unsigned int)ID,data);
	return 3;
}
com(getWindowThreadProcessName) {
	if (!iswin(data)) data[0] = 0;
	DWORD ID = 0;
	NameProcessId((HWND)atol(data),data);
	return 3;
}
com(isWindowVisible) {
	if (IsWindowVisible((HWND)atol(data))) lstrcpy(data,c_true);
	else lstrcpy(data,c_false);
	return 3;
}
com(bringWindowToTop) {
	if (BringWindowToTop((HWND)atol(data))) lstrcpy(data,c_true);
	else lstrcpy(data,c_false);
	return 3;
}
com(isWindow) {
	if (IsWindow((HWND)atol(data))) lstrcpy(data,c_true);
	else lstrcpy(data,c_false);
	return 3;
}
com(getWindowCoords) {
	char parm1[128], parm2[128], plus[32];
	RECT r;
	fzero(&r);
	tokenize(32,data,128,parm1,128,parm2,32,plus,NULL);
	HWND h1 = (HWND)atol(parm1), h2 = (HWND)atol(parm2);
	if (!IsWindow(h1)) {
		lstrcpy(data,e_handle);
		return 3;
	}
	if (!IsWindow(h2)) {
		GetClientRect(h1,&r);
		plus[0] = 0;
		goto end;
	}
	GetWindowCoords(h2,h1,&r);
end:
	wsprintf(data,"%d %d %d %d",r.left,r.top,plus[0] == '1' ? r.right - r.left : r.right,plus[0] == '1' ? r.bottom - r.top : r.bottom);
	return 3;
}
com(setWindowText) {
	char parm1[64], parm2[768];
	gettok(data,1,32,parm1); gettok(data,-2,32,parm2);
	HWND h = (HWND)atol(parm1);
	if (!IsWindow(h)) {
		lstrcpy(data,e_handle);
		return 3;
	}
	if (SetWindowText(h,parm2)) lstrcpy(data,c_true);
	lstrcpy(data,c_false);
	return 3;
}
com(setIcon) {
	stripex(data,32,62);
	char hwnd[32], file[512], index[16], type[16]; index[0] = 0, type[0] = 0;
	HICON Large, Small; char t = 0;
	if (tokenize(62,data,32,hwnd,512,file,16,index,16,type,NULL) < 2) {
		lstrcpy(data,e_miss);
		return 3;
	}
	if (!lstrcmpi(type,icon_size[0])) t = 1;
	else if (!lstrcmpi(type,icon_size[1])) t = 2;
	if (!ExtractIconEx(file,atoi(index),&Large,&Small,1)) {
		lstrcpy(data,c_false);
		return 3;
	}
	switch (t) {
		case 1:
			DestroyIcon((HICON)SendMessage((HWND)atol(hwnd),WM_SETICON,ICON_SMALL,!Small ? (LPARAM)Large : (LPARAM)Small));
			break;
		case 2:
			DestroyIcon((HICON)SendMessage((HWND)atol(hwnd),WM_SETICON,ICON_BIG,!Large ? (LPARAM)Small : (LPARAM)Large));
			break;
		default:
			DestroyIcon((HICON)SendMessage((HWND)atol(hwnd),WM_SETICON,ICON_SMALL,!Small ? (LPARAM)Large : (LPARAM)Small));
			DestroyIcon((HICON)SendMessage((HWND)atol(hwnd),WM_SETICON,ICON_BIG,!Large ? (LPARAM)Small : (LPARAM)Large));
	}
	lstrcpy(data,c_true);
	return 3;
}

com(moveWindow) {
	BOOL repaint;
	char parm1[64], parm2[32], parm3[32], parm4[32], parm5[32], parm6[2], *p;
	parm2[0] = 0, parm3[0] = 0, parm4[0] = 0, parm5[0] = 0, parm6[0] = 0;
	gettok(data,1,32,parm1); p = gettok(data,2,32,parm2);
	p = gettok(p,2,32,parm3); p = gettok(p,2,32,parm4);
	p = gettok(p,2,32,parm5); if (!p) {
		lstrcpy(data,e_miss);
		return 3;
	}	gettok(p,2,32,parm6);
	repaint = parm6[0] ? TRUE : FALSE;
	HWND handle = (HWND)atol(parm1);
	if (!IsWindow(handle)) {
		lstrcpy(data,e_handle);
		return 3;
	}
	long x,y,w,h;
	RECT r; GetWindowCoords(GetParent(handle),handle,&r);
	x = dchars(parm2,r.left), y = dchars(parm3,r.top);
	w = dchars(parm4,r.right - r.left), h = dchars(parm5,r.bottom - r.top);
	if (MoveWindow(handle,x,y,w,h,repaint)) lstrcpy(data,c_true);
	else lstrcpy(data,c_false);
	return 3;
}
com(getNextWindow) {
	unsigned int u = (unsigned int)GetNextWindow((HWND)atol(data),GW_HWNDNEXT);
	bnultoa(u,data);
	return 3;
}
com(getPrevWindow) {
	unsigned int u = (unsigned int)GetNextWindow((HWND)atol(data),GW_HWNDPREV);
	bnultoa(u,data);
	return 3;
}
com(findWindow) {
	stripex(data,32,62);
	char classt[512], wint[512];
	classt[0] = 0, wint[0] = 0;
	gettokp(data,1,62,classt); gettokp(data,-2,62,wint);
	unsigned int u = (unsigned int)FindWindow(classt[0] ? classt : NULL,wint[0] ? wint : NULL);
	bnultoa(u,data);
	return 3;
}
com(findWindowEx) {
	stripex(data,32,62);
	char h1[64], h2[64], classt[512], wint[512] ,*p;
	h1[0] = 0, h2[0] = 0, classt[0] = 0, wint[0] = 0;
	gettokp(data,1,62,h1); p = gettokp(data,2,62,h2);
	p = gettokp(data,3,62,classt); gettokp(data,4,62,wint); 
	HWND handle1 = (HWND)atol(h1), handle2 = (HWND)atol(h2);
	unsigned int u = (unsigned int)FindWindowEx(handle1 ? handle1 : NULL,
		handle2 ? handle2 : NULL,classt[0] ? classt : NULL,wint[0] ? wint : NULL);
	bnultoa(u,data);
	return 3;
}
com(enumChildWindows) {
	char parm1[32], parm2[512];
	parm2[0] = 0;
	tokenize(32,data,32,parm1,512,parm2,-1);
	HWND h = (HWND)atol(parm1);
	if (!IsWindow(h)) {
		lstrcpy(data,e_handle);
		return 3;
	}
	if (!parm2[0]) {
		lstrcpy(data,e_miss);
		return 3;
	}
	lstrcpy(alias2,parm2);
	EnumChildWindows((HWND)atol(data),EnumChildProc,0);
	lstrcpy(data,ok);
	return 3;
}
com(isZoomed) {
	if (IsZoomed((HWND)atol(data))) lstrcpy(data,c_true);
	else lstrcpy(data,c_false);
	return 3;
}
com(isIconic) {
	if (IsIconic((HWND)atol(data))) lstrcpy(data,c_true);
	else lstrcpy(data,c_false);
	return 3;
}
com(openIcon) {
	if (OpenIcon((HWND)atol(data))) lstrcpy(data,c_true);
	else lstrcpy(data,c_false);
	return 3;
}
com(closeWindow) {
	if (CloseWindow((HWND)atol(data))) lstrcpy(data,c_true);
	else lstrcpy(data,c_false);
	return 3;
}
com(animateWindow) {
	char parm1[64], parm2[64], parm3[64] ,*p = NULL;
	if (tokenize(32,data,64,parm1,64,parm2,64,parm3,NULL) != 3) {
		lstrcpy(data,e_miss);
		return 3;
	}
	HWND handle = (HWND)atol(parm1);
	if (!IsWindow(handle)) {
		lstrcpy(data,e_handle);
		return 3;
	}
	DWORD time = atoi(parm2);
	DWORD style = 0;
	p = parm3;
	while (*p) {
		     if (*p == 'S') style |= AW_SLIDE;
		else if (*p == 'A') style |= AW_ACTIVATE;
		else if (*p == 'B') style |= AW_BLEND;
		else if (*p == 'H') style |= AW_HIDE;
		else if (*p == 'C') style |= AW_CENTER;
		else if (*p == 'P') style |= AW_HOR_POSITIVE;
		else if (*p == 'N') style |= AW_HOR_NEGATIVE;
		else if (*p == 'p') style |= AW_VER_POSITIVE;
		else if (*p == 'n') style |= AW_VER_NEGATIVE;
		*p++;
	}
	if (AnimateWindow(handle,time,style)) {
		lstrcpy(data,c_true);
		 InvalidateRect(handle, 0, 1);
	}
	else lstrcpy(data,c_false);
	return 3;
}
com(windowFromPoint) {
	char x[64], y[64]; x[0] = 0, y[0] = 0;
	tokenize(32,data,64,x,64,y,NULL);
	POINT p;
	p.x = atol(x), p.y = atol(y);
	bnultoa((unsigned int)WindowFromPoint(p),data);
	return 3;
}
com(childWindowFromPoint) {
	char hwnd[128], x[64], y[64]; hwnd[0] = 0, x[0] = 0, y[0] = 0;
	tokenize(32,data,128,hwnd,64,x,64,y,NULL);
	POINT p;
	p.x = atol(x), p.y = atol(y);
	bnultoa((unsigned int)ChildWindowFromPoint((HWND)atol(hwnd),p),data);
	return 3;
}
com(childWindowFromPointEx) {
	char hwnd[128], flags[256], x[64], y[64], str[128]; hwnd[0] = 0, x[0] = 0, y[0] = 0, flags[0] = 0;
	tokenize(32,data,128,hwnd,64,x,64,y,256,flags,-1);
	UINT Flags = 0;
	POINT p;
	p.x = atol(x), p.y = atol(y);
	for (int i = 1;gettok(flags,i,32,str);i++) {
		if (!lstrcmpi(str,"ALL")) Flags |= CWP_ALL;
		else if (!lstrcmpi(str,"SKIPINVISIBLE")) Flags |= CWP_SKIPINVISIBLE;
		else if (!lstrcmpi(str,"SKIPDISABLED")) Flags |= CWP_SKIPDISABLED;
		else if (!lstrcmpi(str,"SKIPTRANSPARENT")) Flags |= CWP_SKIPTRANSPARENT;
	}
	bnultoa((unsigned int)ChildWindowFromPointEx((HWND)atol(hwnd),p,Flags),data);
	return 3;
}
com(enableWindow) {
	char parm1[64], parm2[128];
	if (tokenize(32,data,64,parm1,128,parm2,NULL) != 2)	{
		lstrcpy(data,e_miss);
		return 3;
	}
	HWND handle = (HWND)atol(parm1);
	if (!IsWindow(handle)) {
		lstrcpy(data,e_handle);
		return 3;
	}
	if (EnableWindow(handle,parm2[0] == '1' ? TRUE : FALSE)) lstrcpy(data,c_true);
	else lstrcpy(data,c_false);
	return 3;
}
com(isWindowEnabled) {
	if (IsWindowEnabled((HWND)atol(data))) lstrcpy(data,c_true);
	else lstrcpy(data,c_false);
	return 3;
}
com(getWindowLong) {
	char parm1[64], parm2[64];
	if (tokenize(32,data,64,parm1,64,parm2,-1) != 2)	{
		lstrcpy(data,e_miss);
		return 3;
	}
	HWND handle = (HWND)atol(parm1);
	if (!IsWindow(handle)) {
		lstrcpy(data,e_handle);
		return 3;
	}
	int index;
	if (!lstrcmpi(parm2,"style")) index = GWL_STYLE;
	else if (!lstrcmpi(parm2,"exstyle")) index = GWL_EXSTYLE;
	else {
		lstrcpy(data,e_invp);
		return 3;
	}
	LONG L = GetWindowLong(handle,index);
	char *c = data;
	int i = 0 , o = 0;
	if (index == GWL_STYLE) {
		while (i < 20) {
			if (L & style_num[i]) {
				while (style_char[i][o]) *c++ = style_char[i][o++];
				*c++ = 32;
				o = 0;
			}
			i++;
		}
	}
	else {
		while (i < 19) {
			if (L & exstyle_num[i]) {
				while (exstyle_char[i][o]) *c++ = exstyle_char[i][o++];
				*c++ = 32;
				o = 0;
			}
			i++;
		}
	}
	*c = 0;
	return 3;
}
com(setWindowLong) {
	char parm1[64], parm2[64], parm3[512] ,*p; parm3[0] = 0;
	gettok(data,1,32,parm1); if (!(p=gettok(data,2,32,parm2))) 
	{
		lstrcpy(data,e_miss);
		return 3;
	}
	gettok(p,-2,32,parm3);
	HWND handle = (HWND)atol(parm1);
	if (!IsWindow(handle)) {
		lstrcpy(data,e_handle);
		return 3;
	}
	int index;
	if (!lstrcmpi(parm2,"style")) index = GWL_STYLE;
	else if (!lstrcmpi(parm2,"exstyle")) index = GWL_EXSTYLE;
	else {
		lstrcpy(data,e_invp);
		return 3;
	}
	char buffer[256]; buffer[0] = 0;
	int i = 1;
	LONG L = GetWindowLong(handle,index) , S = 0, T;
	bool first = FALSE;
	if (index == GWL_STYLE) {
		while (gettok(parm3,i,32,buffer)) {
			if ((T = s_style(buffer))) {
				S |= T;
			}
			i++;
		}
	}
	else {
			while (gettok(parm3,i,32,buffer)) {
			if ((T = s_exstyle(buffer))) {
				S |= T;
			}
			i++;
		}
	}
	if (SetWindowLong(handle,index,S)) lstrcpy(data,c_true);
	else lstrcpy(data,c_false);
	return 3;
}
com(addWindowLong) {
	char parm1[64], parm2[64], parm3[512] ,*p; parm3[0] = 0;
	gettok(data,1,32,parm1); if (!(p=gettok(data,2,32,parm2))) 
	{
		lstrcpy(data,e_miss);
		return 3;
	}
	gettok(p,-2,32,parm3);
	HWND handle = (HWND)atol(parm1);
	if (!IsWindow(handle)) {
		lstrcpy(data,e_handle);
		return 3;
	}
	int index;
	if (!lstrcmpi(parm2,"style")) index = GWL_STYLE;
	else if (!lstrcmpi(parm2,"exstyle")) index = GWL_EXSTYLE;
	else {
		lstrcpy(data,e_invp);
		return 3;
	}
	char buffer[256]; buffer[0] = 0;
	int i = 1;
	LONG L = GetWindowLong(handle,index) , S = 0, T;
	bool first = false;
	if (index == GWL_STYLE) {
		while (gettok(parm3,i,32,buffer)) {
			if ((T = s_style(buffer))) {
				if (!(L & T)) {
					if (first) S |= T;
					else { S = T; first = true; }
				}
			}
			i++;
		}
	}
	else {
			while (gettok(parm3,i,32,buffer)) {
			if ((T = s_exstyle(buffer))) {
				if (!(L & T)) {
					if (first) S |= T;
					else { S = T; first = true; }
				}
			}
			i++;
		}
	}
	L |= S;
	if (SetWindowLong(handle,index,L)) lstrcpy(data,c_true);
	else lstrcpy(data,c_false);
	return 3;
}
com(remWindowLong) {
	char parm1[64], parm2[64], parm3[512] ,*p; parm3[0] = 0;
	gettok(data,1,32,parm1); if (!(p=gettok(data,2,32,parm2))) 
	{
		lstrcpy(data,e_miss);
		return 3;
	}
	gettok(p,-2,32,parm3);
	HWND handle = (HWND)atol(parm1);
	if (!IsWindow(handle)) {
		lstrcpy(data,e_handle);
		return 3;
	}
	int index;
	if (!lstrcmpi(parm2,"style")) index = GWL_STYLE;
	else if (!lstrcmpi(parm2,"exstyle")) index = GWL_EXSTYLE;
	else {
		lstrcpy(data,e_invp);
		return 3;
	}
	char buffer[256]; buffer[0] = 0;
	int i = 1;
	LONG L = GetWindowLong(handle,index) , S = 0, T;
	bool first = false;
	if (index == GWL_STYLE) {
		while (gettok(parm3,i,32,buffer)) {
			if ((T = s_style(buffer))) {
				if ((L & T)) {
					if (first) S |= T;
					else { S = T; first = true; }
				}
			}
			i++;
		}
	}
	else {
			while (gettok(parm3,i,32,buffer)) {
			if ((T = s_exstyle(buffer))) {
				if ((L & T)) {
					if (first) S |= T;
					else { S = T; first = true; }
				}
			}
			i++;
		}
	}
	L &= ~S;
	if (SetWindowLong(handle,index,L)) lstrcpy(data,c_true);
	else lstrcpy(data,c_false);
	return 3;
}
com(setParent) {
	char parm1[64], parm2[64];
	tokenize(32,data,64,parm1,64,parm2,NULL);
	HWND child, parent;
	child = (HWND)atol(parm1), parent = (HWND)atol(parm2);
	if (!IsWindow(child) || !IsWindow(parent)) {
		lstrcpy(data,e_handle);
		return 3;
	}
	unsigned int u = (unsigned int)SetParent(child,parent);
	bnultoa(u,data);
	return 3;
}
com(getParent) {
	unsigned int u = (unsigned int)GetParent((HWND)atol(data));
	bnultoa(u,data);
	return 3;
}
com(getAncestor) {
	char hwnd[16], flag[32];
	if (tokenize(32,data,16,hwnd,32,flag) != 2) {
		lstrcpy(data,e_miss);
		return 3;
	}
	if (!iswin(hwnd)) {
		lstrcpy(data,e_handle);
		return 3;
	}
	for (int i = 0;i < 3;i++) if (!lstrcmpi(ancestor_str[i],flag)) { 
		bnultoa((unsigned int)GetAncestor((HWND)atol(hwnd),ancestor_num[i]),data);
		return 3;
	}
	lstrcpy(data,c_false);
	return 3;
}
com(showOwnedPopups) {
	char parm1[64], parm2[32];
	if (tokenize(32,data,64,parm1,32,parm2,NULL) != 2) {
		lstrcpy(data,e_miss);
		return 3;
	}
	HWND handle = (HWND)atol(parm1);
	if (!IsWindow(handle)) {
		lstrcpy(data,e_handle);
		return 3;
	}
	if (ShowOwnedPopups(handle,parm2[0] == '1' ? TRUE : FALSE)) lstrcpy(data,c_true);
	else lstrcpy(data,c_false);
	return 3;
}
com(showChilds) {
	char parm1[64], parm2[32];
	if (tokenize(32,data,64,parm1,32,parm2,NULL) != 2) {
		lstrcpy(data,e_miss);
		return 3;
	}
	HWND handle = (HWND)atol(parm1);
	if (!IsWindow(handle)) {
		lstrcpy(data,e_handle);
		return 3;
	}
	if (ShowChilds(handle,parm2[0] == '1' ? TRUE : FALSE)) lstrcpy(data,c_true);
	else lstrcpy(data,c_false);
	return 3;
}
com(showWindow) {
	char parm1[64], parm2[128];
	gettok(data,1,32,parm1); gettok(data,2,32,parm2);
	HWND handle = (HWND)atol(parm1);
	if (!IsWindow(handle)) {
		lstrcpy(data,e_handle);
		return 3;
	}
	int i = 0;
	while (i < 12) {
		if (!lstrcmpi(parm2,show_char[i])) goto next;
		i++;
	}
	lstrcpy(data,e_invp);
	return 3;
next:
	if (ShowWindow(handle,i)) lstrcpy(data,c_true);
	else lstrcpy(data,c_false);
	return 3;
}
com(getShowState) {
	HWND handle = (HWND)atol(data);
	if (!IsWindow(handle)) {
		lstrcpy(data,e_handle);
		return 3;
	}
	LONG L = GetWindowLong(handle,GWL_STYLE);
	if (!(L & WS_VISIBLE)) {
		lstrcpy(data,show_char[0]);
		return 3;
	}
	WINDOWPLACEMENT Place;
	Place.length = sizeof(Place);
	GetWindowPlacement(handle,&Place);
	lstrcpy(data,show_char[Place.showCmd]);
	return 3;	
}
com(updateWindow) {
	if (UpdateWindow((HWND)atol(data))) lstrcpy(data,c_true);
	else lstrcpy(data,c_false);
	return 3;
}
com(destroyWindow) {
	if (DestroyWindow((HWND)atol(data))) lstrcpy(data,c_true);
	else lstrcpy(data,c_false);
	return 3;
}
com(getDlgItem) {
	char parm1[512], parm2[256];
	if (tokenize(32,data,512,parm1,256,parm2,NULL) != 2) {
		lstrcpy(data,e_miss);
		return 3;
	}
	data[0] = 0;
	bnultoa((unsigned int)GetDlgItem((HWND)atol(parm1),atoi(parm2)),data);
	return 3;
}
com(getMircDlgItem) {
	char parm1[512], parm2[128];
	if (tokenize(32,data,512,parm1,128,parm2,NULL) != 2) {
		lstrcpy(data,e_miss);
		return 3;
	}
	wsprintf(mData,"$dialog(%s).hwnd",parm1);
	SendMessage(hmIRC,WM_MEVALUATE,0,0);
	HWND handle = (HWND)atol(mData);
	if (!IsWindow(handle)) {
		lstrcpy(data,c_false);
		return 3;
	}
	HWND res = GetDlgItem(handle,atoi(parm2) + 6000);
	if (!IsWindow(res)) {
		lstrcpy(data,c_false);
		return 3;
	}
	bnultoa((unsigned int)res,data);
	return 3;
}
com(getDlgCtrlID) {
	HWND win = (HWND)atol(data);
	if (!IsWindow(win)) {
		lstrcpy(data,c_false);
		return 3;
	}
	bnultoa((unsigned int)GetDlgCtrlID(win),data);
	return 3;
}
com(ff_start) {
	if (ff) {
		lstrcpy(data,c_false);
		return 3;
	}
	stripex(data,32,62);
	char path[512], mask[256], pr[64], alias[256];
	if (tokenize(62,data,512,path,256,mask,64,pr,256,alias,-1) != 4) {
		lstrcpy(data,e_miss);
		return 3;
	}
	int len1 = lstrlen(path), len2 = lstrlen(mask), len3 = lstrlen(alias);
	if (path[len1 - 1] != 92) {
		path[len1] = 92;
		len1++;
		path[len1] = 0;
	}
	_path = (char *)malloc(len1 + 1);
	_mask = (char *)malloc(len2 + 1);
	_alias = (char *)malloc(len3 + 2);
	lstrcpy(_path,path), lstrcpy(_mask,mask);
	char *c = alias, *d = _alias;
	for (int i = 0;*c;c++,i++) {
		if (i == 0 && *c != 47) *d++ = 47;
		*d++ = *c;
	}
	*d = 0;
	
	 DWORD dwThreadId;
	 _sub = !lstrcmpi(pr,"yes") ? true : false;
	 if (!CreateThread(NULL,0,scand,&FindFileStruct,0,&dwThreadId)) {
		 free_ff();
		 lstrcpy(data,c_false);
	 }
	 else lstrcpy(data,c_true);
	 return 3;
}

com(ff_stop) {
	if (!ff) {
		lstrcpy(data,c_false);
		return 3;
	}
	FindFileStruct.Continue = 0;
	lstrcpy(data,c_true);
	return 3;
}
com(ff_is) {
	if (ff) lstrcpy(data,c_true);
	else lstrcpy(data,c_false);
	return 3;
}
com(subclass) {
	char name[256], handle[64], cancel[32], command[256]; command[0] = 0;
	if (tokenize(32,data,256,name,64,handle,32,cancel,256,command,-1) < 2)  {
		lstrcpy(data,e_miss);
		return 3;
	}
	if (Search(name) != iNULL()) {
		lstrcpy(data,c_false);
		return 3;
	}
	HWND hwnd = (HWND)atol(handle);
	if (!IsWindow(hwnd)) {
		lstrcpy(data,e_handle);
		return 3;
	}
	listc<wproc>::iterator iter;
	if ((iter = Search(hwnd)) != iNULL()) {
		lstrcpy(data,c_false);
		return 3;
	}
	wproc elm; 
	if (command[0]) {
		if (command[0] != '/') {
			elm.command = (char *)malloc(lstrlen(command) + 2);
			wsprintf(elm.command,"/%s",command);
		}
		else {
			elm.command = (char *)malloc(lstrlen(command) + 1);
			lstrcpy(elm.command,command);
		}
	}
	else {
		elm.command = (char *)malloc(14);
		lstrcpy(elm.command,"/.signal cwnd");
	}
	elm.name = (char *)malloc(lstrlen(name) + 1);
	lstrcpy(elm.name,name); elm.win = hwnd;
	elm.proc = (WNDPROC)GetWindowLong(hwnd,GWL_WNDPROC);
	if (cancel[0] == '1') elm.cancel = TRUE;
	else elm.cancel = FALSE;
	SetWindowLong(hwnd,GWL_WNDPROC,(LONG)CustomProc);
	for (listc<cust>::iterator iter = messages.begin();iter != messages.end();iter++) {
		elm.custom.push_back(2);
	}
	_list.push_front(elm);
	wsprintf(mData,"%s %s BeginSubclassing",elm.command,name);
	Signal;
	lstrcpy(data,c_true);
	return 3;
}
com(sfree) {
	listc<wproc>::iterator iter = _list.begin();
	while (iter != _list.end()) {
		if (!lstrcmpi(iter->name,data)) {
			Del(iter,1);
			lstrcpy(data,c_true);
			return 3;
		}
		iter++;
	}
	lstrcpy(data,c_false);
	return 3;
}
com(getInfo) {
	char name[256], info[256];
	if (tokenize(32,data,256,name,256,info,NULL) < 2) {
		lstrcpy(data,e_miss);
		return 3;
	}
	listc<wproc>::iterator ptr;
	if ((ptr = Search(name)) == iNULL()) lstrcpy(data,c_false);
	else if (!lstrcmpi(info,subinfo[0])) bnultoa((unsigned int)ptr->cancel,data);
	else if (!lstrcmpi(info,subinfo[1])) bnultoa((unsigned int)ptr->win,data);
	else if (!lstrcmpi(info,subinfo[2])) lstrcpy(data,ptr->command);
	else if (!lstrcmpi(info,subinfo[3])) {
		if (ptr->mark == NULL) data[0] = 0;
		else lstrcpy(data,ptr->mark);
	}
	else lstrcpy(data,e_invp);
	return 3;
}
com(setInfo) {
	char name[256], info[256], content[512]; content[0] = 0;
	int alloc_size = 0;
	if (tokenize(32,data,256,name,256,info,512,content,-1) < 2) {
miss:
		lstrcpy(data,e_miss);
		return 3;
	}
	listc<wproc>::iterator ptr;
	lstrcpy(data,c_true);
	if ((ptr = Search(name)) == iNULL()) lstrcpy(data,c_false);
	else if (!lstrcmpi(info,subinfo[0])) ptr->cancel = content[0] == '1' ? TRUE : FALSE;
	else if (!lstrcmpi(info,subinfo[2])) {
		alloc_size = lstrlen(content);
		if (!alloc_size) goto miss;
		alloc_size += content[0] == '/' ? 1 : 2;
		if (ptr->command == NULL) ptr->command = (char *)malloc(alloc_size);
		else ptr->command = (char *)realloc(ptr->command,alloc_size);
		if (content[0] == '/') lstrcpy(ptr->command,content);
		else wsprintf(ptr->command,"/%s",content);
	}
	else if (!lstrcmpi(info,subinfo[3])) {
		alloc_size = lstrlen(content) + 1;
		if (ptr->mark == NULL) ptr->mark = (char *)malloc(alloc_size);
		else ptr->mark = (char *)realloc(ptr->mark,alloc_size);
		lstrcpy(ptr->mark,content);
	}
	return 3;
}
com(getsubclassed)
{
	char wild[512], id[64];
	int num, i;
	gettok(data,1,32,wild);
	if (!gettok(data,-2,32,id)) {
		lstrcpy(data,e_miss);
		return 3;
	}
	char *c = id;
	while (*c && (*c < '0' || *c > '9')) c++; //on passe le caract�re non num�riques
	if (!*c) { //erreur, aucun nombre n'a �t� donn�
		lstrcpy(data,e_invp);
		return 3;
	}
	num = atoi(c);
	listc<wproc>::iterator iter = _list.begin();
	if (num < 0) {
		lstrcpy(data,e_invp);
		return 3;
	}
	if (num == 0) {
		//on compte le nombre d'occurences
		for (i = 0;iter != _list.end();iter++) if (wild_match(wild,iter->name)) i++;
		bnultoa(i,data); //transforme int en char
		return 3;
	}
	i = 0;
	while (iter != _list.end()) {
		if (wild_match(wild,iter->name)) {
			i++;
			if (num == i) {
				//on retourne le nom de l'identifiant trouv�
				lstrcpy(data,iter->name);
				return 3;
			}
		}
		iter++;
	}
	data[0] = '\0';
	return 3;
}
com(getblocked) {
	char parm1[64], parm2[64];
	gettok(data,1,32,parm1), gettok(data,2,32,parm2);
	wproc elm; listc<wproc>::iterator ptr;
	if ((ptr = Search(parm1)) == iNULL()) {
		lstrcpy(data,c_false);
		return 3;
	}
	elm = *ptr;
	BOOL status = parm2[0] == '0' ? FALSE : TRUE;
	data[0] = 0; char *in = data;
	int i;
	for (i = 0; i < EVENTS; i++) {
		if (elm.events[i] == status) { //si l'�tat de l'event est celui d�sir�... 
			data = pstrcpy(data,event_char[i],32); //ajoute le nom de l'event � la cha�ne qui sera retourn�e
		}
	}
	i = 0;
	for (listc<char>::iterator iter =  elm.custom.begin();iter != elm.custom.end(); iter++, i++) {
		if (((*iter & 0x1) == 0x1) == status) data = pstrcpy(data,messages[i].data.string(),32);
	}
	*data = 0;
	data = in;
	return 3;
}
com(getignored) {
	char parm1[64], parm2[64];
	gettok(data,1,32,parm1), gettok(data,2,32,parm2);
	wproc elm; listc<wproc>::iterator ptr = Search(parm1);
	if (ptr == iNULL()) {
		lstrcpy(data,c_false);
		return 3;
	}
	elm = *ptr;
	BOOL status = parm2[0] == '1' ? TRUE : FALSE;
	data[0] = 0; char *in = data;
	int i;
	for (i = 0; i < EVENTS; i++) {
		if (elm.send[i] == status) { //si l'�tat de l'event est celui d�sir�... 
			data = pstrcpy(data,event_char[i],32); //ajoute le nom de l'event � la cha�ne qui sera retourn�e
		}
	}
	i = 0;
	for (listc<char>::iterator iter =  elm.custom.begin();iter != elm.custom.end(); iter++, i++) {
		if (((*iter & 0x2) == 0x2) == status) data = pstrcpy(data,messages[i].data.string(),32);
	}
	*data = 0;
	data = in;
	return 3;
}
com(block) {
	char parm1[128], parm2[32], parm3[512] ,*p;
	gettok(data,1,32,parm1); p = gettok(data,2,32,parm2);
	if (!(p = gettok(p,-2,32,parm3)))
	{
		lstrcpy(data,e_miss);
		return 3;
	}
 listc<wproc>::iterator ptr = Search(parm1);
	if (ptr == _list.end()) {
		lstrcpy(data,c_false);
		return 3;
	}
	BOOL statut = parm2[0] == '1' ? TRUE : FALSE;
	int i, o;
	for (i = 1; gettok(parm3,i,32,data); i++) {
		for (o = 0;o < EVENTS;o++) {

			if (wild_match(data,event_char[o])) {
				ptr->events[o] = statut;
			}
		}
		o = 0;
		for (listc<cust>::iterator iter = messages.begin();iter != messages.end();iter++,o++) {
			if (wild_match(data,iter->data.string())) {
				if (statut) *ptr->custom.get(o) |= 1;
				else *ptr->custom.get(o) &= ~1;
			}
		}
	}
	
	lstrcpy(data,c_true);
	return 3;
}
com(ignore) {
	char parm1[128], parm2[32], parm3[512];
	if (tokenize(32,data,128,parm1,32,parm2,512,parm3,-1) != 3) {
		lstrcpy(data,e_miss);
		return 3;
	}
	listc<wproc>::iterator ptr = Search(parm1);
	if (ptr == iNULL()) {
		lstrcpy(data,c_false);
		return 3;
	}
	BOOL statut = parm2[0] == '1' ? FALSE : TRUE;
	int i, o;
	for (i = 1; gettok(parm3,i,32,data); i++) {
		for (o = 0;o < EVENTS;o++) {

			if (wild_match(data,event_char[o])) {
				ptr->send[o] = statut;
			}
		}
		o = 0;
		for (listc<cust>::iterator iter = messages.begin();iter != messages.end();iter++,o++) {
			if (wild_match(data,iter->data.string())) {
				if (statut) *ptr->custom.get(o) |= 2;
				else *ptr->custom.get(o) &= ~2;
			}
		}
	}
	lstrcpy(data,c_true);
	return 3;
}
com(sendMessage) {
	char parm1[128], parm2[32], parm3[32] , parm4[32], str[32]; str[0] = 0;
	LPARAM lParam; WPARAM wParam; UINT msg; HWND window;
	if (tokenize(32,data,128,parm1,32,parm2,32,parm3,32,parm4,32,str) < 4) {
		lstrcpy(data,e_miss);
		return 3;
	}
	window = (HWND)atol(parm1);
	if (!IsWindow(window)) {
		lstrcpy(data,e_handle);
		return 3;
	}
	msg = devents(parm2);
	wParam = (WPARAM)atol(parm3);
	lParam = (LPARAM)atol(parm4);
	if (str[0] == '1') lstrcpyn(data,(LPSTR)SendMessage(window,msg,wParam,lParam),900);
	else bnultoa((unsigned int)SendMessage(window,msg,wParam,lParam),data);
	return 3;
}
com(getSystemMetrics) {
	bnultoa(GetSystemMetrics(atoi(data)),data);
	return 3;
}
com(callWindowProc) {
	char parm1[128], parm2[32], parm3[32] , parm4[32], str[32]; str[0] = 0;
	LPARAM lParam; WPARAM wParam; UINT msg;
	if (tokenize(32,data,128,parm1,32,parm2,32,parm3,32,parm4,32,str) < 4) {
		lstrcpy(data,e_miss);
		return 3;
	}
	listc<wproc>::iterator iter = Search(parm1);
	if (iter == _list.end()) {
		lstrcpy(data,c_false);
		return 3;
	}
	msg = devents(parm2);
	wParam = (WPARAM)atol(parm3);
	lParam = (LPARAM)atol(parm4);
	if (str[0] == '1') lstrcpyn(data,(LPSTR)CallWindowProc(iter->proc,iter->win,msg,wParam,lParam),900);
	else bnultoa((unsigned int)CallWindowProc(iter->proc,iter->win,msg,wParam,lParam),data);
	return 3;
}
com(setWindowPos) {
	SWP swp;
	int res = FillSWP(data,swp);
	switch (res) {
		case -1:
			lstrcpy(data,e_miss);
			break;
		case -2: case -3:
			lstrcpy(data,e_handle);
			break;
		default:
			if (SetWindowPos(swp.hWnd,swp.hWndInsertAfter,swp.X,swp.Y,swp.cx,swp.cy,swp.uFlags))
				lstrcpy(data,c_true);
			else lstrcpy(data,c_false);
	}
	return 3;
}
com(getDeferWindowPos) {
	int a = atoi(data);
	listc<defer>::iterator iter = dwp.begin();
	if (a < 0 || a > (signed)dwp.size()) data[0] = 0;
	else if (a == 0) bnultoa(dwp.size(),data);
	else {
		for (int i = 1;iter != dwp.end();iter++,i++) 
			if (i == a) {
				iter->string.c_str(data);
				return 3;
			}
	}
	return 3;
}
com(delDeferWindowPos) {
	listc<defer>::iterator iter = dwp.begin();
	while (iter != dwp.end()) {
		if (iter->string == data) {
			dwp.pop(iter);
			lstrcpy(data,c_true);
			return 3;
		}
		iter++;
	}
	lstrcpy(data,c_false);
	return 3;
}
com(beginDeferWindowPos) {
	char parm1[256], parm2[128];
	if (tokenize(32,data,256,parm1,128,parm2,NULL) != 2) {
		lstrcpy(data,e_miss);
		return 3;
	}
	listc<defer>::iterator iter;
	iter = dwp.begin();
	while (iter != dwp.end()) {
		if (iter->string == parm1) {
			lstrcpy(data,c_false);
			return 3;
		}
		iter++;
	}
	int n = atoi(parm2);
	if (n < 0) {
		lstrcpy(data,c_false);
		return 3;
	}
	defer tmp;
	if (!(tmp.hdwp = BeginDeferWindowPos(n))) {
		lstrcpy(data,c_false);
		return 3;
	}
	tmp.string = parm1;
	dwp.push_back(tmp);
	lstrcpy(data,c_true);
	return 3;
}
com(deferWindowPos) {
	char name[64], str[512];
	if (tokenize(32,data,64,name,512,str,-1) < 2) { lstrcpy(data,e_miss); return 3; }
	SWP swp;
	int res;
	listc<defer>::iterator iter = dwp.begin();
	while (iter != dwp.end()) {
		if (iter->string == name) goto next;
		iter++;
	}
	lstrcpy(data,c_false);
	return 3;
next:
	res = FillSWP(str,swp);
	switch (res) {
		case -1:
			lstrcpy(data,e_miss);
			break;
		case -2: case -3:
			lstrcpy(data,e_handle);
			break;
		default:
			if (DeferWindowPos(iter->hdwp,swp.hWnd,swp.hWndInsertAfter,swp.X,swp.Y,swp.cx,swp.cy,swp.uFlags))
				lstrcpy(data,c_true);
			else lstrcpy(data,c_false);
	}
	return 3;
}
com(endDeferWindowPos) {
	listc<defer>::iterator iter = dwp.begin();
	while (iter != dwp.end()) {
		if (iter->string == data) {
			if (EndDeferWindowPos(iter->hdwp)) lstrcpy(data,c_true);
			else lstrcpy(data,c_false);
			dwp.pop(iter);
			return 3;
		}
		iter++;
	}
	lstrcpy(data,c_false);
	return 3;
}
com(setID) {
	char parm1[64], parm2[64];
	if (tokenize(32,data,64,parm1,64,parm2,NULL) != 2) {
		lstrcpy(data,e_miss);
		return 3;
	}
	HWND win = (HWND)atol(parm1);
	if (!IsWindow(win)) {
		lstrcpy(data,c_false);
		return 3;
	}
	int n = atoi(parm2);
	SetWindowLong(win,GWL_ID,n);
	lstrcpy(data,c_true);
	return 3;
}

com(addCustMsg) {
	char parm1[64], parm2[512], wptr[8], lptr[8];
	wptr[0] = 0, lptr[0] = 0;
	if (tokenize(32,data,64,parm1,512,parm2,8,wptr,8,lptr,NULL) < 2) {
		lstrcpy(data,e_miss);
		return 3;
	}
	cust elm;
	elm.msg = atol(parm2);
	elm.data = parm1;
	//lstrcpyn(elm.data,parm1);
	elm.wptr = wptr[0] == '1' ? true : false;
	elm.lptr = lptr[0] == '1' ? true : false;
	int i;
	listc<cust>::iterator iter;
	//listc<cust>::iterator iter;
	//On v�rifie si le message ou le texte du message n'existe pas d�j� dans les messages par d�faut
	for (i = 0;i < EVENTS;i++) {
		if (elm.msg == event_num[i] || elm.data == event_char[i]) {
			goto cfalse;
		}
	}
	//On v�rifie si le message ou le texte du message n'existe pas d�j� dans les messages custom
	for (iter = messages.begin();iter != messages.end();iter++) {
		if (elm.msg == iter->msg || elm.data == iter->data) {
cfalse:
			lstrcpy(data,c_false);
			return 3;
		}
	}
	messages.push_back(elm);
	AddNewCustMsg(); //met � jour les messages custom des subclassing actifs
	lstrcpy(data,c_true);
	return 3;
}
com(getCustMsg) {
	listc<cust>::iterator iter;
	if (data[0] >= '0' && data[0] <= '9') {
		int n = atoi(data);
		if (n == 0) {
			bnultoa(messages.size(),data);
			return 3;
		}
		 iter = messages.get(n-1);
		if (iter == messages.end()) data[0] = 0;
		else wsprintf(data,"%s %u %d %d",iter->data.string(),iter->msg,iter->wptr,iter->lptr);
	}
	else {
		for (iter == messages.begin();iter != messages.end();iter++)
			if (iter->data == data) {
				wsprintf(data,"%s %u %d %d",iter->data.string(),iter->msg,iter->wptr,iter->lptr);
				return 3;
			}
			data[0] = 0;
	}
	return 3;
}
com(setCustMsg) {
	char name[256], wptr[8], lptr[8];
	if (tokenize(32,data,256,name,8,wptr,8,lptr) < 3) {
		lstrcpy(data,e_miss);
		return 3;
	}
	lstrcpy(data,c_false);
	for (listc<cust>::iterator iter = messages.begin();iter != messages.end();iter++) {
		if (iter->data == name) {
			iter->wptr = wptr[0] == '1' ? true : false;
			iter->lptr = lptr[0] == '1' ? true : false;
			lstrcpy(data,c_true);
			break;
		}
	}
	return 3;
}
com(delCustMsg) {
	int n = 0;
	listc<cust>::iterator iter = messages.begin();
	while (iter != messages.end()) {
		if (iter->data == data) {
			messages.pop(iter);
			DelCustMsg(n);
			n = -1;
			lstrcpy(data,c_true);
		}
		iter++;
		n++;
	}
	if (n != -1) lstrcpy(data,c_false);
	return 3;
}

com(newStruct) {
	char name[256], size[128];
	size[0] = 0;
	if (!tokenize(32,data,256,name,128,size,-1)) {
		lstrcpy(data,e_miss);
		return 3;
	}
	size_t n = atol(size);
	for (listc<nptr>::iterator iter = strptr.begin();iter != strptr.end();iter++) {
		if (iter->name == name) {
			lstrcpy(data,c_false);
			return 3;
		}
	}
	nptr elm;
	elm.data = (char *)malloc(n);
	elm.size = n;
	for (unsigned int i = 0;i < n;i++) elm.data[i] = 0;
	elm.name = name;
	//lstrcpy(elm.name,name); 
	strptr.push_back(elm);
	lstrcpy(data,c_true);
	elm.size = 0;
	return 3;
}
com(setStruct) {
	char name[256], type[32], pos[16], str[800];
	str[0] = 0;
	nptr elm;
	int t = 0, p , len = 0;
	if (tokenize(32,data,256,name,32,type,16,pos,800,str,-1) < 4) {
		lstrcpy(data,e_miss);
		return 3;
	}
	listc<nptr>::iterator iter = strptr.begin();
	while (iter != strptr.end()) {
		if (iter->name == name) goto next;
		iter++;
	}
no:
	lstrcpy(data,c_false);
	return 3;
next:
	if (!lstrcmpi(type,"str")) t = 1;
	else if (!lstrcmpi(type,"ustr")) t = 2;
	else if (!lstrcmpi(type,"word")) t = 3;
	else if (!lstrcmpi(type,"nword")) t = 4;
	else if (!lstrcmpi(type,"dword")) t = 5;
	else if (!lstrcmpi(type,"ndword")) t = 6;
	else if (!lstrcmpi(type,"asc")) t = 7;
	else goto no;
	p = atol(pos);
	if (p == -1) p = iter->size;
	else if (p < -1) goto no;
	if ((unsigned) p >= iter->size) {
		unsigned int z = iter->size;
		iter->size = p + 1;
		iter->data = (char *)realloc(iter->data,iter->size);
		while (z < iter->size) iter->data[z++] = 0;
	}
	if (t == 7) {
		t = 1;
		char *s , *d; s = d = str;
		char a = 0;
		while (*s) {
			while (*s && (*s < '0' || *s > '9')) s++;
			while (*s >= '0' && *s <= '9') a = a * 10 + *s++ - 48;
			*d++ = a;
			len++;
			a = 0;
		}
	}
	if (len == 0) {
		len = lstrlen(str);
		if (t == 2) len *= 2;
	}
	char *ptr = iter->data + p;
	switch(t) {
		case 1: case 2:
			//size: 2 - p:0 - str: test - len: 3
			if ((unsigned)(p + len) > iter->size) {
				iter->size = p + len;
				iter->data = (char *)realloc(iter->data,iter->size);
				ptr = iter->data + p;
			}
			if (t == 2) len /= 2;
			for (int i = 0;i < len;i++) {
				*ptr++ = str[i];
				if (t == 2) *ptr++ = 0;
			}
			break;
		default:
			DWORD value = atol(str);
			int j = t > 4 ? 4 : 2;
			if ((unsigned)(p + j) > iter->size) {
				iter->size = p + j;
				iter->data = (char *)realloc(iter->data,iter->size);
				ptr = iter->data + p;
			}
			if (t == 3) *ptr++ = LOBYTE((WORD)value), *ptr = HIBYTE((WORD)value);
			else if (t == 4) *ptr++ = HIBYTE((WORD)value), *ptr = LOBYTE((WORD)value);
			else if (t == 5) *ptr++ = LOBYTE((WORD)LOWORD(value)), *ptr++ = HIBYTE((WORD)LOWORD(value)) ,
				*ptr++ = LOBYTE((WORD)HIWORD(value)), *ptr++ = HIBYTE((WORD)HIWORD(value));
			else *ptr++ = HIBYTE((WORD)HIWORD(value)), *ptr++ = LOBYTE((WORD)HIWORD(value)) , 
				*ptr++ = HIBYTE((WORD)LOWORD(value)), *ptr = LOBYTE((WORD)LOWORD(value));
	}
	lstrcpy(data,c_true);
	return 3;
}
com(resizeStruct) {
	char name[256], num[256];
	long newsize;
	if (tokenize(32,data,256,name,256,num,NULL) != 2) {
		lstrcpy(data,e_miss);
		return 3;
	}
	listc<nptr>::iterator iter;
	for (iter = strptr.begin();iter != strptr.end();iter++) {
		if (iter->name == name) {
			newsize = atol(num);
			if (newsize >= 0) {
				if (newsize != iter->size) {
					iter->data = (char *)realloc(iter->data,newsize);
					while (iter->size < (unsigned)newsize) iter->data[iter->size++] = 0;
				}
				else free(iter->data);
				iter->size = newsize;
				lstrcpy(data,c_true);
			}
			else lstrcpy(data,c_false);
			return 3;
		}
	}
	lstrcpy(data,c_false);
	return 3;
}
com(delStruct) {
	listc<nptr>::iterator iter = strptr.begin();
	while (iter != strptr.end()) {
		if (iter->name == data) {
			strptr.pop(iter);
			lstrcpy(data,c_true);
			return 3;
		}
		iter++;
	}
	lstrcpy(data,c_false);
	return 3;
}
com(getStruct) {
	char parm1[256], parm2[32];
	parm2[0] = 0;
	if (!tokenize(32,data,256,parm1,32,parm2,NULL)) {
		lstrcpy(data,c_false);
		return 3;
	}
	int a = atoi(parm1), total = strptr.size();
	listc<nptr>::iterator iter = strptr.begin();
	if (a == 0 && parm1[0] == '0') {
		bnultoa(total,data);
		return 3;
	}
	for (int z = 1;iter != strptr.end();iter++,z++) {
		if (z == a) {
			iter->name.c_str(data);
			return 3;
		}
	}
	data[0] = 0;
	return 3;
}
com(getStructInfo) {
	char name[256], type[32], pos[16], max[16];
	int parm, t, len = 0, p;
	if ((parm = tokenize(32,data,256,name,32,type,16,pos,16,max,NULL)) < 2) {
		lstrcpy(data,e_miss);
		return 3;
	}
	listc<nptr>::iterator iter = strptr.begin();
	while (iter != strptr.end()) {
		if (iter->name == name) goto next;
		iter++;
	}
no:
	lstrcpy(data,c_false);
	return 3;
next:
	if (!lstrcmpi(type,"size")) {
		bnultoa(iter->size,data);
		return 3;
	}
	else if (!lstrcmpi(type,"pointer")) {
		bnultoa((unsigned long)iter->data,data);
		return 3;
	}
	else if (!lstrcmpi(type,"str")) t = 1;
	else if (!lstrcmpi(type,"ustr")) t = 2;
	else if (!lstrcmpi(type,"word")) t = 3;
	else if (!lstrcmpi(type,"nword")) t = 4;
	else if (!lstrcmpi(type,"dword")) t = 5;
	else if (!lstrcmpi(type,"ndword")) t = 6;
	else if (!lstrcmpi(type,"asc")) t = 7;
	else goto no;
	if (!iter->size) {
		data[0] = 0;
		return 3;
	}
	if (parm < 3) p = 0;
	else {
		p = atol(pos);
		if (p < 0 || (unsigned)p >= iter->size) { data[0] = 0; return 3; }
	}
	if (parm < 4) len = iter->size - p;
	else {
		len = atol(max);
		if (len <= 0) { data[0] = 0; return 3; }
	}
	if (len > 900) len = 900; //limitation mIRC...
	char *ptr = iter->data + p, *lim_ptr = ptr + len, *max_ptr = iter->data + iter->size, *ndata;
	int inc, j;
	bool logical;
	unsigned char flang[4] = { (unsigned) p >= iter->size ? 0 : *ptr, (unsigned)p+1 >= iter->size ? 0 : *(ptr+1), (unsigned)p+2 >= iter->size ? 0 : *(ptr+2),
			(unsigned)(p+3) >= iter->size ? 0 : *(ptr+3) };
	//wsprintf(mData,"/echo 3 -s flang: %d %d %d %d",flang[0],flang[1],flang[2],flang[3]);
	//Signal;
	switch (t) {
		case 1: case 2:
			ndata = data;
			inc = t;
			while (*ptr && ptr < lim_ptr && ptr < max_ptr ) {
				*data++ = *ptr;
				ptr += inc;
			}
			*data = 0;
			data = ndata;
			return 3;
	case 7:
		j = 0;
		logical = false;
		data[0] = 0;
		while (ptr < max_ptr && ptr < lim_ptr && j < 890) {
			if (logical) { *data++ = 32; j++; }
			ndata = bnultoa((BYTE)*ptr++,data);
			j += (ndata - data);
			data = ndata;
			logical = true;
		}
		return 3;
	default:
		if (t == 6) bnultoa((flang[0] << 24) + (flang[1] << 16) + (flang[2] << 8)  + flang[3],data);
		else if (t == 4) bnultoa((flang[0] << 8) + flang[1],data);
		else if (t == 5) bnultoa(flang[0] + (flang[1] << 8) + (flang[2] << 16)  + (flang[3] << 24),data);
		else bnultoa(flang[0] + (flang[1] << 8),data);
	}
	return 3;
}
com(setArrow) {
	char parm1[512], parm2[128], header[32], dir[32]; dir[0] = 0;
	char t = 0; int pos = 0;
	if (tokenize(32,data,512,parm1,128,parm2,32,header,32,dir,NULL) < 3) {
		lstrcpy(data,e_miss);
		return 3;
	}
	wsprintf(mData,"$dialog(%s).hwnd",parm1);
	SendMessage(hmIRC,WM_MEVALUATE,0,0);
	HWND handle = (HWND)atol(mData);
	if (!IsWindow(handle)) {
		lstrcpy(data,c_false);
		return 3;
	}
	HWND res = GetDlgItem(handle,atoi(parm2) + 6000);
	if (!IsWindow(res)) {
		lstrcpy(data,c_false);
		return 3;
	}
	HWND report = FindWindowEx(res,NULL,"SysListView32",NULL);
	pos = atoi(header) - 1;
	if (!lstrcmpi(dir,"up")) t = 1;
	else if (!lstrcmpi(dir,"down")) t = 2;
	if (!report) lstrcpy(data,c_false);
	else {
		HWND hLVHeader = ListView_GetHeader(report);
		HDITEM hdi;
		hdi.mask = HDI_FORMAT;
		Header_GetItem(hLVHeader,pos,&hdi);
		hdi.fmt &= ~HDF_SORTUP & ~HDF_SORTDOWN;
		if (t) hdi.fmt |= t == 1 ? HDF_SORTUP : HDF_SORTDOWN;
		Header_SetItem(hLVHeader, pos, &hdi);
		lstrcpy(data,c_true);
	}
	//echo 4 $dll(cwnd.dll,findWindowEx,131746>>SysListView32)
	return 3;
}

com(getArrows) {
	char name[512], id[128];
	if (tokenize(32,data,512,name,128,id,NULL) < 2) {
		lstrcpy(data,e_miss);
	}
	else {
		wsprintf(mData,"$dialog(%s).hwnd",name);
		SendMessage(hmIRC,WM_MEVALUATE,0,0);
		HWND handle = (HWND)atol(mData);
		if (IsWindow((handle = GetDlgItem(handle,atoi(id) + 6000))) && (handle = FindWindowEx(handle,NULL,"SysListView32",NULL))) {
			HWND header = ListView_GetHeader(handle);
			int num = Header_GetItemCount(header), i = 0;
			if (num <= 0) { data[0] = 0; return 3; }
			HDITEM hdi;
			hdi.mask = HDI_FORMAT;
			while (i < num) {
				Header_GetItem(header,i++,&hdi);
				if (i) *data++ = 32;
				if (HDF_SORTDOWN & hdi.fmt) {
					lstrcpy(data,"down");
					data += 4;
				}
				else if (HDF_SORTUP & hdi.fmt) {
					lstrcpy(data,"up");
					data += 2;
				}
				else {
					lstrcpy(data,"normal");
					data += 6;
				}
			}
		}
		else lstrcpy(data,c_false);
	}
	return 3;
}
com(sort) {
	char parm1[512], parm2[128], header[32], type[32], alias[128]; alias[0] = 0;
	int pos = 0;
	if (tokenize(32,data,512,parm1,128,parm2,32,header,32,type,128,alias,NULL) < 4) {
		lstrcpy(data,e_miss);
		return 3;
	}
	wsprintf(mData,"$dialog(%s).hwnd",parm1);
	SendMessage(hmIRC,WM_MEVALUATE,0,0);
	HWND handle = (HWND)atol(mData);
	if (!IsWindow(handle)) {
		lstrcpy(data,c_false);
		return 3;
	}
	HWND res = GetDlgItem(handle,atoi(parm2) + 6000);
	if (!IsWindow(res)) {
		lstrcpy(data,c_false);
		return 3;
	}
	HWND report = FindWindowEx(res,NULL,"SysListView32",NULL);
	pos = atoi(header) - 1;
	lstrcpy(data,c_false);
	if (report) {
		if (alias[0]) {
			wsprintf(mData,"$isalias(%s)",alias);
			SendMessage(hmIRC,WM_MEVALUATE,0,0);
			if (mData[1] != 't') return 3;
		}
		if (pos > Header_GetItemCount(ListView_GetHeader(report)) || pos < 0) return 3;
		TSORT ts;
		ts.hListView = report;
		if (!lstrcmpi(type,"asc")) ts.sortType = 0;
		else if (!lstrcmpi(type,"desc")) ts.sortType = 1;
		else if (!lstrcmpi(type,"custom")) ts.sortType = 2;
		else if (!lstrcmpi(type,"asize")) ts.sortType = 3;
		else if (!lstrcmpi(type,"dsize")) ts.sortType = 4;
		else if (!lstrcmpi(type,"anum")) ts.sortType = 5;
		else if (!lstrcmpi(type,"dnum")) ts.sortType = 6;
		else return 3;
		ts.column = pos;
		if (alias[0]) ts.additional = alias;
		ListView_SortItemsEx(report, CompareStr, &ts);
		if (alias[0]) {
			lstrcpy(mData,"/unset %_012gr*");
			Signal;
		}
		lstrcpy(data,c_true);
	}
	return 3;
}
com(getSortedPos) {
	char parm1[512], parm2[128], header[32], type[32], alias[512], str[512], t; alias[0] = 0; str[0] = 0;
	int pos = 0;
	if ((tokenize(32,data,512,parm1,128,parm2,32,header,32,type,NULL) < 4)) {
mp:
		lstrcpy(data,e_miss);
		return 3;
	}
	if (!lstrcmpi(type,"custom")) {
		if (!gettok(data,5,32,alias)) goto mp;
		gettok(data,-6,32,str);
	}
	else gettok(data,-5,32,str);
	wsprintf(mData,"$dialog(%s).hwnd",parm1);
	SendMessage(hmIRC,WM_MEVALUATE,0,0);
	HWND handle = (HWND)atol(mData);
	if (!IsWindow(handle)) {
		lstrcpy(data,c_false);
		return 3;
	}
	HWND res = GetDlgItem(handle,atoi(parm2) + 6000);
	if (!IsWindow(res)) {
		lstrcpy(data,c_false);
		return 3;
	}
	HWND report = FindWindowEx(res,NULL,"SysListView32",NULL);
	pos = atoi(header) - 1;
	lstrcpy(data,c_false);
	if (report) {
		if (pos > Header_GetItemCount(ListView_GetHeader(report)) || pos < 0) return 3;
		if (!lstrcmpi(type,"asc")) t = 0;
		else if (!lstrcmpi(type,"desc")) t = 1;
		else if (!lstrcmpi(type,"custom")) t = 2;
		else if (!lstrcmpi(type,"asize")) t = 3;
		else if (!lstrcmpi(type,"dsize")) t = 4;
		else if (!lstrcmpi(type,"anum")) t = 5;
		else if (!lstrcmpi(type,"dnum")) t = 6;
		else return 3;
		if (t == 2) {
			wsprintf(mData,"$isalias(%s)",alias);
			SendMessage(hmIRC,WM_MEVALUATE,0,0);
			if (mData[1] != 't') return 3;
		}
		char buf[900];
		//ListView_GetItemText(report,i,pos,buf,900);
		bnultoa(_GetSortedPos(str,0,ListView_GetItemCount(report),report,pos,t,buf,alias),data);
	}
	return 3;
}
com(invalidateRect) {
	char hwnd[32], status[8], x[16], y[16], w[16], h[16]; x[0] = y[0] = w[0] = h[0] = 0;
	int res;
	if ((res = tokenize(32,data,32,hwnd,8,status,16,x,16,y,16,w,16,h)) < 2) {
		lstrcpy(data,e_miss);
		return 3;
	}
	RECT rc;
	SetRect(&rc,atoi(x),atoi(y),atoi(w),atoi(h));
	rc.bottom += rc.top;
	rc.right += rc.left;
	if (InvalidateRect((HWND)atol(hwnd),res > 2 ? &rc : NULL,status[0] == '1' ? TRUE : FALSE))
		lstrcpy(data,c_true);
	else lstrcpy(data,c_false);
	return 3;
}
com(setCursor) {
	char window[64], type[64], path[512]; path[0] = 0;
	if (tokenize(32,data,64,window,64,type,512,path,-1) <2) {
		lstrcpy(data,e_miss);
		return 3;
	}
	HCURSOR cursor = NULL;
	for (int i = 0;i < 14;i++) {
		if (!lstrcmpi(type,cursor_str[i])) {
			cursor = LoadCursor(NULL,cursor_num[i]);
			break;
		}
	}
	if (!lstrcmpi(type,"CUSTOM")) {
		if (!path[0]) {
			lstrcpy(data,e_miss);
			return 3;
		}
		cursor = LoadCursorFromFile(path);
	}
	if (!cursor) {
		lstrcpy(data,c_false);
		return 3;
	}
	SetClassLong((HWND)atol(window),GCL_HCURSOR,(LONG)cursor);
	lstrcpy(data,c_true);
	return 3;
}
com(getCursor) {
	if (!iswin(data)) data[0] = 0;
	else GetCursorName((HCURSOR)GetClassLong((HWND)atol(data),GCL_HCURSOR),data);
	return 3;
}
com(getCursorInfo) {
	char buf[32];
	CURSORINFO curinfo;
	curinfo.cbSize = sizeof(CURSORINFO);
	GetCursorInfo(&curinfo);
	GetCursorName(curinfo.hCursor,buf);
	wsprintf(data,"%d %s %d %d",curinfo.flags,buf,curinfo.ptScreenPos.x,curinfo.ptScreenPos.y);
	return 3;
}
com(showCursor) {
	ShowCursor(data[0] == '1' ? TRUE : FALSE);
	lstrcpy(data,c_true);
	return 3;
}
com(getForegroundWindow) {
	bnultoa((unsigned int)GetForegroundWindow(),data);
	return 3;
}
com(setLayer) {
	char hwnd[32], key[64], alpha[32], flags[256];
	if (tokenize(32,data,32,hwnd,64,key,32,alpha,256,flags,-1) != 4) {
		lstrcpy(data,e_miss);
		return 3;
	}
	HWND win = (HWND)atol(hwnd);
	COLORREF ckey = (COLORREF)atol(key);
	BYTE bAlpha = atoi(alpha);
	DWORD dFlags = 0;
	char buf[128];
	typedef BOOL (WINAPI *SLWA_FUNC)(HWND hWnd, COLORREF crKey, BYTE bAlpha, DWORD dwFlags);
	SLWA_FUNC MySetLayeredWindowAttributes;
	HMODULE hUser32 = GetModuleHandle("USER32.DLL");
	if (!hUser32) goto falso;
	MySetLayeredWindowAttributes = (SLWA_FUNC)GetProcAddress(hUser32, "SetLayeredWindowAttributes");
	if (!MySetLayeredWindowAttributes) goto falso;
	SetWindowLong(win,GWL_EXSTYLE,GetWindowLong(win, GWL_EXSTYLE) | WS_EX_LAYERED);
	for (int i = 1;gettok(flags,i,32,buf);i++) {
		if (!lstrcmpi(layered_str[0],buf)) dFlags |= layered_num[0];
		else if (!lstrcmpi(layered_str[1],buf)) dFlags |= layered_num[1];
	}
	if (bAlpha == 255 &&  (dFlags & layered_num[0]) != layered_num[0]) SetWindowLong(win,GWL_EXSTYLE,GetWindowLong(win, GWL_EXSTYLE) & ~WS_EX_LAYERED);
	if (MySetLayeredWindowAttributes(win,ckey,bAlpha,dFlags))
		lstrcpy(data,c_true);
	else {
falso:
		lstrcpy(data,c_false);
	}
	return 3;
}


com(version) {
	lstrcpy(data,"cwnd.dll v3.4 by Had`S - neowesker@gmail.com");
	return 3;
}