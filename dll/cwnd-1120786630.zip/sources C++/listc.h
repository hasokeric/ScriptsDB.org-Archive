template <class T> class node;
template <class T> class i_listc;

template <class T> class listc {
public:
	typedef i_listc<T> iterator; //Alias
	listc(void); //Constructeur
	listc(const listc<T> &); //Constructeur de copie
	~listc(); //Destructeur

	listc<T> &operator=(const listc<T> &); //Op�rateur d'affectation
	T &operator[](int);

	unsigned int size(void); //Nombre d'�l�ments de la liste
	void push_back(const T&); //Ajoute un �l�ment � la fin de la liste
	void push_front(const T&); //Ajoute un �l�ment au d�but de la liste
	void insert_after(const iterator &, const T&); //Insert un �l�ment apr�s l'�l�ment donn� via un it�rateur
	void insert_before(const iterator &, const T&); //Insert un �l�ment avant l'�l�ment donn� via un it�rateur
	void pop_back(void); //Supprime le dernier �l�ment de la liste
	void pop_front(void); //Supprime le premier �l�ment de la liste
	void pop(iterator &); //Supprime un �l�ment donn� via un it�rateur
	void clear(void); //Supprime tous les �l�ments de la liste
	iterator begin(void); 
	iterator end(void);
	iterator rbegin(void);
	iterator rend(void);
	iterator get(int);
private:
	node<T> *_head;
	node<T> *_queue;
	unsigned int _size;
	i_listc<T> _iter;
	void _New(const T &);
	void _Ins(node<T> *, bool, const T &);
	void _Del(node<T> *);
	friend i_listc<T>;
};
template <class T> class node {
private:
	T *data;
	node<T> *next;
	node<T> *prev;
	friend listc<T>;
	friend i_listc<T>;
};
template <class T> class i_listc {
public:
	i_listc(); //Contructeur
	T &operator *(void) const; //Op�rateur d'indexation
	T *operator ->(void) const;//Op�rateur de s�lection de membre
	i_listc<T> &operator = (i_listc<T> &);
	i_listc<T> &operator ++ (int); //iterator++
	i_listc<T> &operator ++ (void);//++iterator
	i_listc<T> &operator -- (int); //iterator--
	i_listc<T> &operator -- (void); //--iterator
	i_listc<T> &operator + (int);
	i_listc<T> &operator - (int);
	bool operator >(const i_listc<T> &);
	bool operator <(const i_listc<T> &);
	bool operator ==(const i_listc<T> &);
	bool operator !=(const i_listc<T> &);
private:
	node<T> *_element;
	listc<T> *_parent;
	bool end;
	bool rend;
	friend listc<T>;
};
template <class T> listc<T>::listc(void) {
	_head = _queue = NULL;
	_size = 0;
}
template <class T> listc<T>::listc(const listc<T> &source) {
	_head = _queue = NULL;
	_size = 0;
	node<T> *element = source._head;
	while (element != NULL) {
		push_back(*element->data);
		element = element->next;
	}
	_size = source._size;
}
template <class T> listc<T>::~listc(void) {
	for (node<T> *p = _head, *next = NULL;p != NULL;p = next) {
		next = p->next;
		delete p->data;
		delete p;
		//free(p->data);
		//free(p);
	}
}
template <class T> unsigned int listc<T>::size(void) {
	return _size;
}
template <class T> void listc<T>::_New(const T &data) {
	node<T> *element = new node<T>;
	element->data = new T;
	*element->data = data;
	element->next = element->prev = NULL;
	_head = _queue = element;
	_size = 1;
}
template <class T> void listc<T>::_Ins(node<T> *elm, bool dir, const T &data) {
	if (elm == NULL) return;
	node<T> *element = new node<T>, *ptr = NULL;
	element->data = new T;
	*element->data = data;
	element->prev = element->next =  NULL;
	if (dir == false) { //Before
		ptr = elm->prev;
		elm->prev = element;
		if (ptr != NULL) ptr->next = element;
		element->prev = ptr;
		element->next = elm;
		if (_head == elm) _head = element;
	}
	else { //After
		ptr = elm->next;
		elm->next = element;
		if (ptr != NULL) ptr->prev = element;
		element->next = ptr;
		element->prev = elm;
		if (_queue == elm) _queue = element;
	}
	_size++;
}

template <class T> void listc<T>::push_back(const T &data) {
	if (_size == 0) return _New(data);
	_Ins(_queue,1,data);
}
template <class T> void listc<T>::push_front(const T &data) {
	if (_size == 0) return _New(data);
	_Ins(_head,0,data);
}
template <class T> void listc<T>::insert_after(const iterator &iter, const T &data) {
	if (iter._parent == this) {
		_Ins(iter._element,1,data);
	}
}
template <class T> void listc<T>::insert_before(const iterator &iter, const T &data) {
	if (iter._parent == this) {
		_Ins(iter._element,0,data);
	}
}
template <class T> void listc<T>::pop_back(void) {
	if (_size == 0) return; 
	node<T> *element = _queue->prev;
	//free(_queue->data);
	//free(_queue);
	delete _queue->data;
	delete _queue;
	if (element != NULL) element->next = NULL;
	_queue = element;
	_size--;
}
template <class T> void listc<T>::pop_front(void) {
	if (_size == 0) return; 
	node<T> *element = _head->next;
	//free(_head->data);
	//free(_head);
	delete _head->data;
	delete _head;
	if (element != NULL) element->prev = NULL;
	_head = element;
	_size--;
}
template <class T> void listc<T>::pop(i_listc<T> &del) {
	if (del._parent != this) return;
	if (del == end()) return;
	if (del == begin()) {
		pop_front();
		return ;
	}
	if (del == rbegin()) {
		pop_back();
		return ;
	}
	node<T> *prev = del._element->prev, *next = del._element->next;
	delete del._element->data;
	delete del._element;
	//free(del._element->data);
	//free(del._element);
	if (prev->next != NULL) prev->next = next;
	if (next->prev != NULL) next->prev = prev;
	_size--;
}
template <class T> void listc<T>::clear(void) {
	for (node<T> *elm = _head , *next;elm != NULL;elm = next) {
		next = elm->next;
		delete elm->data;
		delete elm;
		//free(elm->data);
		//free(elm);
	}
	_head = _queue = NULL;
	_size = 0;
}
template <class T> listc<T> &listc<T>::operator =(const listc<T> &source) {
	if (this == &source) return *this;
	node<T> *element = _head, *s_element = source._head;
	while (s_element != NULL) {
		if (element != NULL) {
			*element->data = *s_element->data;
			element = element->next;
		}
		else {
			push_back(*s_element->data);
		}
		s_element = s_element->next;
	}
	i_listc<T> iter;
	while (element != NULL) {
		s_element = element->next; //s_element fait office de pointeur additionnel
		iter._element = element;
		iter._parent = this;
		iter.end = false;
		pop(iter);
		element = s_element;
	}
	_size = source._size;
	return *this;
}
template <class T> T &listc<T>::operator [](int n) {
	_iter = get(n);
	return *_iter;
}
template <class T> i_listc<T> listc<T>::begin(void) {
	_iter._element = _head;
	_iter._parent = this;
	_iter.end = _iter.rend =  _size == 0 ? true : false;
	return _iter;
}
template <class T> i_listc<T> listc<T>::rbegin(void) {
	_iter._element = _queue;
	_iter._parent = this;
	_iter.end = _iter.rend = _size == 0 ? true : false;
	return _iter;
}
template <class T> i_listc<T> listc<T>::end(void) {
	_iter._element = NULL;
	_iter._parent = this;
	_iter.end = true;
	_iter.rend = size == 0 ? true : false;
	return _iter;
}
template <class T> i_listc<T> listc<T>::rend(void) {
	_iter._element = NULL;
	_iter._parent = this;
	_iter.end = _size == 0 ? true : false;
	_iter.rend = true;
	return _iter;
}
template <class T> i_listc<T> listc<T>::get(int element) {
	if (_size == 0) return end();
	int n = 0;
	_iter._parent  = this;
	for (node<T> *p = _head;p != NULL;p = p->next,n++) {
		if (n == element) {
			_iter._element = p;
			_iter.end = false;
			break;
		}
	}
	if (!p) {
		_iter._element = NULL;
		_iter.end = true;
	}
	return _iter;
}
template <class T> i_listc<T>::i_listc() {
	end = true;
}
template <class T> i_listc<T> &i_listc<T>::operator=(i_listc<T> &source) {
	_element = source._element;
	end = source.end;
	rend = source.rend;
	_parent = source._parent;
	return *this;
}
template <class T> i_listc<T> &i_listc<T>::operator+(int n) {
	if (end == false && _parent != NULL && n < 1) return *this;
	int a = 0;
	_parent->_iter = *this;
	i_listc<T> *ptr = &_parent->_iter;
	ptr->_parent = _parent;
	do {
		ptr->_element = ptr->_element->next;
		ptr->end = ptr->_element == NULL ? true : false;
		++a;
	} while (ptr->end == false && a < n);
	return _parent->_iter;
}
template <class T> i_listc<T> &i_listc<T>::operator-(int n) {
	if (end == false && _parent != NULL && n < 1) return *this;
	int a = 0;
	_parent->_iter = *this;
	i_listc<T> *ptr = &_parent->_iter;
	ptr->_parent = _parent;
	do {
		ptr->_element = ptr->_element->prev;
		ptr->end = ptr->_element == NULL ? true : false;
		++a;
	} while (ptr->end == false && a < n);
	return _parent->_iter;
}
template <class T> T &i_listc<T>::operator *(void) const {
	return *_element->data;
}
template <class T> T *i_listc<T>::operator ->(void) const {
	return _element->data;
}
template <class T> bool i_listc<T>::operator==(const i_listc<T> &source) {
	if (end != source.end || _element != source._element || _parent != source._parent) return false;
	return true;
}
template <class T> bool i_listc<T>::operator !=(const i_listc<T> &source) {
	if (end == source.end && _element == source._element && _parent == source._parent) return false;
	return true;
}
template <class T> i_listc<T> &i_listc<T>::operator++(int) {
	if (end == true) return *this;
	_parent->_iter = *this;
	if (rend == true) {
		*this = _parent->begin();
		return _parent->_iter;
	}
	_element = _element->next;
	end = _element == NULL ? true : false;
	rend = _parent->_size == 0 ? true : false;
	return _parent->_iter;
}
template <class T> i_listc<T> &i_listc<T>::operator++(void) {
	if (end == true) return *this;
	if (rend == true) {
		*this = _parent->begin();
		return *this;
	}
	_element = _element->next;
	end = _element == NULL ? true : false;
	rend = _parent->_size == 0 ? true : false;
	return *this;
}
template <class T> i_listc<T> &i_listc<T>::operator--(int) {
	if (rend == true) return *this;
	_parent->_iter = *this;
	_element = _element->prev;
	end = _parent->_size == 0 ? true : false;
	rend = _element == NULL ? true : false;
	return _parent->_iter;
}
template <class T> i_listc<T> &i_listc<T>::operator--(void) {
	if (rend == true) return *this;
	_element = _element->prev;
	end = _parent->_size === 0 ? true : false;
	rend = _element == NULL ? true : false;
	return *this;
}
template <class T> bool i_listc<T>::operator <(const i_listc<T> &com) {
	node<T> *elm1 = _element, *elm2 = com._element;
	if (rend == true) {
		if (com.rend != true) return true;
		return false;
	}
	if (com.rend == true) return false;
	
	if (com.end == true) {
		if (end != true) return true;
		return false;
	}
	if (end == true) return false;

	while (elm2 != NULL) {
		if (elm2 == elm1) return false;
		elm2 = elm2->next;
	}
	return true;
}
template <class T> bool i_listc<T>::operator >(const i_listc<T> &com) {
	node<T> *elm1 = _element, *elm2 = com._element;
	if (com.rend == true) {
		if (rend != true) return true;
		return false;
	}
	if (rend == true) return false;
	
	if (end == true) {
		if (com.end != true) return true;
		return false;
	}
	if (com.end == true) return false;

	while (elm2 != NULL) {
		if (elm2 == elm1) return false;
		elm2 = elm2->prev;
	}
	return true;
}