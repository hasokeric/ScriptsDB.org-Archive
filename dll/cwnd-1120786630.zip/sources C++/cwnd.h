#define WIN32_LEAN_AND_MEAN
#define _WIN32_WINNT			0x501

#include <windows.h>
#include <commctrl.h>
#include <shellapi.h>
#include <tlhelp32.h>
#include <stdarg.h>
#include <malloc.h>
#include "listc.h"

#pragma warning(disable:4172)
#pragma warning(disable:4244)
#define com(bleh) extern "C" int __stdcall bleh(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
#define WM_MCOMMAND WM_USER + 200
#define WM_MEVALUATE WM_USER + 201
#define Signal SendMessage(hmIRC, WM_MCOMMAND,0,0)
#define EVENTS 33
#define INFERIOR -1
#define SUPERIOR 1
#define EQUAL 0

/*char cmd_find[512];*/
char alias[256], alias2[256];
const char ok[] = "+OK";
const char c_true[] = "$true";
const char c_false[] = "$false";
const char e_handle[] = "-ERR Invalid window";
const char e_miss[] = "-ERR  Insufficient parameters";
const char e_invp[] = "-ERR Invalid parameter";
const char e_aname[] = "-ERR Ths ident name is already existing";
const char e_awin[] = "-ERR Ths window name is already sublclassed";
const char *style_char[] = {"WS_OVERLAPPED","WS_POPUP","WS_CHILD",
"WS_MINIMIZE","WS_VISIBLE","WS_DISABLED","WS_CLIPSIBLINGS","WS_CLIPCHILDREN",
"WS_MAXIMIZE","WS_CAPTION","WS_BORDER","WS_DLGFRAME","WS_VSCROLL","WS_HSCROLL",
"WS_SYSMENU","WS_THICKFRAME","WS_GROUP","WS_TABSTOP","WS_MINIMIZEBOX","WS_MAXIMIZEBOX"};
const LONG style_num[] = {WS_OVERLAPPED,WS_POPUP,WS_CHILD,
WS_MINIMIZE,WS_VISIBLE,WS_DISABLED,WS_CLIPSIBLINGS,WS_CLIPCHILDREN,
WS_MAXIMIZE,WS_CAPTION,WS_BORDER,WS_DLGFRAME,WS_VSCROLL,WS_HSCROLL,
WS_SYSMENU,WS_THICKFRAME,WS_GROUP,WS_TABSTOP,WS_MINIMIZEBOX,WS_MAXIMIZEBOX};

const char *exstyle_char[] = {"WS_EX_DLGMODALFRAME","WS_EX_NOPARENTNOTIFY",
"WS_EX_TOPMOST","WS_EX_ACCEPTFILES","WS_EX_TRANSPARENT","WS_EX_MDICHILD",
"WS_EX_TOOLWINDOW","WS_EX_WINDOWEDGE","WS_EX_CLIENTEDGE","WS_EX_CONTEXTHELP",
"WS_EX_RIGHT","WS_EX_LEFT","WS_EX_RTLREADING","WS_EX_LTRREADING","WS_EX_LEFTSCROLLBAR",
"WS_EX_RIGHTSCROLLBAR","WS_EX_CONTROLPARENT","WS_EX_STATICEDGE","WS_EX_APPWINDOW"};

const LONG exstyle_num[] = {WS_EX_DLGMODALFRAME,WS_EX_NOPARENTNOTIFY,
WS_EX_TOPMOST,WS_EX_ACCEPTFILES,WS_EX_TRANSPARENT,WS_EX_MDICHILD,
WS_EX_TOOLWINDOW,WS_EX_WINDOWEDGE,WS_EX_CLIENTEDGE,WS_EX_CONTEXTHELP,
WS_EX_RIGHT,WS_EX_LEFT,WS_EX_RTLREADING,WS_EX_LTRREADING,WS_EX_LEFTSCROLLBAR,
WS_EX_RIGHTSCROLLBAR,WS_EX_CONTROLPARENT,WS_EX_STATICEDGE,WS_EX_APPWINDOW};

const char *show_char[] = {"HIDE","SHOWNORMAL","SHOWMINIMIZED","SHOWMAXIMIZED",
"SHOWNOACTIVATE","SHOW","MINIMIZE","SHOWMINNOACTIVE","SHOWNA","RESTORE",
"SHOWDEFAULT","FORCEMINIMIZE"};

char *event_char[] = {"MOUSEACTIVATE","MOUSEMOVE","LBUTTONDOWN","LBUTTONUP",
"LBUTTONDBLCLK","RBUTTONDOWN","RBUTTONUP","RBUTTONDBLCLK","MBUTTONDOWN","MBUTTONUP",
"MBUTTONDBLCLK","MOVE","MOVING","SIZE","SIZING","ACTIVATE","MDIACTIVATE",
"CHILDACTIVATE","SHOWWINDOW","COMMAND","HELP","CLOSE","DESTROY","DISPLAYCHANGE",
"POWERBROADCAST","ENDSESSION","CHAR","HSCROLL","VSCROLL","ENTERSIZEMOVE","EXITSIZEMOVE","PARENTNOTIFY","CREATE"};

UINT event_num[] = {WM_MOUSEACTIVATE,WM_MOUSEMOVE,WM_LBUTTONDOWN,WM_LBUTTONUP,
WM_LBUTTONDBLCLK,WM_RBUTTONDOWN,WM_RBUTTONUP,WM_RBUTTONDBLCLK,WM_MBUTTONDOWN,WM_MBUTTONUP,
WM_MBUTTONDBLCLK,WM_MOVE,WM_MOVING,WM_SIZE,WM_SIZING,WM_ACTIVATE,WM_MDIACTIVATE,
WM_CHILDACTIVATE,WM_SHOWWINDOW,WM_COMMAND,WM_HELP,WM_CLOSE,WM_DESTROY,WM_DISPLAYCHANGE,
WM_POWERBROADCAST,WM_ENDSESSION,WM_CHAR,WM_HSCROLL,WM_VSCROLL,WM_ENTERSIZEMOVE,WM_EXITSIZEMOVE,WM_PARENTNOTIFY,WM_CREATE};

const char* SIZE_char[] = {"MAXHIDE","MAXIMIZED","MAXSHOW","MINIMIZED","RESTORED"};
const WPARAM SIZE_num[] = {SIZE_MAXHIDE,SIZE_MAXIMIZED,SIZE_MAXSHOW,
SIZE_MINIMIZED,SIZE_RESTORED};

const char* SHOWWINDOW_char[] = {"OTHERUNZOOM","OTHERZOOM",
"PARENTCLOSING","PARENTOPENING"};
const int SHOWWINDOW_num[] = {SW_OTHERUNZOOM,SW_OTHERZOOM,
SW_PARENTCLOSING,SW_PARENTOPENING};

const char* power_char[] = {"BATTERYLOW","OEMEVENT","POWERSTATUSCHANGE","QUERYSUSPEND",
"QUERYSUSPENDFAILED","RESUMEAUTOMATIC","RESUMECRITICAL","RESUMESUSPEND","SUSPEND"};

const char* hscroll[] = {"ENDSCROLL","LEFT","RIGHT","LINELEFT",
"LINERIGHT","PAGELEFT","PAGERIGHT","THUMBPOSITION","THUMBTRACK"};
const char* vscroll[] = {"BOTTOM","ENDSCROLL","LINEDOWN","LINEUP","PAGEDOWN","PAGEUP",
"THUMBPOSITION","THUMBTRACK","STOP"};

const char*  swinpos_char[] = {"DRAWFRAME","FRAMECHANGED","HIDEWINDOW","NOACTIVATE",
"NOCOPYBITS","NOMOVE","NOREDRAW","NOSENDCHANGING","NOSIZE","SHOWWINDOW","NOZORDER"};
UINT swinpos_num[] = {SWP_DRAWFRAME,SWP_FRAMECHANGED,SWP_HIDEWINDOW,SWP_NOACTIVATE,
SWP_NOCOPYBITS,SWP_NOMOVE,SWP_NOREDRAW,SWP_NOSENDCHANGING,SWP_NOSIZE,SWP_SHOWWINDOW,SWP_NOZORDER};
const char* subinfo[] = {"noclose","handle","command","mark"};

const char *ancestor_str[] = {"PARENT","ROOT","ROOTOWNER"};
UINT ancestor_num[] = {GA_PARENT,GA_ROOT,GA_ROOTOWNER};

const char *icon_size[] = {"small","large"};

const char *layered_str[] = {"COLORKEY","ALPHA"};
UINT layered_num[] = {LWA_COLORKEY,LWA_ALPHA};

const char *cursor_str[] = {"ARROW","IBEAM","WAIT","CROSS","UPARROW","SIZENWSE",
"SIZENESW","SIZEWE","SIZENS","SIZEALL","NO","HAND","APPSTARTING","HELP"}; 
LPSTR cursor_num[] = {IDC_ARROW,IDC_IBEAM,IDC_WAIT,IDC_CROSS,IDC_UPARROW,IDC_SIZENWSE,
IDC_SIZENESW,IDC_SIZEWE,IDC_SIZENS,IDC_SIZEALL,IDC_NO,IDC_HAND,IDC_APPSTARTING,IDC_HELP};

struct SWP {
	HWND hWnd;
	HWND hWndInsertAfter;
	int X;
	int Y;
	int cx;
	int cy;
	UINT uFlags;
};

struct xProc {
	UINT msg;
	LPARAM lParam;
	WPARAM wParam;
};
class str {
	char *data;
	unsigned int size;
public:
	str();
	~str();
	str(void *); //pour les conversions
	str &operator =(const str &);
	str &operator =(const char *);
	bool operator ==(const str &) const;
	bool operator ==(const char *) const;
	char *c_str(char *);
	const char *string();
};
str::str(void *source) {
	size = 1;
	data = (char *)malloc(1);
	data[0] = 0;
	if (source != NULL) *this = (const char *)source;
}
str::str() { 
	size = 1;
	data = (char *)malloc(1);
	data[0] = 0;
}
str::~str() { free(data); }
str & str::operator =(const str &ref) {
	if (&ref != this) {
		if (size != ref.size) {
			size = ref.size;
			data = (char *)realloc(data,size);
		}
		size--;
		for (unsigned int i = 0;i < size;i++) data[i] = ref.data[i];
		data[i] = 0;
		size++;
	}
	return *this;
}
str & str::operator =(const char *string) {
	if (string == NULL) {
		if (size != 1) {
			size = 1;
			data = (char *)realloc(data,1);
			data[0] = 0;
		}
		return *this;
	}
	int imax = lstrlen(string) + 1;
	if (size != imax) {
		size = imax;
		data = (char *)realloc(data,size);
	}
	int i = 0;
	imax--;
	while (i < imax) data[i++] = *string++;
	data[i] = 0;
	return *this;
}
bool str::operator ==(const str &ref) const {
	if (!lstrcmpi(data,ref.data)) return 1;
	return 0;
}
bool str::operator ==(const char *string) const {
	if (!lstrcmpi(data,string)) return 1;
	return 0;
}
char *str::c_str(char *source) {
	lstrcpy(source,data);
	return source;
}
const char *str::string() {
	return data;
}
class defer {
public:
	defer() { ; }
	~defer() { ; }
	defer(void *source) {
		if (source == NULL) string = NULL, hdwp = NULL;
	}
	str string;
	HDWP hdwp;
};
class cust {
public:
	cust();
	cust(void *); //pour les conversions
	str data;
	UINT msg;
	bool wptr;
	bool lptr;
};
cust::cust() { msg = 0; wptr = lptr = false; }
cust::cust(void *source) {
	if (source == NULL) {
		data = NULL;
		msg = 0;
		wptr = lptr = false;
	}
}
class wproc
{ 
public:
	char *name;
	char *command;
	char *mark;
	HWND win;
	WNDPROC proc;
	BOOL events[EVENTS];
	BOOL send[EVENTS];
	BOOL cancel;
	listc<char>custom;
	wproc();
	wproc(const wproc &ref);
	~wproc();
	wproc &operator=(const wproc &ref);
} ;
struct mem {
	HWND hwnd;
	listc<wproc>::iterator cur;
} last;
class nptr {
public:
	char *data;
	str name;
	size_t size;
	nptr();
	nptr(void *);
	~nptr();
};
nptr::nptr() { data = NULL; size = 0; }
nptr::~nptr() { 
	if (size) free(data);
}
nptr::nptr(void *ptr) {
	if (ptr == NULL) {
		data = NULL;
	}
}	
listc<wproc>_list;
listc<defer>dwp;
listc<nptr>strptr;
listc<cust>messages;

long totMsg;

HANDLE hFileMap;
//HANDLE findfiles;
HWND hmIRC;
LPSTR mData;
HINSTANCE hInstance;
bool ff;
bool _sub;
char *_path;
char *_mask;
char *_alias;
wproc::wproc() {
	name = command = mark = NULL;
	cancel = 0; 
	for (int i = 0;i < EVENTS;i++) events[i] = 0, send[i] = 1;
}
wproc::wproc(const wproc &ref) {
	cancel = 0; 
	int i;
	for (i = 0;i < EVENTS;i++) {
		events[i] = ref.events[i];
		send[i] = ref.send[i];
	}
	cancel = ref.cancel;
	proc = ref.proc;
	win = ref.win;
	custom = ref.custom;
	if (ref.name != NULL) {
		name = (char *)malloc(lstrlen(ref.name) + 1);
		command = (char *)malloc(lstrlen(ref.command) + 1);
		lstrcpy(name,ref.name), lstrcpy(command,ref.command);
	}
	else name = command = NULL;
	if (ref.mark != NULL) {
		mark = (char *)malloc(lstrlen(mark) + 1);
		lstrcpy(mark,ref.mark);
	}
	else mark = NULL;
}
wproc &wproc::operator =(const wproc &ref) {
	int i;
	for (i = 0;i < EVENTS;i++) {
		events[i] = ref.events[i];
		send[i] = ref.send[i];
	}
	cancel = ref.cancel;
	proc = ref.proc;
	win = ref.win;
	custom = ref.custom;
	if (name != NULL) {
		free(name);
		free(command);
	}
	if (mark != NULL) free(mark);
	if (ref.name != NULL) {
		name = (char *)malloc(lstrlen(ref.name) + 1);
		command = (char *)malloc(lstrlen(ref.command) + 1);
		lstrcpy(name,ref.name), lstrcpy(command,ref.command);
	}
	else name = command = NULL;
	if (ref.mark != NULL) {
		mark = (char *)malloc(lstrlen(mark) + 1);
		lstrcpy(mark,ref.mark);
	}
	else mark = NULL;
	return *this;
}
wproc::~wproc() {
	cancel = 0;
	if (name != NULL) {
		free(name);
		free(command);
	}
	if (mark != NULL) free(mark);
}
typedef struct mIRC {
    DWORD  mVersion;
    HWND   mHwnd;
    BOOL   mKeep;
  } LOADINFO;
struct ff {
	char drive[MAX_PATH];
	char mask[1024];
	bool sub;
} scan;

__declspec(naked) char* __fastcall bnultoa(unsigned int dwnum, char* szdst) 
{ 
  __asm {
    or       ecx, ecx
    jnz      short L1
    lea      eax, [edx+1]
    mov      byte ptr[edx], 48
    mov      byte ptr[eax], cl
    ret      0
 L1:
    mov      [esp-4], edi
    mov      [esp-8], edx
    mov      edi, edx
 L2:
    mov      eax, -858993459
    mul      ecx
    mov      eax, edx
    shr      eax, 3
    mov      edx, ecx
    lea      ecx, [eax+eax*8]
    add      ecx, eax
    sub      edx, ecx
    add      dl, 48
    mov      [edi], dl
    mov      ecx, eax
    inc      edi
    test     eax, eax
    jnz      short L2
    mov      byte ptr[edi], al
    mov      [esp-12], edi
    mov      eax, [esp-8]
 L3:
    dec      edi
    mov      dl, [eax]
    mov      cl, [edi]
    mov      [edi], dl
    mov      [eax], cl
    inc      eax
    cmp      eax, edi
    jb       short L3
    mov      eax, [esp-12]
    mov      edi, [esp-4]
    ret      0
  }
}
int atoi(const char *c)
{
	int a; bool neg = false;
	if (*c == 45) {
		c++;
		neg = true;
	}
	a = 0;
	//comme dans n'importe quel version du code ASCII 0 < 9, nous pouvons
	//alors convertir simplement un char en int en s'appuyant sur une multiplication par 10
	while (*c == 32 || (*c > 47 && *c < 58)) {
		if (*c == 32) c++;
		else a = a * 10 + *c++ - 48;
	}
	return neg ? -a : a;
}
__int64 atoi64(const char *c) 
{
	__int64 a; bool neg = false;
	if (*c == 45) {
		c++;
		neg = true;
	}
	a = 0;
	//comme dans n'importe quel version du code ASCII 0 < 9, nous pouvons
	//alors convertir simplement un char en int en s'appuyant sur une multiplication par 10
	while (*c == 32 || (*c > 47 && *c < 58)) {
		if (*c == 32) c++;
		else a = a * 10 + *c++ - 48;
	}
	return neg ? -a : a;
}

long atol(const char *c)
{
	long a; bool neg = false;
	if (*c == 45) {
		c++;
		neg = true;
	}
	a = 0;
	while (*c == 32 || (*c > 47 && *c < 58)) {
		if (*c == 32) c++;
		else a = a * 10 + *c++ - 48;
	}
	return neg ? -a : a;
}
void AdjustRectCoords(HWND hParent,LPRECT rect)
{
	POINT P, D;
	P.x = rect->left, P.y = rect->top;
	D.x = rect->right, D.y = rect->bottom;
	ScreenToClient(hParent,&P);
	ScreenToClient(hParent,&D);
	rect->left = P.x, rect->top = P.y;
	rect->right = D.x, rect->bottom = D.y;
}
void GetWindowCoords(HWND hParent, HWND hwin,LPRECT rect)
{ //plus pr�cis que GetClientRect()...
	GetWindowRect(hwin,rect);
	AdjustRectCoords(hParent,rect);
}
BOOL iswin(const char *c) {
	return IsWindow((HWND)atol(c));
}
void fzero(LPRECT r) {
	r->left = 0;
	r->top = 0;
	r->right = 0;
	r->bottom = 0;
}
//Fonction permettant d'enlever les caract�res en trop dans un motif "tokeniz�"
char *stripex(char *subject,char ex,char tok) {
	char *c = subject, *ref = NULL ,*in; int i = 0; bool stat = false;
	while (*c) {
		if (*c == ex) {
			if (!ref) ref = c;
		}
		else if (*c == tok)	{
			if (ref) {
				for (i = 0, in = c;*c;i++) *ref++ = *c++; 
				*ref = 0;
				c -= i + (c - ref);
			}
			ref = NULL;
			stat = true;
		}
		else {
			if (ref && stat) {
				for (i = 0, in = c;*c;i++) *ref++ = *c++;
				*ref = 0;
				c -= i + (c - ref);
			}	
			ref = NULL;
			stat = false;
		}
		c++;
	}
	return subject;
}
char *gettok(char *subject, int num, char sep, char *dszt) {
	if (!subject) return NULL;
    char *c, *d , *e; /*deux pointeurs sur subject +1 en offset*/
    int i = 0; bool cont;
    if (num < 0) { cont = true; num *= -1; } /*si num est n�gatif*/
    else    cont = false;
    c = d = subject;
    /*si il y en a, on pase les s�parateurs du d�but, afin de
    ne pas retourner un token vide */
    while (*c == sep) c++; d = c;
    //tant que le chaine n'est pas parcourue enti�rement par c..
    while (*c) {
        //si on rencontre le caract�re de s�paration...
        if (*c == sep) {
                i++;
                if (i == num) {
					e = d;
                    if (!cont) while (d < c) *dszt++ = *d++;
                    else while (*d) *dszt++ = *d++;
                    *dszt = 0;
                    //retourne l'offset du token
                    return e;
                }
                //comme d = c, on incr�mente of de r qu'on remet � 0
                while (*c == sep) c++; d = c;
        }
        else c++; 
    }
    //c arriv� � la fin de la cha�ne, on v�rifie si il reste un token...
    if (d < c) { 
        i++;
        if (i == num) {
			e = d;
            while (*d)  *dszt++ = *d++;
            *dszt = 0;
            return e;
        }
    }
    //le token recherch� n'existe pas, on retourne -1
    return NULL;
}
char *gettokp(char *subject, int num, int sep, char *dszt) {
	if (!subject) return NULL;
    char *c, *d , *e; /*deux pointeurs sur subject +1 en offset*/
    int i = 0; bool cont;
    if (num < 0) { cont = true; num *= -1; } /*si num est n�gatif*/
    else    cont = false;
    c = d = subject;
    /*si il y en a, on pase les s�parateurs du d�but, afin de
    ne pas retourner un token vide */
    //tant que le chaine n'est pas parcourue enti�rement par c..
    while (*c) {
        //si on rencontre le caract�re de s�paration...
        if (*c == sep) {
                i++;
                if (i == num) {
					if (c == d) return d;
					e = d;
                    if (!cont) while (d < c) *dszt++ = *d++;
                    else while (*d) *dszt++ = *d++;
                    *dszt = 0;
                    //retourne l'offset du token
                    return e;
                }
                //comme d = c, on incr�mente of de r qu'on remet � 0
                c++; d = c;
        }
        else c++; 
    }
    //c arriv� � la fin de la cha�ne, on v�rifie si il reste un token...
    if (d < c) { 
        i++;
        if (i == num) {
			e = d;
            while (*d)  *dszt++ = *d++;
            *dszt = 0;
            return e;
        }
    }
    //le token recherch� n'existe pas, on retourne -1
    return NULL;
}
/*int tokenize(char sep, char *subject, char *str1, ...) {
	int ret = 0, i = 0;
	char *str = str1 ,*old;
	va_list token;
	va_start(token,str1);
	do {
		while (*subject == sep) subject++;
		if (!*subject) return ret;
		while (*subject != sep && *subject != NULL) *str++ = *subject++;
		*str = 0;
		old = str;
		ret++;
		str = (char *)va_arg(token,char *);
	} while (str != NULL && (int)str != -1);
	if ((int)str == -1 && *subject) { while (*subject) *old++ = *subject++; *old = 0;}
	va_end(token);
	return ret;
}*/
int tokenize(char sep, char *subject, int str1, ...) {
	int ret = 0, i = 0, size = 0, old;
	char *str = (char *)str1;
	size = str1;
	va_list token;
	va_start(token,str1);
	do {
		i = 0;
		size--;
		str = (char *)va_arg(token,char *);
		while (*subject == sep) subject++;
		if (!*subject) return ret;
		while (*subject != sep && *subject != NULL) {
			if (i <  size) { *str++ = *subject; i++; }
			subject++;
		}
		*str = 0;
		old = size;
		ret++;
		size = (int)va_arg(token,int);
		
	} while (size > 0);
	if (size == -1 && *subject) { 
		while (*subject) {
			if (i < old) { *str++ = *subject; i++; }
			subject++;
		}
		*str = 0;
	}
	va_end(token);
	return ret;
}

bool NameProcessId(HWND hwnd, char* out)
{
	DWORD PID; GetWindowThreadProcessId(hwnd,&PID);
	PROCESSENTRY32 Proc; HANDLE Snap;
	if (!(Snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0))) return false;
	Proc.dwSize = sizeof(PROCESSENTRY32);
	if (!Process32First(Snap,&Proc)) {
		CloseHandle(Snap);
		return false;
	}
	if (Proc.th32ProcessID == PID) {
		lstrcpy(out,Proc.szExeFile);
		CloseHandle(Snap);
		return true;
	}
	while (Process32Next(Snap,&Proc)) {
		if (Proc.th32ProcessID == PID) {
			lstrcpy(out,Proc.szExeFile);
			CloseHandle(Snap);
			return true;
		}
	}
	CloseHandle(Snap);
	return false;
}
LONG s_style(char *c) {
	int i = 0;
	while (i < 20) {
		if (!lstrcmpi(style_char[i],c)) return style_num[i];
		i++;
	}
	return NULL;
}
LONG s_exstyle(char *c) {
	int i = 0;
	while (i < 19) {
		if (!lstrcmpi(exstyle_char[i],c)) return exstyle_num[i];
		i++;
	}
	return NULL;
}
void SendEnum(HWND hwnd) {
	char hn[24], wint[256], classt[256] , id[32];
	GetWindowText(hwnd,wint,256); GetClassName(hwnd,classt,256);
	DWORD ID = 0;
	GetWindowThreadProcessId(hwnd,&ID);
	bnultoa((unsigned int)ID,id);
	bnultoa((unsigned int)hwnd,hn);
	wsprintf(mData,"/%s %s\t\"%s\"\t%s\t%s\t%d\t%u",alias,hn,wint,classt,id,IsWindowVisible(hwnd) ? 1 : 0,(long)GetParent(hwnd));
	Signal;
}
void SendEnum2(HWND hwnd) {
	char hn[24], wint[256], classt[256] , id[32];
	GetWindowText(hwnd,wint,256); GetClassName(hwnd,classt,256);
	DWORD ID = 0;
	GetWindowThreadProcessId(hwnd,&ID);
	bnultoa((unsigned int)ID,id);
	bnultoa((unsigned int)hwnd,hn);
	wsprintf(mData,"/%s %s\t\"%s\"\t%s\t%s\t%d\t%u",alias2,hn,wint,classt,id,IsWindowVisible(hwnd) ? 1 : 0,(long)GetParent(hwnd));
	Signal;
}
BOOL CALLBACK EnumChildProc(HWND hwnd,LPARAM lParam) {
	SendEnum2(hwnd);
	return 1;
}
BOOL CALLBACK Enum2(HWND hwnd,LPARAM lParam) {
	SendEnum(hwnd);
	return 1;
}
BOOL CALLBACK Enum(HWND hwnd,LPARAM lParam) {
	SendEnum(hwnd);
	EnumChildWindows(hwnd,Enum2,0);
	return 1;
}
int wild_match(const char *wildcard, const char *string) {
    const char *c, *d; /*deux pointeurs qui serviront en cas d'�chec de matching*/
    while (*wildcard != 42 && *wildcard != 0) {
        if (!*string) return 0; /*string est nulle et wildcard ne l'est pas on retourne 0*/
        /*si le caract�re *string est le m�me que *wildcard ou si *wildcard est
        un point d'interrogation (?=n'importe quel caract�re)...*/
        if ((*string == *wildcard) || (*wildcard == 63)) { string++; wildcard++; }
        else return 0;
    }
    //si il reste des caract�res � v�rifier dans string et que il n'y en a plus aucun dans  wildcard..
    if (*string && !*wildcard) return 0;
    while (*wildcard == 42) wildcard++; /*pour permettre de passer les * en trop (**,***,etc.)*/
    if (!*wildcard) return 1; /*le dernier caract�re du wildcard est un * et comme les caract�res d'avant on �t� v�rifi�s
                                le wildcard valide donc la cha�ne*/
    /*d�but du motif, on configure les pointeurs*/
    c = wildcard; d = string;
    while (*string) {
        if (*wildcard == 42) {
            while (*wildcard == 42) wildcard++; /*pour permettre de passer les * en trop (**,***,etc.)*/
            if (!*wildcard) return 1;
            /*d�but du motif, on configure les pointeurs*/
            c = wildcard; d = string;
        }
        else if ((*string == *wildcard) || (*wildcard == 63)) { string++; wildcard++; }
        /*en cas d'�chec du matching du motif , on remettra wildcard � sa position de d�part (d�but du motif)
        ainsi que string, qu'on avancera de 1 afin de tester toutes les combinaisons*/
        else { string = ++d; wildcard = c; }
    }
    while (*wildcard == 42) wildcard++;
    if (!*wildcard) return 1; 
    /* si wildcard contient un caract�re autre que * et '\0', il ne v�rifie donc pas la cha�ne*/
    return 0;
}
char *pstrcpy(char *subject,const char *source,char C) {
	if (!*source) return NULL;
	while (*source) *subject++ = *source++;
	if (C) *subject++ = C;
	return subject;
}
char* lower(char *c) { //� l'ancienne ;p 
	char *d = c;
	while (*c) {
		switch(*c) {
		case 'A': *c = 'a'; break;
		case 'B': *c = 'b'; break;
		case 'C': *c = 'c'; break;
		case 'D': *c = 'd'; break;
		case 'E': *c = 'e'; break;
		case 'F': *c = 'f'; break;
		case 'G': *c = 'g'; break;
		case 'H': *c = 'h'; break;
		case 'I': *c = 'i'; break;
		case 'J': *c = 'j'; break;
		case 'K': *c = 'k'; break;
		case 'L': *c = 'l'; break;
		case 'M': *c = 'm'; break;
		case 'N': *c = 'n'; break;
		case 'O': *c = 'o'; break;
		case 'P': *c = 'p'; break;
		case 'Q': *c = 'q'; break;
		case 'R': *c = 'r'; break;
		case 'S': *c = 's'; break;
		case 'T': *c = 't'; break;
		case 'U': *c = 'u'; break;
		case 'V': *c = 'v'; break;
		case 'W': *c = 'w'; break;
		case 'X': *c = 'x'; break;
		case 'Y': *c = 'y'; break;
		case 'Z': *c = 'z'; break;
		}
		c++;
	}
	return d;
}
LRESULT CALLBACK CustomProc(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam);

BOOL CALLBACK EnumShowChilds(HWND hwnd,LPARAM lParam) {
	UINT Flags = SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER;
	Flags |= lParam == 1 ? SWP_SHOWWINDOW : SWP_HIDEWINDOW;
	return SetWindowPos(hwnd,NULL,0,0,0,0,Flags);
}
BOOL ShowChilds(HWND hWnd, BOOL fShow) {
	return EnumChildWindows(hWnd, EnumShowChilds,fShow);
}
void Del(listc<wproc>::iterator iter,bool proc) {
	char name[512]; lstrcpy(name,iter->name);
	wsprintf(mData,"%s %s EndSubclassing",iter->command,iter->name);
	if (proc) SetWindowLong(iter->win,GWL_WNDPROC,(LONG)iter->proc);
	_list.pop(iter);
	//list.Delete(iter);
	Signal;
}
listc<wproc>::iterator Search(char *c) {
	listc<wproc>::iterator iter;
	iter = _list.begin();
	while (iter != _list.end()) {
		if (!lstrcmpi(iter->name,c)) return iter;
		iter++;
	}
	return _list.end();
} 

listc<wproc>::iterator Search(HWND hsearch)
{
	listc<wproc>::iterator iter;
	iter = _list.begin();
	while (iter != _list.end()) {
		if (iter->win == hsearch) return iter;
		iter++;
	}
	return _list.end();
} 
listc<wproc>::iterator iNULL(void) {
	return _list.end();
}
LRESULT CALLBACK CustomProc(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	wproc *elm = NULL;
	listc<wproc>::iterator iter;
	if (last.hwnd == hwnd) iter = last.cur;
	else {
		iter = _list.begin();
		while (iter != _list.end() && iter->win != hwnd) iter++;
		if (iter == _list.end()) return 1; 
		last.cur = iter, last.hwnd = hwnd;
	}
	WNDPROC tmp = iter->proc;
	char o, c[24]; c[0] = 0;
	RECT *r;
	int i;
	HELPINFO *lphi;
	switch (uMsg) {
	case WM_MOUSEACTIVATE:
		if (iter->send[0]) {
			wsprintf(mData,"%s %s %s %d %d",iter->command,iter->name,event_char[0],wParam,lParam);
			Signal;
		}
		if (iter->events[0]) return 1;
		break;
	case WM_MOUSEMOVE:
		if (iter->send[1]) {
			wsprintf(mData,"%s %s %s %d %d %d %d",iter->command,iter->name,event_char[1],LOWORD(lParam),HIWORD(lParam),wParam,lParam);
			Signal;
		}
		if (iter->events[1]) return 1;
		break;
	case WM_LBUTTONDOWN:
		if (iter->send[2]) {
			wsprintf(mData,"%s %s %s %d %d %d %d",iter->command,iter->name,event_char[2],LOWORD(lParam),HIWORD(lParam),wParam,lParam );
			Signal;
		}
		if (iter->events[2]) return 1;
		break;
	case WM_LBUTTONUP:
		if (iter->send[3]) {
			wsprintf(mData,"%s %s %s %d %d %d %d",iter->command,iter->name,event_char[3],LOWORD(lParam),HIWORD(lParam),wParam,lParam );
			Signal;
		}
		if (iter->events[3]) return 1;
		break;
	case WM_LBUTTONDBLCLK:
		if (iter->send[4]) {
			wsprintf(mData,"%s %s %s %d %d %d %d",iter->command,iter->name,event_char[4],LOWORD(lParam),HIWORD(lParam),wParam,lParam );
			Signal;
		}
		if (iter->events[4]) return 1;
		break;
	case WM_RBUTTONDOWN:
		if (iter->send[5]) {
			wsprintf(mData,"%s %s %s %d %d %d %d",iter->command,iter->name,event_char[5],LOWORD(lParam),HIWORD(lParam),wParam,lParam );
			Signal;
		}
		if (iter->events[5]) return 1;
		break;
	case WM_RBUTTONUP:
		if (iter->send[6]) {
			wsprintf(mData,"%s %s %s %d %d %d %d",iter->command,iter->name,event_char[6],LOWORD(lParam),HIWORD(lParam),wParam,lParam );
			Signal;
		}
		if (iter->events[6]) return 1;
		break;
	case WM_RBUTTONDBLCLK:
		if (iter->send[7]) {
			wsprintf(mData,"%s %s %s %d %d %d %d",iter->command,iter->name,event_char[7],LOWORD(lParam),HIWORD(lParam),wParam,lParam );
			Signal;
		}
		if (iter->events[7]) return 1;
		break;
	case WM_MBUTTONDOWN:
		if (iter->send[8]) {
			wsprintf(mData,"%s %s %s %d %d %d %d",iter->command,iter->name,event_char[8],LOWORD(lParam),HIWORD(lParam),wParam,lParam );
			Signal;
		}
		if (iter->events[8]) return 1;
		break;
	case WM_MBUTTONUP:
		if (iter->send[9]) {
			wsprintf(mData,"%s %s %s %d %d %d %d",iter->command,iter->name,event_char[9],LOWORD(lParam),HIWORD(lParam),wParam,lParam );
			Signal;
		}
		if (iter->events[9]) return 1;
		break;
	case WM_MBUTTONDBLCLK:
		if (iter->send[10]) {
			wsprintf(mData,"%s %s %s %d %d %d %d",iter->command,iter->name,event_char[10],LOWORD(lParam),HIWORD(lParam),wParam,lParam);
			Signal;
		}
		if (iter->events[10]) return 1;
		break;
	case WM_MOVE:
		if (iter->send[11]) {
			wsprintf(mData,"%s %s %s %d %d %d %d",iter->command,iter->name,event_char[11],LOWORD(lParam),HIWORD(lParam),wParam,lParam );
			Signal;
		}
		if (iter->events[11]) return 1;
		break;
	case WM_MOVING:
		if (iter->send[12]) {
			r = (LPRECT)lParam;
			wsprintf(mData,"%s %s %s %d %d %d %d %d %d",iter->command,iter->name,event_char[12],r->left,r->top,r->right,r->bottom,wParam,lParam);
			Signal;
		}
		if (iter->events[12]) return 1;
		break;
	case WM_SIZE:
		if (iter->send[13]) {
			for (i = 0;i < 5;i++) if (SIZE_num[i] == wParam) {
				int o = 0;
				while (SIZE_char[i][o]) c[o] = SIZE_char[i][o++];
				c[o] = 0;
				break;
			}
			wsprintf(mData,"%s %s %s %d %d %s %d %d",iter->command,iter->name,event_char[13],LOWORD(lParam),HIWORD(lParam),c,wParam,lParam);
			Signal;
		}
		if (iter->events[13]) return 1;
		break;
	case WM_SIZING:
		if (iter->send[14]) {
			r = (LPRECT)lParam;
			wsprintf(mData,"%s %s %s %d %d %d %d %d %d",iter->command,iter->name,event_char[14],r->left,r->top,r->right,r->bottom,wParam,lParam);
			Signal;
		}
		if (iter->events[14]) return 1;
		break;
	case WM_ACTIVATE:
		if (iter->send[15]) {
			wsprintf(mData,"%s %s %s %d %d %d %d",iter->command,iter->name,event_char[15],LOWORD(wParam),lParam,wParam,lParam);
			Signal;
		}
		if (iter->events[15]) return 1;
		break;
	case WM_MDIACTIVATE:
		if (iter->send[16]) {
			wsprintf(mData,"%s %s %s %u %u %d %d",iter->command,iter->name,event_char[16],(unsigned int)wParam,(unsigned int)lParam,wParam,lParam);
			Signal;
		}
		if (iter->events[16]) return 1;
		break;
	case WM_CHILDACTIVATE:
		if (iter->send[17]) {
			wsprintf(mData,"%s %s %s",iter->command,iter->name,event_char[17]);
			Signal;
		}
		if (iter->events[17]) return 1;
		break;
	case WM_SHOWWINDOW:
		if (iter->send[18]) {
			for (i = 0;i < 4;i++) if (SHOWWINDOW_num[i] == (int)wParam) {
				int o = 0;
				while (SHOWWINDOW_char[i][o]) c[o] = SHOWWINDOW_char[i][o++];
				c[o] = 0;
				break;
			}
			wsprintf(mData,"%s %s %s %d %s %d %d",iter->command,iter->name,event_char[18],(int)lParam,c,wParam,lParam);
			Signal;
		}
		if (iter->events[18]) return 1;
		break;
	case WM_COMMAND:
		if (iter->send[19]) {
			wsprintf(mData,"%s %s %s %u %u %u %d %d",iter->command,iter->name,event_char[19],HIWORD(wParam),LOWORD(wParam),(unsigned long)lParam,wParam,lParam);
			Signal;
		}
		if (iter->events[19]) return 1;
		break;
	case WM_HELP:
		if (iter->send[20]) {
			lphi = (LPHELPINFO) lParam;
			wsprintf(mData,"%s %s %s %d %u %u %d %d",iter->command,iter->name,event_char[20],lphi->iContextType,lphi->iCtrlId,(unsigned int)lphi->hItemHandle,wParam,lParam);
			Signal;
		}
		if (iter->events[20]) return 1;
		break;
	case WM_CLOSE:
		if (iter->send[21]) {
			wsprintf(mData,"%s %s %s",iter->command,iter->name,event_char[21]);
			Signal;
		}
		if (iter->cancel == TRUE) return 0;
		
		if (iter->events[21]) return 1;
		
		if (hwnd == hmIRC) {
			Del(iter,1);
			PostMessage(hwnd, uMsg,0,0);
			return 0;
		}
		break;
	case WM_DESTROY:
		if (iter->send[22]) {
			wsprintf(mData,"%s %s %s",iter->command,iter->name,event_char[22]);
			Signal;
		}
		Del(iter,1);
		break;
		return 0;
		//CallWindowProc(tmp,hwnd,uMsg,wParam,lParam); <- a gue no!
		break;
	case WM_DISPLAYCHANGE:
		if (iter->send[23]) {
			wsprintf(mData,"%s %s %s %u %u %u %d %d",iter->command,iter->name,event_char[23],wParam,LOWORD(lParam),HIWORD(lParam),wParam,lParam);
			Signal;
		}
		if (iter->events[23]) return 1;
		break;
	case WM_POWERBROADCAST:
		if (iter->send[24]) {
			i = 0;
			switch((DWORD)wParam) {
			/*{"BATTERYLOW","OEMEVENT","POWERSTATUSCHANGE","QUERYSUSPEND",
"QUERYSUSPENDFAILED","RESUMEAUTOMATIC","RESUMECRITICAL","RESUMESUSPEND","SUSPEND"};*/
			case PBT_APMBATTERYLOW:
				i = 0;
				break;
			case PBT_APMOEMEVENT:
				i = 1;
				break;
			case PBT_APMPOWERSTATUSCHANGE:
				i = 2;
				break;
			case PBT_APMQUERYSUSPEND:
				i = 3;
				break;
			case PBT_APMQUERYSUSPENDFAILED:
				i = 4;
				break;
			case PBT_APMRESUMEAUTOMATIC:
				i = 5;
				break;
			case PBT_APMRESUMECRITICAL:
				i = 6;
				break;
			case PBT_APMRESUMESUSPEND:
				i = 7;
				break;
			case PBT_APMSUSPEND:
				i = 8;
				break;
			}
			lstrcpy(c,power_char[i]);
			wsprintf(mData,"%s%s %s %d %d %d %d",iter->command,iter->name,event_char[24],c,(DWORD)wParam,wParam,lParam);
			Signal;
		}
		if (iter->events[24]) return 1;
		break;
	case WM_ENDSESSION:
		if (iter->send[25]) {
			if (lParam == ENDSESSION_LOGOFF) lstrcpy(c,"LOGOFF");
			else bnultoa((unsigned)lParam,c);
			wsprintf(mData,"%s %s %s %d %s %d %d",iter->command,iter->name,event_char[25],wParam,c,wParam,lParam);
			Signal;
		}
		if (iter->events[25]) return 1;
		break;
	case WM_CHAR:
		if (iter->send[26]) {
			wsprintf(mData,"%s %s %s %d %d",iter->command,iter->name,event_char[26],wParam,lParam);
			Signal;
		}
		if (iter->events[26]) return 1;
		break;
	case WM_HSCROLL:
		if (iter->send[27]) {
			lstrcpy(c,hscroll[(int)LOWORD(wParam)]);
			wsprintf(mData,"%s %s %s %s %d %u %d %d",iter->command,iter->name,event_char[27],c,(short int)HIWORD(wParam),(unsigned int)lParam,wParam,lParam);
			Signal;
		}
		if (iter->events[27]) return 1;
		break;
	case WM_VSCROLL:
		if (iter->send[28]) {
			lstrcpy(c,vscroll[(int)LOWORD(wParam)]);
			wsprintf(mData,"%s %s %s %s %d %u %d %d",iter->command,iter->name,event_char[28],c,(short int)HIWORD(wParam),(unsigned int)lParam,wParam,lParam);
			Signal;
		}
		if (iter->events[28]) return 1;
		break;
	case WM_ENTERSIZEMOVE:
		if (iter->send[29]) {
			wsprintf(mData,"%s %s %s",iter->command,iter->name,event_char[29]);
			Signal;
		}
		if (iter->events[29]) return 1;
		break;
	case WM_EXITSIZEMOVE:
		if (iter->send[30]) {
			wsprintf(mData,"%s %s %s",iter->command,iter->name,event_char[30]);
			Signal;
		}
		if (iter->events[30]) return 1;
		break;
	case WM_PARENTNOTIFY:
		o = 0;
		switch(LOWORD(wParam)) {
		case WM_CREATE:
			o = 32;
			break;
		case WM_DESTROY:
			o = 22;
			break;
		case WM_LBUTTONDOWN:
			o = 2;
			break;
		case WM_MBUTTONDOWN:
			o = 8;
			break;
		case WM_RBUTTONDOWN:
			o = 5;
			break;
		}
		if (iter->send[31]) {
			wsprintf(mData,"%s %s %s %s %d %d %d %d",iter->command,iter->name,event_char[31],event_char[o],HIWORD(wParam),lParam,wParam,lParam);
			Signal;
		}
		if (iter->events[31]) return 1;
		break;
	default:
		int n;
		listc<cust>::iterator itor;
		for (itor = messages.begin(), n = 0;itor != messages.end();itor++,n++) {
			if (itor->msg == uMsg) {
				listc<char>::iterator it = iter->custom.get(n);
					//send: C & 2
					if ((*it & 0x2) == 0x2 ) {
						char wstr[800], lstr[800];
						if (itor->wptr) lstrcpy(wstr,(LPCTSTR)wParam);
						else bnultoa(wParam,wstr);
						if (itor->lptr) lstrcpy(lstr,(LPCTSTR)lParam);
						else bnultoa(lParam,lstr);
						wsprintf(mData,"%s %s %s %s %s",iter->command,iter->name,itor->data.string(),wstr,lstr);
						Signal;
					}
					//block: C & 1
					if ((*it & 0x1) == 0x1) return 1;
				}
		}
	}
	return CallWindowProc(tmp,hwnd,uMsg,wParam,lParam);
}
long dchars(char *str,long num) {
	switch (*str) {
	case '*':break;
	case '+':
		*str++;
		num += atol(str);
		break;
	case '-':
		*str++;
		num -= atol(str);
		break;
	default:
		num = atol(str);
	}
	return num;
}
UINT devents(char *str) {
	if (!(*str > 47 && *str < 58)) {
		int i = 0;
		while (i < 31) {
			if (!lstrcmpi(str,event_char[i])) return event_num[i];
			i++;
		}
	}
	return (UINT)atol(str);
}
void AddNewCustMsg(void) {
	for (listc<wproc>::iterator iter = _list.begin();iter != _list.end();iter++) iter->custom.push_back(2);
}
void DelCustMsg(int pos) {
	for (listc<wproc>::iterator iter = _list.begin();iter != _list.end();iter++) iter->custom.pop(iter->custom.get(pos));
}
char inv(char C) {
	//65 90 97 122
	if (C > 64 && C < 91) return C + 32;
	if (C > 96 && C < 123) return C - 32;
	return C;
}
struct TSORT {
	HWND hListView;
	int column;
	int sortType;
	char str1[901];
	char str2[901];
	char *additional;
	int comp;
} ;
struct FIND_FILE {
	char *Reserved1;
	unsigned int Reserved2;
	unsigned int Reserved3;
	unsigned int Reserved4;
	unsigned int Reserved5;
	unsigned short int MultiExt;
	unsigned short int Continue;
	unsigned int Counts;
	unsigned int Ticks;
} FindFileStruct;
int iwild_match(const char *wildcard, const char *string) {
    const char *c, *d; /*deux pointeurs qui serviront en cas d'�chec de matching*/
	const char *debut = string; /*pointeur initiale sur string*/
Begin:
    while (*wildcard != 42 && *wildcard != 0 && *wildcard != 59) {
        if (!*string) return 0; /*string est nulle et wildcard ne l'est pas on retourne 0*/
        /*si le caract�re *string est le m�me que *wildcard ou si *wildcard est
        un point d'interrogation (?=n'importe quel caract�re)...*/
        if ((*string == *wildcard) ||(*string == inv(*wildcard)) || (*wildcard == 63)) { string++; wildcard++; }
		else {
			while (*wildcard && *wildcard != 59) wildcard++;
			if (*wildcard == 59) goto PreLoop;
			return 0;
		}
    }
	if (*wildcard == 59){
		if (*string) {
			goto PreLoop;
		}
		return 1;
	}
    //si il reste des caract�res � v�rifier dans string et que il n'y en a plus aucun dans  wildcard..
    if (*string && !*wildcard) return 0;
    while (*wildcard == 42) wildcard++; /*pour permettre de passer les * en trop (**,***,etc.)*/
    if (!*wildcard || *wildcard == 59) return 1; /*le dernier caract�re du wildcard est un * et comme les caract�res d'avant on �t� v�rifi�s
                                le wildcard valide donc la cha�ne*/
    /*d�but du motif, on configure les pointeurs*/
    c = wildcard; d = string;
    while (*string) {
		if (*wildcard == 59) {
PreLoop:
			wildcard++;
			string = debut;
			goto Begin;
		}
		if (*wildcard == 42) {
            while (*wildcard == 42) wildcard++; /*pour permettre de passer les * en trop (**,***,etc.)*/
			if (!*wildcard) return 1;
            /*d�but du motif, on configure les pointeurs*/
            c = wildcard; d = string;
        }
        else if ((*string == *wildcard) || (*string == inv(*wildcard)) || (*wildcard == 63)) { string++; wildcard++; }
        /*en cas d'�chec du matching du motif , on remettra wildcard � sa position de d�part (d�but du motif)
        ainsi que string, qu'on avancera de 1 afin de tester toutes les combinaisons*/
        else { string = ++d; wildcard = c; }
    }
    while (*wildcard == 42) wildcard++;
	if (!*wildcard || *wildcard == 59){
		return 1; 
	}
    /* si wildcard contient un caract�re autre que * et '\0', il ne v�rifie donc pas la cha�ne*/
    while (*wildcard && *wildcard != 59) wildcard++;
	if (*wildcard == 59) goto PreLoop;
	return 0;
}

int FillSWP(char *string, SWP &filled) {
	char hwnd[64], hwndA[64], x[32], y[32], w[32], h[32], flags[256];
	if (tokenize(32,string,64,hwnd,64,hwndA,32,x,32,y,32,w,32,h,256,flags,-1) < 6) {
		return -1;
	}
	filled.hWnd = (HWND)atol(hwnd);
	if (!IsWindow(filled.hWnd)) return -2;
	filled.hWndInsertAfter = 0;
	if (!lstrcmpi(hwndA,"BOTTOM")) filled.hWndInsertAfter = HWND_BOTTOM;
	else if (!lstrcmpi(hwndA,"NOTOPMOST")) filled.hWndInsertAfter = HWND_NOTOPMOST;
	else if (!lstrcmpi(hwndA,"TOP")) filled.hWndInsertAfter = HWND_TOP;
	else if (!lstrcmpi(hwndA,"TOPMOST")) filled.hWndInsertAfter = HWND_TOPMOST;
	else {
		filled.hWndInsertAfter = (HWND)atol(hwndA);
	}
	filled.X = atoi(x), filled.Y = atoi(y), filled.cx = atoi(w), filled.cy = atoi(h);
	filled.uFlags = 0; char str[128];
	for (int i = 1;gettok(flags,i,32,str);i++) {
		for (int o = 0;o < 11;o++) 	if (!lstrcmpi(str,swinpos_char[o])) filled.uFlags |= swinpos_num[o];
	}
	if (!(filled.uFlags & SWP_NOZORDER ) && !IsWindow(filled.hWndInsertAfter)) {
			return -3;
		}
	return 1;
}
unsigned int findfile(const char *pathName, const char *mask, bool sub, FIND_FILE *FindFileStruct, bool reserved, bool (*filefonc) (const char *, int)) {
	WIN32_FIND_DATA FindFileData;
	int offset, size , fsize = MAX_PATH , mask_len = 0;
	bool verif = false;
	char *path , *c , *d;
	if (reserved == false) {
		FindFileStruct->Reserved1 = NULL;
		FindFileStruct->Reserved2 = 0;
		FindFileStruct->Reserved3 = 0;
		FindFileStruct->Reserved4 = 0;
		FindFileStruct->Continue = 1;
		FindFileStruct->Counts = 0;
		FindFileStruct->Ticks = GetTickCount();
		offset = lstrlen(pathName);
		while (mask[mask_len]) {
			if (mask[mask_len] == 59) verif = true;
			mask_len++;
		}  
		if (verif == true) mask_len = 1;
		if (mask_len > MAX_PATH) fsize = mask_len;
		size = offset+fsize+1;
		path = (char *)HeapAlloc(GetProcessHeap(),0,size);
		lstrcpy(path,pathName);
		if (verif) {
			path[offset] = 42;
			path[offset+1] = 0;
		}
		else {
			c = &path[offset];
			mask_len = 0;
			while (mask[mask_len]) *c++ = mask[mask_len++];
			*c = 0;
		}
		FindFileStruct->Reserved1 = path;
		FindFileStruct->Reserved3 = mask_len;
		FindFileStruct->MultiExt = verif;
	}
	else {
		path = FindFileStruct->Reserved1;
		if (FindFileStruct->MultiExt == 1) {
			mask_len = 1;
			verif = true;
		}
		else {
			mask_len = FindFileStruct->Reserved3;
			verif = false;
		}
		if (mask_len > MAX_PATH) fsize = mask_len;
		offset = FindFileStruct->Reserved2+FindFileStruct->Reserved4;
		size = offset+fsize+1;
		if ((unsigned)size < FindFileStruct->Reserved5) size = FindFileStruct->Reserved5;
		else {
			path = (char *)HeapReAlloc(GetProcessHeap(),0,path,size);
			FindFileStruct->Reserved1 = path;
		}
		if (!verif) lstrcpyn(path+offset,mask,mask_len+1);
		else {
			path[offset] = 42;
			path[offset+1] = 0;
		}
	}
	FindFileStruct->Reserved5 = size;
	HANDLE Find = FindFirstFile(path,&FindFileData);
	if (Find == INVALID_HANDLE_VALUE) {
		if (!sub) return 0;
		goto Next;
	}
	do {
		if (!(FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
		c = FindFileData.cFileName;
		d = path+offset;
		while  (*c) *d++ = *c++;
		if (verif && !iwild_match(mask,FindFileData.cFileName)) continue;
			*d = 0;
			FindFileStruct->Counts++;
			if (filefonc(path,FindFileStruct->Counts) == false) goto End;
		}
	} while (FindNextFile(Find,&FindFileData) && FindFileStruct->Continue);
Next:
	path[offset] = 42;
	path[offset+1] = 0;
	Find = FindFirstFile(path,&FindFileData);
	if (Find == INVALID_HANDLE_VALUE) {
		if (reserved == false) HeapFree(GetProcessHeap(),0,path);
		return 0;
	}
	if (!FindFileStruct->Continue || !sub) goto End;
	do {
		if ((FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
				if (FindFileData.cFileName[0] != '.' && FindFileData.cFileName[1] != 0)  {
					c = FindFileData.cFileName;
					d = path+offset;
					while  (*c) *d++ = *c++;
					*d++ = 92;
					*d = 0;
					FindFileStruct->Reserved2 = offset;
					FindFileStruct->Reserved4 = lstrlen(path+offset);
					findfile(path+offset,mask,sub,FindFileStruct,1,filefonc);
					path = FindFileStruct->Reserved1;
				}
		}
	} while (FindNextFile(Find,&FindFileData) && FindFileStruct->Continue);
End:
	if (reserved == false) HeapFree(GetProcessHeap(),0,path);
	FindClose(Find);
	if (reserved == false) FindFileStruct->Ticks = GetTickCount() - FindFileStruct->Ticks;
	return FindFileStruct->Counts;
}
void free_ff() {
	free(_path);
	free(_mask);
	free(_alias);
}
bool fill2mIRC(const char *FileName, int N) {
	wsprintf(mData,"%s %s",_alias,FileName);
	Signal;
	return 1;
}
DWORD WINAPI scand( LPVOID lpParam ) 
{ 
	ff = true;
	findfile(_path,_mask,_sub,(FIND_FILE*)lpParam,0,fill2mIRC);
	ff = false;
	lstrcpy(mData,_alias);
	free_ff();
	SendMessage(hmIRC, WM_USER + 200,0,0);
	return 1;
}
int size_comp (const char *string1, const char *string2) {
	const char *c = string1, *d = string2;
	float a = 0, b = 0, f;
	int m = 0, x = 0;
	while (*c >= '0' && *c <= '9') a = a * 10 + *c++ - 48;
	if (*c == '.' || *c == ',') {
		c++;
		f = (float)0.1;
		while (*c >= '0' && *c <= '9') {
			a += f * (*c++ - 48);
			f *=  (float)0.1;
		}
	}
	while (*d >= '0' && *d <= '9') b = b * 10 + *d++ - 48;
	if (*d == '.' || *d == ',') {
		d++;
		f = (float)0.1;
		while (*d >= '0' && *d <= '9') {
			b += f * (*d++ - 48) ;
			f *= (float)0.1;
		}
	}
	while (*c == 32) c++;
	while (*d == 32) d++;
	//first string part
	if (!lstrcmpi(c,"Kb") || !lstrcmpi(c,"Ko")) m = 1;
	else if (!lstrcmpi(c,"Mb") || !lstrcmpi(c,"Mo")) m = 2;
	else if (!lstrcmpi(c,"Gb") || !lstrcmpi(c,"Go")) m = 3;
	//second string part
	if (!lstrcmpi(d,"Kb") || !lstrcmpi(d,"Ko")) x = 1;
	else if (!lstrcmpi(d,"Mb") || !lstrcmpi(d,"Mo")) x = 2;
	else if (!lstrcmpi(d,"Gb") || !lstrcmpi(d,"Go")) x = 3;
	if (m == x) return a < b ? INFERIOR : a > b ? SUPERIOR : EQUAL;
	return m < x ? INFERIOR : m > x ? SUPERIOR : EQUAL;
}
int CompareElm(const char *elm1, const char *elm2, int comp, const char *add) {
	__int64 res;
	switch (comp) {
		case 0: case 1:
			res = lstrcmpi(elm1,elm2);
			if (!res) return 0;
			if (!comp) return res > 0 ? 1 : -1;
			return res > 0 ? -1 : 1;
		case 2:
			lstrcpy(mData,"/set %_012gr1 "); lstrcpyn(mData + 14,elm1,800); Signal;
			mData[12] = '2'; lstrcpyn(mData + 14,elm2,800); Signal;
			wsprintf(mData,"$%s(%%_012gr1,%%_012gr2)",add);
			SendMessage(hmIRC,WM_MEVALUATE,0,0);
			if (mData[0] == '-' && mData[1] == '1') return -1;
			if (mData[0] == '1') return 1;
			return 0;
		case 3:
			return size_comp(elm1,elm2);
		case 4:
			return size_comp(elm2,elm1);
		case 5: case 6:
			res = atoi64(elm1) - atoi64(elm2);
			if (!res) return 0;
			if (comp == 5) return res > 0 ? 1 : -1;
			return res > 0 ? -1 : 1;
	}
	return 0;
}
int _GetSortedPos(const char *cle, int a, int b, HWND report, int column, int type, char *buf, const char *add)
{
	b -= 1;
	int m , comp;
	while (a <= b) {
		m = (a + b) / 2;
		ListView_GetItemText(report,m,column,buf,900);
		comp = CompareElm(buf,cle,type,add);
		if (comp > 0) b = m - 1;
		else if (comp < 0) a = m + 1;
		else return m + 1;
	}
	return a + 1;
}
int CALLBACK CompareStr(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort)
{
	TSORT *ts = (TSORT *)lParamSort;
	ListView_GetItemText(ts->hListView,lParam1,ts->column,ts->str1,900)
	ListView_GetItemText(ts->hListView,lParam2,ts->column,ts->str2,900)
	return CompareElm(ts->str1,ts->str2,ts->sortType,ts->additional);
}
void GetCursorName(HCURSOR cursor, char *data) {
	for (int i = 0;i < 14;i++) {
		if (cursor == LoadCursor(NULL,cursor_num[i])) {
			lstrcpy(data,cursor_str[i]);
			return;
		}
	}
	lstrcpy(data,"CUSTOM");
}