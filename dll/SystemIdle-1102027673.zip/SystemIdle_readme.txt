SystemIdle.dll 1.0 by FoLKeN^

Description: A dll that returns your system idle time, (NOT MIRC $idle!!!!) - useful if you want to script, for example, an auto-away using system idle and not mirc idle. 

Differencing from mirc idle, system idle resets when you press a key, or move your mouse on any window. Its used, for example, to count the time until show screensaver...

Enjoy it ;)

Usage:

		$dll(SystemIdle.dll,GetIdleTime,.)


Returns:
		The system idle time in milliseconds


Example code:

alias sidle {
	return $dll(SystemIdle.dll,GetIdleTime,.)
}

alias test_idle {
	.timeridle -m 0 1 The system idle is... $sidle - Don't move your mouse or press a key or you will reset it!!
}