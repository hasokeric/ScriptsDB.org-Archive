/***************************************************/
/*       hdll.dll by da^hype (Shahir Reza Ali)     */
/* da-hype@hirc.org						           */
/* www.hirc.org									   */
/* Malaysian Made.                                 */
/***************************************************/

#pragma check_stack(off)
#pragma comment(linker,"/OPT:NOWIN98")
#include <windows.h>

// general constants
#define mFunc(x) int __stdcall x(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)
#define mReturn(x) {lstrcpy(data,x);return 3;}

/*
 * Desktop
 * //echo -s $dll(hdll.dll,Desktop,$window($active).hwnd)
 * or //dll hdll.dll Desktop $window($active).hwnd
 */
mFunc(Desktop)
{
	//get the hwnd from mirc with something like
	//echo -s $dll(hdll.dll,Desktop,$window($active).hwnd)
	HWND mircwindow = (HWND)atol(data);

	//make sure the window handle was valid
	if (!IsWindow(mircwindow))
		mReturn("$false");

	//now set the parent to the desktop. NULL tells SetParent to use the desktop window
	SetParent(mircwindow,NULL);

	//get the styles the window was using
	UINT uStyles = (UINT)GetWindowLong(mircwindow,GWL_STYLE);

	//now remove WS_CHILD the ~ means to remove it
	uStyles &= ~WS_CHILD;
	//and add WS_POPUP the | means to add it
	uStyles |= WS_POPUP;

	//set the new styles
	SetWindowLong(mircwindow,GWL_STYLE,(LONG)uStyles);

	//now instruct the script everything was ok. its best to use $true and $false as return
	//values so the scripter can use them in calls such as if (!$dll(my.dll,Function,data))
	mReturn("$true");
}

/*
 * UnDesktop
 * //echo -s $dll(hdll.dll,UnDesktop,$window($active).hwnd)
 * or //dll hdll.dll UnDesktop $window($active).hwnd
 */

mFunc(UnDesktop)
{
	HWND mircwindow = (HWND)atol(data);

	//make sure the window handle was valid
	if (!IsWindow(mircwindow))
		mReturn("$false");

	//we need to find the handle to the mdi client window. this is the real parent for all
	//custom windows and channels etc.. The classname for a mdi client window is MDIClient
	HWND hMdi = FindWindowEx(mWnd,NULL,"MDIClient",NULL);

	//make sure the MDI window handle was valid
	if (!IsWindow(hMdi))
		mReturn("$false");

	//now set the parent window back to the mdi client
	SetParent(mircwindow,hMdi);

	//just as before we need to remove the WS_POPUP and add WS_CHILD

	//get the styles the window was using
	UINT uStyles = (UINT)GetWindowLong(mircwindow,GWL_STYLE);

	//now remove WS_CHILD the ~ means to remove it
	uStyles &= ~WS_POPUP;
	//and add WS_POPUP the | means to add it
	uStyles |= WS_CHILD;

	//set the new styles
	SetWindowLong(mircwindow,GWL_STYLE,(LONG)uStyles);

	mReturn("$true");
}

/*
 * IsDesktop
 * //echo -s $dll(hdll.dll,IsDesktop,$window($active).hwnd)
 * or //dll hdll.dll IsDesktop $window($active).hwnd
 */
mFunc(IsDesktop)
{
	HWND mircwindow = (HWND)atol(data);
	UINT uStyles = GetWindowLong(mircwindow,GWL_STYLE);

	if ((uStyles & WS_POPUP) == WS_POPUP)
		mReturn("$true");
	mReturn("$false");
}

/*
 * Disables mIRC's min buttons
 * /dll hdll.dll NoMinButton .
 *
 */
mFunc(NoMinButton)
{
	SetWindowLong(mWnd,GWL_STYLE,WS_VISIBLE|WS_CLIPCHILDREN|WS_CAPTION|WS_SYSMENU|WS_MAXIMIZEBOX|WS_THICKFRAME);
	SetWindowPos(mWnd,NULL,0,0,0,0,SWP_FRAMECHANGED | SWP_NOMOVE | SWP_NOSIZE | SWP_NOOWNERZORDER | SWP_NOACTIVATE); 
	return 3;
}

/*
 * Checks if min button is enabled/disabled
 * //echo -s $dll(hdll.dll,IsNoMinButton,.)
 *
 */
mFunc(IsNoMinButton)
{
	UINT uStyles = GetWindowLong(mWnd,GWL_STYLE);
	if ((uStyles & WS_MINIMIZEBOX) == WS_MINIMIZEBOX)
	//returns $true if mix button is enabled
	mReturn("$true");
	//returns $true if mix button is disabled
	mReturn("$false");
}

/*
 * Disables mIRC's max buttons
 * /dll hdll.dll NoMaxButton .
 *
 */
mFunc(NoMaxButton)
{
	SetWindowLong(mWnd,GWL_STYLE,WS_VISIBLE|WS_CLIPCHILDREN|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX|WS_THICKFRAME);
	SetWindowPos(mWnd,NULL,0,0,0,0,SWP_FRAMECHANGED | SWP_NOMOVE | SWP_NOSIZE | SWP_NOOWNERZORDER | SWP_NOACTIVATE); 
	return 3;
}

/*
 * Checks if max button is enabled/disabled
 * //echo -s $dll(hdll.dll,IsNoMaxButton,.)
 *
 */
mFunc(IsNoMaxButton)
{
	UINT uStyles = GetWindowLong(mWnd,GWL_STYLE);
	if ((uStyles & WS_MAXIMIZEBOX) == WS_MAXIMIZEBOX)
	//returns $true if max button is enabled
	mReturn("$true");
	//return $false if max button is disabled
	mReturn("$false");
}

/*
 * Restores mIRC's buttons
 * /dll hdll.dll RestoreButtons .
 *
 */
mFunc(RestoreButtons)
{
	SetWindowLong(mWnd,GWL_STYLE,WS_VISIBLE|WS_CLIPCHILDREN|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX|WS_MAXIMIZEBOX|WS_THICKFRAME);
	SetWindowPos(mWnd,NULL,0,0,0,0,SWP_FRAMECHANGED | SWP_NOMOVE | SWP_NOSIZE | SWP_NOOWNERZORDER | SWP_NOACTIVATE); 
	return 3;
}

/*
 * Closes mIRC
 * /dll hdll.dll CloseIrc .
 *
 */
mFunc(CloseIrc) {
	PostMessage(mWnd,WM_CLOSE,0,0);
	return 3; 
}

/*
 * Window Size
 * $dll(hdll.dll,WinSize,$window($active).hwnd)
 * returns value in the form of X Y W H
 */
mFunc(WinSize) {
	RECT rc;
	HWND mircwindow = (HWND)atol(data);
	if (!IsWindow(mircwindow))
		mReturn("$false");
	HWND hMdi = FindWindowEx(mWnd,NULL,"MDIClient",NULL);
	if (!IsWindow(hMdi))
		mReturn("$false");

	GetWindowRect(mircwindow,&rc);
	wsprintf(data,"%d %d %d %d",rc.left,rc.top,rc.right-rc.left,rc.bottom-rc.top);
	return 3; 
}

//
//Other Functions
//
#define MircFunc(x) int __stdcall x(HWND mWnd, HWND aWnd, char *data, char *parms, tbool show, tbool nopause)
typedef unsigned char tbool;

/*
 * GetSpecialDir
 * You can pass in either windows, system, or temp to the same function to get that dir
 * $dll(hdll.dll,GetSpecialDir,windows|system|temp)
 */
MircFunc(GetSpecialDir)
{
	//data will tell us wich directory we want to find
	if (!lstrcmpi(data,"windows"))
	{
		GetWindowsDirectory(data,MAX_PATH);
		mReturn(data);
	}
	if (!lstrcmpi(data,"system"))
	{
		GetSystemDirectory(data,MAX_PATH);
		mReturn(data);
	}
	if (!lstrcmpi(data,"temp"))
	{
		GetTempPath(MAX_PATH,data);
		mReturn(data);
	}
	mReturn("$false");
}

/*
 * GetIconCount
 * returns the number of icons in an icon library file such as *.icl, *.dll or *.exe
 * //echo -a $dll(hdll.dll,GetIconCount,$mircexe)
 */
mFunc(GetIconCount)
{
 int iCount = ExtractIconEx(data,0,NULL,NULL,0);
 wsprintf(data,"%d",iCount);
 mReturn(data);
}

/*
 * Dll Info dialog
 * $dll(win_fn.dll,DllInfo,.)
 *
 */
int WINAPI DllInfo(HWND,HWND,char *data,char*,BOOL,BOOL)
{
	MessageBox(NULL, "Made by da^hype (Shahir Reza Ali). www.hirc.org", "hdll.dll 2.0. Malaysian Made", MB_OK);
	return 0;
}