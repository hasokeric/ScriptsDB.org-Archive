--------------------------------------------------
Tutorial
--------------------------------------------------
Protocole MSN Messenger version MSNP7
--------------------------------------------------

Ce tutorial vous montrera comment vous connecter aux serveurs de MSN Messenger.

Apr�s avoir lu ce tutorial, vous pourrez:
    - Vous connecter aux serveurs
    - Envoyer des messages
    - Recevoir des messages

Ceci est mon premier tutorial, j'esp�re qu'il vous plaira.
J'ai essay� de prendre un th�me dont peu de personnes connaissent et qui peut �tre int�ressant.
Normalement, vous ne devriez pas avoir de probl�mes � vous servir de ce tutorial.
Le tutorial d�bute avec le fichier "index.html"
Bonne lecture!

Artwerks
ppnadeau@hotmail.com

Le 8 d�cembre 2002.