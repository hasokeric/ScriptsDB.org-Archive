File2mIRC 1.00 by m910q
-----------------------

What does it do?
----------------

File2mIRC is a simple program which let mIRC process your files.
You can as an example let mIRC play your music instead of your default player, when you doubleclick on a music file.

If a DDE server isn't found, the program will return a textbox whith an error.


How to use:
-----------

1: Copy File2mIRC.exe from the archive to a place on your harddrive.
2: Enable DDE server in mIRC
3: Run File2mIRC.exe and enter the name of your DDE server, press save and exit.
4: Rightclick on a file and choose "Open with" and then "Choose program", and choose File2mIRC.exe



Example script (See "How to use" first):
----------------------------------------

This example will play MP3 files with mIRC's build-in player.

on *:signal:file2mirc: {
  if ($right($1-,5) == .mp3") { 
    echo -a Playing file: $1-
    echo -a Write "/splay -p stop" to stop the song
    echo -a -
    splay -p $1-
  }
}