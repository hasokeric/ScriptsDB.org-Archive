Voila un ptit truc qui permet d' envoyer des infos suite a des requetes SQL sur un serveur sous mIRC.

Pas besoin de dire que c pas optimiser et tt le reste

J ai fait ca uniquement a but informatif pour ceux qui veulent cr�er une interactivit� entre leur site et leur salon IRC
(affichage des nouveaux msg du forum en tps r�el par exemple)

Modifier le code a votre guise

Pour que ca marche vous avez juste a configurer:
	*dans fonction.php: ip / port / login / pass
	*dans php.mrc: port / login / pass

Enjoy!!!

jhd ( jhd@jhdscript.com )
url: http://www.jhdscript.com