<?php

/*Pour utiliser la fonction vous n' avez qu' a ecrire mirc("le texte a afficher"); dans votre code php
function mirc($msg)
{
	//ouverture du socket sur l ip ou est le serveur mIRC - ici 127.0.01 port 1234 - timeout 5 sec
	if ( $fp = @fsockopen("127.0.0.1", 1234, $errno, $errstr, 5) )
	{
	//on envoit le pass et le login au serveur
	$pass = md5('monpass');
    	$out = "Login:monlogin\r\n";
    	$out .= "Password:$pass\r\n";
		$out .= "Msg:$msg\r\n";
	//ecriture des infos via le socket connecter
    	fwrite($fp, $out);
	//fermeture du socket
    	fclose($fp);
	}
}
?> 