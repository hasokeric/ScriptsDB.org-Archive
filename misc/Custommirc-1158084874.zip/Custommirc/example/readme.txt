Pour le tester
1-charger le fichier Custommirc\example\theme1\dllv4.mrc.
2-taper //testdll

A la fin du test
1-decharger le meme fichier.
2-Un redemarrage du client mIRC est conseill�.