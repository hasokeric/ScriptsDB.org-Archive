
#include <windows.h>

#include <olectl.h>
#include <ole2.h>

//#include <complex>

//http://msdn.microsoft.com/library/default.asp?url=/library/en-us/gdi/clipping_2eni.asp
//http://msdn.microsoft.com/library/default.asp?url=/library/en-us/winui/winui/windowsuserinterface/windowing/dialogboxes/dialogboxreference/dialogboxfunctions/getnextdlggroupitem.asp


//liste de fonctions 

void drawround(RECT rt,HDC hdc,COLORREF c1,COLORREF c2,bool mod=0)
{
		HPEN currPen;
		HPEN oldpen;
		HBRUSH currBrush;
		HBRUSH oldBrush;

		currPen = CreatePen(PS_SOLID, 1, c1);
		oldpen=(HPEN)SelectObject(hdc,currPen);
		if (c2 == NULL) {
		currBrush = (HBRUSH)GetStockObject(NULL_BRUSH);
		}
		else {
			currBrush = CreateSolidBrush(c2);
		}
		oldBrush=(HBRUSH)SelectObject(hdc,currBrush);

		if (mod == 0) RoundRect(hdc,rt.left,rt.top,rt.right,rt.bottom,10,10);
		else Rectangle(hdc,rt.left,rt.top,rt.right,rt.bottom);
		
		SelectObject(hdc, oldpen);
		DeleteObject( currPen );		
		SelectObject(hdc, oldBrush);
		DeleteObject( currBrush );
}



void degrade(HDC hdc,RECT rect,COLORREF ccouleurprog,bool sens) {

		int deca;
		int D;

		int fRed = (int)GetRValue(ccouleurprog);
		int fBlue = (int)GetBValue(ccouleurprog);
		int fGreen = (int)GetGValue(ccouleurprog);
		int i = sens;

		if (sens) {
			deca = rect.bottom - rect.top;
			D = rect.bottom - rect.top + 1;
		}
		else {
			deca = rect.right-rect.left;
			D = rect.right - rect.left;
		}

		HPEN currPen;
		HPEN oldpen;

		for ( ; i < D; ++i) {
		  if (fRed)   fRed -= 128 / deca;
		  if (fBlue)  fBlue -= 128 / deca;
		  if (fGreen) fGreen -= 128 / deca;

			currPen = CreatePen(PS_SOLID, 1, RGB(fRed, fGreen , fBlue));
			oldpen=(HPEN)SelectObject(hdc,currPen);
			if (!sens) {
				MoveToEx(hdc, rect.left + i,rect.top, (LPPOINT) NULL); 
				LineTo(hdc, rect.left + i,rect.bottom);
			}
			else {
				MoveToEx(hdc, rect.left ,rect.bottom - i, (LPPOINT) NULL); 
				LineTo(hdc, rect.right , rect.bottom - i);
			}
			SelectObject(hdc, oldpen);
			DeleteObject( currPen );
		}
}

HFONT MakeFont (char *Font, int PointSize, bool Italic, int Bold,bool under=0)
{
static HDC hDC;
memset(&hDC,0,sizeof(hDC));
static int CyPixels;
memset(&CyPixels,0,sizeof(CyPixels));
hDC=GetDC(HWND_DESKTOP);
CyPixels=GetDeviceCaps(hDC,LOGPIXELSY);
ReleaseDC(HWND_DESKTOP,hDC);
PointSize=(PointSize*CyPixels)/72;
if (Bold == 1) { Bold = FW_BOLD; }

/*
if (Italic)
return CreateFont(0-PointSize,0,0,0,true,true,0,0,ANSI_CHARSET,OUT_TT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,FF_DONTCARE,Font);

return CreateFont(0-PointSize,0,0,0,true,0,0,0,ANSI_CHARSET,OUT_TT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,FF_DONTCARE,Font);
*/
return CreateFont(0-PointSize,0,0,0,Bold,Italic,under,0,ANSI_CHARSET,OUT_TT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,FF_DONTCARE,Font);
}


HBITMAP CaptureScreen(HDC hDesktopDC,int nScreenWidth,int nScreenHeight)
{
    HDC hCaptureDC = CreateCompatibleDC(hDesktopDC);
    HBITMAP hCaptureBitmap =CreateCompatibleBitmap(hDesktopDC, 
        nScreenWidth, nScreenHeight);
    SelectObject(hCaptureDC,hCaptureBitmap); 
    BitBlt(hCaptureDC,0,0,nScreenWidth,nScreenHeight,hDesktopDC,0,0,SRCCOPY); 

    DeleteDC(hCaptureDC);
	return hCaptureBitmap;
}



HBITMAP HwndToBmp(HWND hwnd, char *pszflname)
{
    HDC memdc, hdc;

	DWORD dwNumColors;
    void *pBits;
    HBITMAP hbmp;
    RGBQUAD colors[256];
    BITMAPINFO bmpinfo;
    HGDIOBJ hret;
    RECT rct;
    hdc = GetWindowDC(hwnd);
    if(!hdc) return 0;
    GetWindowRect(hwnd, &rct);
    rct.bottom -= rct.top;
    rct.right -= rct.left;
    rct.top = GetDeviceCaps(hdc, BITSPIXEL);
    if(rct.top <= 8) dwNumColors = 256;
    else dwNumColors = 0;
    if(!(memdc = CreateCompatibleDC(hdc))) { 
		ReleaseDC(hwnd, hdc); return 0;
	}
    bmpinfo.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmpinfo.bmiHeader.biWidth = rct.right;
    bmpinfo.bmiHeader.biHeight = rct.bottom;
    bmpinfo.bmiHeader.biPlanes = 1;
    bmpinfo.bmiHeader.biBitCount = (WORD) rct.top;
    bmpinfo.bmiHeader.biCompression = BI_RGB;
    bmpinfo.bmiHeader.biSizeImage = 0;
    bmpinfo.bmiHeader.biXPelsPerMeter = 0;
    bmpinfo.bmiHeader.biYPelsPerMeter = 0;
    bmpinfo.bmiHeader.biClrUsed = dwNumColors;
    bmpinfo.bmiHeader.biClrImportant = dwNumColors;
    hbmp = CreateDIBSection(hdc, &bmpinfo, DIB_PAL_COLORS, &pBits, NULL, 0);
    if(!hbmp) {
		DeleteDC(memdc);
		ReleaseDC(hwnd, hdc);
		return 0;
	}
    hret = SelectObject(memdc, hbmp);
    if(!hret || (hret == HGDI_ERROR)) {
		DeleteDC(memdc);
		ReleaseDC(hwnd, hdc);
		return 0;
	}
    if(!BitBlt(memdc, 0, 0, rct.right, rct.bottom, hdc, 0, 0, SRCCOPY)) {
		DeleteDC(memdc);
		ReleaseDC(hwnd, hdc);
		return 0;
	}
    if(dwNumColors) dwNumColors = GetDIBColorTable(memdc, 0, dwNumColors, colors);
 
	DeleteDC(memdc);
	ReleaseDC(hwnd, hdc);
	return hbmp;	



/*
	//sauvegarde
    BITMAPFILEHEADER fileheader;
    HANDLE hfl;
    DWORD dwBytes;
	fileheader.bfType = 0x4D42;
    rct.left = dwNumColors * sizeof(RGBQUAD);
    fileheader.bfSize = ((rct.right * rct.bottom * rct.top) >> 3) + rct.left + sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);
    fileheader.bfReserved1 = fileheader.bfReserved2 = 0;
    fileheader.bfOffBits = rct.left + sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);
    bmpinfo.bmiHeader.biClrImportant = 0;
    bmpinfo.bmiHeader.biClrUsed = dwNumColors;
    hfl = CreateFile(pszflname,GENERIC_WRITE,0,0,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,0);
    if(hfl == INVALID_HANDLE_VALUE) {DeleteObject(hbmp); goto errato;}
    WriteFile(hfl, &fileheader, sizeof(BITMAPFILEHEADER), &dwBytes, 0);
    WriteFile(hfl, &bmpinfo.bmiHeader, sizeof(BITMAPINFOHEADER), &dwBytes, 0);
    if(!dwNumColors) WriteFile(hfl, colors, rct.left, &dwBytes, 0);
    WriteFile(hfl, pBits, (rct.right * rct.bottom * rct.top) >> 3, &dwBytes, 0);
    CloseHandle(hfl);
    DeleteObject(hbmp);
    DeleteDC(memdc);
//    return 1;
	
errato:
    DeleteDC(memdc);
relHwndDc:
    ReleaseDC(hwnd, hdc);


return hbmp;
*/
}
/*
HBITMAP HwndToBmpf(HWND hwnd, char *pszflname)
{
    HDC memdc, hdc;
   HANDLE hfl;
   DWORD dwBytes;
	DWORD dwNumColors;
    void *pBits;
    HBITMAP hbmp;
   BITMAPFILEHEADER fileheader;
    RGBQUAD colors[256];
    BITMAPINFO bmpinfo;
    HGDIOBJ hret;
    RECT rct;
    hdc = GetWindowDC(hwnd);
    if(!hdc) return 0;
    GetWindowRect(hwnd, &rct);
    rct.bottom -= rct.top;
    rct.right -= rct.left;
    rct.top = GetDeviceCaps(hdc, BITSPIXEL);
    if(rct.top <= 8) dwNumColors = 256;
    else dwNumColors = 0;
    if(!(memdc = CreateCompatibleDC(hdc))) { 
		ReleaseDC(hwnd, hdc); return 0;
	}
    bmpinfo.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmpinfo.bmiHeader.biWidth = rct.right;
    bmpinfo.bmiHeader.biHeight = rct.bottom;
    bmpinfo.bmiHeader.biPlanes = 1;
    bmpinfo.bmiHeader.biBitCount = (WORD) rct.top;
    bmpinfo.bmiHeader.biCompression = BI_RGB;
    bmpinfo.bmiHeader.biSizeImage = 0;
    bmpinfo.bmiHeader.biXPelsPerMeter = 0;
    bmpinfo.bmiHeader.biYPelsPerMeter = 0;
    bmpinfo.bmiHeader.biClrUsed = dwNumColors;
    bmpinfo.bmiHeader.biClrImportant = dwNumColors;
    hbmp = CreateDIBSection(hdc, &bmpinfo, DIB_PAL_COLORS, &pBits, NULL, 0);
    if(!hbmp) {
		DeleteDC(memdc);
		ReleaseDC(hwnd, hdc);
		return 0;
	}
    hret = SelectObject(memdc, hbmp);
    if(!hret || (hret == HGDI_ERROR)) {
		DeleteDC(memdc);
		ReleaseDC(hwnd, hdc);
		return 0;
	}
    if(!BitBlt(memdc, 0, 0, rct.right, rct.bottom, hdc, 0, 0, SRCCOPY)) {
		DeleteDC(memdc);
		ReleaseDC(hwnd, hdc);
		return 0;
	}
    if(dwNumColors) dwNumColors = GetDIBColorTable(memdc, 0, dwNumColors, colors);
 
	DeleteDC(memdc);
	ReleaseDC(hwnd, hdc);
	


	fileheader.bfType = 0x4D42;
    rct.left = dwNumColors * sizeof(RGBQUAD);
    fileheader.bfSize = ((rct.right * rct.bottom * rct.top) >> 3) + rct.left + sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);
    fileheader.bfReserved1 = fileheader.bfReserved2 = 0;
    fileheader.bfOffBits = rct.left + sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);
    bmpinfo.bmiHeader.biClrImportant = 0;
    bmpinfo.bmiHeader.biClrUsed = dwNumColors;
    hfl = CreateFile(pszflname,GENERIC_WRITE,0,0,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,0);
    if(hfl == INVALID_HANDLE_VALUE) {DeleteObject(hbmp); goto errato;}
    WriteFile(hfl, &fileheader, sizeof(BITMAPFILEHEADER), &dwBytes, 0);
    WriteFile(hfl, &bmpinfo.bmiHeader, sizeof(BITMAPINFOHEADER), &dwBytes, 0);
    if(!dwNumColors) WriteFile(hfl, colors, rct.left, &dwBytes, 0);
    WriteFile(hfl, pBits, (rct.right * rct.bottom * rct.top) >> 3, &dwBytes, 0);
    CloseHandle(hfl);
    DeleteObject(hbmp);
    DeleteDC(memdc);
//    return 1;
		return hbmp;
errato:
    DeleteDC(memdc);
relHwndDc:
    ReleaseDC(hwnd, hdc); return 0;

}
*/

HRGN BmpToRgn (HBITMAP hBmp, COLORREF cTransparentColor)
{

    BITMAP bm;
    GetObject((HBITMAP)hBmp, sizeof(bm), &bm); // met les infos d'en tete du bitmap dans bm


BITMAPINFO bi;
//memset(&bi, 0, sizeof(BITMAPINFO));
bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
bi.bmiHeader.biWidth = bm.bmWidth;
bi.bmiHeader.biHeight = bm.bmHeight;
bi.bmiHeader.biPlanes = bm.bmPlanes;
bi.bmiHeader.biBitCount = 24;
bi.bmiHeader.biCompression = BI_RGB;

DWORD dwWidthBytes = 4*((3*bm.bmWidth+3)/4);
//DWORD dwWidthBytes = 3*bm.bmWidth;
//while (bm.bmWidthBytes % 4) bm.bmWidthBytes++; // bmWidthBytes doit �tre divisible par 4


LPBYTE lpBits = new BYTE[dwWidthBytes*bm.bmHeight];
//LPBYTE lpBits = new BYTE[4*bm.bmWidth*bm.bmHeight];



HDC hdc = GetDC(NULL);
if (hdc == NULL) { MessageBox (NULL, "Pas de hdc","ee", MB_OK); }
GetDIBits(hdc, (HBITMAP)hBmp, 0, bm.bmHeight, lpBits, &bi, DIB_RGB_COLORS);
ReleaseDC(NULL, hdc);

HRGN rgn = CreateRectRgn(0,0,0,0);
int tmp;

//    BYTE *p32 = (BYTE *)bm.bmBits;
    for (int y = 0; y < bm.bmHeight; y++) // parcourt toutes les lignes de l'image, de haut en bas
    {
        for (int x = 0; x < bm.bmWidth; x++) // parcourt tous les pixels de la ligne, de gauche � droite
        {
            // Recherche une suite continue de pixels non transparents
            int x0 = x;
//            long *p = (long *)(p32 + 4*x);
            while (x < bm.bmWidth)
            {
              tmp = (bm.bmHeight-y-1)*dwWidthBytes+3*x;

				long *p = (long *)&lpBits[tmp];
             
			  if ( (unsigned)*p == cTransparentColor )
//			  if ( (lpBits[tmp] == 0) && (lpBits[tmp+1] == 0 ) && (lpBits[tmp+2] == 0) ) 
                     break; // ce pixel est transparent
                x++;
            }
            if (x > x0)
            {
               HRGN hRgnCur = CreateRectRgn(x0,y,x,y+1);
           //    CombineRgn(hRgnBase,hRgnBase,hRgnCur,RGN_OR);
               CombineRgn(rgn,rgn,hRgnCur,RGN_OR);
               DeleteObject(hRgnCur);
            }
        }
        // On passe � la ligne suivante
//        p32 += bm.bmWidthBytes;
    }

//  LocalFree((HLOCAL)lpBmpBits);
//    return hRgn;

delete [] lpBits;

return rgn;
//SetWindowRgn(dlg[hDlg].hwnd,rgn,TRUE);
//DeleteObject(rgn);


}



void AddWinStyles(HWND window,int style,long AddStyles)
{
	LONG Styles = GetWindowLong(window, style);
	Styles |= AddStyles;
	SetWindowLong(window, style, Styles);
}

void RemoveWinStyles(HWND window,int style,long RemStyles)
{
	LONG Styles = GetWindowLong(window, style);
	Styles &= ~RemStyles;
	SetWindowLong(window, style, Styles);
}

HBITMAP LoadAnImage(char* FileName)
{
    WCHAR wpath[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, FileName, -1, wpath, MAX_PATH);

    IPicture* pPic;
    if (OleLoadPicturePath(wpath, NULL, NULL, NULL, IID_IPicture,(LPVOID*)&pPic) != S_OK) {
		return NULL;
	}
    HBITMAP hPic = NULL;
    pPic->get_Handle((UINT*)&hPic);

    HBITMAP hPicRet = (HBITMAP)CopyImage(hPic, IMAGE_BITMAP, 0, 0, LR_COPYRETURNORG);

    pPic->Release();
    return hPicRet;
}

void AdjustRectCoords(HWND hParent,LPRECT rect)
{
	//MapWindowPoints(HWND_DESKTOP, GetParent(hwnd), (LPPOINT)&rcListBox, 2);
	POINT P, D;
	P.x = rect->left, P.y = rect->top;
	D.x = rect->right, D.y = rect->bottom;
	ScreenToClient(hParent,&P);
	ScreenToClient(hParent,&D);
	rect->left = P.x, rect->top = P.y;
	rect->right = D.x, rect->bottom = D.y;
}


/*
void DrawGrayScale( HDC hdc, HBITMAP hBitmap )
{

BITMAP bmpInfo;
GetObject(hBitmap, sizeof(BITMAP), &bmpInfo);

LPBYTE lpBits = new BYTE[4*bmpInfo.bmWidth*bmpInfo.bmHeight];

// initialisation structure BITMAPINFO
BITMAPINFO bmInfo;
memset(&bmInfo, 0, sizeof(BITMAPINFO));
bmInfo.bmiHeader.biSize= sizeof(BITMAPINFOHEADER);
bmInfo.bmiHeader.biWidth= bmpInfo.bmWidth;
bmInfo.bmiHeader.biHeight= bmpInfo.bmHeight;
bmInfo.bmiHeader.biBitCount= 32;
bmInfo.bmiHeader.biPlanes = 1;
bmInfo.bmiHeader.biCompression= BI_RGB;

// r�cup�ration pixels

HDC hdc2 = GetDC(NULL);
GetDIBits(hdc2, hBitmap, 0, bmpInfo.bmHeight, lpBits, &bmInfo, DIB_RGB_COLORS);
//ReleaseDC(NULL, hdc);






//	BITMAPINFO &bmInfo = *(LPBITMAPINFO)hDIB ;

	int nColors = bmInfo.bmiHeader.biClrUsed ? bmInfo.bmiHeader.biClrUsed :
				1 << bmInfo.bmiHeader.biBitCount;


		// Device does not supports palettes but bitmap has a color table
		// Modify the bitmaps color table directly
		// Note : This ends up changing the DIB. If that is not acceptable then
		// copy the DIB and then change the copy rather than the original

		for( int i=0; i < nColors; i++)
		{
			long lSquareSum = bmInfo.bmiColors[i].rgbRed
						* bmInfo.bmiColors[i].rgbRed
						+ bmInfo.bmiColors[i].rgbGreen
						* bmInfo.bmiColors[i].rgbGreen
						+ bmInfo.bmiColors[i].rgbBlue
						* bmInfo.bmiColors[i].rgbBlue;
			int nGray = (int)sqrt(((double)lSquareSum)/3);
			bmInfo.bmiColors[i].rgbRed = nGray;
			bmInfo.bmiColors[i].rgbGreen = nGray;
			bmInfo.bmiColors[i].rgbBlue = nGray;
		}



	int nWidth = bmInfo.bmiHeader.biWidth;
	int nHeight = bmInfo.bmiHeader.biHeight;


	// Draw the image 
	LPVOID lpDIBBits = (LPVOID)(bmInfo.bmiColors + nColors);

	::SetDIBitsToDevice(hdc,	// hDC
		0,				// XDest
		0,				// YDest
		nWidth,				// nDestWidth
		nHeight,			// nDestHeight
		0,				// XSrc
		0,				// YSrc
		0,				// nStartScan
		nHeight,			// nNumScans
		lpDIBBits,			// lpBits
		&bmInfo,		// lpBitsInfo
		DIB_RGB_COLORS);		// wUsage


	
}
*/


//**************************************************************

/*****************************************************************************
// GetBmpSize : r�cup�re la taille d'un bitmap.
// entr�e : hBmp : bitmap dont on souhaite r�cup�rer la taille.
// retour : taille du bitmap sp�cifi�.
*****************************************************************************/
SIZE GetBmpSize(HBITMAP hBmp)
{
    // r�cup�ration des informations sur le bitmap
    BITMAP bmpInfo;
    GetObject(hBmp, sizeof(bmpInfo), &bmpInfo);

    // taille
    SIZE size;
    size.cx = bmpInfo.bmWidth;
    size.cy = bmpInfo.bmHeight;
    return size;
}

//*****************************************************************************
// GetBmpData : r�cup�re les donn�es (pixels) d'un bitmap.
// entr�e : hdc : DC � utiliser pour les appels aux fonctions API.
//          hBmp : bitmap source.
// retour : donn�es du bitmap (� lib�rer par VirtualFree) ou NULL en cas
//          d'erreur.
//-----------------------------------------------------------------------------
// Remarques : - les donn�es sont r�cup�res en 32 bits par pixels (4octets)
//               afin d'�viter d'avoir � rajouter du padding pour aligner les
//               lignes sur 4 octets.
//           - les bitmaps top-down ne sont pas g�r�s.
//           - les pixels sont stock�es par ligne � partir du bas du bitmap
//               (bottum-up).
//*****************************************************************************
LPVOID GetBmpData(HDC hdc, HBITMAP hBmp)
{
    // taille du bitmap, si bitmap top-down on renvoi NULL
    SIZE sizeBmp = GetBmpSize(hBmp);
    if(sizeBmp.cy < 0)
        return NULL;

    // allocation m�moire (on va r�cup�rer en 32 bits par pixel)
    DWORD dwSize = 4*sizeBmp.cx*sizeBmp.cy;
    LPVOID lpMem = VirtualAlloc(NULL, dwSize, MEM_COMMIT, PAGE_READWRITE);
    if(lpMem == NULL)
        return NULL;

    // initialisation structure BITMAPINFO
    BITMAPINFO bi;
    ZeroMemory(&bi, sizeof(BITMAPINFO));
    bi.bmiHeader.biSize         = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biPlanes       = 1;
    bi.bmiHeader.biBitCount     = 32;
    bi.bmiHeader.biWidth        = sizeBmp.cx;
    bi.bmiHeader.biHeight       = sizeBmp.cy;
    bi.bmiHeader.biCompression  = BI_RGB;

    // r�cup�ration bits
    int nResult = GetDIBits(hdc, hBmp, 0, sizeBmp.cy, lpMem, &bi, DIB_RGB_COLORS);

    // si tout c'est bien pass�
    if(nResult != 0)
        return lpMem;

    // erreur, lib�ration de la m�moire
    VirtualFree(lpMem, 0, MEM_RELEASE);
    return NULL;
}

//*****************************************************************************
// RotateBmp : effectue une rotation d'un bitmap.
// entr�e : hdc  : DC � utiliser pour les appels aux fonctions API.
//          hBmpSrc : bitmap source.
//          nAngle  : angle de rotation, en degr�, dans le sens trigo (inverse
//                  horaire. Seules les valeurs 0, 90, 180 et 270 sont
//                  valides.
// retour : bitmap avec la rotation demand�e ou NULL en cas d'erreur.
//*****************************************************************************
HBITMAP RotateBmp(HDC hdc, HBITMAP hBmpSrc, int nAngle)
{
    // nAngle doit �tre 0, 90, 180 ou 270
    if(nAngle != 0 && nAngle != 90 && nAngle != 180 && nAngle != 270)
        return NULL;

    // taille et donn�es du bitmap source
    SIZE sizeSrc = GetBmpSize(hBmpSrc);
    LPVOID lpDataSrc = GetBmpData(hdc, hBmpSrc);
    if(lpDataSrc == NULL)
        return NULL;

    // taille du bitmap de destination
    SIZE sizeDst = sizeSrc;
    if(nAngle == 90 || nAngle == 270)
    {
        sizeDst.cx = sizeSrc.cy;
        sizeDst.cy = sizeSrc.cx;
    }

    // allocation m�moire pour le bitmap de destination (32 bits par pixel)
    DWORD dwSize = 4*sizeDst.cx*sizeDst.cy;
    LPVOID lpDataDst = VirtualAlloc(NULL, dwSize, MEM_COMMIT, PAGE_READWRITE);
    if(lpDataDst == NULL)
    {
        VirtualFree(lpDataSrc, 0, MEM_RELEASE);
        return NULL;
    }

    // affectation des bits
    for(int xSrc = 0; xSrc < sizeSrc.cx; xSrc++)
    {
        for(int ySrc = 0; ySrc < sizeSrc.cy; ySrc++)
        {
            // pixel de destination :
            int xDst, yDst;
            switch(nAngle)
            {
            case 0  : xDst = xSrc;              yDst = ySrc;                break;
            case 90 : xDst = sizeSrc.cy-ySrc-1; yDst = xSrc;                break;
            case 180: xDst = sizeSrc.cx-xSrc-1; yDst = sizeSrc.cy-ySrc-1;   break;
            case 270: xDst = ySrc;              yDst = sizeSrc.cx-xSrc-1;   break;
            }

            // affectation du pixels (32 bits = 4 octets = 1 DWORD)
            LPDWORD lpSrc = (LPDWORD)lpDataSrc+sizeSrc.cx*ySrc+xSrc;
            LPDWORD lpDst = (LPDWORD)lpDataDst+sizeDst.cx*yDst+xDst;
            *lpDst = *lpSrc;
        }
    }

    // initialisation structure BITMAPINFO pour le bitmap de destination
    BITMAPINFO bi;
    ZeroMemory(&bi, sizeof(BITMAPINFO));
    bi.bmiHeader.biSize         = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biPlanes       = 1;
    bi.bmiHeader.biBitCount     = 32;
    bi.bmiHeader.biWidth        = sizeDst.cx;
    bi.bmiHeader.biHeight       = sizeDst.cy;
    bi.bmiHeader.biCompression  = BI_RGB;

    // cr�ation du bitmap de destination
    HBITMAP hBmpDst = CreateDIBitmap(hdc, &bi.bmiHeader, CBM_INIT, lpDataDst,
            &bi, DIB_RGB_COLORS);

    // lib�ration m�moire
    VirtualFree(lpDataSrc, 0, MEM_RELEASE);
    VirtualFree(lpDataDst, 0, MEM_RELEASE);

    // retour
    return hBmpDst;
}


HBITMAP capturehdc(HDC hdcScreen,int longueur,int largeur) {

HDC hdcCompatible = CreateCompatibleDC(hdcScreen); 
 
 
HBITMAP hbmScreen = CreateCompatibleBitmap(hdcScreen, 
                     longueur, largeur); 
 
if (hbmScreen == 0) 
   return 0;
  
if (!SelectObject(hdcCompatible, hbmScreen)) 
    return 0;
 
        if (!BitBlt(hdcCompatible, 
               0,0, 
               longueur, largeur, 
               hdcScreen, 
               0,0, 
               SRCCOPY)) 
 
        return 0;
 
		return hbmScreen;
}

HBITMAP rotate90(HBITMAP hbmp)
{

BITMAP bm;
GetObject((HBITMAP)hbmp, sizeof(bm), &bm);

BITMAPINFO bi,biNew;
biNew.bmiHeader.biSize = bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
biNew.bmiHeader.biHeight = bi.bmiHeader.biWidth = bm.bmWidth;
biNew.bmiHeader.biWidth = bi.bmiHeader.biHeight = bm.bmHeight;
biNew.bmiHeader.biPlanes = bi.bmiHeader.biPlanes = bm.bmPlanes;
biNew.bmiHeader.biBitCount = bi.bmiHeader.biBitCount = 24;
biNew.bmiHeader.biCompression = bi.bmiHeader.biCompression = BI_RGB;

DWORD dwWidthBytes = 4*((3*bm.bmWidth+3)/4);
DWORD dwWidthBytesNew = 4*((3*bm.bmHeight+3)/4);

LPBYTE lpBits = new BYTE[dwWidthBytes*bm.bmHeight];
LPBYTE lpBitsNew = new BYTE[dwWidthBytesNew*bm.bmWidth];

if ((!(lpBits)) || (!(lpBitsNew))) { return NULL; }

HDC hdc = GetDC(NULL);
if (hdc == NULL) { return 0; }

GetDIBits(hdc, (HBITMAP)hbmp, 0, bm.bmHeight, lpBits, &bi, DIB_RGB_COLORS);
GetDIBits(hdc, (HBITMAP)hbmp, 0, bm.bmWidth, lpBitsNew, &biNew, DIB_RGB_COLORS);

int tmp;
int tmp2;

//LPDWORD lpSrc,lpDst;

    for (int y = 0; y < bm.bmHeight; y++)
    {
        for (int x = 0; x < bm.bmWidth; x++)
        {

            tmp = (bm.bmHeight-y-1)*dwWidthBytes+3*x;
			tmp2 = (bm.bmWidth-x-1)*dwWidthBytesNew+3*y;

			lpBitsNew[tmp2] = lpBits[tmp];
			lpBitsNew[tmp2+1] = lpBits[tmp+1];
			lpBitsNew[tmp2+2] = lpBits[tmp+2];


	//		lpSrc = (LPDWORD)&lpBits[tmp];
	//		lpDst =(LPDWORD)&lpBitsNew[tmp2];
	//		*lpDst = *lpSrc;

		}
	}

	HBITMAP hBmpDst=CreateDIBitmap(hdc,&biNew.bmiHeader,CBM_INIT,lpBitsNew,&biNew,DIB_RGB_COLORS);
	ReleaseDC(NULL, hdc);
	delete[] lpBits;
	delete[] lpBitsNew;

	return hBmpDst;

}

//HBRUSH crouge = CreateSolidBrush(RGB(255,0,0));
void MyStrech(HDC hdc,int x1,int y1,int w1,int h1,HBITMAP hbmp,COLORREF c)
{

	 BITMAP bmpInfo;
     GetObject(hbmp, sizeof(bmpInfo), &bmpInfo);
	 HDC hdcbmp; 
     hdcbmp = CreateCompatibleDC(hdc); 
	 HBITMAP hOldBmpSrc = (HBITMAP)SelectObject(hdcbmp, hbmp);
  
	int w2 = bmpInfo.bmWidth;
	int h2 = bmpInfo.bmHeight;


/*
RECT rt;
rt.left=x1;
rt.top=y1;
rt.right=x1+w1;
rt.bottom=y1+h1-1;
FillRect(hdc,&rt,crouge);
*/

	if (w2 > h2) {
		int dec = w2/3;
		TransparentBlt(hdc,x1,y1,dec,h1,hdcbmp,0,0,dec,h2,c);
		TransparentBlt(hdc,x1+dec,y1,w1-2*dec,h1,hdcbmp,dec,0,dec,h2,c);
		TransparentBlt(hdc,x1+w1-dec,y1,dec,h1,hdcbmp,2*dec,0,dec,h2,c);
	}
	else {
		int dec = h2/3;
		TransparentBlt(hdc,x1,y1,w1,dec,hdcbmp,0,0,w2,dec,c);
		TransparentBlt(hdc,x1,y1+dec,w1,h1 - 2*dec,hdcbmp,0,dec,w2,dec,c);
		TransparentBlt(hdc,x1,y1+h1-dec,w1,dec,hdcbmp,0,2*dec,w2,dec,c);
	}

		SelectObject(hdcbmp, hOldBmpSrc);
		DeleteDC(hdcbmp);

}



void MyTransparentBlt2( HDC hdc , int x1, int y1 , int w1 , int h1, HBITMAP hbmp,COLORREF c )
{

	 BITMAP bmpInfo;
     GetObject(hbmp, sizeof(bmpInfo), &bmpInfo);
	 HDC hdcBmp; 
     hdcBmp = CreateCompatibleDC(hdc); 
	 HBITMAP hOldBmpSrc = (HBITMAP)SelectObject(hdcBmp, hbmp);
/* 
RECT rt;
rt.left=x1;
rt.top=y1;
rt.right=x1+w1;
rt.bottom=y1+h1;
FillRect(hdc,&rt,crouge);
*/

	int w2 = bmpInfo.bmWidth;
	int h2 = bmpInfo.bmHeight;
	int x2=0;
	int y2=0;
//	w1=w1+4;


//	int ep1 = w1/3;
//	int lo1 = h1/3;
	int ep2 = w2/3;
	int lo2 = h2/3;

	if ((w1 < w2) || (h1 < h2)){
		TransparentBlt(hdc,x1,y1,w1,h1,hdcBmp,x2,y2,w2,h2,c );
	}
	else {

	TransparentBlt(hdc ,x1,y1,ep2, lo2, hdcBmp, x2,y2, ep2 , lo2 ,c );
	TransparentBlt(hdc ,x1+ep2,y1,w1 - 2*ep2, lo2, hdcBmp, x2+ep2,y2, ep2 , lo2 ,c );
	TransparentBlt(hdc ,x1+w1-ep2,y1,ep2, lo2, hdcBmp, x2+2*ep2 ,y2, ep2 , lo2 ,c );

	TransparentBlt(hdc ,x1,y1+lo2,ep2,h1-2*lo2, hdcBmp, x2,y2+lo2, ep2 , lo2 ,c );
	TransparentBlt(hdc ,x1+ep2,y1+lo2,w1 - 2*ep2, h1-2*lo2, hdcBmp, x2+ep2,y2+lo2, ep2 , lo2 ,c );
	TransparentBlt(hdc ,x1+w1-ep2,y1+lo2,ep2, h1-2*lo2, hdcBmp, x2+2*ep2 ,y2+lo2, ep2 , lo2 ,c );

	TransparentBlt(hdc ,x1,y1+h1-lo2,ep2, lo2, hdcBmp, x2,y2+2*lo2, ep2 , lo2 ,c );
	TransparentBlt(hdc ,x1+ep2,y1+h1-lo2,w1 - 2*ep2, lo2, hdcBmp, x2+ep2,y2+2*lo2, ep2 , lo2 ,c );
	TransparentBlt(hdc ,x1+w1-ep2,y1+h1-lo2,ep2, lo2, hdcBmp, x2+2*ep2 ,y2+2*lo2, ep2 , lo2 ,c );
	}

	SelectObject(hdcBmp, hOldBmpSrc);
	DeleteDC(hdcBmp);

}


void MyTransparentBlt( HDC hdc , int x1, int y1 , int w1 , int h1, HDC hdcBmp, int x2,int y2, int w2 , int h2 ,COLORREF c )
{
//	int ep1 = w1/3;
//	int lo1 = h1/3;
	int ep2 = w2/3;
	int lo2 = h2/3;

	TransparentBlt(hdc ,x1,y1,ep2, lo2, hdcBmp, x2,y2, ep2 , lo2 ,c );
	TransparentBlt(hdc ,x1+ep2,y1,w1 - 2*ep2, lo2, hdcBmp, x2+ep2,y2, ep2 , lo2 ,c );
	TransparentBlt(hdc ,x1+w1-ep2,y1,ep2, lo2, hdcBmp, x2+2*ep2 ,y2, ep2 , lo2 ,c );

	TransparentBlt(hdc ,x1,y1+lo2,ep2,h1-2*lo2, hdcBmp, x2,y2+lo2, ep2 , lo2 ,c );
	TransparentBlt(hdc ,x1+ep2,y1+lo2,w1 - 2*ep2, h1-2*lo2, hdcBmp, x2+ep2,y2+lo2, ep2 , lo2 ,c );
	TransparentBlt(hdc ,x1+w1-ep2,y1+lo2,ep2, h1-2*lo2, hdcBmp, x2+2*ep2 ,y2+lo2, ep2 , lo2 ,c );

	TransparentBlt(hdc ,x1,y1+h1-lo2,ep2, lo2, hdcBmp, x2,y2+2*lo2, ep2 , lo2 ,c );
	TransparentBlt(hdc ,x1+ep2,y1+h1-lo2,w1 - 2*ep2, lo2, hdcBmp, x2+ep2,y2+2*lo2, ep2 , lo2 ,c );
	TransparentBlt(hdc ,x1+w1-ep2,y1+h1-lo2,ep2, lo2, hdcBmp, x2+2*ep2 ,y2+2*lo2, ep2 , lo2 ,c );

}



/*
  LOGBRUSH lb;
  HPEN hPen;
HPEN hPenOld;
// Initialize the pen's brush.
            lb.lbStyle = BS_PATTERN; 
            lb.lbColor = NULL; 
            lb.lbHatch = (long)LoadAnImage("D:\\V3\\NsRn-V3Bugge\\theme1\\point.bmp");

				hPen = (HPEN)ExtCreatePen(PS_COSMETIC, 
                                    1, &lb, 0, NULL);

                hPenOld = (HPEN)SelectObject(hdc, hPen); 

	RoundRect(hdc,rt.left,rt.top,rt.right,rt.bottom,10,10);

                SelectObject(hdc, hPenOld); 
                DeleteObject(hPen); 
*/

int atoi(char *c)
{
	if (!c) return 0;
	int a; bool neg = false;
	if (*c == 45) {
		c++;
		neg = true;
	}
	a = 0;
	while (*c > 47 && *c < 58) a = a * 10 + *c++ - 48;
	return neg ? -a : a;
}


char *C_LEFT(char *texte, int nbre_caracteres) {
   static char resultat[80];
   if (nbre_caracteres > 0 && nbre_caracteres < (int)strlen(texte) ) {
     strncpy (resultat, texte, nbre_caracteres);
     resultat[nbre_caracteres] = '\0';
	}
   return resultat ;
}
 
 
char *C_MID(char *texte, int depart, int fin) {
   static char resultat[80];
   if (depart > 0 && fin < (int)strlen(texte) ) {
     strncpy (resultat, texte + depart , fin - depart);
     resultat[fin - depart] = '\0';
   }
   return resultat;
}
 
char *C_RIGHT(char *texte, int nbre_caracteres) {
  static char resultat[80];
  if (nbre_caracteres > 0 && nbre_caracteres < (int)strlen(texte) ) {
	strncpy(resultat,texte + (strlen(texte) - nbre_caracteres), nbre_caracteres);
    resultat[nbre_caracteres] = '\0';
  }
  return resultat;
}


char* gettok(char *data, int pos, char *C, int all)
{
    char*  Token;
    int    i;
    char data2[1024];
    lstrcpy(data2,data);
    Token = strtok(data2,C);
    for (i = 1; Token && (i < pos); i++) {

      if (i == (pos-1) && all) return strtok(NULL,"");
      else Token = strtok(NULL,C);
    }
    if (all) return strtok(data,"");
    //if (!Token)
    //  lstrcpy(Token,"\0");
    return Token;
}

int numtok(char *data, char *C)
{
    char* Token;
    char data2[1024];
    int i = 0;
    lstrcpy(data2,data);
    Token = strtok(data2,C);
    while (Token) {
      Token = strtok(NULL,C);
      i++;
    }
    return i;
}