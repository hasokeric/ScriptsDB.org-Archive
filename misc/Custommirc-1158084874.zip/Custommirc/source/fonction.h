

void drawround(RECT rt,HDC hdc,COLORREF c1,COLORREF c2,bool mod=0);
void degrade(HDC hdc,RECT rect,COLORREF ccouleurprog,bool sens);

int atoi(char *c);
char *C_LEFT(char *texte, int nbre_caracteres);
char *C_MID(char *texte, int depart, int fin);
char *C_RIGHT(char *texte, int nbre_caracteres);


HFONT MakeFont (char *Font, int PointSize, bool Italic, int Bold,bool under=0);
HBITMAP HwndToBmp(HWND hwnd, char *pszflname);
HRGN BmpToRgn (HBITMAP hBmp, COLORREF cTransparentColor);
void AddWinStyles(HWND window,int style,long AddStyles);
void RemoveWinStyles(HWND window,int style,long RemStyles);
void AdjustRectCoords(HWND hParent,LPRECT rect);

HBITMAP LoadAnImage(char* FileName);
HBITMAP capturehdc(HDC hdcScreen,int longueur,int largeur);
HBITMAP rotate90(HBITMAP hbmp);
void MyStrech(HDC hdc,int x1,int y1,int w1,int h1,HBITMAP hbmp,COLORREF c);
void MyTransparentBlt2( HDC hdc , int x1, int y1 , int w1 , int h1, HBITMAP hbmp,COLORREF c );
void MyTransparentBlt( HDC hdc , int x1, int y1 , int w1 , int h1, HDC hdcBmp, int x2,int y2, int w2 , int h2 ,COLORREF c );

char* gettok(char *data, int pos, char *C, int all = 0);
int numtok(char *data, char *C);