#include <windows.h>

#include "Structure.h"

#pragma check_stack(off)
#pragma comment(linker,"/OPT:NOWIN98")

#define mirc(bleh) int __stdcall WINAPI bleh(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
#define mProc(x) LRESULT CALLBACK x(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam)


#define WM_MCOMMAND WM_USER + 200
#define WM_MEVALUATE WM_USER + 201
#define Signal SendMessage(hmIRC, WM_MCOMMAND,0,0)
#define STY_BOUTON 1342242816
#define STY_CHECK 2
#define STY_RADIO 9
#define STY_CHECKPUSH BS_PUSHLIKE
//#define STY_CHECKPUSH 1342246915
#define STY_CHECKM 1342242827
#define STY_BOX 1342177287

//#define STY_RADIOM 1342243339
#define STY_RADIOM 1342242827

#define STY_RADIO2 1342373897
#define STY_RADIOM2 1342373899
#define STY_BOX2 1342177286
#define STY_TEXTE 268435456

#define STY_LINK 1073741824

#define MAXDIAG 20
#define MAXID 300


int inithandle(char *data);
bool getinit(int data);
void DessinDialog(DIALOG,HDC);
void dessinlistbox (HWND hwnd,HDC hdc);
void DessinerBouton(LPDRAWITEMSTRUCT lpds,LPCTSTR texte,COLORREF couleurfond,bool survol,bool state=0);
void DessinerSkinBouton(HWND hwnd,LPDRAWITEMSTRUCT lpds,LPCTSTR texte,HBRUSH couleurfond,bool survol);
void initskinbut(HBITMAP htmp,HWND hwnd,char *);
void DessinerCheck(LPDRAWITEMSTRUCT lpds,LPCTSTR texte,HBRUSH couleurfond,bool state,bool survol);
void DessinerRadio(LPDRAWITEMSTRUCT lpds,LPCTSTR texte,HBRUSH couleurfond,bool state,bool survol);
void DessinerBox(LPDRAWITEMSTRUCT lpds,LPCTSTR texte,COLORREF couleurtexte,HBRUSH couleurfond);
void Dessinerprogress(LPDRAWITEMSTRUCT lpds,char * texte);

void creerrichedit(HWND phwnd);
void affrichedit(HWND hwndedit);
void suprichedit(HWND hwndedit);
void pasrichedit();
void updaterichedit(HWND hwndedit);
void initRE();


void SetTab(HWND hwnd,LPTABMIRC,RECT);
void addtab(HWND hwnd,LPTABMIRC);
//void modiftab(HWND hwnd);
void Maketab2(HWND hwnd,LPTABMIRC tabpoint);
void Dessintab(HDC hdc,HWND hwnd);

void cleardessin();
void clearrichedit();
void clearcustom();
void clearcombo();
void cleartab();
void clearlistview();
void clearScroll();
void clearedit();

void cleanskin(HWND);
//void clip(HWND hwnd);

char* DecoBoutton(HWND hwnd,int id,char *img,int type);

void createscroll(HWND hwnd);

void MakeBox(HWND hwnd);
void clearbox();

void Makestatic(HWND hwnd);
void Makeedit(HWND hwndCombo);

void Dessinertrackbar(LPDRAWITEMSTRUCT lpds,char * texte,bool survol);
void updatetrack(HWND hwnd,POINT pm,bool ok);

void Makelink(HWND hwnd);

void updateLV(HWND hwndlb,HWND hwndLV);

int atoi(char *c);

//a effacer
