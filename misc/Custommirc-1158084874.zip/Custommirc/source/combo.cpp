#include <windows.h>


#include "fonction.h"

HBITMAP hSkincombo;
HBITMAP hcombo;
extern COLORREF cinvisible;

void mIRCaff(char *text);
HDC hdcSkincombo;
HBRUSH ccadre = GetSysColorBrush(COLOR_3DSHADOW);
void clearfond(HDC hdc,HWND hwnd,RECT rt);


LRESULT WINAPI FlatComboProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{


//	char text [255];
//	wsprintf(text,"%s %d","COMBO",msg);
//	mIRCaff(text);


	HDC				hdc;
	PAINTSTRUCT		ps;
	RECT			rect;
	RECT			rect2;
	POINT			pt;
	
	WNDPROC			OldComboProc = (WNDPROC)GetWindowLong(hwnd, GWL_USERDATA);

	static BOOL		fMouseDown   = FALSE;
	static BOOL		fButtonDown  = FALSE;
	
	switch(msg)
	{
	case WM_PAINT:



		{
		if(wParam == 0)		hdc = BeginPaint(hwnd, &ps);
		else				hdc = (HDC)wParam;

//		hdc = GetDC(hwnd);

		//
		//	Mask off the borders and draw ComboBox normally
		//
		GetClientRect(hwnd, &rect);

		InflateRect(&rect, -GetSystemMetrics(SM_CXEDGE), -GetSystemMetrics(SM_CYEDGE));

		
		InflateRect(&rect, -2, -2);
		
		rect.right -= GetSystemMetrics(SM_CXVSCROLL);

		IntersectClipRect(hdc, rect.left, rect.top, rect.right, rect.bottom);
		
		// Draw the ComboBox
		CallWindowProc(OldComboProc, hwnd, msg, (WPARAM)hdc, lParam);

		//
		//	Now mask off inside and draw the borders
		//
		SelectClipRgn(hdc, NULL);
		rect.right += GetSystemMetrics(SM_CXVSCROLL);

		ExcludeClipRect(hdc, rect.left, rect.top, rect.right, rect.bottom);
		
		// draw borders
		GetClientRect(hwnd, &rect2);
//		FillRect(hdc, &rect2, GetSysColorBrush(COLOR_3DSHADOW));


//		FillRect(hdc, &rect2, ccadre);
MyTransparentBlt2(hdc,rect2.left,rect2.top,rect2.right-rect2.left,rect2.bottom-rect2.top,hcombo,cinvisible);


		// now draw the button
		SelectClipRgn(hdc, NULL);
		rect.left = rect.right - GetSystemMetrics(SM_CXVSCROLL);

		BITMAP bmp; 
		GetObject(hSkincombo, sizeof(BITMAP), (LPSTR)&bmp);

		if(fButtonDown) {
//			DrawFrameControl(hdc, &rect, DFC_SCROLL, DFCS_SCROLLCOMBOBOX|DFCS_FLAT|DFCS_PUSHED);
//			FillRect(hdc, &rect, GetSysColorBrush(COLOR_3DDKSHADOW));
			StretchBlt(hdc,rect.left+0,rect.top+0,rect.right-rect.left-0,rect.bottom-rect.top-0,hdcSkincombo,0,0,bmp.bmWidth / 2,bmp.bmHeight,SRCCOPY );
		}
		else {
//			DrawFrameControl(hdc, &rect, DFC_SCROLL, DFCS_SCROLLCOMBOBOX|DFCS_FLAT);
//			FillRect(hdc, &rect, GetSysColorBrush(COLOR_3DFACE));
			StretchBlt(hdc,rect.left+0,rect.top+0,rect.right-rect.left-0,rect.bottom-rect.top-0,hdcSkincombo,bmp.bmWidth / 2,0,bmp.bmWidth / 2,bmp.bmHeight,SRCCOPY );
		}


//		ReleaseDC(hwnd, hdc);

		if(wParam == 0)
			EndPaint(hwnd, &ps);

		return 0;
		}
	break;
	// check if mouse is within drop-arrow area, toggle
	// a flag to say if the mouse is up/down. Then invalidate
	// the window so it redraws to show the changes.
	case WM_LBUTTONDBLCLK:
	case WM_LBUTTONDOWN:

		pt.x = (short)LOWORD(lParam);
		pt.y = (short)HIWORD(lParam);

		GetClientRect(hwnd, &rect);

		InflateRect(&rect, -GetSystemMetrics(SM_CXEDGE), -GetSystemMetrics(SM_CYEDGE));
		rect.left = rect.right - GetSystemMetrics(SM_CXVSCROLL);

		if(PtInRect(&rect, pt))
		{
			// we *should* call SetCapture, but the ComboBox does it for us
			// SetCapture
			fMouseDown = TRUE;
			fButtonDown = TRUE;
			InvalidateRect(hwnd, 0, 0);
		}

		break;

	// mouse has moved. Check to see if it is in/out of the drop-arrow
	case WM_MOUSEMOVE:

		pt.x = (short)LOWORD(lParam);
		pt.y = (short)HIWORD(lParam);

		if(fMouseDown && (wParam & MK_LBUTTON))
		{
			GetClientRect(hwnd, &rect);

			InflateRect(&rect, -GetSystemMetrics(SM_CXEDGE), -GetSystemMetrics(SM_CYEDGE));
			rect.left = rect.right - GetSystemMetrics(SM_CXVSCROLL);

			if(fButtonDown != PtInRect(&rect, pt))
			{
				fButtonDown = PtInRect(&rect, pt);
				InvalidateRect(hwnd, 0, 0);
			}
		}

		break;

	case WM_LBUTTONUP:

		if(fMouseDown)
		{
			// No need to call ReleaseCapture, the ComboBox does it for us
			// ReleaseCapture

			fMouseDown = FALSE;
			fButtonDown = FALSE;
			InvalidateRect(hwnd, 0, 0);
		}

		break;
	case WM_KILLFOCUS:
		{
			InvalidateRect(hwnd, 0, 0);
		}
		break;
	case WM_ERASEBKGND:
//		InvalidateRect(hwnd, 0, 0);
		break;
	}
	
	return CallWindowProc(OldComboProc, hwnd, msg, wParam, lParam);
}

void MakeFlatCombo(HWND hwndCombo)
{
	if (!hSkincombo) return;
	
	LONG OldComboProc;

	// Remember old window procedure
	OldComboProc = GetWindowLong(hwndCombo, GWL_WNDPROC);
	SetWindowLong(hwndCombo, GWL_USERDATA, OldComboProc);

	// Perform the subclass
	OldComboProc = SetWindowLong(hwndCombo, GWL_WNDPROC, (LONG)FlatComboProc);
}

int __stdcall WINAPI Combo(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
{

	char commande[0xFFF],val1[0xFFFF];

	char *c = data;
	while(*c != ' ') c++;
	*c='\0';
	wsprintf(commande,"%s",data);
	wsprintf(val1,"%s",c+1);

	int vale1 = atoi(val1);


	if (!lstrcmpi(commande,"file")) { 

		hdcSkincombo  = CreateCompatibleDC(0);
		hSkincombo = LoadAnImage(val1);
		if (!hSkincombo) {
			wsprintf(data,"S_ERR wrong combo");
			return 3;
		}
		SelectObject(hdcSkincombo, hSkincombo);
		wsprintf(data,"S_ok");
		return 3;
	}
	if (!lstrcmpi(commande,"bmp")) {
		hcombo=LoadAnImage(val1);
		if (!hcombo) {
			wsprintf(data,"S_ERR wrong combo BMP");
			return 3;
		}
		else {
			wsprintf(data,"S_Ok");
			return 3;
			}
	}
	if (!lstrcmpi(commande,"cadre")) {
		ccadre = CreateSolidBrush(vale1);
		wsprintf(data,"S_ok");
		return 3;
	}
		wsprintf(data,"S_ERR Unknow Commande");
		return 3;
}

void clearcombo(){
	DeleteObject(ccadre);
	DeleteObject(hSkincombo);
	DeleteObject(hcombo);
}

//******************************************************************

COLORREF Textebox = 0;
COLORREF cadrebox = RGB(255,255,255);

HBRUSH Fondbox=NULL;
//HFONT MakeFont (char *Font, int PointSize, bool Italic, int Bold,bool under=0);
HFONT fontbox = NULL;
COLORREF cFondbox;
bool custbox = 0;
int styboxbar = 12;
int styboxtitre = 1;
//void drawround(RECT rt,HDC hdc,COLORREF c1,COLORREF c2,bool mod=0);
int formatbox = 8;
int decbox=0;

HBITMAP hbox;
HBITMAP hboxc;

//void MyTransparentBlt( HDC hdc , int x1, int y1 , int w1 , int h1, HDC hdcBmp, int x2,int y2, int w2 , int h2 ,COLORREF c );
//void MyTransparentBlt2( HDC hdc , int x1, int y1 , int w1 , int h1, HBITMAP hbmp,COLORREF c );


LRESULT WINAPI BoxProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	WNDPROC	OldBoxProc = (WNDPROC)GetWindowLong(hwnd, GWL_USERDATA);
	HDC hdc;
	PAINTSTRUCT		ps;

//	char text [255];
//	wsprintf(text,"%s %d","Box",msg);
//	mIRCaff(text);

	switch(msg)
	{
	case WM_PAINT:
		{
			
		if(wParam == 0)		hdc = BeginPaint(hwnd, &ps);
		else				hdc = (HDC)wParam;

		RECT rt;
		char texte[255];
		GetWindowText(hwnd,texte,256);

		BITMAP bmpInfo;
		GetObject(hbox, sizeof(BITMAP), &bmpInfo);

		GetWindowRect( hwnd, &rt);
		AdjustRectCoords(hwnd,&rt);


		//double buffer
		HDC hMemDC= CreateCompatibleDC(hdc);
		int cx = rt.right-rt.left;
		int cy = rt.bottom-rt.top;
		HBITMAP hMemBmp= CreateCompatibleBitmap(hdc, cx,cy);
		HBITMAP hOldBmp= (HBITMAP)SelectObject(hMemDC, hMemBmp);
		BitBlt(hMemDC, 0, 0, cx,cy, hdc, 0, 0, SRCCOPY);

		HFONT hOldFont;
		if (fontbox) { hOldFont = (HFONT) SelectObject(hMemDC, fontbox); }
		SetTextColor(hMemDC, Textebox);
	    SetBkMode(hMemDC,TRANSPARENT);
		
		if (!(styboxbar & 16)) {
			rt.top+=bmpInfo.bmHeight/2;
		}


		BITMAP bmp;
		HDC hdcBmp;
		hdcBmp = CreateCompatibleDC(hMemDC);
		HBITMAP hOldBmpSrc;

		if ((hboxc) && (!(styboxbar & 16))) {
			GetObject(hboxc, sizeof(bmp), &bmp);
			hOldBmpSrc = (HBITMAP)SelectObject(hdcBmp, hboxc);
			MyTransparentBlt(hMemDC, rt.left , rt.top , rt.right-rt.left , rt.bottom-rt.top , hdcBmp, 0,0,bmp.bmWidth,bmp.bmHeight,cinvisible); 
			SelectObject(hdcBmp, hOldBmpSrc);
			DeleteDC(hdcBmp);
		}
		
	
/*
		if (styboxbar & 4) {
//		  DrawEdge(hdc, &rt,(1 ? EDGE_SUNKEN : EDGE_RAISED ), BF_RECT);
			rt.left-=1;
			rt.top-=1;

			drawround(rt,hdc,RGB(255,255,255),NULL,1);
			OffsetRect(&rt,1,1);

			drawround(rt,hdc,RGB(0,0,0),NULL,1);

			rt.right-=1;
			rt.bottom-=1;

			drawround(rt,hdc,cadrebox,NULL,1);

		}

		int re = styboxbar & 3;
		if (styboxbar & 8) {
			rt.left-=1;
			rt.top-=1;

			drawround(rt,hdc,RGB(255,255,255),NULL);
			OffsetRect(&rt,1,1);

			drawround(rt,hdc,RGB(0,0,0),NULL);

			rt.right-=1;
			rt.bottom-=1;

			drawround(rt,hdc,cadrebox,NULL);
		}
*/
//InflateRect



//		if (styboxbar == 2) {
//			rt.top-=taillbox/2;
//			RECT rt2 = rt;
//			rt2.left+=8;
//			rt2.bottom=rt2.top+taillbox;
//			clearfond(hdc,hwnd,rt2);
//			SetBkMode(hdc, OPAQUE);
//			SetBkColor(hdc,cFondbox);
//		}
		

		int l=rt.right-rt.left;
		if (!(styboxbar & 16)) {
			rt.top=0;
		}

		SIZE dims;
		GetTextExtentPoint32(hMemDC, texte, strlen(texte), &dims);
		if ((styboxbar & 1) || (styboxbar & 32)){
			rt.right=dims.cx + 16;
		}

		rt.bottom=bmpInfo.bmHeight;

		if (styboxbar & 32) {
			OffsetRect(&rt,8,0);
			clearfond(hMemDC,hwnd,rt);
		}

		if (styboxbar & 2) {
	//		OffsetRect(&rt,decbox,0);
			dims.cx=rt.right-rt.left-2*(5+rt.left);
		}

		if (styboxbar & 1) {
			OffsetRect(&rt,decbox,0);
		}

		if (styboxbar & 8) {
			OffsetRect(&rt,decbox,0);
			int a=(l-dims.cx-16)/2;
			rt.right+=a;
			rt.left+=a;
		}


		if (strlen(texte) > 0) {
			if (!(styboxbar & 32)) { MyStrech(hMemDC,rt.left,rt.top,rt.right-rt.left,rt.bottom-rt.top,hbox,cinvisible); }
			ExtTextOut(hMemDC,rt.left+(rt.right-rt.left-dims.cx)/2, (rt.bottom-rt.top-dims.cy)/2, ETO_CLIPPED, &rt, texte, strlen(texte), NULL);
		}

		if (fontbox) { SelectObject(hMemDC, hOldFont); }


		// recopie du contexte en m�moire � l'�cran
		BitBlt(hdc, 0, 0, cx,cy, hMemDC, 0, 0, SRCCOPY);
		// s�lection anciens objets, destruction de ceus cr��s
		SelectObject(hMemDC, hOldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(hMemDC);



			if(wParam == 0)
			EndPaint(hwnd, &ps);

		return 0;

		}
	break;
	}

	return CallWindowProc(OldBoxProc, hwnd, msg, wParam, lParam);

}

void MakeBox(HWND hwnd)
{

	if (!custbox) return;

	LONG OldBoxProc;

	// Remember old window procedure
	OldBoxProc = GetWindowLong(hwnd, GWL_WNDPROC);
	SetWindowLong(hwnd, GWL_USERDATA, OldBoxProc);

	// Perform the subclass
	OldBoxProc = SetWindowLong(hwnd, GWL_WNDPROC, (LONG)BoxProc);
}

int __stdcall WINAPI Box(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
	{

	if (!lstrcmpi(gettok(data,1," "),"title")) {
		hbox = LoadAnImage(gettok(data,2," ",1));
		if (!hbox) { lstrcpy(data,"mauvaise image pour listbox"); return 3; }
	}
	if (!lstrcmpi(gettok(data,1," "),"border")) {
		hboxc = LoadAnImage(gettok(data,2," ",1));
		if (!hboxc) { lstrcpy(data,"mauvaise image pour listbox"); return 3; }
	}
	if (!lstrcmpi(gettok(data,1," "),"style")) {

	  int j = 2;
	  styboxbar = 0;
	  while (gettok(data,j," ")) {

		  if (!lstrcmp("plain",gettok(data,j," "))) {
	        styboxbar |= 2;
		  }
		  else if (!lstrcmp("short",gettok(data,j," "))) {
		    styboxbar |= 1;
		  }
		  else if (!lstrcmp("simple",gettok(data,j," "))) {
		    styboxbar |= 32;
		  }
		  if (!lstrcmp("center",gettok(data,j," "))) {
		    styboxbar |= 8;
		  }
//		  else if (!lstrcmp("box",gettok(data,j," "))) {
//		    styboxbar |= 4;
//		  }
		  else if (!lstrcmp("nothing",gettok(data,j," "))) {
		    styboxbar |= 16;
		  }

		j += 1;
	  }

	}

	if (!lstrcmpi(gettok(data,1," "),"cadre")) { cadrebox = atoi(gettok(data,2," ")); }
	if (!lstrcmpi(gettok(data,1," "),"texte")) { Textebox = atoi(gettok(data,2," ")); }
	if (!lstrcmpi(gettok(data,1," "),"police")) {
		fontbox = MakeFont(gettok(data,2," "), (LPARAM)atoi(gettok(data,3," ")), atoi(gettok(data,4," ")) ? true : false, atoi(gettok(data,5," ")) ? true : false );
		formatbox = atoi(gettok(data,2," "));
	}
	if (!lstrcmpi(gettok(data,1," "),"fond")) { cFondbox = atoi(gettok(data,2," ")) ; Fondbox=CreateSolidBrush(atoi(gettok(data,2," "))); }
	if (!lstrcmpi(gettok(data,1," "),"decalage")) { decbox=atoi(gettok(data,2," ")); }

	custbox = 1;
	wsprintf(data,"S_OK");
	return 3;

}

void clearbox() {
	if (Fondbox) DeleteObject(Fondbox);
	if (fontbox) DeleteObject(fontbox);
	DeleteObject(hbox);
	DeleteObject(hboxc);
}

//***********************************************************************




LRESULT WINAPI StaticProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	WNDPROC	OldBoxProc = (WNDPROC)GetWindowLong(hwnd, GWL_USERDATA);

	char text [255];
	wsprintf(text,"%s %d","Static",msg);
	mIRCaff(text);
return 0;
	switch(msg)
	{
	case WM_PAINT:
		{

		RECT rt;
		char texte[255];
		GetWindowText(hwnd,texte,256);

//		HDC hdc = GetDC(hwnd);

    PAINTSTRUCT ps;
	HDC hdc = BeginPaint(hwnd, &ps);
	
//HDC hdc = GetDC(hwnd);


		GetWindowRect( hwnd, &rt);
		AdjustRectCoords(hwnd,&rt);
	//	GetClientRect(hwnd, &rt);
	//AdjustRectCoords(hwnd,&rt);




ValidateRect(hwnd,NULL);
CallWindowProc(OldBoxProc, hwnd, msg, wParam, lParam);


HDC hdc2 = GetDC(GetParent(hwnd));
//FillRect(hdc2,&rt,hbDialog);
//FillRect(hdc,&rt,Fondbox);
ReleaseDC(GetParent(hwnd), hdc2);


EndPaint(hwnd, &ps); 

		return 0;

		}
	break;
	}

	return CallWindowProc(OldBoxProc, hwnd, msg, wParam, lParam);

}

void Makestatic(HWND hwnd)
{

	LONG OldBoxProc;

	// Remember old window procedure
	OldBoxProc = GetWindowLong(hwnd, GWL_WNDPROC);
	SetWindowLong(hwnd, GWL_USERDATA, OldBoxProc);

	// Perform the subclass
	OldBoxProc = SetWindowLong(hwnd, GWL_WNDPROC, (LONG)StaticProc);

	InvalidateRect(hwnd, 0, 1);

}
