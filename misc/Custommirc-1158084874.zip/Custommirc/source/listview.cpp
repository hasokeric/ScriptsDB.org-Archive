

#include <windows.h>
#include <string.h>

#include "fonction.h"

#include <Commctrl.h>


#include "coolscroll.h"

#pragma comment(lib, "COMCTL32.LIB")

static HWND hwndLV;

extern COLORREF cinvisible;


//HWND winhWnd;
void InitListView(HWND hwnd,char *text);
void Addcol(HWND hwndLV, char *text,int taille);
void clearfond(HDC hdc,HWND hwnd,RECT rt);
void OnDropFiles(HDROP hDropInfo,HWND hwnd);

int taillefontLV = 8;

LRESULT HandleCustomDraw(UINT ctrlid, NMCSBCUSTOMDRAW *nm);
//int atoi(char *c);


typedef struct tagMYLB
{
	WNDPROC proc;
	HWND hwnd;
} MYLB,*LPMYLB;

typedef struct tagMYLV
{
	WNDPROC proc;
	HWND hwnd;
	bool scroll;
} MYLV,*LPMYLV;

void notheme(HWND hwnd);

LRESULT CALLBACK WinProc(HWND, UINT, WPARAM, LPARAM);

void SetupScrollbarsInvert(HWND hwnd);

LRESULT WINAPI LVheaderProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);


//char* gettok(char *data, int pos, char *C, int all = 0);

HWND GethIDhwnd(int id);
void AdjustRectCoords(HWND hParent,LPRECT rect);
void updateLV(HWND hwndlb,HWND hwndLV);
void AddWinStyles(HWND window,int style,long AddStyles);

void mIRCaff(char *text);

COLORREF texte=RGB(0,0,0);
COLORREF fond=RGB(255,255,255);
HBRUSH hbheader = CreateSolidBrush(RGB(0,255,255));
COLORREF cheaders = 0;
HFONT fontLV;

HBITMAP hheader;

void InitListView(HWND hwnd,char *text)
{
LV_ITEM lvi;
int idx = 0;
int col = 0;

// initialisation des champs de la structure
lvi.mask        = LVIF_TEXT | LVIF_PARAM | LVIF_STATE; 
lvi.state       = 0; 
lvi.stateMask   = 0;
lvi.iImage      = 0;
//lvi.iItem       = 0;
lvi.iItem       = idx;
lvi.lParam		= 3;

//ListView_InsertItem(hwnd,&lvi);

SendMessage(hwnd, LVM_SETITEMCOUNT, idx+1, LVSICF_NOINVALIDATEALL);

char mot[255];
int pos=0;
int longu = strlen(text);

for(int i=1; i<longu + 1; i++)
{
   if((text[i]==9) || (i == longu ))
   {

	  for(int k=pos; k<i; k++) { mot[k-pos]=text[k]; }
      mot[i-pos]='\0';
      pos=i+1;

	  lvi.iSubItem    = col;
	  lvi.cchTextMax  = strlen(mot);
 	  lvi.pszText     = mot;
	  if (col == 0) SendMessage(hwnd, LVM_INSERTITEM, 0, (long) &lvi);
	  else SendMessage(hwnd, LVM_SETITEMTEXT, idx, (long) &lvi);
	  col++;
      }
}


}


/*
BOOL ListView_Scroll(

    HWND hwnd,
    int dx,
    int dy
);
*/


LRESULT WINAPI ListBoxProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {

 LPMYLB OldLVdata = (LPMYLB) GetWindowLong(hwnd, GWL_USERDATA);
 WNDPROC	OldBoxProc =OldLVdata->proc;

//	if (msg == 513 ) {
//	char text [255];
//	wsprintf(text,"%s %d %d %d","listbox",msg,wParam,lParam);
//	mIRCaff(text);
/*
	return 0;

	}
*/


	switch(msg)
	{

	case WM_PAINT:
		{
		}
		break;
    case WM_NCDESTROY:
		{ delete OldLVdata;}
        break;
    case LB_ADDSTRING: 
		{ 
		  CallWindowProc(OldBoxProc,hwnd,msg,wParam,lParam);
		  updateLV(hwnd,OldLVdata->hwnd);
		  return 0;
		}
        break;
    case LB_INSERTSTRING:
		{
		  CallWindowProc(OldBoxProc,hwnd,msg,wParam,lParam);
		  updateLV(hwnd,OldLVdata->hwnd);
		  return 0;
		}
        break;
    case LB_DELETESTRING:
		{
		  CallWindowProc(OldBoxProc,hwnd,msg,wParam,lParam);
		  updateLV(hwnd,OldLVdata->hwnd);
		  return 0;
		}
        break;
	case LB_GETCURSEL:
		{
			int lResult = ListView_GetSelectionMark(OldLVdata->hwnd);
			SendMessage(hwnd, LB_SETCURSEL,lResult , 0);
		}
	case LB_SETCURSEL:
		{
			SendMessage(OldLVdata->hwnd,LVM_SETSELECTIONMARK,0,wParam);
		}
	
	}

  return CallWindowProc(OldBoxProc,hwnd,msg,wParam,lParam);

}

LRESULT WINAPI ListviewProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
//	WNDPROC	OldProc = (WNDPROC)GetWindowLong(hwnd, GWL_USERDATA);
 LPMYLV OldLVdata = (LPMYLV) GetWindowLong(hwnd, GWL_USERDATA);
 WNDPROC	OldProc =OldLVdata->proc;

//	char text [255];
//	wsprintf(text,"%s %d %d %d","scroll",msg,wParam,lParam);
//	mIRCaff(text);
//WM_LBUTTONDOWN
//WM_CAPTURECHANGED
//WM_NCHITTEST
	
	bool redes = 0;

	switch(msg)
	{

	case WM_DROPFILES:
		{
			OnDropFiles((HDROP) wParam,hwnd);
		}
	break;


    case WM_NCDESTROY: 
		{ delete OldLVdata; } break;
	case WM_VSCROLL:
		{ redes = 1; } break;
	case WM_HSCROLL:
		{ redes = 1; } break;
//	case 0x020A: // case WM_MOUSEWHEEL:
//		{ redes = 1; } break;
	case WM_LBUTTONDOWN:
		{
//	int lResult = ListView_GetSelectionMark(hwnd);
//	char text [255];
//	wsprintf(text,"%s %d","LV",lResult);
//	mIRCaff(text);
		}
		break;
	}

	if (OldLVdata->scroll == 1)
	{
	switch(msg)
	{
 	case WM_VSCROLL:
		{
		SCROLLINFO si;
		si.cbSize	= sizeof(si);
		si.fMask	= SIF_PAGE | SIF_POS | SIF_RANGE | SIF_DISABLENOSCROLL | SIF_TRACKPOS;
//		GetScrollInfo(hwnd,SB_VERT,&si);
		CoolSB_GetScrollInfo(hwnd,  SB_VERT, &si);

		int ancien = si.nPos;

		switch(LOWORD(wParam))
		{
		case SB_LINEUP:{ si.nPos--; } break;
		case SB_LINEDOWN:{ si.nPos++; }break;
//		case SB_ENDSCROLL:{ CoolSB_SetScrollInfo(hwnd,  SB_VERT, &si,0); } break;
		case SB_PAGEUP:{ si.nPos=0;	} break;
		case SB_PAGEDOWN:{ si.nPos=si.nMax; } break;
		case SB_THUMBTRACK:{ si.nPos=si.nTrackPos; } break;
		}

		CoolSB_SetScrollInfo(hwnd,  SB_VERT, &si,0);


//	char text [255];
//	wsprintf(text,"%s %d %d","scroll",si.nPos,ancien);
//	mIRCaff(text);

		int a = abs(si.nPos - ancien);
		while (a > 0) {
			if (si.nPos>ancien) {
					CallWindowProc(OldProc,hwnd,WM_VSCROLL,1,0);
			}
			if (si.nPos<ancien) {
				CallWindowProc(OldProc,hwnd,WM_VSCROLL,0,0);
			}
			a-=1;
		}

	//SetupScrollbars(hwnd);


//CallWindowProc(OldProc,hwnd,msg,wParam,lParam);

//		SetScrollInfo(hwnd,SB_VERT,&si,1);
//		CallWindowProc(OldProc,hwnd,msg,wParam,lParam);

		InvalidateRect(hwnd, 0, 1);

		return 0;
		}
	break;
	case WM_HSCROLL:
		{
		SCROLLINFO si;
		si.cbSize	= sizeof(si);
		si.fMask	= SIF_PAGE | SIF_POS | SIF_RANGE | SIF_DISABLENOSCROLL | SIF_TRACKPOS;
//		GetScrollInfo(hwnd,SB_HORZ,&si);

		CoolSB_GetScrollInfo(hwnd,  SB_HORZ, &si);

		int ancien = si.nPos;

		switch(LOWORD(wParam))
		{
		case SB_LINELEFT:{ si.nPos--; } break;
		case SB_LINERIGHT:{ si.nPos++; }break;
		case SB_ENDSCROLL:{ CoolSB_SetScrollInfo(hwnd,  SB_HORZ, &si,0); } break;
		case SB_PAGELEFT:{ si.nPos=0;	} break;
		case SB_PAGERIGHT:{ si.nPos=si.nMax; } break;
		case SB_THUMBTRACK:{ si.nPos=si.nTrackPos; } break;
		}

		CoolSB_SetScrollInfo(hwnd,  SB_HORZ, &si,0);

		int a = abs(si.nPos - ancien);
		while (a > 0) {
			if (si.nPos>ancien) {
				CallWindowProc(OldProc,hwnd,WM_HSCROLL,1,0);
			}
			if (si.nPos<ancien) {
				CallWindowProc(OldProc,hwnd,WM_HSCROLL,0,0);
			}
			a-=1;
		}
		
//SetupScrollbars(hwnd);

//		CallWindowProc(OldProc,hwnd,msg,wParam,lParam);

		InvalidateRect(hwnd, 0, 1);

		return 0;
		}
	break;
	case WM_SIZE:
		{
		CallWindowProc(OldProc,hwnd,msg,wParam,lParam);
		SetupScrollbars(hwnd);
		return 0;
		}
	break;

	case WM_KEYFIRST:
		{
		CallWindowProc(OldProc,hwnd,msg,wParam,lParam);
		SetupScrollbars(hwnd);
		return 0;
		}
	break;

	case 0x020A: // case WM_MOUSEWHEEL:
		{
		CallWindowProc(OldProc,hwnd,msg,wParam,lParam);
		SetupScrollbars(hwnd);
		return 0;
		}

	case LVM_INSERTITEM:
		{
		CallWindowProc(OldProc,hwnd,msg,wParam,lParam);
		SetupScrollbars(hwnd);
		return 1;
		}
	}
	}

	if (redes == 1) {
		InvalidateRect(hwnd, 0, 1);
	}

	return CallWindowProc(OldProc,hwnd,msg,wParam,lParam);

}

LRESULT WINAPI LVheaderProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{

 WNDPROC	OldBoxProc = (WNDPROC)GetWindowLong(hwnd, GWL_USERDATA);


//	char text [255];
//	wsprintf(text,"%s %d","Listbox",msg);
//	mIRCaff(text);	
 
 switch(msg)
	{

	case WM_PAINT:
		{


    PAINTSTRUCT ps;
	HDC hdc = BeginPaint(hwnd, &ps);

	RECT rclient,rectItem;
	GetClientRect(hwnd,&rclient);


	//double buffer
	HDC hMemDC= CreateCompatibleDC(hdc);
	int cx = rclient.right-rclient.left;
	int cy = rclient.bottom-rclient.top;
	HBITMAP hMemBmp= CreateCompatibleBitmap(hdc, cx,cy);
	HBITMAP hOldBmp= (HBITMAP)SelectObject(hMemDC, hMemBmp);


	clearfond(hMemDC,hwnd,rclient);

	TCHAR buf[256];
	HD_ITEM hditem;

	int nItems = Header_GetItemCount(hwnd);


	for(int i = 0; i <nItems; i++)
	{
 

	hditem.mask = HDI_TEXT | HDI_FORMAT | HDI_ORDER | HDI_BITMAP;
    hditem.pszText = buf;
    hditem.cchTextMax = 255;

	Header_GetItem(hwnd,i,&hditem);

	Header_GetItemRect(hwnd,i,&rectItem);

	if (hheader) {
		BITMAP bmp;
		HDC hdcBmp;
		hdcBmp = CreateCompatibleDC(hMemDC);
		HBITMAP hOldBmpSrc;
		GetObject(hheader, sizeof(bmp), &bmp);
		hOldBmpSrc = (HBITMAP)SelectObject(hdcBmp, hheader);
		MyTransparentBlt(hMemDC, rectItem.left , rectItem.top , rectItem.right-rectItem.left , rectItem.bottom-rectItem.top , hdcBmp, 0,0,bmp.bmWidth,bmp.bmHeight,cinvisible); 
		SelectObject(hdcBmp, hOldBmpSrc);
		DeleteDC(hdcBmp);
	}
	
	
	InflateRect(&rectItem,-1,-1);

	int largeur=rectItem.right-rectItem.left;
	int hauteur=rectItem.bottom-rectItem.top;
	int hauticone = (int)(hauteur *.8);
	int dec = (hauteur - hauticone)/2; 

	if (hditem.mask && HDI_BITMAP) {
		DrawIconEx(hMemDC,rectItem.left+dec, rectItem.top+dec,(HICON)hditem.hbm,hauticone,hauticone,NULL,NULL,DI_NORMAL);
		largeur+=hauticone + 2*dec ;
		largeur-=10; //BUG ICONNU
	}

	HFONT hOldFont;
	if (fontLV) { hOldFont = (HFONT) SelectObject(hMemDC, fontLV); }

	SetBkMode(hMemDC,TRANSPARENT);
	SetTextColor(hMemDC, cheaders);

	SIZE dims;
	GetTextExtentPoint32(hMemDC, buf, strlen(buf), &dims);

	ExtTextOut(hMemDC,rectItem.left+(largeur-dims.cx)/2, rectItem.top+(hauteur-dims.cy)/2, ETO_CLIPPED, &rectItem, buf, strlen(buf), NULL);

	if (fontLV) { SelectObject(hMemDC, hOldFont); }

  }

	// recopie du contexte en m�moire � l'�cran
	BitBlt(hdc, 0, 0, cx,cy, hMemDC, 0, 0, SRCCOPY);
	// s�lection anciens objets, destruction de ceus cr��s
	SelectObject(hMemDC, hOldBmp);
	DeleteObject(hMemBmp);
	DeleteDC(hMemDC);

	EndPaint(hwnd, &ps); 

		return 0;

		}
	break;
	}

	return CallWindowProc(OldBoxProc, hwnd, msg, wParam, lParam);

}



void Addcol(HWND hwndLV, char *text,int taille,char * fic) {


//	char *yy = (LPTSTR) malloc(255);;

	HWND hLVHeader = ListView_GetHeader(hwndLV);

	LVCOLUMN lvc;
	lvc.mask = LVCF_TEXT | LVCF_WIDTH;
	lvc.cx = taille;
	lvc.pszText = text;
	ListView_InsertColumn(hwndLV, 0, &lvc);

	HDITEM h;
    h.mask = HDI_TEXT | HDI_FORMAT | HDI_ORDER;
	h.mask=12;
    h.cchTextMax = 255;
	Header_GetItem(hLVHeader,0,&h);

  
	h.mask |=HDI_BITMAP;
	HANDLE hicon = (HICON)LoadImage(0,fic,IMAGE_ICON,32,32,LR_LOADFROMFILE);
	if (!hicon) { return ; } 
	h.hbm = (HBITMAP)hicon;

	h.pszText=text;

	h.cchTextMax=strlen(text);
	Header_SetItem(hLVHeader,0,&h);


}


int __stdcall WINAPI Listview(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
	{

	char commande[0xFFFF];

	char data1[0xFFFF];
	wsprintf(data1,data);
	char val1[0xFFFF],val2[0xFFFF],val3[0xFFFF],val4[0xFFFF];

	wsprintf(commande,"%s",strtok(data1," "));
	wsprintf(val1,"%s",strtok(NULL," "));
	wsprintf(val2,"%s",strtok(NULL," "));
	wsprintf(val3,"%s",strtok(NULL," "));
	wsprintf(val4,"%s",strtok(NULL," "));
	int vale1 = atoi(val1);
	int vale2 = atoi(val2);
	int vale3 = atoi(val3);
	int vale4 = atoi(val4);

//	commande = gettok(data, 1, " ");
	if (!lstrcmpi(commande,"create")) {
		HWND hancien = GethIDhwnd(atoi(gettok(data, 2, " ")));
		if (!hancien) { wsprintf(data,"S_ERR wronf ID"); return 3; }
		RECT rt;
		GetWindowRect(hancien,&rt);
		AdjustRectCoords(GetParent(hancien),&rt);
//		int Styles = LVS_EX_FULLROWSELECT | LVS_EX_HEADERDRAGDROP | LVS_EX_GRIDLINES;
		int Styles = 0;
		int j = 3;
		bool dad=0;
		while (gettok(data,j," ")) {
			if (!lstrcmp("draganddrop",gettok(data,j," ")))
			dad=1;
			if (!lstrcmp("fullselect",gettok(data,j," ")))
			Styles |= LVS_EX_FULLROWSELECT;
			if (!lstrcmp("hdraganddrop",gettok(data,j," ")))
		    Styles |= LVS_EX_HEADERDRAGDROP;
			if (!lstrcmp("grid",gettok(data,j," ")))
			Styles |= LVS_EX_GRIDLINES;
			if (!lstrcmp("sortascending",gettok(data,j," ")))
			Styles |= LVS_SORTASCENDING ;
			if (!lstrcmp("sortdescending",gettok(data,j," ")))
			Styles |= LVS_SORTDESCENDING ;
			j++;
		}

	INITCOMMONCONTROLSEX icex;

	icex.dwSize = sizeof(INITCOMMONCONTROLSEX);
	icex.dwICC = ICC_LISTVIEW_CLASSES;
	InitCommonControlsEx(&icex);


//InflateRect(&rt,-20,-20);
     hwndLV = CreateWindow (WC_LISTVIEW, "",
         WS_VSCROLL | WS_CHILD| LVS_REPORT | WS_VISIBLE,
        rt.left , rt.top, rt.right-rt.left, rt.bottom-rt.top,
        GetParent(hancien), NULL, GetModuleHandle(NULL), NULL);

/*WS_VSCROLL | WS_HSCROLL 
     hwndLV = CreateWindow (WC_LISTVIEW, "",
         WS_CHILD | LVS_REPORT | WS_VISIBLE,
       0 , 0, rt.right-rt.left, rt.bottom-rt.top,
        hancien, NULL, GetModuleHandle(NULL), NULL);
*/
//   AddWinStyles(hancien,GWL_STYLE,LBS_NOSEL);
//EnableWindow(hancien,0);

	 if (hwndLV == NULL) { wsprintf(data,"S_ERR"); return 3; }

	 ListView_SetExtendedListViewStyleEx(hwndLV, 0, Styles );
	 notheme(hwndLV);

	 if (dad) { DragAcceptFiles(hwndLV,TRUE); }
//	  DragAcceptFiles(hwndLV,TRUE);

	  ShowWindow(hancien, SW_HIDE);
      ShowWindow(hwndLV, SW_SHOW);
      UpdateWindow(hwndLV);

//SendMessage(hwndLV, LVM_SETEXTENDEDLISTVIEWSTYLE, LVS_EX_FULLROWSELECT, LVS_EX_FULLROWSELECT);
	
	ListView_SetBkColor(hwndLV,fond);
    ListView_SetTextBkColor(hwndLV,fond);

    ListView_SetTextColor(hwndLV,texte);
    // on change le style
 //   SetWindowLong(hwndLV,GWL_STYLE,GetWindowLong(hwndLV,GWL_STYLE) );
			 
	HWND hLVHeader = ListView_GetHeader(hwndLV); // header de la ListView



	
	LONG OldBoxProc;

	OldBoxProc = GetWindowLong(hLVHeader, GWL_WNDPROC);
	SetWindowLong(hLVHeader, GWL_USERDATA, OldBoxProc);
	OldBoxProc = SetWindowLong(hLVHeader, GWL_WNDPROC, (LONG)LVheaderProc);

	LPMYLB OldLVdata = new MYLB;
	OldLVdata->proc=(WNDPROC)GetWindowLong(hancien, GWL_WNDPROC);
	OldLVdata->hwnd=hwndLV;
	SetWindowLong(hancien, GWL_USERDATA, (long)OldLVdata);
	SetWindowLong(hancien, GWL_WNDPROC, (long)ListBoxProc);

	LPMYLV OldLVdata2 = new MYLV;
	OldLVdata2->proc=(WNDPROC)GetWindowLong(hwndLV, GWL_WNDPROC);
	OldLVdata2->hwnd=hancien;
	OldLVdata2->scroll=0;
	SetWindowLong(hwndLV, GWL_USERDATA, (long)OldLVdata2);
	SetWindowLong(hwndLV, GWL_WNDPROC, (long)ListviewProc);

	}
	if (!lstrcmpi(commande,"column")) {
		HWND hancien = GethIDhwnd(atoi(gettok(data, 2, " ")));
		if (!hancien) { wsprintf(data,"S_ERR wrong ID"); return 3; }
//		HWND hwndLV = (HWND)GetWindowLong(hancien, GWL_USERDATA);
		LPMYLB OldLVdata = (LPMYLB) GetWindowLong(hancien, GWL_USERDATA);
		char g[255];
		wsprintf(g,gettok(data, 4, " "));
		char t[255];
		wsprintf(t,gettok(data, 5, " ",1));
//		Addcol(OldLVdata->hwnd,gettok(data, 5, " ",1),atoi(gettok(data, 3, " ")),g);
		Addcol(OldLVdata->hwnd,t,atoi(gettok(data, 3, " ")),g);
	}

	if (!lstrcmpi(commande,"police")) {
		fontLV = MakeFont(val1, (LPARAM)vale2, vale3 ? true : false, vale4 ? true : false );
		taillefontLV=vale2;
	}
	if (!lstrcmpi(commande,"header")) {
		cheaders = atoi(gettok(data, 2, " "));
		hheader = LoadAnImage(gettok(data,3," ",1));
		if (!hheader) { lstrcpy(data,"mauvaise image pour listview"); return 3; }
	}
	if (!lstrcmpi(commande,"couleur")) {
		texte = atoi(gettok(data, 2, " "));
		fond = atoi(gettok(data, 3, " "));
	}
	if (!lstrcmpi(commande,"scroll")) {
		HWND hancien = GethIDhwnd(atoi(gettok(data, 2, " ")));
		if (!hancien) { wsprintf(data,"S_ERR wrong ID"); return 3; }
		LPMYLB OldLVdata = (LPMYLB) GetWindowLong(hancien, GWL_USERDATA);
		HWND hwndLV = OldLVdata->hwnd ;
	//	HWND hwndLV = hlv;
		if (!hwndLV) { wsprintf(data,"S_ERR lost listview"); return 3; }

		if (!InitializeCoolSB(hwndLV)) {
			wsprintf(data,"S_ERR Handle non dispo");
			return 3;
		}

		setcomscroll(hwndLV, SB_BOTH);

		LPMYLV OldLVdata2 = (LPMYLV) GetWindowLong(hwndLV, GWL_USERDATA);
		OldLVdata2->scroll=1;
//		WNDPROC OldProc = (WNDPROC)SetWindowLong(hwndLV,GWL_WNDPROC,(long)ListviewProc);
		SetWindowLong(hwndLV, GWL_USERDATA, (LONG) OldLVdata2);

		SetupScrollbars(hwndLV);
	}
	if (!lstrcmpi(commande,"image")) {
		HWND hancien = GethIDhwnd(atoi(gettok(data, 2, " ")));
		if (!hancien) { wsprintf(data,"S_ERR wrong ID"); return 3; }
		LPMYLB OldLVdata = (LPMYLB) GetWindowLong(hancien, GWL_USERDATA);
		HWND hwndLV = OldLVdata->hwnd ;
		if (!hwndLV) { wsprintf(data,"S_ERR lost listview"); return 3; }
		LVBKIMAGE plvbki;
		ListView_GetBkImage(hwndLV,&plvbki);
		plvbki.ulFlags |= LVBKIF_STYLE_TILE | LVBKIF_SOURCE_URL;
		plvbki.pszImage=gettok(data, 3, " ",1);
		plvbki.xOffsetPercent=0; // position
		plvbki.yOffsetPercent=0; // on the list view
		SendMessage(hwndLV,LVM_SETTEXTBKCOLOR,0,(LPARAM)CLR_NONE); 
		ListView_SetBkImage(hwndLV,&plvbki);
	}
	/*
	if (!lstrcmpi(commande,"texte")) { Textebox = vale1; }
	if (!lstrcmpi(commande,"police")) {
		taillbox = 2 * vale2 + 2 ;
		fontbox = MakeFont(val1, (LPARAM)vale2, vale3 ? true : false, vale4 ? true : false );
	}
	if (!lstrcmpi(commande,"fond")) { cFondbox = vale1 ; Fondbox=CreateSolidBrush(vale1); }
	custbox = 1;
*/
	wsprintf(data,"S_OK");
	return 3;

}

void updateLV(HWND hwndlb,HWND hwndLV) {
	ListView_DeleteAllItems(hwndLV);
	int nCount = SendMessage(hwndlb, LB_GETCOUNT, 0, 0);
	int i;
	char szText[256];
	for(i = 0; i < nCount; i++)
	{
		SendMessage(hwndlb, LB_GETTEXT, i, (LPARAM) szText);
		InitListView(hwndLV,szText);
	}
}

void clearlistview() {
	DeleteObject(hbheader);
	DeleteObject(hheader);
}


/*
#define SB_LINEUP           0
#define SB_LINELEFT         0
#define SB_LINEDOWN         1
#define SB_LINERIGHT        1
#define SB_PAGEUP           2
#define SB_PAGELEFT         2
#define SB_PAGEDOWN         3
#define SB_PAGERIGHT        3
#define SB_THUMBPOSITION    4
#define SB_THUMBTRACK       5
#define SB_TOP              6
#define SB_LEFT             6
#define SB_BOTTOM           7
#define SB_RIGHT            7
#define SB_ENDSCROLL        8
*/