#include <windows.h>

#include "fonction.h"

LRESULT WINAPI LinkProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

void mIRCaff(char *text);
HWND GethIDhwnd(int);
void Makelink(HWND hwnd);
void MakeDrop(HWND hwnd);
void mIRCcom(char *text);


COLORREF ctexte=RGB(0,0,255);
COLORREF ctexte2=RGB(0,255,255);
HANDLE hicon;


HFONT fontlink = NULL;


int __stdcall WINAPI Link(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
{


	if (!lstrcmpi(gettok(data,1," "),"make")) {
		HWND hwnd = GethIDhwnd(atoi(gettok(data,2," ")));
		Makelink(hwnd);
	}

	if (!lstrcmpi(gettok(data,1," "),"cursor")) {
		hicon = (HICON)LoadImage(0,gettok(data,2," ",1),IMAGE_CURSOR,32,32,LR_LOADFROMFILE);
		if (!hicon) { wsprintf(data,"S_ERR wrong cursor"); } else { wsprintf(data,"S_ok"); }
	}

	if (!lstrcmpi(gettok(data,1," "),"texte")) {
		ctexte = atoi(gettok(data,2," "));
		ctexte2 = atoi(gettok(data,3," "));
		wsprintf(data,"S_ok"); 
	}

	if (!lstrcmpi(gettok(data,1," "),"police")) {
		fontlink = MakeFont(gettok(data,2," "), (LPARAM)atoi(gettok(data,3," ")), atoi(gettok(data,4," ")) ? true : false, atoi(gettok(data,5," ")) ? true : false,1 );
		wsprintf(data,"S_ok"); 
	}

	return 3;

}


void Makelink(HWND hwnd)
{
	
	AddWinStyles(hwnd,GWL_STYLE,SS_NOTIFY);

	if (hicon) { SetClassLong(hwnd, GCL_HCURSOR, (long)hicon); }


	LONG OldComboProc;

	// Remember old window procedure
	OldComboProc = GetWindowLong(hwnd, GWL_WNDPROC);
	SetWindowLong(hwnd, GWL_USERDATA, OldComboProc);

	// Perform the subclass
	OldComboProc = SetWindowLong(hwnd, GWL_WNDPROC, (LONG)LinkProc);
}

LRESULT WINAPI LinkProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{

WNDPROC			OldComboProc = (WNDPROC)GetWindowLong(hwnd, GWL_USERDATA);
//	char text [255];
//	wsprintf(text,"%s %d","link",msg);
//	mIRCaff(text);	




	switch(msg)
	{
	case WM_LBUTTONDOWN: {
		char texte[255];
		GetWindowText(hwnd,texte,256);
		ShellExecute(hwnd,"open",texte,0,0,SW_SHOWNORMAL);
	}
	break;
	case WM_PAINT:
		{

//	wsprintf(text,"%s %s","link",texte);
//	mIRCaff(text);	


			PAINTSTRUCT		ps;
			HDC hdc;
			RECT rect;
			if(wParam == 0)		hdc = BeginPaint(hwnd, &ps);
			else				hdc = (HDC)wParam;

			GetClientRect(hwnd, &rect);
	char texte[255];
	GetWindowText(hwnd,texte,256);


					HFONT hOldFont;
//					char texte[255];

					SetBkMode(hdc, TRANSPARENT);
		
					if (fontlink) { hOldFont = (HFONT) SelectObject(hdc, fontlink); }
					SetTextColor(hdc,ctexte);
					DrawText(hdc,texte,strlen(texte),&rect,DT_WORDBREAK);

					if (fontlink) { SelectObject(hdc, hOldFont); }







			if(wParam == 0) { EndPaint(hwnd, &ps); }
			return 0;
		}
		break;
	}

	return CallWindowProc(OldComboProc, hwnd, msg, wParam, lParam);
}










/*
int __stdcall WINAPI RemStyle(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
{
	HWND hwnd = (HWND)atol(data);
	InitializeCoolSB(hwnd);

	CoolSB_SetSize(hwnd, SB_BOTH, 18, 18);
	CoolSB_SetMinThumbSize(hwnd, SB_BOTH, 18);


	CoolSB_SetStyle(hwnd, SB_VERT, CSBS_HOTTRACKED);
	SetupScrollbars(hwnd);

	AddWinStyles(hwnd,GWL_STYLE,WS_VSCROLL);
	RemoveWinStyles(hwnd,GWL_STYLE,WS_HSCROLL);

	return 3;
}
*/

//****************************************************************************************/

void recupNomFichierDragDrop(HDROP* leDrop,   char* listeResult)
{
        HDROP hDropInfo=*leDrop;
        int nb,taille,i;
        taille=0;
        nb=0;
        nb=DragQueryFile(hDropInfo, 0xFFFFFFFF, NULL, 0 );
        /*if(nb==0)
            PB1("un appel inutil � la fonction BVisuel::recupNomFichierDragDrop");*/
        char fic[255];

        for( i = 0; i < nb; i++ )
        {
                taille=DragQueryFile(hDropInfo, i, NULL, 0 )+1;
                DragQueryFile(hDropInfo, i, fic, taille );
                    strcat(listeResult," ");
                    strcat(listeResult,fic);
                 }
        DragFinish(hDropInfo);  //vidage de la mem...
        *leDrop=hDropInfo;  //TOCHECK : transmistion de param...
}






void OnDropFiles(HDROP hDropInfo,HWND hwnd)
{
		
		int id = GetDlgCtrlID(hwnd);
		if (id > 6000) { id = id - 6000; }

		char text [255];
        char listeFicSrces[255];
		listeFicSrces[0]='\0';

        recupNomFichierDragDrop(&hDropInfo, listeFicSrces);
		if (strlen(listeFicSrces) > 0) {
			wsprintf(text,"%s %d %s","//.signal DROPPING id ",id,listeFicSrces);
			mIRCcom(text);
		}

}



int __stdcall WINAPI Dropping(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
	{
	HWND hwnd = GethIDhwnd(atoi(data));
	if (!hwnd) { wsprintf(data,"ERR Dialog lost Mark or Wrond ID"); return 3; }

	char classt[256];
	GetClassName(hwnd,classt,256);

	if (!lstrcmpi(classt,"Listbox")) {
		//MakeDrop(hwnd);
	}
	else if (!lstrcmpi(classt,"Edit")) {
	}
	else {
		wsprintf(data,"S_ERR : Dropping not possible on this ID");
		return 3;
	}

	DragAcceptFiles(hwnd,TRUE);

	wsprintf(data,"S_OK");
	return 3;

}

LRESULT WINAPI DropProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{

	WNDPROC	OldlistProc = (WNDPROC)GetWindowLong(hwnd, GWL_USERDATA);
	
	switch(msg)
	{
	case WM_DROPFILES:
		{
			OnDropFiles((HDROP) wParam,hwnd);
			return 0;
		}
	break;
	}

	return CallWindowProc(OldlistProc, hwnd, msg, wParam, lParam);
}

void MakeDrop(HWND hwnd)
{

	LONG OldlistProc;

	OldlistProc = GetWindowLong(hwnd, GWL_USERDATA);
	if (OldlistProc) return;

	OldlistProc = GetWindowLong(hwnd, GWL_WNDPROC);
	SetWindowLong(hwnd, GWL_USERDATA, OldlistProc);

	OldlistProc = SetWindowLong(hwnd, GWL_WNDPROC, (LONG)DropProc);
}