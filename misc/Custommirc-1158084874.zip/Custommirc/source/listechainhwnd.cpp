#include <windows.h>
#include "Structure.h"


LISTCHAIN *liste;

long LCinser_debut(long pointeurN,long valeurN)
{ 
  LISTCHAIN *vlist_item;
  if((vlist_item = (LISTCHAIN *)malloc(sizeof(LISTCHAIN))) == NULL)
  { 
	 return NULL;
  }
  vlist_item->pointeur=pointeurN;
  vlist_item->valeur=valeurN;
  vlist_item->next = liste;
  liste = vlist_item;
  return(1);
}

long LCrecherche(long pointeurN)
{
  LISTCHAIN *vlist_move;
  LISTCHAIN *vlist_move_prev;
 // list_item *vlist_tmp;
  vlist_move_prev = NULL;

  for(vlist_move=liste;(vlist_move!=NULL) && (vlist_move->pointeur!=pointeurN);
      vlist_move_prev=vlist_move,vlist_move=vlist_move->next);

  if(vlist_move == NULL)
  { 
    return(NULL);
  }
 
  return vlist_move->valeur; 
   
}

long LCsup(long pointeurN)
{
  LISTCHAIN *vlist_move;
  LISTCHAIN *vlist_move_prev;
  LISTCHAIN *vlist_tmp;

  vlist_move_prev = NULL;
  for(vlist_move=liste;(vlist_move!=NULL) && (vlist_move->pointeur!=pointeurN);
      vlist_move_prev=vlist_move,vlist_move=vlist_move->next);

  if(vlist_move == NULL)
  { 
    return 0;
  }
  else {
    if(vlist_move_prev == NULL)
    {
      vlist_tmp = vlist_move->next;
      free(vlist_move);
		liste = vlist_tmp;
      return(1);
    } else {
       vlist_move_prev->next = vlist_move->next;
       free(vlist_move);
//		list = list;
       return(1);
    }
  }
}

void LCnetoye(){
  LISTCHAIN *vlist_move;
  LISTCHAIN *vlist_move_prev;
  LISTCHAIN *vlist_tmp;
 // list_item *vlist_tmp;
  vlist_move_prev = NULL;
	HWND hwnd;
	LPDIALOG dlg;

	vlist_move=liste;
	while (vlist_move!=NULL) {
		
		dlg = (LPDIALOG)vlist_move->valeur ;
		hwnd = (HWND)vlist_move->pointeur;

		if ((hwnd) && (!IsWindow(hwnd))) {
			
			if(vlist_move_prev == NULL)
			{
			  vlist_tmp = vlist_move->next;
			  free(vlist_move);
			  liste = vlist_tmp;
			}
			else {
			   vlist_move_prev->next = vlist_move->next;
			   free(vlist_move);
			}

			
			//LCsup((long)hwnd);
			delete dlg;
		}

		vlist_move_prev=vlist_move;
		vlist_move = vlist_move->next;
	}

}



/*
void cleanlistchain(long pointeurN)
{

  LISTCHAIN *vlist_move;
  LISTCHAIN *vlist_move_prev;
 // list_item *vlist_tmp;
  vlist_move_prev = NULL;

  for(vlist_move=list;(vlist_move!=NULL) && (vlist_move->pointeur!=pointeurN);
      vlist_move_prev=vlist_move,vlist_move=vlist_move->next);

  if(vlist_move == NULL)
  { 
    return(NULL);
  }

	return vlist_move->valeur; 

	LCsup(vlist_move->pointeur);

}
*/