/*--------------------------------------------------------------------------------

--------------------------------------------------------------------------------*/
//style de bouttons http://msdn.microsoft.com/library/default.asp?url=/library/en-us/vclib/html/_mfc_button_styles.asp
//http://www.vbaccelerator.com/home/NET/Code/Controls/ListBox_and_ComboBox/TextBox_Icon/article.asp
//http://msdn.microsoft.com/library/default.asp?url=/library/en-us/vclib/html/_mfc_button_styles.asp
//WINUSER.H
//138

//fond des box differente couleur


#include "custom.h"
#include <commctrl.h>


#include <winuser.h>

#include "fonction.h"


#include "coolscroll.h"
//#include "coolsb_detours.h"
#pragma comment(lib, "coolsb_detours.lib")


extern COLORREF cinvisible;




//fonctions
LRESULT HandleCustomDraw(UINT ctrlid, NMCSBCUSTOMDRAW *nm);
void afftitre(HWND hwnd,int tempo);
int getanim();
void MakeFlatCombo(HWND hwndCombo);
void OnDropFiles(HDROP hDropInfo,HWND hwnd);
HBITMAP CaptureScreen(HDC hDesktopDC,int nScreenWidth,int nScreenHeight);


long LCinser_debut(long,long);
long LCrecherche(long pointeurN);
long LCsup(long pointeurN);
void LCnetoye();

//void SetTabBox(HWND hwnd,LPTABMIRC);
//void testscroll(HWND hwnd);
//void invalidtab (HDC hdc);
//void caretab(HDC hdc);


HWND GetMarkHwnd();



/*********************
*** Definition *********
*********************/

static int qw;
//static int hMark;
TRACKMOUSEEVENT sourie;

int wfond=0;
int hfond=0;

//int nbrDlg;
//LPDIALOG bugdiag;
//DIALOG dlg[MAXDIAG];
//DIALOG dlg;
HWND curHwnd;
HWND mIRC_hwnd;
//static HWND hStatic3;
//static HWND hListBox;

static HBRUSH hbList= NULL;
extern HBRUSH hbDialog = NULL;
static HBRUSH hbEdit= NULL;
static HBRUSH hbScroll= NULL;
static HBRUSH hbCombo= NULL;
static HBRUSH hblist = NULL;

static COLORREF cTexte = NULL;
static COLORREF cTexte2 = NULL;
static COLORREF cfond = NULL;
static COLORREF ctexteedit = NULL;
static COLORREF cfondcombo = NULL;
static COLORREF ctextecombo = NULL;
//static COLORREF cfondlist = NULL;
static COLORREF ctextelist = NULL;

static HFONT fonttext = NULL;
static HFONT fontedit = NULL;
static HFONT fontlist = NULL;
static HFONT fontcombo = NULL;


typedef DWORD (WINAPI *PFONCTION)(HWND, LPCWSTR,LPCWSTR);
HINSTANCE handletheme;
PFONCTION fonctiontheme;
HANDLE hFileMap;
LPSTR mData;

//markage
HWND hwndmarked;

//***************** Communcation  avec mirc ************

void mIRCeval(char *text, char *res) {
  wsprintf(mData,"%s",text);
  SendMessage(mIRC_hwnd, WM_USER + 201,0,0);
  lstrcpy(res,mData);
}

void mIRCaff(char *text) {
wsprintf(mData,"%s %s","/echo -a Debogage",text);
SendMessage(mIRC_hwnd,WM_USER + 200,0,0);
}

void mIRCcom(char *text) {
  wsprintf(mData,"%s",text);
  SendMessage(mIRC_hwnd, WM_USER + 200,0,0);
}

//****************** effacement du fond *****************


HBRUSH Setfond(HBITMAP hbitmap) {
	BITMAP bmp; 
	GetObject(hbitmap, sizeof(BITMAP), (LPSTR)&bmp);
	wfond=bmp.bmWidth;
	hfond=bmp.bmHeight;
	return CreatePatternBrush(hbitmap);
}


void clearfond(HDC hdc,HWND hwnd,RECT rt)
{

	if ((wfond) && (hfond)) {
		POINT lppt;
		POINT df;
		df.x=rt.left;
		df.y=rt.top;
		MapWindowPoints(hwnd,GetParent(hwnd), (LPPOINT)&df, 1);

		int aa = df.x / wfond;
		int bb = df.y / hfond;
		int cc = wfond - (df.x - aa * wfond);
		int dd = hfond - (df.y - bb * hfond);

		SetBrushOrgEx(hdc,cc,dd,&lppt);
	}

	FillRect(hdc,&rt,hbDialog);

}


//****************** PROCEDURE *****************

mProc(Procbutton) {


	LPDIALOG dlg = (LPDIALOG)GetWindowLong(GetParent(hwnd), GWL_USERDATA);
	if (!dlg) {
		return 0;
	}

	int id = GetDlgCtrlID(hwnd) - 6000 ;
	HWND tmphwnd = GetParent(hwnd);

//	wsprintf(mData,"%s %d","/echo -a Test boutton",uMsg);
//	SendMessage(mIRC_hwnd,WM_USER + 200,0,0);

	/*
	if (id == 55) {
			dlg->id[id].deco = 1;
			SetWindowLong(hwnd,GWL_WNDPROC,(long)dlg->id[id].ancienproc);
			SetWindowLong(hwnd,GWL_USERDATA,(long)0);
			RemoveWinStyles(hwnd,GWL_STYLE,BS_OWNERDRAW);


	}
*/

//	int hDlg = 0;
//	while (dlg->hwnd != tmphwnd) hDlg++;


	switch (uMsg) {
	case WM_NCHITTEST:
		{
		  if (dlg->id[id].style == 8) {
			
			int etat = SendMessage(hwnd,BM_GETSTATE,0,0);
	  
			  if (!GetAsyncKeyState(VK_LBUTTON)){
		//	  SendMessage(hwnd,BM_SETSTATE,0,0);
			//	  SetFocus(tmphwnd);
			//	SetFocus(NULL);
				  etat = 0;
			  }


				if ((etat == 108) || (etat == 8))
				{
				POINT pm;
				pm.y = HIWORD(lParam); 
				pm.x = LOWORD(lParam);
				MapWindowPoints(HWND_DESKTOP, hwnd, (LPPOINT)&pm, 1);
				updatetrack(hwnd,pm,0);
	//			SendMessage(hwnd,BM_CLICK,0,0);
				}

			  
		  }
		}
	case BM_SETSTATE:
		{
		}
	break;
    case WM_ERASEBKGND:
		{
	     return (LRESULT)0L;
		}
	break;
	case WM_LBUTTONDOWN:
		{
			if (dlg->id[id].style == 8) {
			  if (lParam != 0)
			  {
//				POINT pm;
//				pm.y = HIWORD(lParam); 
//				pm.x = LOWORD(lParam);
				}
			}
		}
	break;
	case WM_CTLCOLORDLG://Couleur de fond de la boite de dialogue
		if (hbDialog) { return (INT_PTR)hbDialog; }
    break;
	case WM_MOUSELEAVE:
		{
			dlg->hpasse = NULL;
			if (dlg->id[id].style >= 1) {
				InvalidateRect(hwnd, 0, 1);
			}
			if (dlg->id[id].style == 8) {

			}
		}
	break;
	case WM_MOUSEMOVE:
	 {
		 if ((dlg->hpasse != hwnd) && ( dlg->id[id].style >= 1 ) )  {
			dlg->hpasse = hwnd;
			
			sourie.cbSize = sizeof(TRACKMOUSEEVENT);
			sourie.hwndTrack = hwnd;
			sourie.dwHoverTime = 1;
			sourie.dwFlags = TME_LEAVE;

			_TrackMouseEvent(&sourie);

			InvalidateRect(hwnd, 0, 1);




		 }
	 }
	 break;
	 case WM_DESTROY:
		{
			if (dlg->id[id].style == 1) {
				if (dlg->id[id].deco == 3) {
					cleanskin(hwnd);
				}
			}

			CallWindowProc(dlg->id[id].ancienproc,hwnd,uMsg,wParam,lParam);

			
			SetWindowLong(hwnd,GWL_WNDPROC,(long)dlg->id[id].ancienproc);
			SetWindowLong(hwnd,GWL_USERDATA,(long)0);
			RemoveWinStyles(hwnd,GWL_STYLE,BS_OWNERDRAW);
			dlg->id[id].deco = 1;
//			dlg->id[id].style == 0;
//			dlg->testold=NULL;
//			DeleteObject((dlg->id[id].)


			return 0;
		}
	 break;
	 default:
		 {
		 }
     break;
	}

  return CallWindowProc(dlg->id[id].ancienproc,hwnd,uMsg,wParam,lParam);
}



/*
BOOL CALLBACK EnumChildProc2(HWND hwnd,LPARAM lParam) {
	wsprintf(mData,"%s ","/echo -a second =>");
	SendMessage(mIRC_hwnd,WM_USER + 200,0,0);

	HWND tmphwnd = GetParent(hwnd);

	char classt[256];
	GetClassName(hwnd,classt,256);


	return 1;
}
*/


BOOL CALLBACK EnumChildProc(HWND hwnd,LPARAM lParam) {

	HWND tmphwnd = GetParent(hwnd);

	LPDIALOG dlg = (LPDIALOG)GetWindowLong(tmphwnd, GWL_USERDATA);

	char classt[256];
	GetClassName(hwnd,classt,256);
	LONG Styles = GetWindowLong(hwnd, GWL_STYLE);

	int id = GetDlgCtrlID(hwnd) - 6000 ;

	wsprintf(mData,"%s classe %s id %d style %d","/echo -a INIT =>",classt,id,Styles);
	SendMessage(mIRC_hwnd,WM_USER + 200,0,0);

//************* TAB **********************

	if ((id < 0) && (!lstrcmpi(classt,"Static"))) {
		//partie du bas
//		GetWindowRect( hwnd, &rrr);
//		AdjustRectCoords(hwnd,&rrr);
//DestroyWindow(hwnd);
//ShowWindow(hwnd,SW_HIDE);

//		SetWindowLong(hwnd,GWL_STYLE,SS_OWNERDRAW |WS_CHILD | WS_VISIBLE );
//		AddWinStyles(hwnd,GWL_STYLE,SS_OWNERDRAW WS_CHILD | WS_VISIBLE );

//	dlg->ptab.htab = hwnd;

//Maketab2(hwnd);

		RECT rrr;
		GetWindowRect( hwnd, &rrr);
	//	AdjustRectCoords(hwnd,&rrr);
		AdjustRectCoords(GetParent(hwnd),&rrr);

	//	modiftab(hwnd);
		SetTab(hwnd,&dlg->ptab,rrr);




		//************RemoveWinStyles(hwnd,GWL_STYLE,WS_VISIBLE | WS_CHILD);
		//***********tabtest(hwnd);
  }
	if ((id < 0) && (!lstrcmpi(classt,"ListBox"))) {
	//		x y w et h sont nul = lui ki gere les changement de focus
	dlg->ptab.hwndbox = hwnd;



	Maketab2(hwnd,&dlg->ptab);



//		SetTabBox(hwnd,&dlg->ptab);
	}


	if ((id<0) || ( id>10000)) return 1 ;

//*****************************************************************

	if (dlg->id[id].deco == 1) return 1;

	if (dlg->id[id].deco == NULL) { dlg->id[id].deco = 2; }

	//tab aussi
	if ((Styles == 1207959552) || (Styles == 1207959555)) {
		addtab(hwnd,&dlg->ptab);
//		wsprintf(mData,"%s id %d","/echo -a tab =>",id);
//		SendMessage(mIRC_hwnd,WM_USER + 200,0,0);
	}
	else if (!lstrcmpi(classt,"ComboBox")) {
		MakeFlatCombo(hwnd);
		if (fontcombo) {
			SendMessage(hwnd,(UINT)WM_SETFONT,(WPARAM)fontcombo,1);
//			SendMessage(hwnd,(UINT)WM_SIZE,NULL,NULL);
		}

	}
	else if (!lstrcmpi(classt,"Button")) {

//		wsprintf(mData,"%s %s","/echo -a init1","BS_NOTIFY");
//		if (Styles & BS_NOTIFY) SendMessage(mIRC_hwnd,WM_USER + 200,0,0);

	
		if (Styles == STY_BOX ) {
			dlg->id[id].style = 7;
			MakeBox(hwnd);
//			AddWinStyles(hwnd,GWL_STYLE,BS_OWNERDRAW );

//SetWindowLong(hwnd, GWL_STYLE, WS_CHILD | WS_VISIBLE | BS_GROUPBOX);			
//AddWinStyles(hwnd,GWL_STYLE,BS_OWNERDRAW );			
	
//			SetBkMode((HDC)GetDC(hwnd),TRANSPARENT);

		}


		else if (Styles & STY_CHECKPUSH) {
			if (getinit(2) && (dlg->id[id].deco == 2)) {
				AddWinStyles(hwnd,GWL_STYLE,BS_OWNERDRAW );
				dlg->id[id].style = 2;
				dlg->id[id].state = 0;
				dlg->id[id].ancienproc = (WNDPROC)SetWindowLong(hwnd,GWL_WNDPROC,(long)Procbutton);

				bool bChecked = (SendMessage(hwnd, BM_GETCHECK, 0, 0) == BST_CHECKED);
				if (bChecked) dlg->id[id].state = 1;
				
			}
		}




		else if (Styles & STY_CHECK) {
			if (getinit(2) && (dlg->id[id].deco == 2)) {
				AddWinStyles(hwnd,GWL_STYLE,BS_OWNERDRAW );
				dlg->id[id].style = 2;
				dlg->id[id].state = 0;
				dlg->id[id].ancienproc = (WNDPROC)SetWindowLong(hwnd,GWL_WNDPROC,(long)Procbutton);

				bool bChecked = (SendMessage(hwnd, BM_GETCHECK, 0, 0) == BST_CHECKED);
				if (bChecked) dlg->id[id].state = 1;
				
			}
		}
		else if (Styles & STY_RADIO) {
			if (getinit(2) && (dlg->id[id].deco == 2)) {
				AddWinStyles(hwnd,GWL_STYLE,BS_OWNERDRAW );
				dlg->id[id].style = 3;
				dlg->id[id].state = 0;
				dlg->id[id].ancienproc = (WNDPROC)SetWindowLong(hwnd,GWL_WNDPROC,(long)Procbutton);

				bool bChecked = (SendMessage(hwnd, BM_GETCHECK, 0, 0) == BST_CHECKED);
				if (bChecked) dlg->id[id].state = 1;
			
			}
		}


		else if (Styles & STY_BOUTON) {
			if (getinit(1) && (dlg->id[id].deco == 2)) {
				AddWinStyles(hwnd,GWL_STYLE,BS_OWNERDRAW);
				dlg->id[id].style = 1;
				dlg->id[id].ancienproc = (WNDPROC)SetWindowLong(hwnd,GWL_WNDPROC,(long)Procbutton);
			}
			else if (getinit(1) && (dlg->id[id].deco == 3)) {
				AddWinStyles(hwnd,GWL_STYLE,BS_OWNERDRAW);
				dlg->id[id].style = 1;
				dlg->id[id].ancienproc = (WNDPROC)SetWindowLong(hwnd,GWL_WNDPROC,(long)Procbutton);
//				clip(hwnd);
			}
			else if (getinit(1) && (dlg->id[id].deco == 8)) {
				AddWinStyles(hwnd,GWL_STYLE,BS_OWNERDRAW);
				dlg->id[id].style = 10;
				dlg->id[id].ancienproc = (WNDPROC)SetWindowLong(hwnd,GWL_WNDPROC,(long)Procbutton);
			}
			else if (getinit(1) && (dlg->id[id].deco == 6)) {
				AddWinStyles(hwnd,GWL_STYLE,BS_OWNERDRAW);
				dlg->id[id].style = 8;
				dlg->id[id].ancienproc = (WNDPROC)SetWindowLong(hwnd,GWL_WNDPROC,(long)Procbutton);
			}
		}

	}
	else if (!lstrcmpi(classt,"Listbox")) {

		if (fontlist) {
			SendMessage(hwnd,(UINT)WM_SETFONT,(WPARAM)fontlist,1);
			SendMessage(hwnd,(UINT)WM_SIZE,NULL,NULL);
		}
		if (getinit(3)) {	
//			AddWinStyles(hwnd,GWL_STYLE,LBS_OWNERDRAWFIXED);
			dlg->id[id].style = 4;
		}
	}

	else if (!lstrcmpi(classt,"Static")) {

		if (Styles & STY_TEXTE) {
			char *resultat;
			char tex[255];
			GetWindowText(hwnd,tex,255);
			resultat = C_LEFT(tex,4);
			if ((!lstrcmpi(resultat,"www.")) || (!lstrcmpi(resultat,"WWW.")) || (!lstrcmpi(resultat,"http")) || (!lstrcmpi(resultat,"HTTP"))) {
				Makelink(hwnd);
				dlg->id[id].style = 5;
		//		AddWinStyles(hwnd,GWL_STYLE,SS_OWNERDRAW);
				Styles=0;
			}

		}
		if ((Styles & STY_TEXTE) || (Styles & 1073741824)) {
			if (cTexte2) {
				dlg->id[id].style = 5;
				AddWinStyles(hwnd,GWL_STYLE,SS_OWNERDRAW);
			}

			else {
				dlg->id[id].style = 5;
				if (fonttext) { SendMessage(hwnd,(UINT)WM_SETFONT,(WPARAM)fonttext,1); }
			}

		}


	}
	else if (!lstrcmpi(classt,"Edit")) {
		if (dlg->id[id].deco == 3) {
			if (fontedit) { SendMessage(hwnd,(UINT)WM_SETFONT,(WPARAM)fontedit,1); }
			creerrichedit(hwnd);
			Makeedit(hwnd);
			affrichedit(hwnd);
			updaterichedit(hwnd);
			dlg->id[id].style = 6;
		}
		else if (dlg->id[id].deco == 2) {
			if (fontedit) { SendMessage(hwnd,(UINT)WM_SETFONT,(WPARAM)fontedit,1); }
			dlg->id[id].style = 6;
			Makeedit(hwnd);
		}
	}
	
	return 1;
}

static int az = 0;



mProc(Procprincipale)
{

	LRESULT result;

	LPDIALOG dlg = (LPDIALOG)GetWindowLong(hwnd, GWL_USERDATA);
	if (!dlg) {
		return 0;
	}

	char classt[256];
	char winom[256];


	HWND testhwnd = (HWND)lParam;

	if (IsWindow(testhwnd)) {
		int idtest = GetDlgCtrlID(testhwnd) - 6000 ;

	/*
			if (idtest < 0) {

			wsprintf(mData,"%s id %d","/echo -a TAB =>",idtest);
			SendMessage(mIRC_hwnd,WM_USER + 200,0,0);

			switch (uMsg)
			{
				case WM_CTLCOLORLISTBOX:
				{
					if (ctextelist) {
						SetTextColor((HDC)wParam,ctextelist);
						SetBkMode((HDC)wParam,TRANSPARENT);
					}
					if (hblist) { return (BOOL) hblist; }
				}
				break;
				case WM_CTLCOLORSTATIC:
				{
				SetTextColor((HDC)wParam,cTexte);
				SetBkMode((HDC)wParam, TRANSPARENT);
				return (BOOL)GetStockObject(NULL_BRUSH);
				}
				break;
			}
			}

	*/
		if ((idtest > 0) && (idtest < MAXID)) {
			if (dlg->id[idtest].deco == 1) {
				return CallWindowProc(dlg->testold,hwnd,uMsg,wParam,lParam);
			}
		}
	}

//	if (uMsg != 78) {
//		wsprintf(mData,"%s %d","/echo -ts Test procedure",uMsg);
//		SendMessage(mIRC_hwnd,WM_USER + 200,0,0);
//	}


	switch (uMsg)
	{
	case WM_INITDIALOG:
	{
		//n existe pas !!!!!
	}
	break;

	case WM_DROPFILES:
		{
			OnDropFiles((HDROP) wParam,hwnd);
		}
	break;

/*
	case WM_WINDOWPOSCHANGED:{
		LPWINDOWPOS lpwp;
		lpwp=(LPWINDOWPOS)lParam;

		if ((lpwp->hwndInsertAfter!=NULL) &&(lpwp->x !=0)) {


				wsprintf(mData,"/echo -a WM_WINDOWPOSCHANGED %d > %d et %d %d %d %d",dlg->hwnd,lpwp->hwndInsertAfter,GetNextWindow(dlg->hwnd,GW_HWNDNEXT),GetNextWindow(dlg->hwnd,GW_HWNDPREV),GetTopWindow(dlg->hwnd),GetTopWindow(NULL));
				SendMessage(mIRC_hwnd,WM_USER + 200,0,0);

//			wsprintf(mData,"%s %d","/echo -ta WM_WINDOWPOSCHANGED",lpwp->hwndInsertAfter );
//			SendMessage(mIRC_hwnd,WM_USER + 200,0,0);

			result = CallWindowProc(dlg->testold,hwnd,uMsg,wParam,lParam);

//			HWND prec = GetForegroundWindow();
//			SetForegroundWindow(dlg->hwnd);


			HDC hdc = GetWindowDC(dlg->hwnd);

			dlg->tmp=NULL;
			SetWindowRgn(dlg->hwnd,NULL,TRUE);
			DessinDialog( *dlg ,hdc);

			dlg->tmp=CaptureScreen(hdc,dlg->largeur,dlg->longueur);

			if (dlg->tmp) {
				HRGN rgn = BmpToRgn(dlg->tmp,RGB(0,0,0));
				SetWindowRgn(dlg->hwnd,rgn,TRUE);
				DeleteObject(rgn);
			}

//			SetForegroundWindow(prec);
			return result;
	
		}



	}
	break;
*/
	case WM_NCDESTROY:
	{

		DeleteObject(dlg->tmp);
		for (int n=0;n < dlg->nbreid ;n++) {
			 dlg->id[n].style=0 ;
			 dlg->id[n].ancienproc=0 ;
			 dlg->id[n].deco=0 ;
		}
		free(dlg->id);
		dlg->id=NULL;
		dlg->ptab.hwndbox=0;

//		LCsup((long)dlg->hwnd);

		dlg->hwnd = NULL;



    result = CallWindowProc(dlg->testold,hwnd,uMsg,wParam,lParam);

//	wsprintf(mData,"%s %d","/echo -a Test procedure resulata",result);
//	SendMessage(mIRC_hwnd,WM_USER + 200,0,0);



//	SetWindowLong(dlg->hwnd,GWL_WNDPROC,(long)dlg->testold);
//	SetWindowLong(dlg->hwnd,GWL_USERDATA,(long)0);

	delete dlg;
	return result;

		
	}
	break;
	
    case WM_SETTEXT:
    {
//		wsprintf(mData,"%s","/echo -a WM_SETTEXT");
//		SendMessage(mIRC_hwnd,WM_USER + 200,0,0);
    }
    break;

	case WM_NOTIFY:
	{
		NMHDR *hdr = (NMHDR *)lParam;
		if(hdr->code == NM_COOLSB_CUSTOMDRAW)
		{
			return HandleCustomDraw(wParam, (NMCSBCUSTOMDRAW *)lParam);
		}
	}
	break;
	case WM_CTLCOLORBTN:
	{
//		if(GetWindowLong((HWND)lParam, GWL_ID) == IDST_TXT) {
//		SetBkMode((HDC) wParam, TRANSPARENT);
		return (BOOL)GetStockObject(NULL_BRUSH);
	}
	break;
	case WM_CTLCOLORSTATIC://Dessin des STATICs, RADIOs et CHECKBOXes
		{
			int idtest = GetDlgCtrlID((HWND)lParam) - 6000 ;

//			if (dlg->id[idtest].style == 7)
//			{
//				SetTextColor((HDC)wParam,RGB(255,255,255));
//				SetBkMode((HDC)wParam, RGB(255,255,255));
//				return (BOOL)hbCombo;
//			}
//			else {
				SetTextColor((HDC)wParam,cTexte);
				SetBkMode((HDC)wParam, TRANSPARENT);
				return (BOOL)GetStockObject(NULL_BRUSH);
//			}
		}
	break;
	case WM_CTLCOLORDLG://Couleur de fond de la boite de dialogue
		if (hbDialog) { return (INT_PTR)hbDialog; }
    break;

	case WM_CTLCOLOREDIT://Dessin du contr�le EDIT
		{
			GetClassName((HWND)lParam,classt,256);
			if (!lstrcmpi(classt,"ComboBox"))
           {
				if (ctextecombo) { SetTextColor((HDC)wParam,ctextecombo); }
				if (cfondcombo) {
					SetBkColor((HDC)wParam,cfondcombo);
					SetBkMode((HDC)wParam, TRANSPARENT);
				}
				//if (hbCombo) { return (BOOL) hbCombo; }
				return 1;
			}
			else {
				if (ctexteedit) {
					SetTextColor((HDC)wParam,ctexteedit);
					SetBkMode((HDC)wParam, TRANSPARENT);
				}
//				SetBkColor((HDC)wParam,cfondedit);
				if (hbEdit) { return (BOOL) hbEdit; }
			}
		}
	break;
	case WM_CTLCOLORSCROLLBAR://Dessin des SCROLLBARs
		{
			if (hbScroll) { return (BOOL) hbScroll; }
		}
	break;
	case WM_TIMER:
		{
		dlg->tim++;
		if (dlg->tim > 2) { dlg->tim = 0; }
		afftitre(hwnd,dlg->tim);
		}
	break;
	case WM_ERASEBKGND:
		{
//		return (LRESULT)0L;
		}
	break;
	case WM_PAINT:

		{

		HDC hdc;
		hdc = GetWindowDC(hwnd);

		if ((GetForegroundWindow() == dlg->hwnd) && (!dlg->tmp))  {

			RECT rt;
			GetWindowRect(dlg->hwnd,&rt);
			AdjustRectCoords(dlg->hwnd,&rt);
			FillRect(hdc,&rt,hbDialog);
			DessinDialog( *dlg ,hdc);
			dlg->tmp=CaptureScreen(hdc,dlg->largeur,dlg->longueur);
			if (dlg->tmp) {
				HRGN rgn = BmpToRgn(dlg->tmp,cinvisible);
				SetWindowRgn(dlg->hwnd,rgn,TRUE);
				DeleteObject(rgn);
			}
		}


//		RECT rt;
//		GetWindowRect(hwnd,&rt);
//		AdjustRectCoords(hwnd,&rt);
//		FillRect(hdc,&rt,hbDialog);


		if ((getinit(10)) &&(dlg->tmp != (HBITMAP)1)) {
			DessinDialog(*dlg,hdc);
			afftitre(hwnd,dlg->tim);
		}


		//Rafraichissement des controls pour �viter qu'ils passent sous l'image
		HWND titest2;
		titest2 = ::FindWindowEx(hwnd,NULL,NULL,NULL);
		RECT retest;
		GetWindowRect(hwnd,&retest);
		while (::FindWindowEx(hwnd,titest2,NULL,NULL) != NULL) {
			titest2 = FindWindowEx(hwnd,titest2,NULL,NULL);
			::GetWindowRect(titest2,&retest);
			::InvalidateRect(titest2,NULL,false);
		}

		result = CallWindowProc(dlg->testold,hwnd,uMsg,WPARAM(hdc),lParam);
	

		DeleteDC(hdc);
		return result;

		}
    break;

	case WM_LBUTTONDOWN:
		{
			pasrichedit();
			POINT pm;
			GetCursorPos(&pm);
			RECT rt;
			GetWindowRect( hwnd, &rt);
//	        cy = GetSystemMetrics(SM_CYSCREEN);
			if ((pm.y > rt.top) && (pm.y < rt.top + 30)){
				PostMessage (hwnd, WM_NCLBUTTONDOWN, HTCAPTION, lParam);
			}
		}
    break;
	/*
	case WM_MOUSELEAVE:
		{
			qw = 0;
		}
		break;
	case WM_MOUSEMOVE:
	 {
		 if (!qw) {
			 qw = 1;

		
			
			sourie.cbSize = sizeof(TRACKMOUSEEVENT);
			sourie.hwndTrack = hwnd;
			sourie.dwHoverTime = 1;
			sourie.dwFlags = TME_LEAVE;

			_TrackMouseEvent(&sourie);
			HWND a = sourie.hwndTrack;
			wsprintf(mData,"%s %d","/echo -a WM_MOUSEHOVER",a);
			SendMessage(mIRC_hwnd,WM_USER + 200,0,0);
		 }
	 }
	 break;
*/
  case WM_DRAWITEM:
	  //Dessin des controls
		{
		    LPDRAWITEMSTRUCT lpdis = (LPDRAWITEMSTRUCT)lParam;
			LONG Styles = GetWindowLong(lpdis->hwndItem, GWL_STYLE);

        	GetClassName(lpdis->hwndItem,classt,256);
			GetWindowText(lpdis->hwndItem,winom,256);

			if (!lstrcmpi(classt,"Static")) {
				int id = GetDlgCtrlID(lpdis->hwndItem) - 6000 ;
				if (dlg->id[id].deco == 3) {
					if (lstrcmpi(winom,"")) {
						Dessinerprogress(lpdis,winom);
					}
				}
				else {

					RECT rt;
					HFONT hOldFont;
					char texte[255];
					GetWindowText(lpdis->hwndItem,texte,256);
					GetClientRect(lpdis->hwndItem ,&rt);
					SetBkMode(lpdis->hDC, TRANSPARENT);
		
					if (fonttext) { hOldFont = (HFONT) SelectObject(lpdis->hDC, fonttext); }
					SetTextColor(lpdis->hDC,cTexte2);
					DrawText(lpdis->hDC,texte,strlen(texte),&rt,DT_WORDBREAK);
					SetTextColor(lpdis->hDC,cTexte);
					rt.top+=1;
					rt.left+=1;
					DrawText(lpdis->hDC,texte,strlen(texte),&rt,DT_WORDBREAK);
					if (fonttext) { SelectObject(lpdis->hDC, hOldFont); }
				}
			}
			if (!lstrcmpi(classt,"Button"))
            {
				int id = GetDlgCtrlID(lpdis->hwndItem) - 6000 ;
				bool survol = ( dlg->hpasse == lpdis->hwndItem );

				if (dlg->id[id].style == 1)
				{
					if (dlg->id[id].deco == 3) {
						DessinerSkinBouton(lpdis->hwndItem,lpdis,winom,hbDialog,survol);
					}
					else {
						DessinerBouton(lpdis,winom,RGB(255,255,0),survol);
					}
					return TRUE;
				}
				else if (dlg->id[id].style == 10) {
					DessinerBouton(lpdis,winom,RGB(255,255,0),survol);
				}
				else if (dlg->id[id].style == 11) {
					DessinerBouton(lpdis,winom,RGB(255,255,0),survol);
				}
				else if (dlg->id[id].style == 2)
				{
					if (Styles & BS_PUSHLIKE) {
						DessinerBouton(lpdis,winom,RGB(255,255,0),survol,dlg->id[id].state);
					}
					else {
						DessinerCheck(lpdis,winom,hbDialog,dlg->id[id].state,survol);
					}
					return TRUE;
				}
				else if (dlg->id[id].style == 3)
				{
					DessinerRadio(lpdis,winom,hbDialog,dlg->id[id].state,survol);
					return TRUE;
				}
				else if (dlg->id[id].style == 7)
				{
					DessinerBox(lpdis,winom,RGB(0,0,255),hbDialog);
					return TRUE;
				}
				else if (dlg->id[id].style == 8) {
					Dessinertrackbar(lpdis,winom,survol);
				}


			}

		}
	break;
	case WM_CTLCOLORLISTBOX://Dessin de la LISTBOX
		{

			GetClassName((HWND)lParam,classt,256);

			if (!lstrcmpi(classt,"ComboLBox"))
            {
				if (ctextecombo) { SetTextColor((HDC)wParam,ctextecombo); }
				if (cfondcombo) {
					SetBkColor((HDC)wParam,cfondcombo);
					SetBkMode((HDC)wParam, TRANSPARENT);
				}
				if (hbCombo) return (BOOL)hbCombo;
			}
			else if (!lstrcmpi(classt,"listbox"))
			{

//				if (GetWindowLong((HWND)lParam, GWL_USERDATA) != NULL) {
//					updateLV((HWND)lParam,(HWND)GetWindowLong((HWND)lParam, GWL_USERDATA));
//				}


//		wsprintf(mData,"%s hwnd %d hdc %d","/echo -a WM_CTLCOLORLISTBOX",(HWND)lParam,(HDC)wParam);
//		SendMessage(mIRC_hwnd,WM_USER + 200,0,0);
/*
				int id = GetDlgCtrlID((HWND)lParam) - 6000 ;
				if (getinit(3)  && (dlg->id[id].deco == 3)) {
					SetTextColor((HDC)wParam,RGB(255,255,0));
					SetBkMode((HDC)wParam,TRANSPARENT);
					dessinlistbox((HWND)lParam,(HDC)wParam);
				}
				else {
*/
					if (ctextelist) {
						SetTextColor((HDC)wParam,ctextelist);
						SetBkMode((HDC)wParam,TRANSPARENT);
					}
					if (hblist) { return (BOOL) hblist; }
//				}
				return 0;
			}
		}
	break;
//	case WM_SETCURSOR:
//		{
//
//		}
//	break;
	case WM_COMMAND://Clic sur un contr�le
		{

/*
		if (wParam == 2) {
			DestroyWindow(hwnd);
			return 0;	
			char text [255];
//			wsprintf(text,"%s %d %s","//var %i = 1 | while $dialog(%i) { if $dialog(%i).hwnd == ", hwnd ,"{ //dialog -x $dialog(%i) } | inc %i }");
//			mIRCcom(text);

//			return 0;
			/*
			HWND hwnd2 = GetDlgItem(hwnd,55 + 6000);


	SetWindowLong(dlg->hwnd,GWL_WNDPROC,(long)dlg->testold);
	SetWindowLong(dlg->hwnd,GWL_USERDATA,(long)0);

//result = CallWindowProc(dlg->testold,hwnd,uMsg,wParam,lParam);
delete dlg;
return result;
//			dlg->id[55].deco = 1;
			SetWindowLong(hwnd2,GWL_WNDPROC,(long)dlg->id[55].ancienproc);
			SetWindowLong(hwnd2,GWL_USERDATA,(long)0);
			RemoveWinStyles(hwnd2,GWL_STYLE,BS_OWNERDRAW);


			return result;

		}
*/
		switch(HIWORD(wParam))
		{

//		case CM_EDIT:
//			{
//			wsprintf(mData,"%s","/echo -a CM_EDIT");
//			SendMessage(mIRC_hwnd,WM_USER + 200,0,0);
//			}
//		break;
		case EN_CHANGE:{
			int id = GetDlgCtrlID((HWND)lParam) - 6000 ;
			if (dlg->id[id].deco == 3) {
//				wsprintf(mData,"%s","/echo -a EN_CHANGE");
//				SendMessage(mIRC_hwnd,WM_USER + 200,0,0);
				updaterichedit((HWND)lParam);
			}
		}
		break;
		case EN_SETFOCUS:
			{
			suprichedit((HWND)lParam);
			return 0;
			}
		break;
		case EN_KILLFOCUS:
			{
			affrichedit((HWND)lParam);
			return 0;
			}
		break;
		case LBN_SELCHANGE:
			{
//			wsprintf(mData,"%s %d %d","/echo -a selchnage",wParam,lParam);
//			SendMessage(mIRC_hwnd,WM_USER + 200,0,0);
		//	InvalidateRect((HWND)lParam, 0, 1);
			}
		break;
		case BN_CLICKED:
			GetClassName((HWND)lParam,classt,256);
			LONG Styles = GetWindowLong((HWND)lParam, GWL_STYLE);

//			wsprintf(mData,"%s %d","/echo -a click",Styles);
//			SendMessage(mIRC_hwnd,WM_USER + 200,0,0);
//			WORD aa = HIWORD(wParam);
//			DWORD aaa = HIWORD(wParam);

			if (!lstrcmpi(classt,"Button")) {

			int id = GetDlgCtrlID((HWND)lParam) - 6000 ;
			int aa = HIWORD(wParam);


			if (dlg->id[id].style == 1) {
			     RemoveWinStyles((HWND)lParam,GWL_STYLE,BS_OWNERDRAW);
				 result = CallWindowProc(dlg->testold,hwnd,uMsg,wParam,lParam);
				 AddWinStyles((HWND)lParam,GWL_STYLE,BS_OWNERDRAW);
				 return result;
			}
			else if (dlg->id[id].style == 8) {
				 POINT pm={0,0};
				 updatetrack((HWND)lParam,pm,1);
			     RemoveWinStyles((HWND)lParam,GWL_STYLE,BS_OWNERDRAW);
				 result = CallWindowProc(dlg->testold,hwnd,uMsg,wParam,lParam);
				 AddWinStyles((HWND)lParam,GWL_STYLE,BS_OWNERDRAW);
				 return result;
			}
			else if (dlg->id[id].style == 10) {
			     RemoveWinStyles((HWND)lParam,GWL_STYLE,BS_OWNERDRAW|BS_ICON);
				 result = CallWindowProc(dlg->testold,hwnd,uMsg,wParam,lParam);
				 AddWinStyles((HWND)lParam,GWL_STYLE,BS_OWNERDRAW|BS_ICON);
				 return result;
			}
			else if (dlg->id[id].deco == 4) {
			     RemoveWinStyles((HWND)lParam,GWL_STYLE,BS_BITMAP);
				 result = CallWindowProc(dlg->testold,hwnd,uMsg,wParam,lParam);
				 AddWinStyles((HWND)lParam,GWL_STYLE,BS_BITMAP);
				 return result;
			}
			else if (dlg->id[id].deco == 5) {
			     RemoveWinStyles((HWND)lParam,GWL_STYLE,BS_ICON);
				 result = CallWindowProc(dlg->testold,hwnd,uMsg,wParam,lParam);
				 AddWinStyles((HWND)lParam,GWL_STYLE,BS_ICON);
				 return result;
			}
			else if (dlg->id[id].style == 2)
			{
				dlg->id[id].state = (1 - dlg->id[id].state) ? true : false;;

				RemoveWinStyles((HWND)lParam,GWL_STYLE,BS_OWNERDRAW);
				AddWinStyles((HWND)lParam,GWL_STYLE,BS_AUTOCHECKBOX);

				if (dlg->id[id].state == 1) {
					SendMessage ( (HWND)lParam, BM_SETCHECK, (WPARAM) BST_CHECKED, 0 );
				}
				else {
					SendMessage ( (HWND)lParam, BM_SETCHECK, (WPARAM) BST_UNCHECKED, 0 );
					CallWindowProc(dlg->testold,hwnd,uMsg,wParam,lParam);
				}
				AddWinStyles((HWND)lParam,GWL_STYLE,BS_OWNERDRAW);
		
			}
			/*
			else if (dlg->id[id].style == 8)
			{
				GetWindowText((HWND)lParam,winom,256);
			POINT pm;
			GetCursorPos(&pm);
		wsprintf(mData,"%s donne %d","/echo -a trackbar",pm.x);
	    SendMessage(mIRC_hwnd,WM_USER + 200,0,0);
			}
			*/
			else if (dlg->id[id].style == 3)
			{
				HWND htmp = GetNextDlgGroupItem(dlg->hwnd,(HWND)lParam,true);
				HWND htmp2 = htmp;

				while ( htmp != NULL) {

					int id2 = GetDlgCtrlID(htmp) - 6000 ;
					if (id2 > 0) {

						if (dlg->id[id2].style == 3) {

							RemoveWinStyles(htmp,GWL_STYLE,BS_OWNERDRAW);
							AddWinStyles(htmp,GWL_STYLE,BS_AUTORADIOBUTTON);

							if (htmp == (HWND)lParam) {
								dlg->id[ id2 ].state = 1;
								SendMessage ( htmp, BM_SETCHECK, (WPARAM) BST_CHECKED, 0 );
							}
							else {
								dlg->id[id2].state = 0;
								SendMessage ( htmp, BM_SETCHECK, (WPARAM) BST_UNCHECKED, 0 );
								CallWindowProc(dlg->testold,hwnd,uMsg,wParam,lParam);
							}
							AddWinStyles(htmp,GWL_STYLE,BS_OWNERDRAW);
						}
					}

					htmp = GetNextDlgGroupItem(dlg->hwnd,htmp,true);
					if (htmp == htmp2) { htmp = NULL; }
				}
			}
			}
		}
		break;
		}
	break;
	case WM_CLOSE:
		{
	//		return 0;
		}

/* DESACTIV2E Mai je sais pas pourkoi ??????
    case WM_NCPAINT:
		{
		return (LRESULT)0L;
		}
	break;
*/


//par d�fault, redonne la main a mIrc pour la gestion du dialog
//	default:
//		result = CallWindowProc(dlg->testold,hwnd,uMsg,wParam,lParam);
	}

	if (!dlg->testold) { return 0;}
    result = CallWindowProc(dlg->testold,hwnd,uMsg,wParam,lParam);
	return result;
}

extern "C"
{
	void WINAPI LoadDll(LOADINFO *li)
	{
		mIRC_hwnd = li->mHwnd;
		//create file mapping
		hFileMap = CreateFileMapping(INVALID_HANDLE_VALUE,0,PAGE_READWRITE,0,4096,"mIRC");	
		mData = (LPSTR)MapViewOfFile(hFileMap,FILE_MAP_ALL_ACCESS,0,0,0);

		handletheme = LoadLibrary("uxtheme.dll");
		if (handletheme != NULL)
		{
			fonctiontheme=(PFONCTION) GetProcAddress(handletheme,"SetWindowTheme");
			if (fonctiontheme == NULL)
				{
					FreeLibrary(handletheme);
				}		
		}
		initRE();
	//	CoolSB_InitializeApp();

	}

int WINAPI UnloadDll(int timeout)
{
	if (!timeout)
	{
		cleartab();
		cleardessin();
		clearrichedit();
		clearcustom();
		clearcombo();
		clearbox();
		cleardessin();
		clearlistview();
		clearedit();
/*
		HWND titest2 = ::FindWindowEx(mIRC_hwnd,NULL,NULL,NULL);
		while (::FindWindowEx(mIRC_hwnd,titest2,NULL,NULL) != NULL) {
			titest2 = FindWindowEx(mIRC_hwnd,titest2,NULL,NULL);
			DestroyWindow(titest2);
		}
*/


		clearScroll();
		//close file mapping
		UnmapViewOfFile(mData);
		CloseHandle(hFileMap);
		if (fonctiontheme != NULL)
		{
			FreeLibrary(handletheme);
		}

	//	CoolSB_UninitializeApp();

	}
	return 0;
}



	mirc(Base)
	{

	char commande[0xFFF],val1[0xFFFF],val2[0xFFFF],val3[0xFFFF],val4[0xFFFF];

	wsprintf(commande,"%s",strtok(data," "));
	wsprintf(val1,"%s",strtok(NULL," "));
	wsprintf(val2,"%s",strtok(NULL," "));
	wsprintf(val3,"%s",strtok(NULL," "));
	wsprintf(val4,"%s",strtok(NULL," "));

	long vale1,vale2,vale3,vale4;
	vale1 = atoi(val1);
	vale2 = atoi(val2);
	vale3 = atoi(val3);
	vale4 = atoi(val4);

	if (!lstrcmpi(val1,"fond")) {
		HBITMAP hhh = LoadAnImage(val2);
		if (!lstrcmpi(commande,"edit")) { hbEdit= CreatePatternBrush(hhh); }
//		if (!lstrcmpi(commande,"combo")) { cfondcombo = vale2; ctextecombo = vale1; }
		if (!lstrcmpi(commande,"list")) { hblist = CreatePatternBrush(hhh); }
		if (!lstrcmpi(commande,"scrollbar")) { hbScroll = CreatePatternBrush(hhh); }
		if (!lstrcmpi(commande,"dialog")) { hbDialog = Setfond(hhh); }
	}
	else {
		if (!lstrcmpi(commande,"fond")) { cfond = vale1 ; hbDialog = CreateSolidBrush(vale1); }
		if (!lstrcmpi(commande,"fondedit")) { hbEdit = CreateSolidBrush(vale1); }
		if (!lstrcmpi(commande,"texte")) { cTexte = vale1; cTexte2 = vale2; }
		if (!lstrcmpi(commande,"edit")) { if (val2) hbEdit= CreateSolidBrush(vale2); ctexteedit = vale1; }
		if (!lstrcmpi(commande,"texte")) { cTexte = vale1; }
		if (!lstrcmpi(commande,"policetexte")) { fonttext = MakeFont(val1, (LPARAM)vale2, vale3 ? true : false, vale4 ? true : false ); }
		if (!lstrcmpi(commande,"policeedit")) { fontedit = MakeFont(val1, (LPARAM)vale2, vale3 ? true : false, vale4 ? true : false ); }
		if (!lstrcmpi(commande,"policelist")) { fontlist = MakeFont(val1, (LPARAM)vale2, vale3 ? true : false, vale4 ? true : false ); }
		if (!lstrcmpi(commande,"policecombo")) { fontcombo = MakeFont(val1, (LPARAM)vale2, vale3 ? true : false, vale4 ? true : false ); }
		if (!lstrcmpi(commande,"combo")) { if (val2) { cfondcombo = vale2; hbCombo=CreateSolidBrush(vale2); } ctextecombo = vale1; }
		if (!lstrcmpi(commande,"list")) { if (val2) hblist = CreateSolidBrush(vale2) ; ctextelist = vale1; }
		if (!lstrcmpi(commande,"scrollbar")) { hbScroll = CreateSolidBrush(vale1); }
	}
		lstrcpy(data,"S_OK");
		return 3;
	}

	mirc(init)
	{
		if (inithandle(data) == 0) { lstrcpy(data,"S_OK"); }
		else { lstrcpy(data,"ERR Erreur de fichiers deco"); }
		return 3;
	}


	mirc(Mark)
	{
		HWND tmphwnd = (HWND)atol(data);

		if (tmphwnd == NULL) { wsprintf(data,"Wrong handle for mark"); return 3; }
		

		long g = GetWindowLong(tmphwnd, GWL_USERDATA);
		if (g) { wsprintf(data,"Already marked"); return 3; }

//		hDlg = 0;
//		while (::IsWindow(dlg->hwnd)) hDlg++;
//		if (hDlg >= MAXDIAG) { wsprintf(data,"FULL"); return 3; }

		if (!IsWindow(tmphwnd)) {
			lstrcpy(data,"ERR wrong handle");
			return 3;
		}

		//ok tout est bon on peux y aller

		hwndmarked=tmphwnd;

		LPDIALOG dlg = new DIALOG;
		
		SetWindowLong(tmphwnd, GWL_USERDATA,(long)dlg);

//		LCnetoye();
//		long t = LCinser_debut((long)tmphwnd,(long)dlg);
//		if (t == NULL) { lstrcpy(data,"ERR prb interne"); return 3; }
//		LCrecherche((long)tmphwnd);

		dlg->nbreid=1;
		HWND titest2 = ::FindWindowEx(tmphwnd,NULL,NULL,NULL);
		while (::FindWindowEx(tmphwnd,titest2,NULL,NULL) != NULL) {
			titest2 = FindWindowEx(tmphwnd,titest2,NULL,NULL);
			dlg->nbreid+=1;
		}

//		free(dlg->id);
		dlg->id=(DATADIAG*) malloc(dlg->nbreid*sizeof(DATADIAG));


		for (int n=0;n < dlg->nbreid ;n++) {
			 dlg->id[n].style=0 ;
			 dlg->id[n].ancienproc=0 ;
			 dlg->id[n].deco=0 ;
		}

		dlg->hwnd = tmphwnd;
		dlg->testold = NULL;
		dlg->ptab.max=0;

		lstrcpy(data,"S_Ok dialog marked");
		return 3;
	}

	mirc(Custom)
	{


		HWND hwnd = GetMarkHwnd();
		if (!IsWindow(hwnd)) { wsprintf(data,"ERR Dialog lost Mark"); return 3; }
		LPDIALOG dlg = (LPDIALOG)GetWindowLong(hwnd, GWL_USERDATA);
		if (!dlg) { wsprintf(data,"ERR Dialog lost Mark"); return 3; }

		if (dlg->testold) { wsprintf(data,"ERR Already customised"); return 3; }

		RECT rt;
		GetWindowRect( dlg->hwnd, &rt);
		dlg->largeur = rt.right-rt.left;
		dlg->longueur =rt.bottom-rt.top;

		dlg->testold = (WNDPROC)SetWindowLong(dlg->hwnd,GWL_WNDPROC,(long)Procprincipale);

		EnumChildWindows(dlg->hwnd,EnumChildProc,0);

		bool bb = 0;
		if (!lstrcmpi(data,"noborder")) {
			bb = 1;
			dlg->tmp=(HBITMAP)1;
			//SetWindowLong(dlg->hwnd,GWL_STYLE,::GetWindowLong(dlg->hwnd,GWL_STYLE) &~ WS_CAPTION);
		}
		
		if (getinit(10) && (dlg->largeur > 100) && (dlg->longueur>100) && (bb == 0)) {

			SetWindowLong(dlg->hwnd,GWL_STYLE,::GetWindowLong(dlg->hwnd,GWL_STYLE) &~ WS_CAPTION);

			//applique le decor
			HDC hdc;
			hdc = GetWindowDC(dlg->hwnd);


			ShowWindow(dlg->hwnd,SW_SHOW);
		//	SetWindowPos(dlg->hwnd, HWND_TOPMOST, rt.left, rt.top, dlg->largeur, dlg->longueur, SWP_NOSENDCHANGING);
		//	ShowWindow(dlg->hwnd,SW_SHOW);
		//	SetWindowPos(dlg->hwnd, HWND_TOPMOST, rt.left, rt.top, dlg->largeur, dlg->longueur, SWP_NOSENDCHANGING);

			dlg->tmp=NULL;

			if (GetForegroundWindow() == dlg->hwnd) {

				RECT rt;
				GetWindowRect(dlg->hwnd,&rt);
				AdjustRectCoords(dlg->hwnd,&rt);
				FillRect(hdc,&rt,hbDialog);

				DessinDialog( *dlg ,hdc);

				dlg->tmp=CaptureScreen(hdc,dlg->largeur,dlg->longueur);

				if (dlg->tmp) {
					HRGN rgn = BmpToRgn(dlg->tmp,cinvisible);
					SetWindowRgn(dlg->hwnd,rgn,TRUE);
					DeleteObject(rgn);
				}
			}
			else {
				SetWindowRgn(dlg->hwnd,NULL,TRUE);
			}

//			//http://msdn.microsoft.com/library/default.asp?url=/library/en-us/sysinfo/base/changing_the_colors_of_window_elements.asp
//			int aiElements[3] = {COLOR_3DHIGHLIGHT, COLOR_CAPTIONTEXT,COLOR_3DHILIGHT };
//			DWORD aColors[3];
//			aColors[0] = RGB(255, 0, 0);
//			aColors[1] = RGB(255, 0, 0);
//			aColors[2] = RGB(255, 0, 0);
//			SetSysColors(3, aiElements, aColors); 

			SetWindowPos(dlg->hwnd, HWND_NOTOPMOST, rt.left, rt.top, dlg->largeur, dlg->longueur, SWP_NOSENDCHANGING);
		//	DeleteObject(htmp);

			ReleaseDC(dlg->hwnd,hdc);
		}

		

	//	InvalidateRect(dlg->hwnd, 0, 1);

		if (getanim()) { SetTimer(dlg->hwnd, 1, 500, NULL); }

		wsprintf(data,"S_OK");

		return 3;
	}	

}


//*****************************************************************

/*
int GethMark()
{
	if (!IsWindow(dlg[hMark].hwnd)) { return -1; }
	return hMark;
}
*/

HWND GethIDhwnd(int id)
{
	HWND hwnd = GetDlgItem(hwndmarked,id + 6000);
	if (!hwnd) { return 0; }
	return hwnd;
}

HWND GetMarkHwnd() {
	if (!IsWindow(hwndmarked)) { return NULL; }
	return hwndmarked;
}



mirc(Detail)
	{

//	int hDlg = GethMark();

	HWND hwnd = GetMarkHwnd();
//	if (!hwnd) { wsprintf(data,"ERR Dialog lost Mark"); return 3; }
	if (!IsWindow(hwnd)) { wsprintf(data,"ERR Dialog lost Mark"); return 3; }
	LPDIALOG dlg = (LPDIALOG)GetWindowLong(hwnd, GWL_USERDATA);
	if (!dlg) { wsprintf(data,"ERR Dialog lost Mark"); return 3; }

	char commande[0xFFF],IDs[0xFFFF],val1[0xFFFF];

	wsprintf(commande,"%s",strtok(data," "));
	wsprintf(IDs,"%s",strtok(NULL," "));
	wsprintf(val1,"%s",strtok(NULL," "));

	int ID = atol(IDs);

	if (!lstrcmpi(commande,"normal")) { 
		dlg->id[ID].deco = 1;
//		if (!hbmp) { lstrcpy(data,"mauvais boutton"); return 3; }
		lstrcpy(data,"S_OK");
	}
	if (!lstrcmpi(commande,"forme")) { 
		dlg->id[ID].deco = 2;
		lstrcpy(data,"S_OK");
	}
	if (!lstrcmpi(commande,"Skin")) {
		HWND hwntmp = GetDlgItem(dlg->hwnd,ID + 6000);
		char classt[256];
		GetClassName(hwntmp,classt,256);
		dlg->id[ID].deco = 3;
		if (!lstrcmpi(classt,"Button")) {
			HBITMAP htmp = LoadAnImage(val1);
			if (!htmp) { lstrcpy(data,"mauvais boutton skin"); return 3; }
			initskinbut(htmp,hwntmp,val1);
		}
		lstrcpy(data,"S_OK");
	}
	if (!lstrcmpi(commande,"Richedit")) {
		HWND hwntmp = GetDlgItem(dlg->hwnd,ID + 6000);
		char classt[256];
		GetClassName(hwntmp,classt,256);
		if (!lstrcmpi(classt,"Edit")) {
			dlg->id[ID].deco = 3;
		}
		lstrcpy(data,"S_OK");
	}
	if (!lstrcmpi(commande,"ProgressBar")) {
		HWND hwntmp = GetDlgItem(dlg->hwnd,ID + 6000);
		char classt[256];
		GetClassName(hwntmp,classt,256);
		if (!lstrcmpi(classt,"Static")) {
			dlg->id[ID].deco = 3;
		}
		lstrcpy(data,"S_OK");
	}
	if (!lstrcmpi(commande,"Trackbar")) {
		HWND hwntmp = GetDlgItem(dlg->hwnd,ID + 6000);
		char classt[256];
		GetClassName(hwntmp,classt,256);
		if (!lstrcmpi(classt,"Button")) {
			dlg->id[ID].deco = 6;
		}
		lstrcpy(data,"S_OK");
	}
	if (!lstrcmpi(commande,"img")) {
		dlg->id[ID].deco = 4;
//		DecoBoutton(dlg->hwnd,ID,val1,1);
		lstrcpy(data,DecoBoutton(dlg->hwnd,ID,val1,1));
	}
	if (!lstrcmpi(commande,"icone")) {
		dlg->id[ID].deco = 5;
		lstrcpy(data,DecoBoutton(dlg->hwnd,ID,val1,2));
	}
	if (!lstrcmpi(commande,"iconetext")) {
		HWND hwntmp = GetDlgItem(dlg->hwnd,ID + 6000);
		char classt[256];
		GetClassName(hwntmp,classt,256);
		if (!lstrcmpi(classt,"Button")) {
			dlg->id[ID].deco = 8;
/*		
AddWinStyles(hwntmp,GWL_STYLE,BS_BITMAP);
		HBITMAP hImage = (HBITMAP)LoadImage(0,val1,IMAGE_ICON,32,32,LR_LOADFROMFILE);
		if (!hImage) { lstrcpy(data,"S_Err"); return 3; }
		long r = SendMessage(hwntmp, BM_SETIMAGE, (WPARAM)IMAGE_ICON, (LPARAM)(HANDLE)hImage);
*/
	lstrcpy(data,DecoBoutton(dlg->hwnd,ID,val1,2));

//	HWND hwndicone = (HWND)SendMessage(hwntmp,BM_GETIMAGE,(WPARAM)IMAGE_ICON,0);
//	if (!hwndicone) {
//		int b = 3;
//	}


		}
		else lstrcpy(data,"S_Err :WRONG ID");
	}
	

	return 3;
}

void clearcustom() {
	DeleteObject(fonttext); DeleteObject(fontedit); DeleteObject(fontlist); DeleteObject(fontcombo); 
	DeleteObject(hbList);
	DeleteObject(hbDialog);
	DeleteObject(hbEdit);
	DeleteObject(hbScroll);
	DeleteObject(hbCombo);
	DeleteObject(hblist);
}

void notheme(HWND hwnd) {
	if (fonctiontheme) fonctiontheme(hwnd,L" ",L" ");
}


mirc(Cleardata) {
	cleartab();
	cleardessin();
	clearrichedit();
	clearcustom();
	clearcombo();
	clearbox();
	cleardessin();
	clearlistview();
	clearedit();
	wsprintf(data,"S_ok");
	return 3;
}
mirc(info)
{
	wsprintf(data,"NsRnTheme Nemesis Revolution www.nsrn.fr.st V0.5");
	return 3;
}
mirc(version)
{
	wsprintf(data,"NsRnTheme Nemesis Revolution www.nsrn.fr.st V0.5");
	return 3;
}