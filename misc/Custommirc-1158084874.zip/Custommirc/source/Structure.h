typedef struct tagMYLV
{
	WNDPROC proc;
	HWND hwnd;
	bool scroll;
} MYLV,*LPMYLV;



typedef struct
{
	DWORD  mVersion;
	HWND   mHwnd;
	BOOL   mKeep;
} LOADINFO;


struct DATADIAG
{
	bool state;
	int style;
	WNDPROC ancienproc;
	int deco;
};

struct TAB
{
	char texte[255];
	HWND hwnd;
	HICON hicon;
};

typedef struct tagTABMIRC {

 	TAB tab[20];
	int max;
	RECT rteff;
	HWND hwndbox;
//	HWND htab;
	WNDPROC ancienproc;

} TABMIRC,*LPTABMIRC;


//Structure encadrant chaque dialog
typedef struct DIALOG
{
	WNDPROC testold;
	HBITMAP tmp;
	HWND hwnd;
	BOOL move;
	DATADIAG *id;
	HWND hpasse;
	TABMIRC ptab;
	int largeur;
	int longueur;
	int tim;
	int nbreid;
//	int ID[500];
}*LPDIALOG;

;
//65535 dialog possible
//struct DIALOG dlg[0xFFFF];

struct LISTCHAIN
{
	long pointeur;
	long valeur;
	LISTCHAIN *next;
};
