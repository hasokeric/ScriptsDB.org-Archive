
#include <windows.h>
#include "fonction.h"
#include "Structure.h"


void mIRCaff(char *text);
void clearfond(HDC hdc,HWND hwnd,RECT rt);

HFONT fonttitre=NULL;
extern COLORREF cinvisible;

bool progdeg = 0;
bool progsens = 0;

HBRUSH ccouleurprogb;
COLORREF ccouleurprog;
COLORREF cTextetitre=0;
COLORREF cTextetitre2=0;

HBRUSH cfondprog;
HBRUSH cbordprog;

HBITMAP htrackh;
HBITMAP htrackv;
HBITMAP htrackregh;
HBITMAP htrackregv;

HBITMAP hProgressv;
HBITMAP hProgressh;
HBITMAP hProgressbarv;
HBITMAP hProgressbarh;

int titreX=60;
int titreY=7;
int animation=0;
int formattitre = 8;
int decprog=4;
int tailleicone=16;

#define mirc(bleh) int __stdcall WINAPI bleh(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)


/*
struct DATADIAG
{
	bool state;
	int style;
	WNDPROC ancienproc;
	int deco;
};


//Structure encadrant chaque dialog
struct TAB
{
	char texte[255];
	HWND hwnd;
	HICON hicon;
};

typedef struct tagTABMIRC {

 	TAB tab[20];
	int max;
	RECT rteff;
	HWND hwndbox;
	HWND htab;
	WNDPROC ancienproc;

} TABMIRC,*LPTABMIRC;
#define MAXID 300

//Structure encadrant chaque dialog
struct DIALOG
{
	WNDPROC testold;
	HBITMAP tmp;
	HWND hwnd;
	BOOL move;
	DATADIAG id[MAXID];
	HWND hpasse;
	TABMIRC ptab;
	int largeur;
	int longueur;
	int tim;
//	int ID[500];
};
*/

HBITMAP hbmp;
HBITMAP htoolbmp;

HBITMAP htooldbmp;
HBITMAP htoolcbmp;
HBITMAP htoolgbmp;
HBITMAP htooltitrebmp;

HBITMAP hlistbmp;
HBITMAP hfondbmp;
HBITMAP hbcotebmp;
HBITMAP hcotebasbmp;
HBITMAP hcotehautbmp;
HBITMAP hcheck;

static COLORREF ctextboutton = RGB(255,0,0);
static COLORREF ctextcheck = RGB(255,0,0);
static COLORREF ctextboutton2 = 0;
static COLORREF ctextcheck2 = 0;


static bool okdeco = 0;

int largtrack=30;
int crantrack=1;
HBRUSH rouge=CreateSolidBrush(RGB(255,0,0));
int dectrack=0;

//HFONT MakeFont (char *Font, int PointSize, bool Italic, int Bold,bool under=0);
HFONT fontboutton = NULL;
HFONT fontcheckradio = NULL;



//****************************************************************************

mirc(Titre)
	{

	if (!lstrcmpi(gettok(data,1," "),"police")) {
		fonttitre = MakeFont(gettok(data,2," "), (LPARAM)atoi(gettok(data,3," ")), atoi(gettok(data,4," ")) ? true : false, atoi(gettok(data,5," ")) ? true : false );
		formattitre = atoi(gettok(data,3," "));
	}

	if (!lstrcmpi(gettok(data,1," "),"texte")) { cTextetitre = atoi(gettok(data,2," ")); cTextetitre = atoi(gettok(data,3," "));}

	if (!lstrcmpi(gettok(data,1," "),"origine")) { titreX = atoi(gettok(data,2," ")); titreY = atoi(gettok(data,3," "));}

//	if (!lstrcmpi(commande,"animation")) { animation = vale1;}

	lstrcpy(data,"S_OK");
	return 3;
}


mirc(Boutton)
	{
	if (!lstrcmpi(gettok(data,1," "),"3etat")) {
		hbmp = LoadAnImage(gettok(data,2," ",1));
		if (!hbmp) { lstrcpy(data,"mauvais boutton 3etat"); return 3; }
	}
	if (!lstrcmpi(gettok(data,1," "),"texte")) { ctextboutton = atoi(gettok(data,2," ")); ctextboutton2 = atoi(gettok(data,3," ")); }
	if (!lstrcmpi(gettok(data,1," "),"tailleicone")) { tailleicone = atoi(gettok(data,2," ")); }
	if (!lstrcmpi(gettok(data,1," "),"police")) {
		fontboutton = MakeFont(gettok(data,2," "), (LPARAM)atoi(gettok(data,3," ")), atoi(gettok(data,4," ")) ? true : false, atoi(gettok(data,5," ")) ? true : false );
	}

	lstrcpy(data,"S_OK");
	return 3;
}


mirc(Check)
	{

	if (!lstrcmpi(gettok(data,1," "),"3etat")) {
		hcheck = LoadAnImage(gettok(data,2," ",1));
		if (!hcheck) { lstrcpy(data,"Mauvaise imge pour les check"); return 3; }
	}
	if (!lstrcmpi(gettok(data,1," "),"texte")) {
		ctextcheck = atoi(gettok(data,2," ")); ctextcheck2 = atoi(gettok(data,3," "));
	}
	if (!lstrcmpi(gettok(data,1," "),"police")) {
		fontcheckradio = MakeFont(gettok(data,2," "), (LPARAM)atoi(gettok(data,3," ")), atoi(gettok(data,4," ")) ? true : false, atoi(gettok(data,5," ")) ? true : false );
	}


	lstrcpy(data,"S_OK");
	return 3;
}

mirc(ProgressBar)
	{

	char commande[0xFFF],val1[0xFFFF];

	wsprintf(commande,"%s",strtok(data," "));
	wsprintf(val1,"%s",strtok(NULL," "));

	int vale1 = atoi(val1);

	if (!lstrcmpi(commande,"Style")) {
		if (!lstrcmpi(val1,"degrade")) { progdeg = true; }
		if (!lstrcmpi(val1,"normal")) { progdeg = false; }
		if (!lstrcmpi(val1,"cont")) { progsens = true; }
		if (!lstrcmpi(val1,"prog")) { progsens = false; }
//		if (!lstrcmpi(val1,"cut")) { progcut = true; }
//		if (!lstrcmpi(val1,"plain")) { progcut = false; }
	}
	if (!lstrcmpi(commande,"barre")) { cfondprog = CreateSolidBrush(vale1); }
	if (!lstrcmpi(commande,"couleur")) { ccouleurprog = vale1; ccouleurprogb = CreateSolidBrush(vale1); }
	if (!lstrcmpi(commande,"bord")) { cbordprog = CreateSolidBrush(vale1); }

	if (!lstrcmpi(commande,"bmp")) {
		hProgressh = LoadAnImage(val1);
		if (!hProgressh) { lstrcpy(data,"mauvaise image Scrollbar"); return 3; }
		hProgressv = rotate90(hProgressh);
	}
	if (!lstrcmpi(commande,"bar")) {
		hProgressbarh = LoadAnImage(val1);
		if (!hProgressbarh) { lstrcpy(data,"mauvaise image de barre Scrollbar"); return 3; }
		hProgressbarv = rotate90(hProgressbarh);
	}
	if (!lstrcmpi(commande,"decalage")) { decprog = vale1; }

	lstrcpy(data,"S_OK");
	return 3;
}


mirc(Trackbar)
	{

	char commande[0xFFF],val1[0xFFFF];

	wsprintf(commande,"%s",strtok(data," "));
	wsprintf(val1,"%s",strtok(NULL," "));

	int vale1 = atoi(val1);
/*
	if (!lstrcmpi(commande,"Style")) {
		if (!lstrcmpi(val1,"normal")) { progdeg = false; }
		if (!lstrcmpi(val1,"cont")) { progsens = true; }
		if (!lstrcmpi(val1,"prog")) { progsens = false; }
	}
*/
	if (!lstrcmpi(commande,"track")) {
		htrackh = LoadAnImage(val1);
		if (!htrackh) { lstrcpy(data,"mauvaise trackar"); return 3; }
		htrackv=rotate90(htrackh);
	}
	if (!lstrcmpi(commande,"barre")) {
		htrackregh = LoadAnImage(val1);
		if (!htrackregh) { lstrcpy(data,"mauvaise barre de trackar"); return 3; }
		htrackregv = rotate90(htrackregh);
	}
	if (!lstrcmpi(commande,"cran")) {
		crantrack = vale1;
		if (crantrack < 1) { crantrack = 1; }
	}
	if (!lstrcmpi(commande,"decalage")) {
		dectrack = vale1;
	}
	if (!lstrcmpi(commande,"largeur")) {
		largtrack = vale1;
		if (largtrack<1) largtrack = 1;
		if (largtrack>100) largtrack = 100;
	}


	lstrcpy(data,"S_OK");
	return 3;
}



//****************** extention ******************
struct PEXT
{
char chem[255];
char fich[255];
char ext[255];
};

PEXT ext;

void *NomFichier(char *fichier)
{
//	ext.chem = (char *) malloc(255);
//	ext.fich = (char *) malloc(255);
//	ext.ext = (char *) malloc(255);
	
	int i = 0;
	char *tmp = (char *) malloc(255);
	char *fichiertmp;
   	char *c = fichier;
	while(*c) c++;

	while(*c != '\\') {
		c--;
		i++;
	}
	c++;
	fichiertmp = c;

	strcpy(tmp, fichier);
	i = strlen(fichier) - i + 1;
	tmp[i]='\0';
	strcpy(ext.chem, tmp);

 	c = fichiertmp;
	while(*c) c++;
	while(*c != '.') c--;
	c++;
	strcpy(ext.ext, c);

	i = 0;
	while(fichiertmp[i] != '.') {
		c[i] = fichiertmp[i];
		i++;
	}
	c[i]='\0';
	strcpy(ext.fich, c);

	return 0;
}

//***********************************************
//******* LISTE CHAINEES **********************************


struct SKINBUTTON
{
char * fich;
HBITMAP hbouttonbmp;
HWND hwnd;
//HRGN rng;
SKINBUTTON *next;
};


//SKINBUTTON butt;


SKINBUTTON *list;

SKINBUTTON *inserer_debut(char * fic,HBITMAP hbouttonbmp,HWND hwnd,HRGN rgn)
{ 
  SKINBUTTON *vlist_item;
  if((vlist_item = (SKINBUTTON *)malloc(sizeof(SKINBUTTON))) == NULL)
  { 
	 int az = 2;
  }
  vlist_item->fich = (char *) malloc(255);
  strcpy(vlist_item->fich, fic);
  vlist_item->hbouttonbmp  = hbouttonbmp;
  vlist_item->hwnd  = hwnd;
//  vlist_item->rng  = rgn;
  vlist_item->next = list;
  list = vlist_item;
  return(vlist_item);
}

SKINBUTTON *rechercher(HWND hwnd)
{
  SKINBUTTON *vlist_move;
  SKINBUTTON *vlist_move_prev;
 // list_item *vlist_tmp;
  vlist_move_prev = NULL;

  for(vlist_move=list;(vlist_move!=NULL) && (vlist_move->hwnd!=hwnd);
      vlist_move_prev=vlist_move,vlist_move=vlist_move->next);

  if(vlist_move == NULL)
  { 
    return(NULL);
  }
 
  return vlist_move; 
   
}

SKINBUTTON *supprimer(HWND hwnd)
{
  SKINBUTTON *vlist_move;
  SKINBUTTON *vlist_move_prev;
  SKINBUTTON *vlist_tmp;

  vlist_move_prev = NULL;
  for(vlist_move=list;(vlist_move!=NULL) && (vlist_move->hwnd!=hwnd);
      vlist_move_prev=vlist_move,vlist_move=vlist_move->next);

  if(vlist_move == NULL)
  { 
    return 0;
  }
  else {
    if(vlist_move_prev == NULL)
    {
      vlist_tmp = vlist_move->next;
      free(vlist_move);
		list = vlist_tmp;
      return(vlist_tmp);
    } else {
       vlist_move_prev->next = vlist_move->next;
       free(vlist_move);
//		list = list;
       return(list);
    }
  }
}

void cleanskin(HWND hwnd)
{
	SKINBUTTON *butt = rechercher(hwnd);
	if (butt != NULL) {
//		DeleteObject(butt->rng);
		supprimer(hwnd);
	}
}
//*******************************************************

int getanim() { return animation; }


void afftitre(HWND hwnd,int tempo) {

	char winom[256];
	GetWindowText(hwnd,winom,256);
	char szWindowText[200]; 

	if (animation == 1) {

	char deco[4];

	if (tempo == 0) { wsprintf(deco,"%s","oOo"); }
	if (tempo == 1) { wsprintf(deco,"%s","Ooo"); }
	if (tempo == 2) { wsprintf(deco,"%s","ooO"); }

	wsprintf(szWindowText, "%s %s %s", deco,winom,deco);

	}
	else {
		wsprintf(szWindowText, "%s", winom);
	}


	HDC hdc;
	hdc = GetWindowDC(hwnd);

	HFONT hOldFont;
	if (fonttitre) { hOldFont = (HFONT) SelectObject(hdc, fonttitre); }

//	ExtTextOut(hdc,rt.left+3, rt.top+2, ETO_CLIPPED, &rt, tabpoint->tab[nbre].texte, strlen(tabpoint->tab[nbre].texte), NULL);

//	SetTextColor(hdc, RGB(255,0,255));
//	SetBkColor(hdc, RGB(0,0,0));

    SetTextColor(hdc, cTextetitre);
    SetBkMode(hdc,TRANSPARENT);

    TextOut(hdc,titreX, titreY, szWindowText, strlen(szWindowText));

	if (fonttitre) { SelectObject(hdc, hOldFont); }

	DeleteDC(hdc);
}

bool getinit(int data) {
	if ((data == 1) && ( hbmp != NULL)) { return 1; }
	if ((data == 2) && ( hcheck != NULL)) { return 1; }
	if ((data == 3) && ( hlistbmp != NULL)) { return 1; }
	if ((data == 10) && (okdeco)) { return 1; }
	return 0;
}

int inithandle(char *data)
{
	char chemin[256];
	char ext[5];
	wsprintf(ext,"%s",strtok(data," "));
	wsprintf(data,"%s",strtok(NULL," "));

//	wsprintf(chemin,"%s%s",data,"Barhaut.bmp");
//	htoolbmp = LoadAnImage(chemin);
//	if (!htoolbmp) { lstrcpy(data,"Mauvaise tool"); return 3; }

	wsprintf(chemin,"%s%s.%s",data,"titre",ext);
	htooltitrebmp = LoadAnImage(chemin);
	if (!htooltitrebmp) { lstrcpy(data,"Mauvaise image titre"); return 3; }
//	wsprintf(chemin,"%s%s.%s",data,"Barhautc",ext);
//	htoolcbmp = LoadAnImage(chemin);
//	if (!htoolcbmp) { lstrcpy(data,"Mauvaise tool C"); return 3; }
	wsprintf(chemin,"%s%s.%s",data,"Barhautd",ext);
	htooldbmp = LoadAnImage(chemin);
	if (!htooldbmp) { lstrcpy(data,"Mauvaise tool D"); return 3; }

	wsprintf(chemin,"%s%s.%s",data,"BarBas",ext);
	hfondbmp = LoadAnImage(chemin);
	if (!hfondbmp) { lstrcpy(data,"Mauvaise bar du bas"); return 4; }
	
	wsprintf(chemin,"%s%s.%s",data,"cote50",ext);
	hbcotebmp = LoadAnImage(chemin);
	if (!hbcotebmp) { lstrcpy(data,"Mauvaise barre de cote"); return 5; }

	wsprintf(chemin,"%s%s.%s",data,"CoteBas",ext);
	hcotebasbmp = LoadAnImage(chemin);
	if (!hcotebasbmp) { lstrcpy(data,"Mauvaise barre de Bas cote"); return 6; }

	wsprintf(chemin,"%s%s.%s",data,"CoteHaut",ext);
	hcotehautbmp = LoadAnImage(chemin);
	if (!hcotehautbmp) { lstrcpy(data,"Mauvaise barre de haut cote"); return 7; }

	okdeco = 1;
	return 0;

}


void Dessinerprogress(LPDRAWITEMSTRUCT lpds,char * texte) {

	RECT ClientRect;
	int min,max,pos;

	char mint[255],maxt[255],post[255];

	wsprintf(post,"%s",strtok(texte," "));
	wsprintf(mint,"%s",strtok(NULL," "));
	wsprintf(maxt,"%s",strtok(NULL," "));
	min = atoi(mint);
	max = atoi(maxt);
	pos = atoi(post);

	if (pos>max) pos = max;
	if (pos<min) pos = min;

	if (max == min) max = min +1;

	GetClientRect(lpds->hwndItem ,&ClientRect);

	
HDC hMemDC= CreateCompatibleDC(lpds->hDC);
int cx = ClientRect.right-ClientRect.left;
int cy = ClientRect.bottom-ClientRect.top;
HBITMAP hMemBmp= CreateCompatibleBitmap(lpds->hDC, cx,cy);
HBITMAP hOldBmp= (HBITMAP)SelectObject(hMemDC, hMemBmp);



 clearfond(hMemDC,lpds->hwndItem ,ClientRect);

	RECT          LeftRect, RightRect;
//	char          szTexte[10];
//	HRGN          hRgn;



	DWORD dwTextStyle = DT_CENTER | DT_VCENTER | DT_SINGLELINE;
	int nPos = ( 100* pos / (max - min));

	int D;
	bool sens = 0;
	int dec;

//	LeftRect = RightRect = ClientRect;

	CopyRect(&LeftRect,&ClientRect);

	if ((ClientRect.bottom-ClientRect.top) < (ClientRect.right-ClientRect.left)) {
		MyStrech(hMemDC,ClientRect.left,ClientRect.top,ClientRect.right-ClientRect.left,ClientRect.bottom-ClientRect.top,hProgressh,cinvisible);
		dec=decprog*(ClientRect.bottom-ClientRect.top)/100;
		InflateRect(&LeftRect,-dec,-dec);
		CopyRect(&RightRect,&LeftRect);
		D = LeftRect.right - LeftRect.left;
		LeftRect.right = LeftRect.left + (int)((D * nPos) / 100);
		RightRect.left = LeftRect.right;
	}
	else {
		MyStrech(hMemDC,ClientRect.left,ClientRect.top,ClientRect.right-ClientRect.left,ClientRect.bottom-ClientRect.top,hProgressv,cinvisible);
		sens = 1;
		dec=decprog*(ClientRect.right-ClientRect.left)/100;
		InflateRect(&LeftRect,-dec,-dec);
		CopyRect(&RightRect,&LeftRect);
		D = LeftRect.bottom - LeftRect.top;
		LeftRect.top = LeftRect.bottom - (int)((D * nPos) / 100);
		RightRect.bottom = LeftRect.top;
	}
		

	// Dessiner la bar
	if (progdeg) {
		
		if (progsens) sens = sens ? false : true;
		//degrade(hMemDC,LeftRect,ccouleurprog,sens);
		if (sens == 1) MyTransparentBlt2(hMemDC,LeftRect.left,LeftRect.top,LeftRect.right-LeftRect.left,LeftRect.bottom-LeftRect.top,hProgressbarv,cinvisible);
		else MyTransparentBlt2(hMemDC,LeftRect.left,LeftRect.top,LeftRect.right-LeftRect.left,LeftRect.bottom-LeftRect.top,hProgressbarh,cinvisible);
	}
	else {
		FillRect(hMemDC, &LeftRect, ccouleurprogb);
	}


	FillRect(hMemDC, &RightRect, cfondprog);

/*

	// Afficher le texte
	SetBkMode(lpds->hDC, TRANSPARENT);
	// Le blan
	hRgn = CreateRectRgn(LeftRect.left, LeftRect.top, LeftRect.right, LeftRect.bottom);
	SelectClipRgn(lpds->hDC, hRgn);
	SetTextColor(lpds->hDC, crBgColour);
	DrawText(lpds->hDC, szTexte, (int)lstrlen(szTexte), &ClientRect, dwTextStyle);
	// Le bleu
	DeleteObject(hRgn);
	hRgn = CreateRectRgn(RightRect.left, RightRect.top, RightRect.right, RightRect.bottom);
	SelectClipRgn(lpds->hDC, hRgn);
	SetTextColor(lpds->hDC, crBarColour);
	DrawText(lpds->hDC, szTexte, (int)lstrlen(szTexte), &ClientRect, dwTextStyle);
*/

	//FillRect(lpds->hDC,&rt,rouge);
//	DrawEdge(lpds->hDC, &ClientRect,(0 ? EDGE_SUNKEN : EDGE_RAISED ), BF_RECT); 

// recopie du contexte en m�moire � l'�cran
BitBlt(lpds->hDC, 0, 0, cx,cy, hMemDC, 0, 0, SRCCOPY);
// s�lection anciens objets, destruction de ceus cr��s
SelectObject(hMemDC, hOldBmp);
DeleteObject(hMemBmp);
DeleteDC(hMemDC);
	
}


void Dessinertrackbar(LPDRAWITEMSTRUCT lpds,char * texte,bool survol) {



	RECT ClientRect;
	int min,max,pos,mod;

	LPTSTR Texte;
	Texte = (LPTSTR) malloc(255);
	
	char mint[255],maxt[255],post[255],pmod[255];

	GetWindowText(lpds->hwndItem,texte,256);

	wsprintf(post,"%s",strtok(texte," "));
	wsprintf(mint,"%s",strtok(NULL," "));
	wsprintf(maxt,"%s",strtok(NULL," "));
	wsprintf(pmod,"%s",strtok(NULL," "));
	min = atoi(mint);
	max = atoi(maxt);
	pos = atoi(post);
	mod = atoi(pmod);

	GetClientRect(lpds->hwndItem ,&ClientRect);


// cr�ation d'un contexte d'affichage en m�moire et d'un bitmap associ�
HDC hMemDC= CreateCompatibleDC(lpds->hDC);
HBITMAP hMemBmp= CreateCompatibleBitmap(lpds->hDC, ClientRect.right-ClientRect.left,ClientRect.bottom-ClientRect.top);
HBITMAP hOldBmp= (HBITMAP)SelectObject(hMemDC, hMemBmp);

	 clearfond(hMemDC,lpds->hwndItem ,ClientRect);

	int nPos;

	BOOL etat=lpds->itemState & ODS_SELECTED;

//	if (etat == 1) { pos = mod; }

	nPos = ( 100 * pos / (max - min));

	bool sens = 0;
	int larg;
	RECT barre;
	barre=ClientRect;

	if ((ClientRect.bottom-ClientRect.top) < (ClientRect.right-ClientRect.left)) {
		larg = (ClientRect.bottom-ClientRect.top) * largtrack / 100;
		barre.top=(ClientRect.bottom - ClientRect.top - larg) / 2;
		barre.bottom=barre.top+larg;

		MyStrech(hMemDC,barre.left,barre.top,barre.right-barre.left,barre.bottom-barre.top,htrackregh,cinvisible);

	}
	else {
		sens =1;
		larg = (ClientRect.right-ClientRect.left) * largtrack / 100;
		barre.left=(ClientRect.right - ClientRect.left - larg) / 2;
		barre.right=barre.left+larg;

		MyStrech(hMemDC,barre.left,barre.top,barre.right-barre.left,barre.bottom-barre.top,htrackregv,cinvisible);

	}


//	DrawEdge(hMemDC, &barre,(0 ? EDGE_SUNKEN : EDGE_RAISED ), BF_RECT);
//	InflateRect(&barre,-1,-1);
//	if (barretrack) FillRect(hMemDC,&barre,barretrack);

//InflateRect(&ClientRect,-25,-25);

 
	BITMAP bmp;
	HDC hdcBmp; 
	hdcBmp = CreateCompatibleDC(hMemDC);

	int dec;
	float reduc;
	int hauteur = ClientRect.bottom-ClientRect.top;
	int longueur = ClientRect.right-ClientRect.left;

	if (sens == 0) {
		GetObject(htrackh, sizeof(BITMAP), (LPSTR)&bmp);
		SelectObject(hdcBmp, htrackh);
		reduc = hauteur/(float)bmp.bmHeight ;
		dec = (int)(bmp.bmWidth * reduc / 6);
		longueur-=2*(dectrack);
//		nPos = (int)(dectrack + (longueur ) * pos / 100 - dec);
		nPos = ClientRect.left+dectrack-dec+(pos*longueur/100);

		TransparentBlt(hMemDC,nPos,ClientRect.top,(int)(bmp.bmWidth * reduc) / 3,(int)(bmp.bmHeight * reduc),hdcBmp,(survol + etat) * (bmp.bmWidth / 3),0,bmp.bmWidth / 3 , bmp.bmHeight,cinvisible );
	}
	else {
		GetObject(htrackv, sizeof(BITMAP), (LPSTR)&bmp);
		SelectObject(hdcBmp, htrackv);

		reduc = longueur/(float)bmp.bmWidth ;
		dec = (int)(bmp.bmWidth * reduc / 3);
		hauteur-=2*dectrack;
//		nPos = (int)(dec + (hauteur ) * pos / 100 - (bmp.bmHeight * reduc / 6));
		nPos = ClientRect.top+dectrack-dec+(pos*hauteur/100);

		TransparentBlt(hMemDC,ClientRect.left,nPos,(int)(bmp.bmWidth * reduc),(int)(bmp.bmHeight * reduc / 3),hdcBmp,0,(survol + etat) *(bmp.bmHeight / 3),bmp.bmWidth, bmp.bmHeight/3,cinvisible );
	}

	/*
RECT rt;
rt.top=0;
rt.bottom=10;
rt.left=ClientRect.left+dectrack;
rt.right=ClientRect.right-dectrack;
FillRect(hMemDC,&rt,rouge);
*/
/*
	int num;
	if (etat == 1) { num = 2; }
	else {
		if (survol == 0) { num = 0; }
		else { num = 1; }
	}
*/
	DeleteDC(hdcBmp);
	
// recopie du contexte en m�moire � l'�cran
BitBlt(lpds->hDC, 0, 0, ClientRect.right-ClientRect.left,ClientRect.bottom-ClientRect.top, hMemDC, 0, 0, SRCCOPY);
// s�lection anciens objets, destruction de ceus cr��s
SelectObject(hMemDC, hOldBmp);
DeleteObject(hMemBmp);
DeleteDC(hMemDC);

	
}

void updatetrack(HWND hwnd,POINT pm,bool ok) {

	LPTSTR Texte;
	Texte = (LPTSTR) malloc(255);
	int min,max,pos;
	int nPos;
	RECT rt;
	
	char mint[255],maxt[255],post[255];

	GetWindowText(hwnd,Texte,256);
	GetClientRect(hwnd ,&rt);

//	InflateRect(&rt,-dectrack,0);
//	InflateRect(&rt,0,-dectrack);

	wsprintf(post,"%s",strtok(Texte," "));
	wsprintf(mint,"%s",strtok(NULL," "));
	wsprintf(maxt,"%s",strtok(NULL," "));
	min = atoi(mint);
	max = atoi(maxt);
	pos = atoi(post);


	if (ok) {
		wsprintf(Texte,"%d %d %d %d",pos,min,max);
		SetWindowText(hwnd,Texte);
	}
	else {

		if ((rt.bottom-rt.top) < (rt.right-rt.left)) {
			nPos =  100 * (pm .x-rt.left-dectrack) / (rt.right - rt.left - 2*dectrack);
		}
		else {
			nPos =  100 * (pm .y-rt.top-dectrack) / (rt.bottom - rt.top - 2*dectrack);
		}

		nPos = (nPos + crantrack / 2) / crantrack;
		nPos = nPos * crantrack;

		if (nPos > 100) { nPos = 100; }
		if (nPos < 0) { nPos = 0; }

wsprintf(Texte,"%d %d %d %d",nPos,min,max);

//		wsprintf(Texte,"%d %d %d %d",pos,min,max,nPos);
		SetWindowText(hwnd,Texte);


		if (pos != nPos) {
SendMessage(hwnd,BM_CLICK,0,0);
		}



	}

}

/*
void dessinlistbox (HWND hwnd,HDC hdc)
{

//		HDC hdc2=hdc;
//		hdc2 = GetDC(hwnd);

		RECT rt;
		GetWindowRect( hwnd, &rt);
		int largeur=rt.right-rt.left - 4 ;
		int hauteur=rt.bottom-rt.top - 4 ;

		BITMAP bmp; 
		GetObject(hlistbmp, sizeof(BITMAP), (LPSTR)&bmp);
		HDC hdcBmp; 
		hdcBmp = CreateCompatibleDC(hdc); 
		SelectObject(hdcBmp, hlistbmp);
//		SetBkMode((HDC)wParam,TRANSPARENT);
		StretchBlt( hdc , 0, 0 , largeur , hauteur, hdcBmp, 0,0, bmp.bmWidth , bmp.bmHeight ,SRCCOPY );
		DeleteDC(hdcBmp);
}
*/
void DessinDialog(DIALOG dlg,HDC hdc)
{

		if (dlg.tmp == (HBITMAP)1) { return; }

		BITMAP bmp;
		HDC hdcBmp; 
		hdcBmp = CreateCompatibleDC(hdc);

		
/*		if (dlg.tmp) {
			GetObject(dlg.tmp, sizeof(BITMAP), (LPSTR)&bmp);
			SelectObject(hdcBmp, dlg.tmp );
			BitBlt( hdc , 0 , 0 ,bmp.bmWidth,bmp.bmHeight ,hdcBmp, 0,0, SRCCOPY );

			DeleteDC(hdcBmp);

			return;
		}
*/
		
		//barre du fond
		GetObject(hfondbmp, sizeof(BITMAP), (LPSTR)&bmp);
		SelectObject(hdcBmp, hfondbmp);
		int i;
		i = dlg.largeur /	bmp.bmWidth;
		while ( i >= 0 ) {
			BitBlt( hdc , i * bmp.bmWidth , dlg.longueur - bmp.bmHeight ,bmp.bmWidth,bmp.bmHeight,hdcBmp, 0,0, SRCCOPY );
			i--;
		}

		//barres de cot�s
		GetObject(hbcotebmp, sizeof(BITMAP), (LPSTR)&bmp);
		SelectObject(hdcBmp, hbcotebmp);
		i = dlg.longueur / bmp.bmHeight;
		while ( i >= 0 ) {
			BitBlt( hdc , dlg.largeur - bmp.bmWidth / 2 , i * bmp.bmHeight ,bmp.bmWidth,bmp.bmHeight,hdcBmp, bmp.bmWidth / 2,0, SRCCOPY );
			BitBlt( hdc , 0 , i * bmp.bmHeight ,bmp.bmWidth / 2,bmp.bmHeight,hdcBmp, 0,0, SRCCOPY );
			i--;
		}

		//barre du haut
//		int longtitre = dlg.largeur /2;
		GetObject(htooldbmp, sizeof(BITMAP), (LPSTR)&bmp);
		SelectObject(hdcBmp, htooldbmp);
		i = (dlg.largeur) / bmp.bmWidth;
		int nbreblit = 0;
		while ( i >= nbreblit ) {
			BitBlt( hdc ,i*bmp.bmWidth, 0 , bmp.bmWidth ,bmp.bmHeight ,hdcBmp, 0,0, SRCCOPY );
			i--;
		}

		//angles du bas
		GetObject(hcotebasbmp, sizeof(BITMAP), (LPSTR)&bmp);
		SelectObject(hdcBmp, hcotebasbmp);
		BitBlt( hdc ,0, dlg.longueur - bmp.bmHeight , bmp.bmWidth / 2,bmp.bmHeight ,hdcBmp, 0,0, SRCCOPY );
		BitBlt( hdc ,dlg.largeur  - bmp.bmWidth / 2, dlg.longueur - bmp.bmHeight,bmp.bmWidth / 2 ,bmp.bmHeight ,hdcBmp, bmp.bmWidth / 2,0, SRCCOPY );

		//angles du haut
		GetObject(hcotehautbmp, sizeof(BITMAP), (LPSTR)&bmp);
		SelectObject(hdcBmp, hcotehautbmp);
		int dectitre = bmp.bmWidth / 2;
		BitBlt( hdc ,0, 0 , bmp.bmWidth / 2,bmp.bmHeight ,hdcBmp, 0,0, SRCCOPY );
		BitBlt( hdc ,dlg.largeur  - bmp.bmWidth / 2, 0,bmp.bmWidth / 2 ,bmp.bmHeight ,hdcBmp, bmp.bmWidth / 2,0, SRCCOPY );

		//titre
		char winom[256];
		GetWindowText(dlg.hwnd,winom,256);

		int longtitre = (formattitre - 1) * strlen(winom);
		if (longtitre > (dlg.largeur - dectitre * 2) ) {
			longtitre = dlg.largeur - dectitre * 2;
		}

		GetObject(htooltitrebmp, sizeof(BITMAP), (LPSTR)&bmp);
		SelectObject(hdcBmp, htooltitrebmp);
		BitBlt( hdc ,dectitre, 0 , bmp.bmWidth / 3,bmp.bmHeight ,hdcBmp, 0,0, SRCCOPY );

		i=1;
		nbreblit = longtitre / (bmp.bmWidth / 3);
		while ( i <= nbreblit ) {
			BitBlt( hdc ,dectitre + i*(bmp.bmWidth / 3), 0 , bmp.bmWidth/3 ,bmp.bmHeight ,hdcBmp, 1* bmp.bmWidth / 3,0, SRCCOPY );
			i++;
		}

		BitBlt( hdc ,dectitre + longtitre, 0 , bmp.bmWidth / 3,bmp.bmHeight ,hdcBmp, 2* bmp.bmWidth / 3,0, SRCCOPY );

	//	StretchBlt( hdc , bmp.bmWidth / 2, 0 , dlg.largeur - 2 *  dlg.theme.epcote, bmp.bmHeight, hdcBmp, 0,0, bmp.bmWidth , bmp.bmHeight ,SRCCOPY );

		DeleteDC(hdcBmp);
}

/*
void FillWithBitmap(HDC dc, HBITMAP hbmp, RECT r)
{
	if (butt.rng == NULL) {
		HBITMAP htmp = LoadAnImage("D:\\V3\\NsRn-V3Bugge\\theme1\\maskB1.bmp");
		butt.rng = BmpToRgn(htmp,RGB(0,0,0));
		SelectClipRgn(dc,butt.rng);
		SetWindowRgn(butt.hwnd,hrgns, TRUE);
	}
	else {
		SelectClipRgn(dc,butt.rng);
	}

	if(!hbmp) return;
	HDC memdc;
	memdc = CreateCompatibleDC(dc);
	SelectObject(memdc,hbmp);
	int w = r.right - r.left;
	int	h = r.bottom - r.top;
	int x,y,z;

	BITMAP bmp; 
	GetObject(hbmp, sizeof(BITMAP), (LPSTR)&bmp);
	int	bx=bmp.bmWidth ;
	int	by=bmp.bmHeight;
/*
	for (y = r.top ; y < h ; y += by){
		if ((y+by)>h) by=h-y;
		z=bx;
		for (x = r.left ; x < w ; x += z){
			if ((x+z)>w) z=w-x;
			BitBlt( dc ,x, y, z, by, memdc, 0, 0, SRCCOPY);
		}
	}
*//*
BitBlt( dc , 0, 0 , bx , by, memdc, 0,0, SRCCOPY );


	DeleteDC(memdc);
}
*/

HBITMAP htmpp = NULL; 

void DessinerSkinBouton(HWND hwnd,LPDRAWITEMSTRUCT lpds,LPCTSTR texte,HBRUSH couleurfond,bool survol)
{

	SKINBUTTON *butt = rechercher(hwnd);

	if (butt == NULL ) return;

	//D�clarations:
	SIZE dims;
	char nom[50];
	//D�finir le texte du bouton:
	strcpy(nom, texte);
	//D�terminer les dimensions du texte:
    GetTextExtentPoint32(lpds->hDC, nom, strlen(nom), &dims);
	//D�finir la couleur du texte:
    SetTextColor(lpds->hDC, ctextboutton);
	//D�finir la couleur du fond:
    SetBkMode(lpds->hDC,TRANSPARENT);
  //  SetBkColor(lpds->hDC, couleurfond);
	//D�terminer l'�tat du bouton:
	BOOL etat=lpds->itemState & ODS_SELECTED;

	//D�terminer la largeur et la hauteur du bouton:
	int largeur=lpds->rcItem.right-lpds->rcItem.left;
	int hauteur=lpds->rcItem.bottom-lpds->rcItem.top;

	/*
	RECT rect;
	GetClientRect(lpds->hwndItem ,&rect);
	//Effacer contenu du STATIC:
	FillRect(lpds->hDC,&rect,couleurfond);
*/


	BITMAP bmp; 
	GetObject(butt->hbouttonbmp, sizeof(BITMAP), (LPSTR)&bmp);
	HDC hdcBmp; 
	hdcBmp = CreateCompatibleDC(lpds->hDC); 
	SelectObject(hdcBmp, butt->hbouttonbmp);
//		SetBkMode(hdc,TRANSPARENT);
//		BitBlt(lpds->hDC,0,0, bmp.bmWidth,bmp.bmHeight, hdcBmp, 0,0, SRCCOPY);
//    StretchBlt( lpds->hDC , 0, 0 , largeur , hauteur, hdcBmp, 0,0, bmp.bmWidth , bmp.bmHeight ,SRCCOPY );


/*
	if (etat == 1) {
		BitBlt( lpds->hDC , 0, 0 , largeur , hauteur, hdcBmp, 2 * (bmp.bmWidth / 3) ,0, SRCCOPY );
	}
	else {
		if (survol == 0) {
			BitBlt( lpds->hDC , 0, 0 , largeur , hauteur, hdcBmp, 0 * (bmp.bmWidth / 3) ,0, SRCCOPY );
		}
		else {
			BitBlt( lpds->hDC , 0, 0 , largeur , hauteur, hdcBmp, 1 * (bmp.bmWidth / 3),0, SRCCOPY );
		}
	}
	*/

//TransparentBlt(lpds->hDC,0,0,50,50,hdcBmp,0,0,50,50,RGB(0,0,0));


//	MyMaskBlt(lpds->hDC,0,0,50,50,hdcBmp,0,0,htmpp,0,0,MAKEROP4(SRCCOPY, DSTCOPY) );

/*
	if (etat == 1) {
		TransparentBlt(lpds->hDC,0,0,largeur , hauteur,hdcBmp,2 * (bmp.bmWidth / 3),0,largeur , hauteur,RGB(0,0,0) );
	}
	else {
		if (survol == 0) {
			TransparentBlt(lpds->hDC,0,0,largeur , hauteur,hdcBmp,0 * (bmp.bmWidth / 3),0,largeur , hauteur,RGB(0,0,0) );;
		}
		else {
			TransparentBlt(lpds->hDC,0,0,largeur , hauteur, hdcBmp,1 * (bmp.bmWidth / 3),0,largeur , hauteur,RGB(0,0,0) );
		}
	}	
*/
TransparentBlt(lpds->hDC,0,0,largeur , hauteur, hdcBmp,(survol + etat) * (bmp.bmWidth / 3),0,largeur , hauteur,cinvisible );
	
	DeleteDC(hdcBmp);



//FillWithBitmap(lpds->hDC,butt.hbouttonbmp,lpds->rcItem);

	return;
}

void DessinerBouton(LPDRAWITEMSTRUCT lpds,LPCTSTR texte,COLORREF couleurfond,bool survol,bool state)
{
	if (!hbmp) return;

	//D�clarations:
	SIZE dims;
	char nom[50];

	HFONT hOldFont;
	if (fontboutton) { hOldFont = (HFONT) SelectObject(lpds->hDC, fontboutton); }

	//D�finir le texte du bouton:
	strcpy(nom, texte);
	//D�terminer les dimensions du texte:
    GetTextExtentPoint32(lpds->hDC, nom, strlen(nom), &dims);
	//D�finir la couleur du fond:
    SetBkMode(lpds->hDC,TRANSPARENT);
  //  SetBkColor(lpds->hDC, couleurfond);
	//D�terminer l'�tat du bouton:
	BOOL etat=lpds->itemState & ODS_SELECTED;

	if ((survol == 0) && (state == 1)) { etat = 1 ; survol = 1;}
	

	//D�terminer la largeur et la hauteur du bouton:
	int largeur=lpds->rcItem.right-lpds->rcItem.left;
	int hauteur=lpds->rcItem.bottom-lpds->rcItem.top;

	BITMAP bmp; 
	GetObject(hbmp, sizeof(BITMAP), (LPSTR)&bmp);
	HDC hdcBmp; 
	hdcBmp = CreateCompatibleDC(lpds->hDC); 
	SelectObject(hdcBmp, hbmp);
//		SetBkMode(hdc,TRANSPARENT);
//		BitBlt(lpds->hDC,0,0, bmp.bmWidth,bmp.bmHeight, hdcBmp, 0,0, SRCCOPY);
//    StretchBlt( lpds->hDC , 0, 0 , largeur , hauteur, hdcBmp, 0,0, bmp.bmWidth , bmp.bmHeight ,SRCCOPY );


	 if (!IsWindowEnabled(lpds->hwndItem)) {
		MyTransparentBlt( lpds->hDC , 0, 0 , largeur , hauteur, hdcBmp, 3 * (bmp.bmWidth / 4) ,0, bmp.bmWidth / 4, bmp.bmHeight ,cinvisible );
		SetTextColor(lpds->hDC, RGB(0,0,0));
	}
	/*
	else if (etat == 1) {
		TransparentBlt( lpds->hDC , 0, 0 , largeur , hauteur, hdcBmp, 2 * (bmp.bmWidth / 4) ,0, bmp.bmWidth / 4, bmp.bmHeight ,RGB(0,0,0) );
	}
	else {
		if (survol == 0) {
			TransparentBlt( lpds->hDC , 0, 0 , largeur , hauteur, hdcBmp, 0 * (bmp.bmWidth / 4) ,0, bmp.bmWidth / 4 , bmp.bmHeight ,RGB(0,0,0) );
		}
		else {
			TransparentBlt( lpds->hDC , 0, 0 , largeur , hauteur, hdcBmp, 1 * (bmp.bmWidth / 4),0, bmp.bmWidth / 4 , bmp.bmHeight ,RGB(0,0,0) );
		}
	}
	*/
	else {
		MyTransparentBlt( lpds->hDC , 0, 0 , largeur , hauteur, hdcBmp, (etat + survol) * (bmp.bmWidth / 4),0, bmp.bmWidth / 4 , bmp.bmHeight ,cinvisible );
	}
	
	DeleteDC(hdcBmp);

	HICON hwndicone = (HICON)SendMessage(lpds->hwndItem,BM_GETIMAGE,(WPARAM)IMAGE_ICON,0);
	if (hwndicone) {
		if (strlen(nom)<1) {
			dims.cx = (long)(- 0.4*tailleicone);
		}
		DrawIconEx(lpds->hDC,(largeur-(int)(tailleicone*1.4+dims.cx))/2+etat, (hauteur-tailleicone)/2+etat,hwndicone,tailleicone,tailleicone,NULL,NULL,DI_NORMAL);
		largeur+=(int)(tailleicone*1.4);
		DeleteObject(hwndicone);
	}

	//Ecrire le texte sur le bouton:
	COLORREF c1 = ctextboutton;
	COLORREF c2 = ctextboutton2;
	if (etat == 1) {
		if (ctextboutton2) {
			c1=ctextboutton2;
			c2=ctextboutton;
		}
	}
   if (ctextboutton2) {
	   SetTextColor(lpds->hDC, c2);
	   ExtTextOut(lpds->hDC,(largeur-dims.cx)/2+etat, (hauteur-dims.cy)/2+etat, ETO_CLIPPED, &lpds->rcItem, nom, strlen(nom), NULL);
	   largeur+=1;
	   hauteur+=1;
   }
    SetTextColor(lpds->hDC, c1);
    ExtTextOut(lpds->hDC,(largeur-dims.cx)/2+etat, (hauteur-dims.cy)/2+etat, ETO_CLIPPED, &lpds->rcItem, nom, strlen(nom), NULL);

   
   //Dessiner le cadre du bouton selon son �tat:
//	DrawEdge(lpds->hDC, &lpds->rcItem,(etat ? EDGE_SUNKEN : EDGE_RAISED ), BF_RECT);                

	if (fontboutton) { SelectObject(lpds->hDC, hOldFont); }

	return;
}

void DessinerCheck(LPDRAWITEMSTRUCT lpds,LPCTSTR texte,HBRUSH couleurfond,bool state,bool survol)
{

	if (!hcheck) return;

	//D�clarations:
	SIZE dims;
	char nom[50];

	HFONT hOldFont;
	if (fontcheckradio) { hOldFont = (HFONT) SelectObject(lpds->hDC, fontcheckradio); }

	//D�finir le texte du bouton:
	strcpy(nom, texte);
	//D�terminer les dimensions du texte:
    GetTextExtentPoint32(lpds->hDC, nom, strlen(nom), &dims);
	//D�finir la couleur du fond:
    SetBkMode(lpds->hDC,TRANSPARENT);
  //  SetBkColor(lpds->hDC, couleurfond);
	//D�terminer l'�tat du bouton:
	BOOL etat=lpds->itemState & ODS_SELECTED;

	BOOL bg = lpds->itemState;
	etat = state;


	//D�terminer la largeur et la hauteur du bouton:
	int largeur=lpds->rcItem.right-lpds->rcItem.left;
	int hauteur=lpds->rcItem.bottom-lpds->rcItem.top;

/*
	RECT rect;
	GetClientRect(lpds->hwndItem ,&rect);
	//Effacer contenu du STATIC:
	FillRect(lpds->hDC,&rect,couleurfond);
*/


	BITMAP bmp; 
	GetObject(hcheck, sizeof(BITMAP), (LPSTR)&bmp);
	HDC hdcBmp; 
	hdcBmp = CreateCompatibleDC(lpds->hDC); 
	SelectObject(hdcBmp, hcheck);
//	SetBkMode(hdc,TRANSPARENT);

	if (!IsWindowEnabled(lpds->hwndItem)) {
		TransparentBlt(lpds->hDC , lpds->rcItem.left , lpds->rcItem.top + dims.cy / 2 ,bmp.bmWidth / 4 ,bmp.bmHeight,hdcBmp, ( bmp.bmWidth / 4) * 3 ,0, bmp.bmWidth / 4 , bmp.bmHeight ,cinvisible );
		SetTextColor(lpds->hDC, RGB(0,0,0));
	}
	else if (etat == 1) {
		 TransparentBlt(lpds->hDC , lpds->rcItem.left , lpds->rcItem.top + dims.cy / 2 ,bmp.bmWidth / 4 ,bmp.bmHeight,hdcBmp, ( bmp.bmWidth / 4) * 0 ,0, bmp.bmWidth / 4 , bmp.bmHeight ,cinvisible );
	}
	else {
		if (survol == 0) {
			TransparentBlt( lpds->hDC , lpds->rcItem.left , lpds->rcItem.top + dims.cy / 2,bmp.bmWidth / 4 ,bmp.bmHeight,hdcBmp, ( bmp.bmWidth / 4) * 1 ,0, bmp.bmWidth / 4, bmp.bmHeight ,cinvisible );
		}
		else {
			TransparentBlt( lpds->hDC , lpds->rcItem.left , lpds->rcItem.top + dims.cy / 2,bmp.bmWidth / 4 ,bmp.bmHeight,hdcBmp, ( bmp.bmWidth / 4) * 2 ,0, bmp.bmWidth / 4 , bmp.bmHeight ,cinvisible );
		}
	}

	DeleteDC(hdcBmp);


//Ecrire le texte sur le bouton:

   if (ctextcheck2) {
	   SetTextColor(lpds->hDC, ctextcheck2);
	   ExtTextOut(lpds->hDC,(largeur-dims.cx)/2 - 10 + bmp.bmWidth / 4, (hauteur-dims.cy)/2, ETO_CLIPPED, &lpds->rcItem, nom, strlen(nom), NULL);
 	   largeur+=1;
	   hauteur+=1;
   }
	//D�finir la couleur du texte:
    SetTextColor(lpds->hDC, ctextcheck);

    ExtTextOut(lpds->hDC,(largeur-dims.cx)/2 - 10 + bmp.bmWidth / 4, (hauteur-dims.cy)/2, ETO_CLIPPED, &lpds->rcItem, nom, strlen(nom), NULL);
	if (fontcheckradio) { SelectObject(lpds->hDC, hOldFont); }


    //Dessiner le cadre du bouton selon son �tat:
//	DrawEdge(lpds->hDC, &lpds->rcItem,(etat ? EDGE_SUNKEN : EDGE_RAISED ), BF_RECT);                

	return;
}

void DessinerRadio(LPDRAWITEMSTRUCT lpds,LPCTSTR texte,HBRUSH couleurfond,bool state,bool survol)
{
	if (!hcheck) return;

	//D�clarations:
	SIZE dims;
	char nom[50];

	HFONT hOldFont;
	if (fontcheckradio) { hOldFont = (HFONT) SelectObject(lpds->hDC, fontcheckradio); }

	//D�finir le texte du bouton:
	strcpy(nom, texte);
	//D�terminer les dimensions du texte:
    GetTextExtentPoint32(lpds->hDC, nom, strlen(nom), &dims);
	//D�finir la couleur du fond:
    SetBkMode(lpds->hDC,TRANSPARENT);
  //  SetBkColor(lpds->hDC, couleurfond);
	//D�terminer l'�tat du bouton:
	BOOL etat=lpds->itemState & ODS_SELECTED;

	BOOL bg = lpds->itemState;
	etat = state;

	//D�terminer la largeur et la hauteur du bouton:
	int largeur=lpds->rcItem.right-lpds->rcItem.left;
	int hauteur=lpds->rcItem.bottom-lpds->rcItem.top;
/*
	RECT rect;
	GetClientRect(lpds->hwndItem ,&rect);
	FillRect(lpds->hDC,&rect,couleurfond);
*/

	BITMAP bmp; 
	GetObject(hcheck, sizeof(BITMAP), (LPSTR)&bmp);
	HDC hdcBmp; 
	hdcBmp = CreateCompatibleDC(lpds->hDC); 
	SelectObject(hdcBmp, hcheck);
//	SetBkMode(hdc,TRANSPARENT);

	if (!IsWindowEnabled(lpds->hwndItem)) {
		TransparentBlt(lpds->hDC , lpds->rcItem.left , lpds->rcItem.top + dims.cy / 2 ,bmp.bmWidth / 4 ,bmp.bmHeight,hdcBmp, ( bmp.bmWidth / 4) * 3 ,0, bmp.bmWidth / 4 , bmp.bmHeight ,cinvisible );
		SetTextColor(lpds->hDC, RGB(0,0,0));
	}
	else if (etat == 1) {
		 TransparentBlt(lpds->hDC , lpds->rcItem.left , lpds->rcItem.top + dims.cy / 2 ,bmp.bmWidth / 4 ,bmp.bmHeight,hdcBmp, ( bmp.bmWidth / 4) * 0 ,0, bmp.bmWidth / 4 , bmp.bmHeight ,cinvisible );
	}
	else {
		if (survol == 0) {
			TransparentBlt( lpds->hDC , lpds->rcItem.left , lpds->rcItem.top + dims.cy / 2,bmp.bmWidth / 4 ,bmp.bmHeight,hdcBmp, ( bmp.bmWidth / 4) * 1 ,0, bmp.bmWidth / 4, bmp.bmHeight ,cinvisible );
		}
		else {
			TransparentBlt( lpds->hDC , lpds->rcItem.left , lpds->rcItem.top + dims.cy / 2,bmp.bmWidth / 4 ,bmp.bmHeight,hdcBmp, ( bmp.bmWidth / 4) * 2 ,0, bmp.bmWidth / 4 , bmp.bmHeight ,cinvisible );
		}
	}

	DeleteDC(hdcBmp);

	//Ecrire le texte sur le bouton:


   if (ctextcheck2) {
	   SetTextColor(lpds->hDC, ctextcheck2);
	   ExtTextOut(lpds->hDC,(largeur-dims.cx)/2 - 10 + bmp.bmWidth / 4, (hauteur-dims.cy)/2, ETO_CLIPPED, &lpds->rcItem, nom, strlen(nom), NULL);
	   largeur+=1;
	   hauteur+=1;
   }
	//D�finir la couleur du texte:
    SetTextColor(lpds->hDC, ctextcheck);

    ExtTextOut(lpds->hDC,(largeur-dims.cx)/2 - 10 + bmp.bmWidth / 4, (hauteur-dims.cy)/2, ETO_CLIPPED, &lpds->rcItem, nom, strlen(nom), NULL);
	if (fontcheckradio) { SelectObject(lpds->hDC, hOldFont); }
	

	return;
}


void DessinerBox(LPDRAWITEMSTRUCT lpds,LPCTSTR texte,COLORREF couleurtexte,HBRUSH couleurfond)
{
	//D�clarations:
	SIZE dims;
	char nom[50];
	//D�finir le texte du bouton:
	strcpy(nom, texte);
	//D�terminer les dimensions du texte:
    GetTextExtentPoint32(lpds->hDC, nom, strlen(nom), &dims);

	//D�terminer l'�tat du bouton:
	BOOL etat=lpds->itemState & ODS_SELECTED;
	BOOL bg = lpds->itemState;
	etat = 1;

	//D�terminer la largeur et la hauteur du bouton:
	int largeur=lpds->rcItem.right-lpds->rcItem.left;
	int hauteur=lpds->rcItem.bottom-lpds->rcItem.top;
/*
	RECT rect;
	GetClientRect(lpds->hwndItem ,&rect);
	FillRect(lpds->hDC,&rect,couleurfond);


	BITMAP bmp; 
	GetObject(hcheck, sizeof(BITMAP), (LPSTR)&bmp);
	HDC hdcBmp; 
	hdcBmp = CreateCompatibleDC(lpds->hDC); 
	SelectObject(hdcBmp, hcheck);
	
*/

	//Ecrire le texte sur le bouton:
//    ExtTextOut(lpds->hDC,(largeur-dims.cx)/2+etat - 10 + bmp.bmWidth / 3, (hauteur-dims.cy)/2+etat, ETO_CLIPPED, &lpds->rcItem, nom, strlen(nom), NULL);
	

	SetBkMode(lpds->hDC,TRANSPARENT);
	DrawEdge(lpds->hDC, &lpds->rcItem,(etat ? EDGE_SUNKEN : EDGE_RAISED ), BF_RECT);                

//	DeleteDC(hdcBmp);

	return;
}


void cleardessin() {
	DeleteObject(cbordprog);
	DeleteObject(ccouleurprogb);
	DeleteObject(cfondprog);
	if (fonttitre) DeleteObject(fonttitre);

DeleteObject( hbmp);
DeleteObject( htoolbmp);

DeleteObject( htooldbmp);
DeleteObject( htoolcbmp);
DeleteObject( htoolgbmp);
DeleteObject( htooltitrebmp);

DeleteObject( hlistbmp);
DeleteObject( hfondbmp);
DeleteObject( hbcotebmp);
DeleteObject( hcotebasbmp);
DeleteObject( hcotehautbmp);
DeleteObject( hcheck);

DeleteObject( htrackh);
DeleteObject( htrackv);
DeleteObject( htrackregh);
DeleteObject( htrackregv);

DeleteObject( hProgressv);
DeleteObject( hProgressh);
DeleteObject( hProgressbarv);
DeleteObject( hProgressbarh);


	return;
}

/*
void clip(HWND hwnd){
	HDC hdc = GetDC(hwnd);
	HBITMAP htmp = LoadAnImage("D:\\V3\\NsRn-V3Bugge\\theme1\\B1mask.bmp");
	HRGN rng = BmpToRgn(htmp,RGB(0,0,0));
	SelectClipRgn(hdc,rng);
	SetWindowRgn(hwnd,rng, TRUE);
}
*/

void initskinbut(HBITMAP htmp,HWND hwnd,char *fich)
{

	NomFichier(fich);
	wsprintf(fich,"%s%s%s.%s",ext.chem,ext.fich,"mask",ext.ext);

	inserer_debut(fich,htmp,hwnd,NULL);


	htmp = LoadAnImage(fich );
	if (htmp) {
		HRGN rng = BmpToRgn(htmp,cinvisible);
		SetWindowRgn(hwnd,rng, TRUE);
		SelectClipRgn(GetDC(hwnd),rng);
		DeleteObject(rng);
	}

}


char * DecoBoutton(HWND hwnd,int id,char *img,int type)
{

	HWND hBouton = GetDlgItem(hwnd,id + 6000);
	if (!IsWindow(hBouton)) {
		return "Mauvais ID";
	}

	char classt[256];
	GetClassName(hBouton,classt,256);
	if (lstrcmpi(classt,"Button")) return "Ce n'est pas un boutton";

	if (type == 1) {
		AddWinStyles(hBouton,GWL_STYLE,BS_BITMAP);
		HBITMAP hImage = LoadAnImage ( img );
		if (!hImage) return "ERR mauvais fichier"; 
		SendMessage(hBouton, BM_SETIMAGE, (WPARAM)IMAGE_BITMAP, (LPARAM)(HANDLE)hImage);
	}
	if (type == 2) {

//	LONG Styles = GetWindowLong(window, style);
//	Styles |= AddStyles;
//	SetWindowLong(hBouton, GWL_STYLE,  WS_CHILD | WS_TABSTOP | WS_VISIBLE | BS_ICON );
		AddWinStyles(hBouton,GWL_STYLE,BS_ICON);
		HBITMAP hImage = (HBITMAP)LoadImage(0,img,IMAGE_ICON,32,32,LR_LOADFROMFILE);
		if (!hImage) return "ERR mauvais fichier"; 
		SendMessage(hBouton, BM_SETIMAGE, (WPARAM)IMAGE_ICON, (LPARAM)(HANDLE)hImage);
	}
	return "_OK";
}
