
#include <windows.h>

#include "fonction.h"
#include "Structure.h"


//*****************************************************
//****************************************************
//       DestroyIcon
//pour nettoyer les icones apres chak dialogue
//utiliser plutot wmerase que wmpaint 
//*********************************************  


HWND GethIDhwnd(int id);
void mIRCaff(char *text);
void mIRCcom(char *text);

LRESULT WINAPI edittab2(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);


extern HBRUSH hbDialog;

//Donn� memoris� pour theme
int tailletab=20;
HBITMAP htab;
HBITMAP htab2;
//HBRUSH crouge = CreateSolidBrush(RGB(255,0,0));
static COLORREF Textetab = 0;
static COLORREF Textetab2 = 0;

static HFONT fonttab = NULL;

extern COLORREF cinvisible;

/************** proceduere *******************/

void SetTab(HWND hwnd,LPTABMIRC tabpoint,RECT rt)
{
//	LPTABMIRC tabpoint = new TABMIRC;
//  lpmb->hover = false;

	//modiftab
	RECT rrr;
	GetWindowRect( hwnd, &rrr);
	AdjustRectCoords(GetParent(hwnd),&rrr);
//	MoveWindow(hwnd,rrr.left,rrr.top-tailletab,rrr.right-rrr.left,rrr.bottom- rrr.top + tailletab,1);
	MoveWindow(hwnd,rrr.left,rrr.top,0,0,1);
//	ShowWindow(hwnd, SW_HIDE);
	DestroyWindow(hwnd);

	CopyRect(&tabpoint->rteff,&rt);
	tabpoint->rteff.top=tabpoint->rteff.top-tailletab;

}
/*
void tabtest2(HWND hwnd)
	{

	RECT rt;
	GetWindowRect( hwnd, &rt);
	int largeur=rt.right-rt.left ;
	int hauteur=rt.bottom-rt.top ;
	AdjustRectCoords(GetParent(hwnd),&rt);

	ancienproc2 = (WNDPROC)SetWindowLong(hwnd,GWL_WNDPROC,(long)ChildWndProc);

	HWND hwnd2 = CreateWindowEx(
    WS_EX_CLIENTEDGE | WS_EX_TOPMOST | WS_CHILD,
    "Static",
    NULL,
    WS_VISIBLE, 
	rt.left, rt.top, largeur, hauteur,
    GetParent(hwnd),
    NULL,
    GetModuleHandle(NULL), 
    NULL);

	HDC hdc = GetWindowDC(hwnd2);
	GetWindowRect( hwnd2, &rt);
//	rt.left=0;
//	rt.top=0;
	FillRect(hdc,&rt,hbDialog);

DeleteDC(hdc);

}
*/

void addtab(HWND hwnd,LPTABMIRC tabpoint) {

//	LPTABMIRC tabpoint = (LPTABMIRC) GetWindowLong(htab, GWL_USERDATA);

	RECT rt;

	GetWindowRect( hwnd, &rt);
//	AdjustRectCoords(GetParent(hwnd),&rt);


	tabpoint->tab[tabpoint->max].hwnd=hwnd;

	HICON hicon = (HICON)GetWindowLong(hwnd, GWL_USERDATA);
	tabpoint->tab[tabpoint->max].hicon = hicon;

//	int max = tabpoint->max;

	GetWindowText(hwnd,tabpoint->tab[tabpoint->max].texte,256);

	if (tabpoint->max<20) tabpoint->max++;
}
/*
void modiftab(HWND hwnd) {
	RECT rrr;
	GetWindowRect( hwnd, &rrr);
	AdjustRectCoords(GetParent(hwnd),&rrr);
//	MoveWindow(hwnd,rrr.left,rrr.top-tailletab,rrr.right-rrr.left,rrr.bottom- rrr.top + tailletab,1);
	MoveWindow(hwnd,rrr.left,rrr.top,0,0,1);
//	ShowWindow(hwnd, SW_HIDE);
DestroyWindow(hwnd);
}
*/

//*********************************************************


void Maketab2(HWND hwnd,LPTABMIRC tabpoint)
{
	

//	MoveWindow(hwnd,rrr.left,rrr.top-tailletab,rrr.right-rrr.left,rrr.bottom- rrr.top + tailletab,1);

	MoveWindow(hwnd,tabpoint->rteff.left,tabpoint->rteff.top,tabpoint->rteff.right-tabpoint->rteff.left,tabpoint->rteff.bottom-tabpoint->rteff.top,1);

//	LONG OldComboProc;

	//

	tabpoint->ancienproc = (WNDPROC)SetWindowLong(hwnd,GWL_WNDPROC,(long)edittab2);
	SetWindowLong(hwnd, GWL_USERDATA, (LONG) tabpoint);


	//
/*
	// Remember old window procedure
	OldComboProc = GetWindowLong(hwnd, GWL_WNDPROC);
	SetWindowLong(hwnd, GWL_USERDATA, OldComboProc);

	// Perform the subclass
	OldComboProc = SetWindowLong(hwnd, GWL_WNDPROC, (LONG)edittab2);

*/
}


LRESULT WINAPI edittab2(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{


	LPTABMIRC tabpoint2 = (LPTABMIRC)GetWindowLong(hwnd, GWL_USERDATA);

	char text [255];
//	wsprintf(text,"%s %d","TAB intercept",msg);
//	mIRCaff(text);





	HDC				hdc;
	PAINTSTRUCT		ps;
//	RECT			rect;
//	RECT			rect2;
//	POINT			pt;
	
	WNDPROC			OldComboProc = tabpoint2->ancienproc;

	int nbre = tabpoint2->max - 1;
	int maxnbre = nbre+1;

	switch(msg)
	{
	case WM_NCPAINT:
		{
			return 0;
		}
	break;
	case WM_ERASEBKGND:
		{
		return (LRESULT)0L;
		}
	break;
  	case WM_PAINT:

		{

//	wsprintf(text,"%s %d","TAB dessin",msg);
//	mIRCaff(text);


		if(wParam == 0)		hdc = BeginPaint(hwnd, &ps);
		else				hdc = (HDC)wParam;

		RECT rtt;
		GetWindowRect( hwnd, &rtt);
		AdjustRectCoords(hwnd,&rtt);
//		FillRect(hdc,&rtt,hbDialog);


//********************************************
/*
POINT lppt;

int aa = rt.left / wfond;
int bb = rt.top / hfond;
int cc = wfond - (rt.left - aa * wfond);
int dd = hfond - (rt.top - bb * hfond);
cc=3;
dd=3;

SetBrushOrgEx(hdc,dec,dec,&lppt);
*/
//*******************************

		//double buffer
		HDC hMemDC= CreateCompatibleDC(hdc);
		int cx = rtt.right-rtt.left-1;
		int cy = rtt.bottom-rtt.top-1;
		HBITMAP hMemBmp= CreateCompatibleBitmap(hdc, cx,cy);
		HBITMAP hOldBmp= (HBITMAP)SelectObject(hMemDC, hMemBmp);
	//	BitBlt(hMemDC, 0, 0, cx,cy, hdc, 0, 0, SRCCOPY);



//	long res = CallWindowProc(OldComboProc, hwnd, msg, (WPARAM)hMemDC, lParam);
	long res =1;

//	rtt.bottom-=5;
//	FillRect(hMemDC,&rtt,crouge);
	FillRect(hMemDC,&rtt,hbDialog);

    SetBkMode(hMemDC,TRANSPARENT);

	HFONT hOldFont;
	if (fonttab) { hOldFont = (HFONT) SelectObject(hMemDC, fonttab); }

	int a = SendMessage(tabpoint2->hwndbox,LB_GETCURSEL,0,0);

	RECT rt;
	rt.top=rtt.top;
	rt.bottom=rtt.top+tailletab;

	rtt.top+=tailletab;
//	DrawEdge(hdc, &rtt,( EDGE_RAISED ), BF_RECT);


	BITMAP bmp;
	HDC hdcBmp;
	hdcBmp = CreateCompatibleDC(hMemDC);
	HBITMAP hOldBmpSrc;

	if (htab2) {
		GetObject(htab2, sizeof(bmp), &bmp);
		hOldBmpSrc = (HBITMAP)SelectObject(hdcBmp, htab2);
		MyTransparentBlt(hMemDC, rtt.left , rtt.top , rtt.right-rtt.left , rtt.bottom-rtt.top , hdcBmp, 0,0,bmp.bmWidth,bmp.bmHeight,cinvisible); 
		SelectObject(hdcBmp, hOldBmpSrc);
	}


	GetObject(htab, sizeof(bmp), &bmp);
	hOldBmpSrc = (HBITMAP)SelectObject(hdcBmp, htab);


	int etat = 1;
	while (nbre>=0) {

		rt.left=(nbre)*(rtt.right - rtt.left) / (maxnbre);
		rt.right=rt.left + (rtt.right - rtt.left) / (maxnbre);

		if (nbre == a ) { etat = 1; } else { etat = 0; }

		MyTransparentBlt(hMemDC, rt.left , rt.top , rt.right-rt.left-1 , rt.bottom-rt.top , hdcBmp, etat*(bmp.bmWidth/2),0,bmp.bmWidth/2,bmp.bmHeight,cinvisible); 


		//petite reduction
		rt.left = rt.left + (rt.right-rt.left)/15;
		rt.right = rt.right - (rt.right-rt.left)/15;

		//icones
		SIZE dims;
		GetTextExtentPoint32(hMemDC, tabpoint2->tab[nbre].texte, strlen(tabpoint2->tab[nbre].texte), &dims);
		int largeur=rt.right-rt.left;
		int hauteur=rt.bottom-rt.top;
		int hauticone = (int)(hauteur *.7);
		int dec = (hauteur - hauticone)/2; 


		if (tabpoint2->tab[nbre].hicon) {
			DrawIconEx(hMemDC,rt.left+dec, rt.top+dec,tabpoint2->tab[nbre].hicon,hauticone,hauticone,NULL,NULL,DI_NORMAL);
			largeur+=hauticone + 2*dec ;
		}
		
	   if (Textetab2) {
		   SetTextColor(hMemDC, Textetab2);
		   ExtTextOut(hMemDC,rt.left+(largeur-dims.cx)/2, rt.top+(hauteur-dims.cy)/2, ETO_CLIPPED, &rt, tabpoint2->tab[nbre].texte, strlen(tabpoint2->tab[nbre].texte), NULL);
		   largeur+=1;
		   hauteur+=1;
	   }

		SetTextColor(hMemDC, Textetab);
		ExtTextOut(hMemDC,rt.left+(largeur-dims.cx)/2, rt.top+(hauteur-dims.cy)/2, ETO_CLIPPED, &rt, tabpoint2->tab[nbre].texte, strlen(tabpoint2->tab[nbre].texte), NULL);

		nbre--;

//InflateRect(&rt,-3,-3);
//DrawFocusRect(hdc,&rt);


	}

	SelectObject(hdcBmp, hOldBmpSrc);
	DeleteDC(hdcBmp);


	if (fonttab) { SelectObject(hMemDC, hOldFont); }

		// recopie du contexte en m�moire � l'�cran
		BitBlt(hdc, 0, 0, cx,cy, hMemDC, 0, 0, SRCCOPY);
		// s�lection anciens objets, destruction de ceus cr��s
		SelectObject(hMemDC, hOldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(hMemDC);


	DeleteDC(hdc);
 //   EndPaint(GetParent(hwnd), &ps);

//******************************


		if(wParam == 0)
			EndPaint(hwnd, &ps);

		return res;
		}
		break;
		case LB_GETCURSEL:
		{
//			wsprintf(text,"%s %d","TAB inter LB_GETCURSEL",msg);
//			mIRCaff(text);

		}
		break;
		case WM_LBUTTONDOWN://Clic sur un contr�le
		{

		//return CallWindowProc(OldComboProc, hwnd, msg, wParam, lParam);

		RECT rtt;
		GetWindowRect( hwnd, &rtt);

		POINT pt;
		GetCursorPos(&pt);

		int a=(rtt.right-rtt.left)/(maxnbre);
		a=(pt.x-rtt.left)/a;

		int b=SendMessage(tabpoint2->hwndbox,LB_GETCURSEL,0,0);
		if ((a == b) || (pt.y > rtt.top+tailletab)) { return 0; }

/*
		SendMessage(tabpoint2->hwndbox,LB_SETCURSEL,a,0);

		long res = CallWindowProc(OldComboProc, hwnd, msg, wParam, lParam);
		SendMessage(tabpoint2->hwndbox,LB_SETCURSEL,a,0);


*/

		//marche mais pas bon
			SendMessage(hwnd,LB_SETCURSEL,a,0);
     //       CallWindowProc(OldComboProc, hwnd, msg, wParam, lParam);
		
		//	SendMessage( tabpoint2->tab[a].hwnd ,WM_WINDOWPOSCHANGING,0,(long)&lpwp);
			wsprintf(text,"%s %d %s %d %s","//var %i = 1 | while $dialog(%i) { if $dialog(%i).hwnd == ", GetParent(hwnd) ,"{ //did -c $dialog(%i)", GetDlgCtrlID(tabpoint2->tab[a].hwnd) - 6000," } | inc %i }");
			mIRCcom(text);

			InvalidateRect(hwnd, 0, 1);


			DestroyCursor(GetCursor());

			return 0;
		}
		break;
		case WM_DESTROY:
		{
			tabpoint2->max=0;
		}
		break;
		
	}
	
	return CallWindowProc(OldComboProc, hwnd, msg, wParam, lParam);
}






//***********************************************************************************************


int __stdcall WINAPI Tab(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
	{

	char commande[0xFFF],val1[0xFFFF],val2[0xFFFF],val3[0xFFFF],val4[0xFFFF];

	wsprintf(commande,"%s",strtok(data," "));
	wsprintf(val1,"%s",strtok(NULL," "));
	wsprintf(val2,"%s",strtok(NULL," "));
	wsprintf(val3,"%s",strtok(NULL," "));
	wsprintf(val4,"%s",strtok(NULL," "));
	int vale1 = atoi(val1);
	int vale2 = atoi(val2);
	int vale3 = atoi(val3);
	int vale4 = atoi(val4);

	if (!lstrcmpi(commande,"taille")) { 
		if ((vale1 > 29) && (vale1<100)) { tailletab = vale1; }
	}
	if (!lstrcmpi(commande,"texte")) { Textetab = vale1; Textetab2 = vale2;}
	if (!lstrcmpi(commande,"police")) { fonttab = MakeFont(val1, (LPARAM)vale2, vale3 ? true : false, vale4 ? true : false ); }
	if (!lstrcmpi(commande,"icone")) {
		HICON hicon = (HICON)LoadImage(0,val2,IMAGE_ICON,32,32,LR_LOADFROMFILE);
		if (!hicon) { wsprintf(data,"S_ERR mauvaise icone"); return 3; } 

		HWND hwndd = GethIDhwnd(vale1);
		SetWindowLong(hwndd, GWL_USERDATA, (long)hicon);
		
	}
	if (!lstrcmpi(commande,"bmpTab")) {
		htab = LoadAnImage(val1);
		if (!htab) { lstrcpy(data,"mauvaise image pour les tabs"); return 3; }
	}
	if (!lstrcmpi(commande,"bmpBox")) {
		htab2 = LoadAnImage(val1);
		if (!htab2) { lstrcpy(data,"mauvaise image pour les tabs"); return 3; }
	}
	
	wsprintf(data,"S_OK");
	return 3;

}

void cleartab() {
	if (fonttab) DeleteObject(fonttab);
	DeleteObject(htab);
	DeleteObject(htab2);
}