
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>
#define _WIN32_IE 0x0500 
#include <commctrl.h>
#include <stdlib.h>


COLORREF ctoolt=RGB(0,0,0);
COLORREF ctoolf=RGB(255,255,255);
int stylestool=WS_POPUP | TTS_NOPREFIX | TTS_ALWAYSTIP;

extern COLORREF cinvisible=RGB(255,0,255);



HWND GethIDhwnd(int id);


int __stdcall WINAPI Tooltip(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
	{

	char commande[0xFFF],val1[0xFFFF],val2[0xFFFF];

	wsprintf(commande,"%s",strtok(data," "));
	wsprintf(val1,"%s",strtok(NULL," "));
	wsprintf(val2,"%s",strtok(NULL," "));

	if (!lstrcmpi(commande,"color")) { ctoolt = atoi(val1); ctoolf = atoi(val2); }
	if (!lstrcmpi(commande,"style")) {
		if (!lstrcmpi(val1,"balloon")) {
			stylestool = WS_POPUP | TTS_NOPREFIX | TTS_ALWAYSTIP | TTS_BALLOON;
	}
		else { stylestool=WS_POPUP | TTS_NOPREFIX | TTS_ALWAYSTIP; }
	}

	wsprintf(data,"S_OK");
	return 3;


}

int __stdcall WINAPI Maketooltip(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
	{

	TOOLINFO mytoolinfo;
	char textetool[255];

	HWND hwndTT;
	UINT ID; 
	char cID[10];

	// extract ID
	wsprintf(cID,"%s",strtok(data," "));

	// extract text
	wsprintf(textetool,"%s",strtok(NULL,">"));

	ID = 6000 + (UINT) atoi(cID);

	HWND hwndid = GethIDhwnd(atoi(data));
	if (!hwndid) { wsprintf(data,"ERR Dialog lost Mark or Wrond ID"); return 3; }

	hwndTT = CreateWindowEx(WS_EX_TOPMOST,
    TOOLTIPS_CLASS,
    NULL,
	stylestool,
    CW_USEDEFAULT,
    CW_USEDEFAULT,
    CW_USEDEFAULT,
    CW_USEDEFAULT,
    GetParent(hwndid),
    NULL,
    NULL,
    NULL
    );

SetWindowPos(hwndTT, HWND_TOPMOST,0, 0, 0, 0,SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);

	if (!IsWindow(hwndTT)) {
		wsprintf(data,"ERROR Tooltip: Unable to Create Tooltip Window");
		return 3;
	}
	
	//set up tooltips
	mytoolinfo.cbSize = sizeof(TOOLINFO);
	mytoolinfo.uFlags = TTF_SUBCLASS | TTF_IDISHWND;
    mytoolinfo.hwnd = GetParent(hwndid);
    mytoolinfo.hinst = NULL;
    mytoolinfo.uId = (UINT) hwndid;
    mytoolinfo.lpszText = textetool;

	//modif
	//SendMessage(Window[i].tooltip[j].hwnd, TTM_SETMAXTIPWIDTH, 0, width);
	//SendMessage(hwndTT, TTM_SETTITLE, icon, (LPARAM) title);
	SendMessage(hwndTT, TTM_SETTIPTEXTCOLOR, (WPARAM) ctoolt, 0);
	SendMessage(hwndTT, TTM_SETTIPBKCOLOR, (WPARAM) ctoolf, 0);

	// add tooltip to dialog ID
	SendMessage(hwndTT, TTM_ADDTOOL, 0, (LPARAM) &mytoolinfo );
	// activate tooltip
	SendMessage(hwndTT, TTM_ACTIVATE, (WPARAM) TRUE, 0 );
	// set maximum tooltip window width
	SendMessage(hwndTT, TTM_SETMAXTIPWIDTH, 0, 250);

	wsprintf(data,"S_OK");
	return 3;

}


int __stdcall WINAPI Option(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
	{

	char commande[0xFFF],val1[0xFFFF],val2[0xFFFF];

	wsprintf(commande,"%s",strtok(data," "));
	wsprintf(val1,"%s",strtok(NULL," "));
	wsprintf(val2,"%s",strtok(NULL," "));

	if (!lstrcmpi(commande,"masque")) { cinvisible = atoi(val1);}

	wsprintf(data,"S_OK");
	return 3;

}

