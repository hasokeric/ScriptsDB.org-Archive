#include <windows.h>
#include <commctrl.h>
#include "coolscroll.h"


HBITMAP LoadAnImage(char* FileName);
//UINT CALLBACK CoolSB_DrawProc(HDC hdc, UINT uCmdId, UINT uButflags, RECT *rect);
//extern HWND hwndScroll;

//extern BOOL fCustomDraw  ;
//extern BOOL fButtons     ;
//extern BOOL fThumbAlways ;


HDC hdcSkin;
extern HWND hwndCtrl;
HBITMAP		hSkinBmp;

typedef struct 
{
	int x, y;
	int width, height;
} CustomDrawTable;

//
//	Define a set of structures which describe
//	where-abouts the source "textures" are in the
//	custom draw bitmap. We need to know x, y, width and height
//	for each scrollbar segment.
//

CustomDrawTable cdt_horz_normal[] = 
{
	{ 0,  0,  18, 18 },	//left arrow  NORMAL
	{ 0,  19, 18, 18 }, //right arrow NORMAL
	{ 0,  83, 1,  18 }, //page left   NORMAL
	{ 0,  83, 1,  18 }, //page right  NORMAL
	
	{ -1, -1, -1, -1 },	//padding

	{ 54, 0,  9,  18 }, //horz thumb (left)
	{ 54+9, 0, 1, 18 }, //horz thumb (middle)
	{ 54+9, 0, 9, 18 }, //horz thumb (right)
};

CustomDrawTable cdt_horz_hot[] = 
{
	{ 18, 0,  18, 18 }, //left arrow  ACTIVE
	{ 18, 19, 18, 18 }, //right arrow ACTIVE
	{ 4,  83, 1,  18 }, //page left   ACTIVE
	{ 4,  83, 1,  18 }, //page right  ACTIVE

	{ -1, -1, -1, -1 },	//padding

	{ 54,   19, 9, 18 }, //horz thumb (left)
	{ 54+9, 19, 1, 18 }, //horz thumb (middle)
	{ 54+9, 19, 9, 18 }, //horz thumb (right)
};

CustomDrawTable cdt_horz_active[] = 
{
	{ 36, 0,  18, 18 }, //left arrow  ACTIVE
	{ 36, 19, 18, 18 }, //right arrow ACTIVE
	{ 4,  83, 1,  18 }, //page left   ACTIVE
	{ 4,  83, 1,  18 }, //page right  ACTIVE

	{ -1, -1, -1, -1 },	//padding

	{ 54,   38, 9, 18 }, //horz thumb (left)
	{ 54+9, 38, 1, 18 }, //horz thumb (middle)
	{ 54+9, 38, 9, 18 }, //horz thumb (right)
};

CustomDrawTable cdt_vert_normal[] = 
{
	{ 72, 0,  18, 18 }, //up arrow   NORMAL
	{ 72, 19, 18, 18 }, //down arrow NORMAL
	{ 0,  112, 18, 1 }, //page up	 NORMAL
	{ 0,  112, 18, 1 }, //page down  NORMAL

	{ -1, -1, -1, -1 },	//padding

	{ 126, 0,  18, 9  }, //vert thumb (left)
	{ 126, 9,  18, 1  }, //vert thumb (middle)
	{ 126, 9,  18, 9  }, //vert thumb (right)
};

CustomDrawTable cdt_vert_hot[] = 
{
	{ 90, 0,  18, 18 }, //up arrow   ACTIVE
	{ 90, 19, 18, 18 }, //down arrow ACTIVE
	{ 4,  83, 18, 1  }, //page up	 ACTIVE
	{ 4,  83, 18, 1  }, //page down  ACTIVE

	{ -1, -1, -1, -1 },	//padding

	{ 126, 19,  18, 9  }, //vert thumb (left)
	{ 126, 28,  18, 1  }, //vert thumb (middle)
	{ 126, 28,  18, 9  }, //vert thumb (right)
};

CustomDrawTable cdt_vert_active[] = 
{
	{ 108, 0,  18, 18 }, //up arrow   ACTIVE
	{ 108, 19, 18, 18 }, //down arrow ACTIVE
	{ 4,  83, 18, 1  }, //page up	 ACTIVE
	{ 4,  83, 18, 1  }, //page down  ACTIVE

	{ -1, -1, -1, -1 },	//padding

	{ 126, 38,  18, 9  }, //vert thumb (left)
	{ 126, 47,  18, 1  }, //vert thumb (middle)
	{ 126, 47,  18, 9  }, //vert thumb (right)
};

LRESULT HandleCustomDraw(UINT ctrlid, NMCSBCUSTOMDRAW *nm)
{
	RECT *rc;
	CustomDrawTable *cdt;
	UINT code = NM_CUSTOMDRAW;

	UNREFERENCED_PARAMETER(ctrlid);
/*
	// inserted buttons do not use PREPAINT etc..
	if(nm->nBar == SB_INSBUT)
	{
		CoolSB_DrawProc(nm->hdc, nm->uItem, nm->uState, &nm->rect);
		return CDRF_SKIPDEFAULT;
	}
*/
//	if(!fCustomDraw) return CDRF_DODEFAULT;

	if(nm->dwDrawStage == CDDS_PREPAINT)
	{
		if(1 == 1)
			return CDRF_SKIPDEFAULT;
		else
			return CDRF_DODEFAULT;
	}

	if(nm->dwDrawStage == CDDS_POSTPAINT)
	{
		
	}

	//the sizing gripper in the bottom-right corner
	if(nm->nBar == SB_BOTH)	
	{
		RECT *rc = &nm->rect;
		
		StretchBlt(nm->hdc, rc->left, rc->top, rc->right-rc->left, rc->bottom-rc->top,
			hdcSkin, 100, 100, 18, 18, SRCCOPY);
				
		return CDRF_SKIPDEFAULT;
	}
	else if(nm->nBar == SB_HORZ)
	{
		rc = &nm->rect;

		if(nm->uState == CDIS_HOT)	
			cdt = &cdt_horz_hot[nm->uItem];
		else if(nm->uState == CDIS_SELECTED) 
			cdt = &cdt_horz_active[nm->uItem];
		else				   
			cdt = &cdt_horz_normal[nm->uItem];
		
		if(nm->uItem == HTSCROLL_THUMB)
		{
			StretchBlt(nm->hdc, rc->left,   rc->top, 9, rc->bottom-rc->top, hdcSkin, cdt->x, cdt->y, cdt->width, cdt->height, SRCCOPY);
			cdt++;
			StretchBlt(nm->hdc, rc->left+9, rc->top, (rc->right-rc->left)-18, rc->bottom-rc->top, hdcSkin, cdt->x, cdt->y, cdt->width, cdt->height, SRCCOPY);
			cdt++;
			StretchBlt(nm->hdc, rc->left+(rc->right-rc->left)-9, rc->top, 9, rc->bottom-rc->top, hdcSkin, cdt->x, cdt->y, cdt->width, cdt->height, SRCCOPY);
			return CDRF_SKIPDEFAULT;
		}

	}
	else if(nm->nBar == SB_VERT)
	{
		rc = &nm->rect;

		if(nm->uState == CDIS_HOT)		
			cdt = &cdt_vert_hot[nm->uItem];
		else if(nm->uState == CDIS_SELECTED)  
			cdt = &cdt_vert_active[nm->uItem];
		else				    
			cdt = &cdt_vert_normal[nm->uItem];

		if(nm->uItem == HTSCROLL_THUMB)
		{
			StretchBlt(nm->hdc, rc->left, rc->top,   rc->right-rc->left, 9, hdcSkin, cdt->x, cdt->y, cdt->width, cdt->height, SRCCOPY);
			cdt++;
			StretchBlt(nm->hdc, rc->left, rc->top+9, rc->right-rc->left, (rc->bottom-rc->top)-18, hdcSkin, cdt->x, cdt->y, cdt->width, cdt->height, SRCCOPY);
			cdt++;			
			StretchBlt(nm->hdc, rc->left, rc->top+(rc->bottom-rc->top)-9, rc->right-rc->left, 9,hdcSkin, cdt->x, cdt->y, cdt->width, cdt->height, SRCCOPY);
			return CDRF_SKIPDEFAULT;
		}
	}
/*
	//INSERTED BUTTONS are handled here...
	else if(nm->nBar == SB_INSBUT)
	{
		CoolSB_DrawProc(nm->hdc, nm->uItem, nm->uState, &nm->rect);
		return CDRF_SKIPDEFAULT;
	}
	else
	{
		return CDRF_DODEFAULT;
	}
*/
	//normal bitmaps, use same code for HORZ and VERT
	StretchBlt(nm->hdc, rc->left, rc->top, rc->right-rc->left, rc->bottom-rc->top,
		hdcSkin, cdt->x, cdt->y, cdt->width, cdt->height, SRCCOPY);

	return CDRF_SKIPDEFAULT;

}


int __stdcall WINAPI initscroll(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
{
	hdcSkin  = CreateCompatibleDC(0);
	hSkinBmp = LoadAnImage(data);
	//	hSkinBmp = (HBITMAP)LoadImage(0, data, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_CREATEDIBSECTION);
	if (!hSkinBmp) {
		wsprintf(data,"S_ERR wrong scroll");
		return 3;
	}
	SelectObject(hdcSkin, hSkinBmp);
	wsprintf(data,"S_ok");
	return 3;
}


void RedrawNC(HWND hwnd)
{
	SetWindowPos(hwnd, 0, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE|
		SWP_FRAMECHANGED|SWP_DRAWFRAME);

}

bool okscroll() {
	if (hSkinBmp) return 1;
	return 0;
}