
#include <windows.h>
#include "coolscroll.h"
#include <Commctrl.h>

#include "fonction.h"

bool okscroll();
void mIRCaff(char *text);
void OnDropFiles(HDROP,HWND);


int atoi(char *c);

void	InitTest(void);
int size=18;

HWND GethIDhwnd(int id);
//char* gettok(char *data, int pos, char *C, int all = 0);
//HBITMAP LoadAnImage(char* FileName);
//WNDPROC ancienproc;
//LRESULT result;

//
//	Child window procedure
//

void SetupScrollbarsInvert(HWND hwnd)
{

	SCROLLINFO si;
	si.cbSize	= sizeof(si);

	si.fMask	= SIF_TRACKPOS | SIF_PAGE | SIF_POS | SIF_RANGE ;//| SIF_DISABLENOSCROLL;

	SCROLLINFO siSB;
	siSB.cbSize	= sizeof(siSB);

	siSB.fMask	= SIF_TRACKPOS | SIF_PAGE | SIF_POS | SIF_RANGE ;//| SIF_DISABLENOSCROLL;

		// VERT
	GetScrollInfo(hwnd,SB_VERT,&si);
	CoolSB_GetScrollInfo(hwnd,SB_VERT,&siSB);
	si.nPos=siSB.nPos;
	if (si.nPos<si.nMin) { si.nPos=si.nMin; }
	if (si.nPos>si.nMax) { si.nPos=si.nMax; }

	SetScrollInfo(hwnd, SB_VERT, &si, TRUE);

		// HORZ
	GetScrollInfo(hwnd,SB_HORZ,&si);
	CoolSB_GetScrollInfo(hwnd,SB_HORZ,&siSB);
	si.nPos=siSB.nPos;
	if (si.nPos<si.nMin) { si.nPos=si.nMin; }
	if (si.nPos>si.nMax) { si.nPos=si.nMax; }

	SetScrollInfo(hwnd, SB_HORZ, &si, TRUE);

}


void SetupScrollbars(HWND hwnd)
{

	LONG Styles = GetWindowLong(hwnd, GWL_STYLE);

	SCROLLINFO si;
	si.cbSize	= sizeof(si);

/*
	SCROLLBARINFO sbi;
	sbi.cbSize	= sizeof(sbi);
	b = GetScrollBarInfo(hwnd,OBJID_VSCROLL,&sbi);
*/
	si.fMask	= SIF_TRACKPOS | SIF_PAGE | SIF_POS | SIF_RANGE | SIF_DISABLENOSCROLL;

		// VERT
	if (Styles & WS_VSCROLL) {
		GetScrollInfo(hwnd,SB_VERT,&si);
		CoolSB_SetScrollInfo(hwnd, SB_VERT, &si, TRUE);
	}
		// HORZ
	if (Styles & WS_HSCROLL) {
		GetScrollInfo(hwnd,SB_HORZ,&si);
		CoolSB_SetScrollInfo(hwnd, SB_HORZ, &si, TRUE);
	}

}


LRESULT CALLBACK ChildWndProc2(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{

	static int count;

	LPSCROLLMIRC scrollpt = (LPSCROLLMIRC)GetWindowLong(hwnd, GWL_USERDATA);

//	char text [255];
//	wsprintf(text,"%s %d","liste box ",msg);
//	mIRCaff(text);



	switch(msg)
	{

	case WM_DROPFILES:
		{
			OnDropFiles((HDROP) wParam,hwnd);
		}
	break;

    case WM_DESTROY:{ 
		long  l =  CallWindowProc(scrollpt->ancienproc,hwnd,msg,wParam,lParam);
		UninitializeCoolSB(hwnd);
		return l;
		}
		break;
	case WM_VSCROLL:
		{
		SCROLLINFO si;
		si.cbSize	= sizeof(si);
		si.fMask	= SIF_PAGE | SIF_POS | SIF_RANGE | SIF_TRACKPOS;
		GetScrollInfo(hwnd,SB_VERT,&si);

//	CoolSB_SetScrollInfo(hwnd,  SB_VERT, &si,0);


	CoolSB_SetScrollPos(hwnd, SB_VERT, si.nPos, TRUE);

	CallWindowProc(scrollpt->ancienproc,hwnd,msg,wParam,lParam);

//InvalidateRect(hwnd, 0, 1);

		return 0;
		}
	break;
	case WM_HSCROLL:
		{
		SCROLLINFO si;
		si.cbSize	= sizeof(si);
		si.fMask	= SIF_PAGE | SIF_POS | SIF_RANGE | SIF_TRACKPOS;
		GetScrollInfo(hwnd,SB_HORZ,&si);

		CoolSB_SetScrollPos(hwnd, SB_HORZ, si.nPos, TRUE);

		CallWindowProc(scrollpt->ancienproc,hwnd,msg,wParam,lParam);

//		InvalidateRect(hwnd, 0, 1);

		return 0;
		}
	break;
	case 0x020A: // case WM_MOUSEWHEEL:
		{
		CallWindowProc(scrollpt->ancienproc,hwnd,msg,wParam,lParam);
		SetupScrollbars(hwnd);
		return 0;
		}
	case WM_SIZE:
		{
		CallWindowProc(scrollpt->ancienproc,hwnd,msg,wParam,lParam);
		SetupScrollbars(hwnd);
		return 0;
		}
	break;
	case WM_KEYFIRST:
		{
		CallWindowProc(scrollpt->ancienproc,hwnd,msg,wParam,lParam);
		SetupScrollbars(hwnd);
		return 0;
		}
	break;
/*
  case WM_ERASEBKGND:
		{
		CallWindowProc(scrollpt->ancienproc,hwnd,msg,wParam,lParam);
//		SetupScrollbars(hwnd);
		return 0;
		}
	break;
*/

  //	case 257:{
//SetupScrollbars(hwnd);
//			 }
//		break;

	case LB_ADDSTRING:
		{
		CallWindowProc(scrollpt->ancienproc,hwnd,msg,wParam,lParam);
		SetupScrollbars(hwnd);
		return 0;
		}
	}

	return CallWindowProc(scrollpt->ancienproc,hwnd,msg,wParam,lParam);
}


/*
void createscroll(HWND hwnd) {

SCROLLINFO si;
RECT rt;
int largeur;
int hauteur;
HWND phwnd = GetParent(hwnd);
HWND nhwnd;


		InitializeCoolSB(hwnd);
		CoolSB_SetStyle(hwnd, SB_BOTH, CSBS_NORMAL);
/*
		si.cbSize = sizeof(si);
		si.fMask  = SIF_ALL;
		si.nMin   = 0;
		si.nMax   = 100;
		si.nPos   = 0;
		si.nPage  = 10;

		SetScrollInfo(hwnd, SB_VERT, &si, TRUE);
*//*
	fCustomDraw = 1;

	CoolSB_SetSize(hwnd, SB_BOTH, 18, 18);
	CoolSB_SetMinThumbSize(hwnd, SB_BOTH, 18);
	CoolSB_SetStyle(hwnd, SB_BOTH, CSBS_HOTTRACKED);


	ancienproc = (WNDPROC)SetWindowLong(hwnd,GWL_WNDPROC,(long)ChildWndProc2);			

	SetupScrollbars(hwnd);

	return;
}
*/
/*
void testscroll(HWND hwnd) {

	InitializeCoolSB(hwnd);
	CoolSB_SetStyle(hwnd, SB_BOTH, CSBS_NORMAL);
	CoolSB_SetSize(hwnd, SB_BOTH, 18, 18);
	CoolSB_SetMinThumbSize(hwnd, SB_BOTH, 18);
	CoolSB_SetStyle(hwnd, SB_BOTH, CSBS_HOTTRACKED);

	ancienproc = (WNDPROC)SetWindowLong(hwnd,GWL_WNDPROC,(long)ChildWndProc2);			

	SetupScrollbars(hwnd);
}
*/

typedef struct tagMYLV
{
	WNDPROC proc;
	HWND hwnd;
} MYLV,*LPMYLV;



void clearScroll(){

}


void setcomscroll(HWND hwnd,int wSBflags) {
	CoolSB_SetSize(hwnd, wSBflags, size, size);
	CoolSB_SetMinThumbSize(hwnd, wSBflags, size);
	CoolSB_SetStyle(hwnd, wSBflags, CSBS_HOTTRACKED);
}


int __stdcall WINAPI Scroollbar(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
{
	if (!lstrcmpi(gettok(data,1," "),"size")) {
		size = atol(gettok(data,2," "));
		lstrcpy(data,"S_ok"); return 3;
	}
//	if (!lstrcmpi(gettok(data,1," "),"border")) {
//		hboxc = LoadAnImage(gettok(data,2," ",1));
//		if (!hboxc) { lstrcpy(data,"mauvaise image pour listbox"); return 3; }
//	}
	lstrcpy(data,"Unknow command"); return 3;
	return 3;
}

int __stdcall WINAPI Scrooll(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
	{

	HWND hwnd = GethIDhwnd(atoi(data));

	if (GetWindowLong(hwnd, GWL_USERDATA)) { wsprintf(data,"S_ERR No scroll available"); return 3; }
	if (!hwnd) { wsprintf(data,"ERR Dialog lost Mark or Wrond ID"); return 3; }
	
	if (!okscroll()) {
		wsprintf(data,"S_ERR Bitmap for scrolling not loaded");
		return 3;
	}

	LONG Styles = GetWindowLong(hwnd, GWL_STYLE);

//	bool b = InitializeCoolSB(hwnd);
	if (!InitializeCoolSB(hwnd)) {
		wsprintf(data,"S_ERR Handle non dispo");
		return 3;
	}


//if (Styles & WS_VSCROLL) {

//	bool b = CoolSB_SetStyle(hwnd, SB_VERT, CSBS_NORMAL);
	setcomscroll(hwnd, SB_VERT);

	LPSCROLLMIRC scrollpt = new SCROLLMIRC;
	
	scrollpt->ancienproc = (WNDPROC)SetWindowLong(hwnd,GWL_WNDPROC,(long)ChildWndProc2);			

	SetWindowLong(hwnd, GWL_USERDATA, (LONG) scrollpt);

	SetupScrollbars(hwnd);

	wsprintf(data,"S_OK");
	return 3;

}