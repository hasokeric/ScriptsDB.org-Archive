
//http://www.cppfrance.com/code.aspx?ID=10718

// fichier inclus pour les applications windows
#include <windows.h>
// fichier contenant les d�finitions des contr�les communs
#include <commctrl.h>
// fichier contenant les d�finitions sp�cifiques au richedit
#include <richedit.h>
#include <windowsx.h>

#include "fonction.h"

#define MAXRICH 30
//int numtok(char *data, char *C);
void mIRCeval(char *text, char *res);
void RichEditInsertText(HWND hwnd, char *text, bool bline, bool uline, bool bcolor, COLORREF color, bool bbkgcolor, COLORREF bkgcolor, int reverse);
void mIRCaff(char *text);

struct RICH
{
	HWND edtSample;
	HWND edtancien;
	WNDPROC Richancienproc;
};


RICH myrich[MAXRICH];
HWND richsel = NULL;

//COLORREF color1 = RGB(0,0,255);
//COLORREF color2 = RGB(255,0,0);

COLORREF palette[16];

#define mProc(x) LRESULT CALLBACK x(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam)

HINSTANCE richDll;

//***********************

void RichEditClear(HWND hwnd) {
  SendMessage(hwnd,EM_HIDESELECTION, 1, 0);
  SendMessage(hwnd,EM_SETSEL, 0, -1);
  SendMessage(hwnd,EM_REPLACESEL, false, (DWORD) "");
  SendMessage(hwnd,EM_SETSEL, -1, -1);
  SendMessage(hwnd,EM_HIDESELECTION, 0, 0);		
}

void RichEditSetPalette(HWND hwnd, char *data) {
 
  int i = 0, n = numtok(data," ");
  COLORREF color;

  while (i < n) {

    color = (COLORREF) atol(gettok(data,i+1," ",0));
    palette[i] = color;

    i++;
  }
}

void RichEditmIRCPalette(char *colors) {

  char com[255];
  lstrcpy(com,"$color(0) $color(1) $color(2) $color(3) $color(4) $color(5) $color(6) $color(7) $color(8) $color(9) $color(10) $color(11) $color(12) $color(13) $color(14) $color(15)");
  mIRCeval(com, colors);
  //Signal(colors);
}

COLORREF RichEditColor(int color) {

  char com[20];
  char col[20];
  wsprintf(com,"$color(%d).hwnd",color);
  mIRCeval(com, col);

  COLORREF rcol = (COLORREF) atol(col);
  return rcol;
}

bool RichEditIsNum(char a) {
  if (a >= '0' && a <= '9') return 1;
  return 0;
}

void RichEditParseText(HWND phwnd, HWND rehwnd, bool newline) {

  int len = GetWindowTextLength(phwnd);
  char *text = new char[len+2];

  GetWindowText(phwnd, text, len+1);
  RichEditClear(rehwnd);

  bool uline = false;
  bool bline = false;
  //int mcolor = -1;
  //int bkgcolor = -1;
  COLORREF mcolor = 0;
  COLORREF bkgcolor = 0;

  bool bmcolor = true;
  bool bbkgcolor = false;

  char cbuf[2];
  char colbuf[3];
  cbuf[1] = '\0';
  colbuf[2] = '\0';

  int i = 0;
  while (text[i] != '\0') {

    cbuf[0] = text[i];

    // if current char is a control code
    if (text[i] == 2 || text[i] == 3 || text[i] == 15 || text[i] == 22 || text[i] == 31) {

      // CTRL+B Parsing
      if (text[i] == 2) {
        bline = (1 - bline) ? true : false;
      }
      // CTRL+K Parsing
      else if (text[i] == 3) {

        if (RichEditIsNum(text[i+1])) {
          //Signal("digit detected");
          colbuf[0] = text[i+1];
          colbuf[1] = '\0';
          i++;

          if (RichEditIsNum(text[i+1])) {
            //Signal("double digit detected");
            colbuf[1] = text[i+1];
            i++;
          }
          // color code number
          bmcolor = true;
          mcolor = palette[(int) atoi(colbuf)];
          //Signal(colbuf);

          // maybe a background color
          if (text[i+1] == ',') {

            i++;
            if (RichEditIsNum(text[i+1])) {
              //Signal("digit detected");
              colbuf[0] = text[i+1];
              colbuf[1] = '\0';
              i++;

              if (RichEditIsNum(text[i+1])) {
                //Signal("double digit detected");
                colbuf[1] = text[i+1];
                i++;
              }
              // color code number
              bbkgcolor = true;
              bkgcolor = palette[(int) atoi(colbuf)];
              //Signal(colbuf);
            }
          }
        }
        else {
          bmcolor = false;
          bbkgcolor = false;
        }
      }
      // CTRL+O Parsing
      else if (text[i] == 15) {
        bline = false;
        uline = false;
        mcolor = -1;
        bkgcolor = -1;
      }
      // CTRL+R Parsing
      else if (text[i] == 22) {
        bline = false;
        uline = false;
      }
      // CTRL+U Parsing
      else if (text[i] == 31) {
        uline = (1 - uline) ? true : false;
      }

      //Signal("Control Code Detected");
    }
    // regular char
    else if (text[i] == '\n' && newline) {
      bline = false;
      uline = false;
      mcolor = -1;
      bkgcolor = -1;
    }
    else {
      //Signal(cbuf);
      RichEditInsertText(rehwnd, cbuf, bline, uline, bmcolor, mcolor, bbkgcolor, bkgcolor, 0);
    }
    i++;
  }
  RedrawWindow(rehwnd, NULL, NULL, RDW_INTERNALPAINT|RDW_ALLCHILDREN|RDW_INVALIDATE|RDW_ERASE);

  delete []text;
}

//*******************



CHARFORMAT2 RichEditGetCFormat(HWND hwnd) {
  CHARFORMAT2 chrf;
  ZeroMemory(&chrf, sizeof(CHARFORMAT2));
  chrf.cbSize = sizeof(CHARFORMAT2);		
  SendMessage(hwnd,EM_GETCHARFORMAT,SCF_DEFAULT,(LPARAM)&chrf);
  return chrf;
}


void RichEditInsertText(HWND hwnd, char *text, bool bline, bool uline, bool bcolor, COLORREF color, bool bbkgcolor, COLORREF bkgcolor, int reverse) {

  // get total length
  int len = GetWindowTextLength(hwnd);
  // get line char number from end char pos
  int line = Edit_LineIndex(hwnd, Edit_LineFromChar(hwnd, len-1));
  // get line length
  int linelen = SendMessage(hwnd,EM_LINELENGTH, line, 0);
  // total length of insert point
  len = line + linelen;

  // position caret at pos len and insert the text
  SendMessage(hwnd,EM_HIDESELECTION, 1, 0);
  SendMessage(hwnd,EM_SETSEL, len, -1);
  SendMessage(hwnd,EM_REPLACESEL, false, (DWORD) text);
  SendMessage(hwnd,EM_SETSEL, -1, -1);
  SendMessage(hwnd,EM_HIDESELECTION, 0, 0);		

  CHARFORMAT2 chrf;
  ZeroMemory(&chrf, sizeof(CHARFORMAT2));
  chrf.cbSize = sizeof(CHARFORMAT2);
  chrf = RichEditGetCFormat(hwnd);


/*
  CHARFORMAT2 chrf;
  ZeroMemory(&chrf, sizeof(CHARFORMAT2));
  chrf.cbSize = sizeof(CHARFORMAT2);
  chrf.dwMask = CFM_BACKCOLOR | CFM_BOLD | CFM_COLOR | CFM_FACE | CFM_ITALIC | CFM_SIZE | CFM_UNDERLINE;
  chrf.dwEffects = 0;
  chrf.crTextColor = 0;
  chrf.crBackColor = RGB(255,255,255);
 */

  chrf.dwMask = CFM_BACKCOLOR | CFM_BOLD | CFM_COLOR | CFM_FACE | CFM_ITALIC | CFM_SIZE | CFM_UNDERLINE;

  chrf.dwEffects = 0;

chrf.bCharSet = ANSI_CHARSET;
chrf.bPitchAndFamily = DEFAULT_PITCH;
strcpy(chrf.szFaceName, "Tahoma");


  //if (color != -1) chrf.crTextColor = RichEditColor(color);
  //if (color != -1) chrf.crBackColor = RichEditColor(bkgcolor);
  if (bcolor) chrf.crTextColor = color;
  if (bbkgcolor) chrf.crBackColor = bkgcolor;
  if (bline) chrf.dwEffects |= CFE_BOLD;
  if (uline) chrf.dwEffects |= CFE_UNDERLINE;


  // select from pos len to end and color text with specified parameters
  SendMessage(hwnd,EM_HIDESELECTION, 1, 0);
  SendMessage(hwnd,EM_SETSEL, len, -1);
  SendMessage(hwnd,EM_SETCHARFORMAT, SCF_SELECTION, (LPARAM) &chrf);
  SendMessage(hwnd,EM_SETSEL, -1, -1);
  SendMessage(hwnd,EM_HIDESELECTION, 0, 0);
}

void initRE() {
   InitCommonControls();
   richDll = LoadLibrary("RICHED32.DLL");

  char richcolors[255];
  RichEditmIRCPalette(richcolors);
  RichEditSetPalette(NULL, richcolors);
}

void creerrichedit(HWND phwnd) {

	int cur = 0;
//	while (myrich[cur].edtancien != NULL) cur++;
	while (::IsWindow(myrich[cur].edtancien)) cur++;



	RECT rt;
	GetWindowRect( phwnd, &rt);
	int largeur=rt.right-rt.left ;
	int hauteur=rt.bottom-rt.top ;
	AdjustRectCoords(GetParent(phwnd),&rt);

//WS_HSCROLL
  HWND hwnd = CreateWindowEx(
    WS_EX_CLIENTEDGE | WS_EX_TOPMOST ,
    "RichEdit",
    NULL,
    WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 
    rt.left, rt.top, largeur, hauteur,
    GetParent(phwnd),
    NULL,
    GetModuleHandle(NULL), 
    NULL);

//	AddWinStyles(phwnd, GWL_STYLE, WS_CLIPCHILDREN);


//	myrich[cur].Richancienproc = (WNDPROC)SetWindowLong(hwnd,GWL_WNDPROC,(long)RichEditProc);

	myrich[cur].edtSample = hwnd;
	myrich[cur].edtancien = phwnd;

//	RichEditInsertText(hwnd, "zuttte", 1, 1, 1, color1, 1, color2, 0);
//	RichEditInsertText(hwnd, "blabla", 0, 0, 1, color2, 1, color1, 0);

//    ShowWindow(hwnd, SW_HIDE);
	//ShowWindow(hwnd, SW_SHOW);

 // char richcolors[255];
 // RichEditmIRCPalette(richcolors);
 // RichEditSetPalette(hwnd, richcolors);

}

void updaterichedit(HWND hwndedit) {
	int cur = 0;
	while (myrich[cur].edtancien != NULL) {
		if (hwndedit == myrich[cur].edtancien) {
			RichEditParseText(myrich[cur].edtancien,myrich[cur].edtSample, 1);
		}
		cur++;
	}
}

void affrichedit(HWND hwndedit) {
	int cur = 0;
	while (myrich[cur].edtancien != NULL) {
		if (hwndedit == myrich[cur].edtancien) {
			RichEditParseText(myrich[cur].edtancien,myrich[cur].edtSample, 1);
			ShowWindow(myrich[cur].edtSample, SW_SHOW);
			ShowWindow(myrich[cur].edtancien, SW_HIDE);
//			SetFocus(edtSample);
		}
		cur++;
	}
}

void suprichedit(HWND hwndedit) {
//	return;
	int cur = 0;
	while (myrich[cur].edtancien != NULL) {
		if (hwndedit == myrich[cur].edtSample) {
			ShowWindow(myrich[cur].edtSample, SW_HIDE); 
			ShowWindow(myrich[cur].edtancien, SW_SHOW);
			SetFocus(myrich[cur].edtancien);
			richsel = myrich[cur].edtSample;
		}
		cur++;
	}
}

void pasrichedit() {
	if (richsel != NULL) {
		ShowWindow(richsel, SW_SHOW);
		int cur = 0;
		while ((myrich[cur].edtSample != richsel) && (cur < MAXRICH )) cur ++;
		ShowWindow(myrich[cur].edtancien, SW_HIDE);
		//		SetFocus(richsel);
		richsel = NULL;
	}
}

void clearrichedit() {
	FreeLibrary(richDll);
//	DeleteObject(rgn);
	return;
}