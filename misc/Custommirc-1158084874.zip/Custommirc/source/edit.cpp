#include <windows.h>
#include "fonction.h"
#include "coolscroll.h"



HBITMAP hedit;

void mIRCaff(char *text);

void clearfond(HDC hdc,HWND hwnd,RECT rt);

void OnDropFiles(HDROP hDropInfo,HWND hwnd);

extern COLORREF cinvisible;





LRESULT WINAPI editProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{


//	char text [255];

//	wsprintf(text,"%s %d","edit",msg);
//	mIRCaff(text);	

	HDC				hdc;
	PAINTSTRUCT		ps;
	RECT			rect;
	RECT			rect2;
//	POINT			pt;
	
	WNDPROC			OldComboProc = (WNDPROC)GetWindowLong(hwnd, GWL_USERDATA);

	static BOOL		fMouseDown   = FALSE;
	static BOOL		fButtonDown  = FALSE;
	

	switch(msg)
	{
	case WM_NCPAINT:
		{

return 0;
/*

		RECT rect2;
		GetClientRect(hwnd, &rect2);


	hdc=GetDCEx(hwnd, (HRGN)wParam, DCX_WINDOW|DCX_INTERSECTRGN);

hdc = GetDC(hwnd);

//	wsprintf(text,"%s %d","edit nc",wParam);
//	mIRCaff(text);	


//CallWindowProc(OldComboProc, hwnd, msg, (WPARAM)hdc, lParam);

MyTransparentBlt2(hdc,rect2.left,rect2.top,rect2.right-rect2.left,rect2.bottom-rect2.top,hedit,RGB(0,0,0));


	ReleaseDC(hwnd, hdc);

		return 0;
*/
  
		}
		break;

  
	case WM_PAINT:

		{
		if(wParam == 0)		hdc = BeginPaint(hwnd, &ps);
		else				hdc = (HDC)wParam;


		GetClientRect(hwnd, &rect);


		//double buffer
		HDC hMemDC= CreateCompatibleDC(hdc);
		int cx = rect.right-rect.left;
		int cy = rect.bottom-rect.top;
		HBITMAP hMemBmp= CreateCompatibleBitmap(hdc, cx,cy);
		HBITMAP hOldBmp= (HBITMAP)SelectObject(hMemDC, hMemBmp);
		BitBlt(hMemDC, 0, 0, cx,cy, hdc, 0, 0, SRCCOPY);



		InflateRect(&rect, -GetSystemMetrics(SM_CXEDGE), -GetSystemMetrics(SM_CYEDGE));
		
		InflateRect(&rect, -2, -2);
		
		IntersectClipRect(hMemDC, rect.left, rect.top, rect.right, rect.bottom);
		
		CallWindowProc(OldComboProc, hwnd, msg, (WPARAM)hMemDC, lParam);


		SelectClipRgn(hMemDC, NULL);

		ExcludeClipRect(hMemDC, rect.left, rect.top, rect.right, rect.bottom);
		

		GetClientRect(hwnd, &rect2);
		MyTransparentBlt2(hMemDC,rect2.left,rect2.top,rect2.right-rect2.left,rect2.bottom-rect2.top,hedit,cinvisible);

		// recopie du contexte en m�moire � l'�cran
		BitBlt(hdc, 0, 0, cx,cy, hMemDC, 0, 0, SRCCOPY);
		// s�lection anciens objets, destruction de ceus cr��s
		SelectObject(hMemDC, hOldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(hMemDC);


		if(wParam == 0)
			EndPaint(hwnd, &ps);

		return 0;
		}
	break;
	
	case WM_KILLFOCUS:
		{
			InvalidateRect(hwnd, 0, 0);
		}
		break;
	case WM_GETDLGCODE :
		//135 256 258 257
		{

	//				wsprintf(text,"%s %s","edit","modif");
	//				mIRCaff(text);

		InvalidateRect(hwnd, 0, 0);
		}
		break;
	case WM_NCHITTEST:
		{
			if (GetAsyncKeyState(VK_LBUTTON)){
				//	wsprintf(text,"%s %s","edit","modif");
				//	mIRCaff(text);
				InvalidateRect(hwnd, 0, 0);
			}
		}
		break;
	case WM_ERASEBKGND:
//		InvalidateRect(hwnd, 0, 0);
		break;



//donn�e pr scrollbar

    case WM_DESTROY:{ 
		long b =  CallWindowProc(OldComboProc,hwnd,msg,wParam,lParam);
		UninitializeCoolSB(hwnd);
		return b;
		}
		break;
	case WM_VSCROLL:
		{
		SCROLLINFO si;
		si.cbSize	= sizeof(si);
		si.fMask	= SIF_PAGE | SIF_POS | SIF_RANGE | SIF_TRACKPOS | SIF_DISABLENOSCROLL;
		GetScrollInfo(hwnd,SB_VERT,&si);

	CoolSB_SetScrollPos(hwnd, SB_VERT, si.nPos, TRUE);

	CallWindowProc(OldComboProc,hwnd,msg,wParam,lParam);

InvalidateRect(hwnd, 0, 1);

		return 0;
		}
	break;
	case WM_HSCROLL:
		{
		SCROLLINFO si;
		si.cbSize	= sizeof(si);
		si.fMask	= SIF_PAGE | SIF_POS | SIF_RANGE | SIF_TRACKPOS | SIF_DISABLENOSCROLL;
		GetScrollInfo(hwnd,SB_HORZ,&si);

		CoolSB_SetScrollPos(hwnd, SB_HORZ, si.nPos, TRUE);

		CallWindowProc(OldComboProc,hwnd,msg,wParam,lParam);

		InvalidateRect(hwnd, 0, 1);

		return 0;
		}
	break;
	case 0x020A: // case WM_MOUSEWHEEL:
		{
		CallWindowProc(OldComboProc,hwnd,msg,wParam,lParam);
		SetupScrollbars(hwnd);
		return 0;
		}
	case WM_SIZE:
		{
		CallWindowProc(OldComboProc,hwnd,msg,wParam,lParam);
		SetupScrollbars(hwnd);
		return 0;
		}
	break;
	
	case WM_KEYFIRST:
		{
		CallWindowProc(OldComboProc,hwnd,msg,wParam,lParam);
		SetupScrollbars(hwnd);
		return 0;
		}
	break;

	case WM_DROPFILES:
		{
			OnDropFiles((HDROP) wParam,hwnd);
		}
	break;
		

//
//  case WM_ERASEBKGND:
//		{
//		CallWindowProc(OldComboProc,hwnd,msg,wParam,lParam);
//		SetupScrollbars(hwnd);
//		return 0;
//		}
//	break;
//

//	case LB_ADDSTRING:
//		{
//		CallWindowProc(OldComboProc,hwnd,msg,wParam,lParam);
//		SetupScrollbars(hwnd);
//		return 0;
//		}
//		break;

	}
	
	return CallWindowProc(OldComboProc, hwnd, msg, wParam, lParam);
}

void Makeedit(HWND hwnd)
{


	LONG Styles = GetWindowLong(hwnd, GWL_STYLE);

	LONG OldComboProc;

	// Remember old window procedure
	OldComboProc = GetWindowLong(hwnd, GWL_WNDPROC);
	SetWindowLong(hwnd, GWL_USERDATA, OldComboProc);

	// Perform the subclass
	OldComboProc = SetWindowLong(hwnd, GWL_WNDPROC, (LONG)editProc);

	if ((Styles & WS_VSCROLL) || (Styles & WS_HSCROLL)) {
		if (!InitializeCoolSB(hwnd)) {
			return ;
		}

		setcomscroll(hwnd, SB_BOTH);

		SetupScrollbars(hwnd);
	}


}



int __stdcall WINAPI Edit(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
{

	char commande[0xFFF],val1[0xFFFF];

	char *c = data;
	while(*c != ' ') c++;
	*c='\0';
	wsprintf(commande,"%s",data);
	wsprintf(val1,"%s",c+1);

	int vale1 = atoi(val1);


	if (!lstrcmpi(commande,"bmp")) {
		hedit=LoadAnImage(val1);
		if (!hedit) {
			wsprintf(data,"S_ERR wrong edit BMP");
			return 3;
		}
		else wsprintf(data,"S_Ok");
		return 3;
	}

		wsprintf(data,"S_ERR Unknow Commande");
		return 3;

}

void clearedit(){
//	DeleteObject(ccadre);
	DeleteObject(hedit);
}

//*********************************************************************************************/


