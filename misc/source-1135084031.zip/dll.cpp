/*!
 * \file dll.cpp
 * \brief Main DLL File
 *
 * This file contains the main DCX dll routines.
 *
 * \author David Legault ( clickhere at scriptsdb dot org )
 * \version 1.0
 *
 * \b Revisions
 *
 * � ScriptsDB.org - 2005
 */

#include "defines.h"
#include "classes/dcxdialogcollection.h"
#include "classes/dcxdialog.h"
#include "classes/dcxcontrol.h"

#include "classes/custom/divider.h"

#include <exdisp.h>
#include <mshtml.h>
#include <exdispid.h>

DcxDialogCollection Dialogs; //!< blah

mIRCDLL mIRCLink; //!< blah

PFNSETTHEME SetWindowThemeUx = NULL; //!< blah
HMODULE UXModule = NULL;             //!< UxTheme.dll Module Handle
BOOL XPPlus = FALSE;                 //!< Is OS WinXP+ ?

FILE * logFile;

GdiplusStartupInput gdiplusStartupInput; // GDI+ Startup Input Param
ULONG_PTR           gdiplusToken;        // GDI+ Token Param

IClassFactory * g_pClassFactory; //!< Web Control Factory

/*!
 * \brief mIRC DLL Load Function
 *
 * This function is called when the DLL is loaded.
 *
 * It initializes all what the DLL needs and links mIRC received information to the mIRCDLL \b mIRCLink
 * data structure to be used later in various functions in the DLL.
 *
 * \param load mIRC Load Structure Pointer
 */

void WINAPI LoadDll( LOADINFO * load ) {

  mIRCLink.m_hFileMap = CreateFileMapping( INVALID_HANDLE_VALUE, 0, PAGE_READWRITE, 0, 4096, "mIRC" );     
  mIRCLink.m_pData = (LPSTR) MapViewOfFile( mIRCLink.m_hFileMap, FILE_MAP_ALL_ACCESS, 0, 0, 0 );
  mIRCLink.m_mIRCHWND = load->mHwnd;

  // Initializing OLE Support
  //CoInitialize( NULL );

  // Initializing OLE Support
  OleInitialize( NULL );

  //get IClassFactory* for WebBrowser
	CoGetClassObject( CLSID_WebBrowser, CLSCTX_INPROC_SERVER, 0, IID_IClassFactory, (void**) &g_pClassFactory );

  // RichEdit DLL Loading
  LoadLibrary( "RICHED20.DLL" );

  // UXModule Loading
  UXModule = LoadLibrary( "UXTHEME.DLL" );

  if( UXModule ) {

		SetWindowThemeUx = (PFNSETTHEME) GetProcAddress( UXModule, "SetWindowTheme" );
		
    if ( SetWindowThemeUx )
			XPPlus = TRUE;
    else {
			FreeLibrary( UXModule );
			UXModule = NULL;
      XPPlus = FALSE;
		}
	}

  // Initialize GDI+.
  GdiplusStartup( &gdiplusToken, &gdiplusStartupInput, NULL );

  // Load Control definitions
  INITCOMMONCONTROLSEX icex;
  icex.dwSize = sizeof( INITCOMMONCONTROLSEX );
  icex.dwICC  = ICC_TREEVIEW_CLASSES | ICC_BAR_CLASSES | ICC_PROGRESS_CLASS | ICC_LISTVIEW_CLASSES | 
    ICC_USEREX_CLASSES | ICC_COOL_CLASSES | ICC_STANDARD_CLASSES | ICC_UPDOWN_CLASS | ICC_DATE_CLASSES | 
    ICC_TAB_CLASSES | ICC_INTERNET_CLASSES;
  InitCommonControlsEx( &icex ); 

  WNDCLASSEX wc;
  ZeroMemory( (void*)&wc , sizeof(WNDCLASSEX) );
  wc.cbSize = sizeof( WNDCLASSEX );

  // Custom ProgressBar
  GetClassInfoEx( NULL, PROGRESS_CLASS, &wc );
  wc.lpszClassName = DCX_PROGRESSBARCLASS;
  RegisterClassEx( &wc );

  // Custom TreeView
  GetClassInfoEx( NULL, WC_TREEVIEW, &wc );
  wc.lpszClassName = DCX_TREEVIEWCLASS;
  RegisterClassEx( &wc );

  // Custom Toolbar
  GetClassInfoEx( NULL, TOOLBARCLASSNAME, &wc );
  wc.lpszClassName = DCX_TOOLBARCLASS;
  RegisterClassEx( &wc );

  // Custom StatusBar
  GetClassInfoEx( NULL, STATUSCLASSNAME, &wc );
  wc.lpszClassName = DCX_STATUSBARCLASS;
  RegisterClassEx( &wc );

  // Custom ListView
  GetClassInfoEx( NULL, WC_LISTVIEW, &wc );
  wc.lpszClassName = DCX_LISTVIEWCLASS;
  RegisterClassEx( &wc );

  // Custom ComboEx
  GetClassInfoEx( NULL, WC_COMBOBOXEX, &wc );
  wc.lpszClassName = DCX_COMBOEXCLASS;
  RegisterClassEx( &wc );
  
  // Custom TrackBar
  GetClassInfoEx( NULL, TRACKBAR_CLASS, &wc );
  wc.lpszClassName = DCX_TRACKBARCLASS;
  RegisterClassEx( &wc );

  // Custom RichEdit
  GetClassInfoEx( NULL, "RichEdit20A", &wc );
  wc.lpszClassName = DCX_RICHEDITCLASS;
  RegisterClassEx( &wc );

  // Custom RebarCtrl
  GetClassInfoEx( NULL, REBARCLASSNAME, &wc );
  wc.lpszClassName = DCX_REBARCTRLCLASS;
  RegisterClassEx( &wc );

  // Custom Color Combo
  GetClassInfoEx( NULL, "COMBOBOX", &wc );
  wc.lpszClassName = DCX_COLORCOMBOCLASS;
  RegisterClassEx( &wc );

  // Custom TabCtrl
  GetClassInfoEx( NULL, WC_TABCONTROL, &wc );
  wc.lpszClassName = DCX_TABCTRLCLASS;
  RegisterClassEx(&wc);

  // Custom UpDown
  GetClassInfoEx( NULL, UPDOWN_CLASS, &wc );
  wc.lpszClassName = DCX_UPDOWNCLASS;
  RegisterClassEx( &wc );

  // Custom IppAddress
  GetClassInfoEx( NULL, WC_IPADDRESS, &wc );
  wc.lpszClassName = DCX_IPADDRESSCLASS;
  RegisterClassEx( &wc );

  // Init Divider Control
  //InitDivider( GetModuleHandle( NULL ) );
  
  // Custom Divider
  wc.cbSize			    = sizeof( WNDCLASSEX );
	wc.style		  	  = 0;
	wc.lpfnWndProc	  = DividerWndProc;
	wc.cbClsExtra		  = 0;
	wc.cbWndExtra		  = 0;
	wc.hInstance		  = GetModuleHandle( NULL );
	wc.hIcon			    = NULL;
	wc.hCursor			  = NULL;
	wc.hbrBackground	= (HBRUSH)(COLOR_3DFACE+1);
	wc.lpszMenuName		= 0;
	wc.lpszClassName	= DCX_DIVIDERCLASS;
	wc.hIconSm			  = NULL;
  RegisterClassEx( &wc );
  
  //GetClassInfoEx( NULL, DIVIDERCLASSNAME, &wc );
  //wc.lpszClassName = ;
  //RegisterClassEx( &wc );
  
  /*
  // Custom Panel
  wc.cbSize			    = sizeof( WNDCLASSEX );
	wc.style		  	  = 0;
	wc.lpfnWndProc	  = DefWindowProc;
	wc.cbClsExtra		  = 0;
	wc.cbWndExtra		  = 0;
	wc.hInstance		  = GetModuleHandle( NULL );
	wc.hIcon			    = LoadCursor( GetModuleHandle( NULL ), IDC_ARROW );
	wc.hCursor			  = NULL;
	wc.hbrBackground	= NULL; //(HBRUSH)(COLOR_3DFACE+1);
	wc.lpszMenuName		= 0;
	wc.lpszClassName	= DCX_PANELCLASS;
	wc.hIconSm			  = NULL;
  RegisterClassEx( &wc );
  */
  
  // Custom Panel
  GetClassInfoEx( NULL, "#32770", &wc );
  wc.lpszClassName = DCX_PANELCLASS;
  RegisterClassEx( &wc );

  // Custom Box
  GetClassInfoEx( NULL, "#32770", &wc );
  wc.lpszClassName = DCX_BOXCLASS;
  RegisterClassEx( &wc );
    
  // Custom Button
  GetClassInfoEx( NULL, "BUTTON", &wc );
  wc.lpszClassName = DCX_BUTTONCLASS;
  RegisterClassEx( &wc );

  // Custom Calendar
  GetClassInfoEx( NULL, MONTHCAL_CLASS, &wc );
  wc.lpszClassName = DCX_CALENDARCLASS;
  RegisterClassEx( &wc );
}

/*!
 * \brief mIRC DLL UnLoad Function
 *
 * This function is called when the DLL is unloaded.
 *
 * It initializes all what the DLL needs and links mIRC received information to the mIRCDLL \b mIRCLink
 * data structure to be used later in various functions in the DLL.
 *
 * \param timeout Unload trigger indicator (0 = timeout unload after 10 min - 1 = exit or /dll -u)
 */

int WINAPI UnloadDll( int timeout ) {

  // DLL unloaded because mIRC exits or /dll -u used
  if ( timeout == 0 ) {

    //mIRCError( "Unloading DCX DLL" );

    Dialogs.closeDialogs( );

    UnregisterClass( DCX_PROGRESSBARCLASS, GetModuleHandle(NULL) );
    UnregisterClass( DCX_TREEVIEWCLASS, GetModuleHandle(NULL) );
    UnregisterClass( DCX_TOOLBARCLASS, GetModuleHandle(NULL) );
    UnregisterClass( DCX_STATUSBARCLASS, GetModuleHandle(NULL) );
    UnregisterClass( DCX_LISTVIEWCLASS, GetModuleHandle(NULL) );
    UnregisterClass( DCX_COMBOEXCLASS, GetModuleHandle(NULL) );
    UnregisterClass( DCX_TRACKBARCLASS, GetModuleHandle(NULL) );
    UnregisterClass( DCX_RICHEDITCLASS, GetModuleHandle(NULL) );
    UnregisterClass( DCX_REBARCTRLCLASS, GetModuleHandle(NULL) );
    UnregisterClass( DCX_COLORCOMBOCLASS, GetModuleHandle(NULL) );
    UnregisterClass( DCX_UPDOWNCLASS, GetModuleHandle(NULL) );
    UnregisterClass( DCX_BUTTONCLASS, GetModuleHandle(NULL) );
    UnregisterClass( DCX_DIVIDERCLASS, GetModuleHandle(NULL) );
    UnregisterClass( DCX_PANELCLASS, GetModuleHandle(NULL) );
    UnregisterClass( DCX_TABCTRLCLASS, GetModuleHandle(NULL) );
    UnregisterClass( DCX_CALENDARCLASS, GetModuleHandle(NULL) );

    UnregisterClass( DCX_BOXCLASS, GetModuleHandle(NULL) );

    // Class Factory of Web Control
    if ( g_pClassFactory != NULL )
      delete g_pClassFactory;
			
		// Terminating OLE Support
		OleUninitialize( );

    // GDI+ Shutdown
    GdiplusShutdown( gdiplusToken );

    UnmapViewOfFile( mIRCLink.m_pData );
    CloseHandle( mIRCLink.m_hFileMap );

    return 1;
  }
  // keep DLL in memory
  else 
    return 0;
}

/*!
 * \brief DCX DLL Version Function
 */

mIRC( Version ) {

  wsprintf( data, "DCX DLL %d.%d.%d %s by ClickHeRe �2005 - http://dcx.scriptsdb.org", 
                  DLL_VERSION, DLL_SUBVERSION, DLL_BUILD, DLL_STATE );
  return 3;
}

/*!
 * \brief DCX DLL Mark Function
 *
 * Argument \b data contains -> [NAME] [ALIAS]
 */

// Mark [NAME] [ALIAS]
mIRC( Mark ) {

  TString d( data );
  d.trim( );

  if ( d.numtok( " " ) < 2 ) {
    ret( "D_ERROR Mark: [NAME] [ALIAS]" );
  }

  char com[100];
  char res[20];
  wsprintf( com, "$dialog(%s).hwnd", d.gettok( 1, " " ).to_chr( ) );
  mIRCeval( com, res );

  HWND mHwnd = (HWND) atoi( res );

  if ( IsWindow( mHwnd ) == FALSE ) {
    ret( "D_ERROR Mark: Invalid Dialog Window" );
  }

  if ( Dialogs.getDialogByHandle( mHwnd ) != NULL ) {
    ret( "D_ERROR Mark: Window Already Marked" );
  }

  //addStyle( mHwnd, GWL_STYLE, WS_CLIPCHILDREN );
  
  Dialogs.markDialog( mHwnd, d.gettok( 1, " " ), d.gettok( 2, " " ) );
  
  ret( "D_OK Mark: Dialog Marked" );
}

/*!
 * \brief DCX DLL /xdid Function
 *
 * mIRC /xdid -switch dialog ID (options) interface
 *
 * Argument \b data contains -> [NAME] [ID] [SWITCH] (OPTIONS)
 */

mIRC( xdid ) {

  TString d( data );
  d.trim( );

  //mIRCError( d.to_chr( ) );

  if ( d.numtok( " " ) < 3 ) {
    mIRCError( "/xdid invalid arguments" );
    data[0] = 0;
    return 3;
  }

  //mIRCError( d.gettok( 1, " " ).to_chr( ) );

  DcxDialog * p_Dialog = Dialogs.getDialogByName( d.gettok( 1, " " ) );

  if ( p_Dialog == NULL ) {
    char error[200];
    wsprintf( error, "/xdid unknown dialog \"%s\": see Mark command", d.gettok( 1, " " ).to_chr( ) );
    mIRCError( error );
    data[0] = 0;
    return 3;
  }

  TString IDs = d.gettok( 2, " " ), d2;

  DcxControl * p_Control;

  int i = 1, n = IDs.numtok( "," );

  // Multiple IDs
  if ( n > 1 ) {

    while ( i <= n ) {

      p_Control = p_Dialog->getControlByID( (UINT) atoi( IDs.gettok( i, "," ).to_chr( ) ) + mIRC_ID_OFFSET );

      //mIRCError( p_Dialog->getName( ).to_chr( ) );

      if ( p_Control == NULL ) {
        char error[200];
        wsprintf( error, "/xdid invalid ID : %s", d.gettok( 2, " " ).to_chr( ) );
        mIRCError( error );
        data[0] = 0;
        return 3;
      }

      d2 = d.gettok( 1, " " ) + " " + IDs.gettok( i, "," ) + " " + d.gettok( 3, -1, " " );

      //mIRCError( d2.to_chr( ) );

      p_Control->parseCommandRequest( d2 );

      i++;
    }
  }
  //Single ID
  else {

    p_Control = p_Dialog->getControlByID( (UINT) atoi( d.gettok( 2, " " ).to_chr( ) ) + mIRC_ID_OFFSET );

    if ( p_Control == NULL ) {
      char error[200];
      wsprintf( error, "/xdid invalid ID : %s", d.gettok( 2, " " ).to_chr( ) );
      mIRCError( error );
      data[0] = 0;
      return 3;
    }

    p_Control->parseCommandRequest( d );
  }

  return 3;
}

/*!
 * \brief DCX DLL $xdid Function
 *
 * mIRC $xdid(dialog, ID, options).prop interface
 *
 * Argument \b data contains -> [NAME] [ID] [PROP] (OPTIONS)
 */

mIRC( _xdid ) {

  TString d( data );
  d.trim( );

  data[0] = 0;

  if ( d.numtok( " " ) < 3 ) {
    mIRCError( "$ $+ xdid invalid arguments" );
    return 3;
  }

  DcxDialog * p_Dialog = Dialogs.getDialogByName( d.gettok( 1, " " ) );

  if ( p_Dialog == NULL ) {
    char error[200];
    wsprintf( error, "$ $+ xdid unknown dialog \"%s\": see Mark command", d.gettok( 1, " " ).to_chr( ) );
    mIRCError( error );
    return 3;
  }

  DcxControl * p_Control = p_Dialog->getControlByID( (UINT) atoi( d.gettok( 2, " " ).to_chr( ) ) + mIRC_ID_OFFSET );

  if ( p_Control == NULL ) {
    char error[200];
    wsprintf( error, "$ $+ xdid invalid ID : %s", d.gettok( 2, " " ).to_chr( ) );
    mIRCError( error );
    return 3;
  }

  p_Control->parseInfoRequest( d, data );

  return 3;
}

/*!
 * \brief DCX DLL /xdialog Function
 *
 * mIRC /xdialog -switch dialog (options) interface
 *
 * Argument \b data contains -> [NAME] [SWITCH] (OPTIONS)
 */

mIRC( xdialog ) {

  TString d( data );
  d.trim( );

  //mIRCSignal( d.to_chr( ) );

  if ( d.numtok( " " ) < 2 ) {
    mIRCError( "/xdialog invalid arguments" );
    data[0] = 0;
    return 3;
  }

  DcxDialog * p_Dialog = Dialogs.getDialogByName( d.gettok( 1, " " ) );

  if ( p_Dialog == NULL ) {
    char error[200];
    wsprintf( error, "/xdialog unknown dialog \"%s\": see Mark command", d.gettok( 1, " " ).to_chr( ) );
    mIRCError( error );
    data[0] = 0;
    return 3;
  }

  p_Dialog->parseCommandRequest( d );

  return 3;
}

/*!
 * \brief DCX DLL $xdialog Function
 *
 * mIRC $xdialog(dialog, options).prop interface
 *
 * Argument \b data contains -> [NAME] [SWITCH] (OPTIONS)
 */

mIRC( _xdialog ) {

  TString d( data );
  d.trim( );

  // reset mIRC data
  data[0] = 0;

  if ( d.numtok( " " ) < 2 ) {
    mIRCError( "$ $+ xdialog invalid arguments" );
    return 3;
  }

  DcxDialog * p_Dialog = Dialogs.getDialogByName( d.gettok( 1, " " ) );

  if ( p_Dialog == NULL ) {
    char error[200];
    wsprintf( error, "$ $+ xdialog unknown dialog \"%s\": see Mark command", d.gettok( 1, " " ).to_chr( ) );
    mIRCError( error );
    return 3;
  }

  p_Dialog->parseInfoRequest( d, data );

  return 3;
}

//*************************

/*!
 * \brief Windows Theme Setting Function
 *
 * Used to remove theme on controls
 */

HRESULT SetWindowTheme( HWND hwnd, LPCWSTR pszSubAppName, LPCWSTR pszSubIdList ) {

  if ( XPPlus )
    return SetWindowThemeUx( hwnd, L" ", L" " );
  else
    return 0;
}

/*!
 * \brief Windows XP function
 *
 * Returns whether the OS version is XP+ or not
 *
 * \return > \b true if OS is XP+ \n
 *         > \b false otherwise
 */

BOOL isXP( ) {
  return XPPlus;
}