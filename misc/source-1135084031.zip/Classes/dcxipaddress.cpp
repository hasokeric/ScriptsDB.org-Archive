/*!
 * \file dcxipaddress.cpp
 * \brief blah
 *
 * blah
 *
 * \author David Legault ( clickhere at scriptsdb dot org )
 * \version 1.0
 *
 * \b Revisions
 *
 * � ScriptsDB.org - 2005
 */

#include "dcxipaddress.h"
#include "dcxdialog.h"

/*!
 * \brief Constructor
 *
 * \param ID Control ID
 * \param p_Dialog Parent DcxDialog Object
 * \param rc Window Rectangle
 * \param styles Window Style Tokenized List
 */

DcxIpAddress::DcxIpAddress( UINT ID, DcxDialog * p_Dialog, RECT * rc, TString & styles ) 
: DcxControl( ID, p_Dialog ) 
{

  LONG Styles = 0, ExStyles = 0;
  BOOL bNoTheme = FALSE;
  this->parseControlStyles( styles, &Styles, &ExStyles, &bNoTheme );

  this->m_Hwnd = CreateWindowEx(	
    0, 
    DCX_IPADDRESSCLASS, 
    NULL,
    WS_CHILD | WS_VISIBLE | Styles, 
    rc->left, rc->top, rc->right - rc->left, rc->bottom - rc->top,
    p_Dialog->getHwnd( ),
    (HMENU) ID,
    GetModuleHandle( NULL ), 
    NULL);

  if ( bNoTheme )
    SetWindowTheme( this->m_Hwnd , L" ", L" " );

  this->registreDefaultWindowProc( );
  SetProp( this->m_Hwnd, "dcx_cthis", (HANDLE) this );
}

/*!
 * \brief Constructor
 *
 * \param ID Control ID
 * \param p_Dialog Parent DcxDialog Object
 * \param mParentHwnd Parent Window Handle
 * \param rc Window Rectangle
 * \param styles Window Style Tokenized List
 */

DcxIpAddress::DcxIpAddress( UINT ID, DcxDialog * p_Dialog, HWND mParentHwnd, RECT * rc, TString & styles ) 
: DcxControl( ID, p_Dialog ) 
{

  LONG Styles = 0, ExStyles = 0;
  BOOL bNoTheme = FALSE;
  this->parseControlStyles( styles, &Styles, &ExStyles, &bNoTheme );

  this->m_Hwnd = CreateWindowEx(	
    0, 
    DCX_IPADDRESSCLASS, 
    NULL,
    WS_CHILD | WS_VISIBLE | Styles, 
    rc->left, rc->top, rc->right - rc->left, rc->bottom - rc->top,
    mParentHwnd,
    (HMENU) ID,
    GetModuleHandle(NULL), 
    NULL);

  if ( bNoTheme )
    SetWindowTheme( this->m_Hwnd , L" ", L" " );

  this->registreDefaultWindowProc( );
  SetProp( this->m_Hwnd, "dcx_cthis", (HANDLE) this );
}

/*!
 * \brief blah
 *
 * blah
 */

DcxIpAddress::~DcxIpAddress( ) {

  this->unregistreDefaultWindowProc( );
}

/*!
 * \brief blah
 *
 * blah
 */

void DcxIpAddress::parseControlStyles( TString & styles, LONG * Styles, LONG * ExStyles, BOOL * bNoTheme ) {

  unsigned int i = 1, numtok = styles.numtok( " " );

  while ( i <= numtok ) {

    if ( styles.gettok( i , " " ) == "bitmap" )
      *Styles |= BS_BITMAP;
    else if ( styles.gettok( i , " " ) == "default" )
      *Styles |= BS_DEFPUSHBUTTON;

    i++;
  }
  this->parseGeneralControlStyles( styles, Styles, ExStyles, bNoTheme );
}

/*!
 * \brief $xdid Parsing Function
 *
 * \param input [NAME] [ID] [PROP] (OPTIONS)
 * \param szReturnValue mIRC Data Container
 *
 * \return > void
 */

void DcxIpAddress::parseInfoRequest( TString & input, char * szReturnValue ) {

  int numtok = input.numtok( " " );

  // [NAME] [ID] [PROP]
  if ( input.gettok( 3, " " ) == "ip" ) {

    DWORD ip;
    this->getAddress( &ip );

    wsprintf( szReturnValue, "%d.%d.%d.%d", FIRST_IPADDRESS( ip ),
                                            SECOND_IPADDRESS( ip ),
                                            THIRD_IPADDRESS( ip ),
                                            FOURTH_IPADDRESS( ip ) );


    return;
  }
  else if ( this->parseGlobalInfoRequest( input, szReturnValue ) ) {

    return;
  }
  
  szReturnValue[0] = 0;
}

/*!
 * \brief blah
 *
 * blah
 */

void DcxIpAddress::parseCommandRequest( TString & input ) {

  DCXSwitchFlags flags;
  ZeroMemory( (void*)&flags, sizeof( DCXSwitchFlags ) );
  this->parseSwitchFlags( &input.gettok( 3, " " ), &flags );

  int numtok = input.numtok( " " );

  // xdid -r [NAME] [ID] [SWITCH] ItemText
  if ( flags.switch_flags[17] && numtok > 3 ) {
    this->clearAddress( );
  }
  
  // xdid -a [NAME] [ID] [SWITCH] IP.IP.IP.IP
  if ( flags.switch_flags[0] && numtok > 3 ) {
    
    TString IP = input.gettok( 4, " " );

    if ( IP.numtok( ".") == 4 ) {

      BYTE b[4];

      for ( int i = 0; i < 4; i++ ) {

        b[i] = atoi( IP.gettok( i+1, "." ).to_chr( ) );
      }

      DWORD adr = MAKEIPADDRESS( b[0], b[1], b[2], b[3] );
      this->setAddress( adr );
    }
  }
  // xdid -g [NAME] [ID] [SWITCH] [N] [MIN] [MAX]
  else if ( flags.switch_flags[6] && numtok > 5 ) {

     int nField = atoi( input.gettok( 4, " " ).to_chr( ) ) - 1;
     BYTE min = atoi( input.gettok( 5, " " ).to_chr( ) );
     BYTE max = atoi( input.gettok( 6, " " ).to_chr( ) );

     if ( nField > -1 && nField < 4 )
       this->setRange( nField, min, max );
  }
  // xdid -j [NAME] [ID] [SWITCH] [N]
  else if ( flags.switch_flags[9] && numtok > 3 ) {

    int nField = atoi( input.gettok( 4, " " ).to_chr( ) ) - 1;

    if ( nField > -1 && nField < 4 )
      this->setFocus( nField );
  }
  else {
    this->parseGlobalCommandRequest( input, flags );
  }
}

/*!
 * \brief blah
 *
 * blah
 */

LRESULT DcxIpAddress::setRange( int nField, BYTE iMin, BYTE iMax ) {
  return SendMessage( this->m_Hwnd, IPM_SETRANGE, (WPARAM) nField, (LPARAM) MAKEIPRANGE( iMin, iMax ) );
}

/*!
 * \brief blah
 *
 * blah
 */

LRESULT DcxIpAddress::setFocus( int nField ) {
  return SendMessage( this->m_Hwnd, IPM_SETFOCUS, (WPARAM) nField, (LPARAM) 0 );
}

/*!
 * \brief blah
 *
 * blah
 */

LRESULT DcxIpAddress::setAddress( DWORD dwIpAddress ) {
  return SendMessage( this->m_Hwnd, IPM_SETADDRESS, (WPARAM) 0, (LPARAM) dwIpAddress );
}

/*!
 * \brief blah
 *
 * blah
 */

LRESULT DcxIpAddress::getAddress( LPDWORD lpdwIpAddress ) {
  return SendMessage( this->m_Hwnd, IPM_GETADDRESS, (WPARAM) 0, (LPARAM) lpdwIpAddress );
}

/*!
 * \brief blah
 *
 * blah
 */

LRESULT DcxIpAddress::clearAddress( ) {
  return SendMessage( this->m_Hwnd, IPM_CLEARADDRESS, (WPARAM) 0, (LPARAM) 0 );
}

/*!
 * \brief blah
 *
 * blah
 */

LRESULT DcxIpAddress::PostMessage( UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL & bParsed ) {

  switch( uMsg ) {

    case WM_HELP:
      {
        char ret[256];
        this->callAliasEx( ret, "%s,%d", "help", this->getUserID( ) );
      }
      break;

    case WM_NOTIFY : 
      {
        //mIRCError( "Control WM_NOTIFY" );

        LPNMHDR hdr = (LPNMHDR) lParam;

        if (!hdr)
          break;

        switch( hdr->code ) {

          case IPN_FIELDCHANGED:
            {

              char ret[256];
              this->callAliasEx( ret, "%s,%d", "edit", this->getUserID( ) );
              bParsed = TRUE;
            }
            break;
        }
      }
      break;

    case WM_CONTEXTMENU:
      {
        char ret[256];
        this->callAliasEx( ret, "%s,%d", "rclick", this->getUserID( ) );
      }
      break;

    case WM_LBUTTONDOWN:
      {
        char ret[256];
        this->callAliasEx( ret, "%s,%d", "sclick", this->getUserID( ) );
      }
      break;

    case WM_MOUSEMOVE:
      {
        this->m_pParentDialog->setMouseControl( this->getUserID( ) );
      }
      break;

    case WM_SETFOCUS:
      {
        this->m_pParentDialog->setFocusControl( this->getUserID( ) );
      }
      break;

    case WM_DESTROY:
      {
        //mIRCError( "WM_DESTROY" );
        delete this;
        bParsed = TRUE;
      }
      break;

    default:
      break;
  }

  return 0L;
}