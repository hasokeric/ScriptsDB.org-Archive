/*!
 * \file dcxstatusbar.cpp
 * \brief blah
 *
 * blah
 *
 * \author David Legault ( clickhere at scriptsdb dot org )
 * \version 1.0
 *
 * \b Revisions
 *
 * � ScriptsDB.org - 2005
 */

#include "dcxstatusbar.h"
#include "dcxdialog.h"

/*!
 * \brief Constructor
 *
 * \param ID Control ID
 * \param p_Dialog Parent DcxDialog Object
 * \param rc Window Rectangle
 * \param styles Window Style Tokenized List
 */

DcxStatusBar::DcxStatusBar( UINT ID, DcxDialog * p_Dialog, RECT * rc, TString & styles ) : DcxControl( ID, p_Dialog ) {

  LONG Styles = 0, ExStyles = 0;
  BOOL bNoTheme = FALSE;
  this->parseControlStyles( styles, &Styles, &ExStyles, &bNoTheme );

  this->m_Hwnd = CreateWindowEx(	
    0, 
    DCX_STATUSBARCLASS, 
    NULL,
    WS_CHILD | WS_VISIBLE | Styles, 
    rc->left, rc->top, rc->right - rc->left, rc->bottom - rc->top,
    p_Dialog->getHwnd( ),
    (HMENU) ID,
    GetModuleHandle(NULL), 
    NULL);

  if ( bNoTheme )
    SetWindowTheme( this->m_Hwnd , L" ", L" " );

  this->m_hImageList = NULL;

  this->registreDefaultWindowProc( );
  SetProp( this->m_Hwnd, "dcx_cthis", (HANDLE) this );
}

/*!
 * \brief Constructor
 *
 * \param ID Control ID
 * \param p_Dialog Parent DcxDialog Object
 * \param mParentHwnd Parent Window Handle
 * \param rc Window Rectangle
 * \param styles Window Style Tokenized List
 */

DcxStatusBar::DcxStatusBar( UINT ID, DcxDialog * p_Dialog, HWND mParentHwnd, RECT * rc, TString & styles ) 
: DcxControl( ID, p_Dialog ) 
{

  LONG Styles = 0, ExStyles = 0;
  BOOL bNoTheme = FALSE;
  this->parseControlStyles( styles, &Styles, &ExStyles, &bNoTheme );

  this->m_Hwnd = CreateWindowEx(	
    0, 
    DCX_STATUSBARCLASS, 
    NULL,
    WS_CHILD | WS_VISIBLE | Styles, 
    rc->left, rc->top, rc->right - rc->left, rc->bottom - rc->top,
    mParentHwnd,
    (HMENU) ID,
    GetModuleHandle(NULL), 
    NULL);

  if ( bNoTheme )
    SetWindowTheme( this->m_Hwnd , L" ", L" " );

  this->m_hImageList = NULL;

  this->registreDefaultWindowProc( );
  SetProp( this->m_Hwnd, "dcx_cthis", (HANDLE) this );
}

/*!
 * \brief blah
 *
 * blah
 */

DcxStatusBar::~DcxStatusBar( ) {

  this->cleanPartIcons( );
  ImageList_Destroy( this->getImageList( ) );

  this->unregistreDefaultWindowProc( );
}

/*!
 * \brief blah
 *
 * blah
 */

void DcxStatusBar::parseControlStyles( TString & styles, LONG * Styles, LONG * ExStyles, BOOL * bNoTheme ) {

  unsigned int i = 1, numtok = styles.numtok( " " );

  while ( i <= numtok ) {

    if ( styles.gettok( i , " " ) == "grip" ) 
      *Styles |= SBARS_SIZEGRIP;
    else if ( styles.gettok( i , " " ) == "tooltips" ) 
      *Styles |= SBARS_TOOLTIPS;
    else if ( styles.gettok( i , " " ) == "nodivider" ) 
      *Styles |= CCS_NODIVIDER;
    else if ( styles.gettok( i , " " ) == "top" ) 
      *Styles |= CCS_TOP;
    else if ( styles.gettok( i , " " ) == "noresize" ) 
      *Styles |= CCS_NORESIZE;
    else if ( styles.gettok( i , " " ) == "noparentalign" ) 
      *Styles |= CCS_NOPARENTALIGN ;

    i++;
  }
  this->parseGeneralControlStyles( styles, Styles, ExStyles, bNoTheme );
}

/*!
 * \brief $xdid Parsing Function
 *
 * \param input [NAME] [ID] [PROP] (OPTIONS)
 * \param szReturnValue mIRC Data Container
 *
 * \return > void
 */

void DcxStatusBar::parseInfoRequest( TString & input, char * szReturnValue ) {

  int numtok = input.numtok( " " );

  // [NAME] [ID] [PROP] [N]
  if ( input.gettok( 3, " " ) == "text" && numtok > 3 ) {

    int iPart = atoi( input.gettok( 3, " " ).to_chr( ) ), nParts = this->getParts( 256, 0 );

    if ( iPart > -1 && iPart < nParts ) {
      
      this->getText( iPart, szReturnValue );
      return;
    }
  }
  // [NAME] [ID] [PROP]
  else if ( input.gettok( 3, " " ) == "parts" ) {

    INT parts[256];
    int nParts = this->getParts( 256, 0 );

    this->getParts( 256, parts );

    int i = 0;
    szReturnValue[0] = 0;
    char d[10];

    while ( i < nParts ) {

      wsprintf( d, "%d", parts[i] );

      if ( i == 0 ) {
        lstrcat( szReturnValue, d );
      }
      else {
        lstrcat( szReturnValue, " " );
        lstrcat( szReturnValue, d );
      }

      i++;
    }
  }
  // [NAME] [ID] [PROP] [N]
  else if ( input.gettok( 3, " " ) == "tooltip" && numtok > 3 ) {

    int iPart = atoi( input.gettok( 3, " " ).to_chr( ) ), nParts = this->getParts( 256, 0 );

    if ( iPart > -1 && iPart < nParts ) {
      
      this->getTipText( iPart, 900, szReturnValue );
      return;
    }
  }
  else if ( this->parseGlobalInfoRequest( input, szReturnValue ) ) {

    return;
  }

  szReturnValue[0] = 0;
}

/*!
 * \brief blah
 *
 * blah
 */

void DcxStatusBar::parseCommandRequest( TString & input ) {

  DCXSwitchFlags flags;
  ZeroMemory( (void*)&flags, sizeof( DCXSwitchFlags ) );
  this->parseSwitchFlags( &input.gettok( 3, " " ), &flags );

  int numtok = input.numtok( " " );

  // xdid -k name ID [COLOR]
  if ( flags.switch_flags[10] ) {

    this->setBkColor( (COLORREF) atol( input.gettok( 4, " " ).to_chr( ) ) );
  }
  // xdid -l [NAME] [ID] [SWITCH] [POS [POS POS ...]]
  else if ( flags.switch_flags[11] && numtok > 3 ) {

    int nParts = numtok - 3;
    INT parts[256];

    int i = 0;
    while ( i < nParts ) {

      parts[i] = atoi( input.gettok( i+4, " " ).to_chr( ) );
      i++;
    }
    this->setParts( nParts, parts );
  }
  // xdid -t [NAME] [ID] [SWITCH] N [+FLAGS] [#ICON] [Cell Text][TAB]Tooltip Text
  else if ( flags.switch_flags[19] && numtok > 5 ) {

    int nPos = atoi( input.gettok( 4, " " ).to_chr( ) ) - 1;
    TString flags = input.gettok( 5, " " );
    int icon = atoi( input.gettok( 6, " " ).to_chr( ) ) - 1;

    TString itemtext;

    if ( input.gettok( 1, "\t" ).numtok( " " ) > 6 ) {
      
      itemtext = input.gettok( 1, "\t" ).gettok( 7, -1, " " );
      itemtext.trim( );
    }

    TString tooltip;

    if ( input.numtok( "\t" ) > 1 ) {
      
      tooltip = input.gettok( 2, "\t" );
      tooltip.trim( );
    }

    DestroyIcon( (HICON) this->getIcon( nPos ) );
    if ( icon != -1 )
      this->setIcon( nPos, ImageList_GetIcon( this->getImageList( ), icon, ILD_TRANSPARENT ) );
    else
      this->setIcon( nPos, NULL );

    this->setText( nPos, this->parseItemFlags( flags ), itemtext.to_chr( ) );
    this->setTipText( nPos, tooltip.to_chr( ) );

  }
  // xdid -w [NAME] [ID] [SWITCH] [INDEX] [FILENAME]
  else if ( flags.switch_flags[22] && numtok > 4 ) {

    HIMAGELIST himl;
    HICON icon;
    int index;

    if ( ( himl = this->getImageList( ) ) == NULL ) {

      himl = this->createImageList( );

      if ( himl )
        this->setImageList( himl );
    }

    index = atoi( input.gettok( 4, " ").to_chr( ) );
    TString filename = input.gettok( 5, -1, " " );
    ExtractIconEx( filename.to_chr( ), index, 0, &icon, 1 );
    ImageList_AddIcon( himl, icon );
    DestroyIcon( icon );
  }
  // xdid -y [NAME] [ID] [SWITCH] [+FLAGS]
  else if ( flags.switch_flags[24] ) {

    ImageList_Destroy( this->getImageList( ) );
  }
  else {
    this->parseGlobalCommandRequest( input, flags );
  }
}

/*!
 * \brief blah
 *
 * blah
 */

HIMAGELIST DcxStatusBar::getImageList( ) {

  return this->m_hImageList;
}

/*!
 * \brief blah
 *
 * blah
 */

void DcxStatusBar::setImageList( HIMAGELIST himl ) {

  this->m_hImageList = himl;
}

/*!
 * \brief blah
 *
 * blah
 */

HIMAGELIST DcxStatusBar::createImageList( ) {

  return ImageList_Create( 16, 16, ILC_COLOR32|ILC_MASK, 1, 0 );
}

/*!
 * \brief blah
 *
 * blah
 */

UINT DcxStatusBar::parseItemFlags( TString & flags ) {

  INT i = 1, len = flags.len( ), iFlags = 0;

  // no +sign, missing params
  if ( flags[0] != '+' ) 
    return iFlags;

  while ( i < len ) {

    if ( flags[i] == 'n' )
      iFlags |= SBT_NOBORDERS;
    else if ( flags[i] == 'p' )
      iFlags |= SBT_POPOUT;

    ++i;
  }
  return iFlags;
}

/*!
 * \brief blah
 *
 * blah
 */

void DcxStatusBar::cleanPartIcons( ) {

  int n = 0;
  while ( n < 256 ) {

    DestroyIcon( (HICON) this->getIcon( n ) );
    n++;
  }
}

/*!
 * \brief blah
 *
 * blah
 */

LRESULT DcxStatusBar::setParts( int nParts, LPINT aWidths ) {
  return SendMessage( this->m_Hwnd, SB_SETPARTS, (WPARAM) nParts, (LPARAM) aWidths );
}

/*!
 * \brief blah
 *
 * blah
 */

LRESULT DcxStatusBar::getParts( int nParts, LPINT aWidths ) {
  return SendMessage( this->m_Hwnd, SB_GETPARTS, (WPARAM) nParts, (LPARAM) aWidths );
}

/*!
 * \brief blah
 *
 * blah
 */

LRESULT DcxStatusBar::setBkColor( COLORREF clrBk ) {
  return SendMessage( this->m_Hwnd, SB_SETBKCOLOR, (WPARAM) 0, (LPARAM) clrBk );
}

/*!
 * \brief blah
 *
 * blah
 */

LRESULT DcxStatusBar::setText( int iPart, int Style, LPSTR lpstr ) {
  return SendMessage( this->m_Hwnd, SB_SETTEXT, (WPARAM) iPart | Style, (LPARAM) lpstr );
}

/*!
 * \brief blah
 *
 * blah
 */

LRESULT DcxStatusBar::getText( int iPart, LPSTR lpstr ) {
  return SendMessage( this->m_Hwnd, SB_GETTEXT, (WPARAM) iPart, (LPARAM) lpstr );
}

/*!
 * \brief blah
 *
 * blah
 */

LRESULT DcxStatusBar::setTipText( int iPart, LPSTR lpstr ) {
  return SendMessage( this->m_Hwnd, SB_SETTIPTEXT, (WPARAM) iPart, (LPARAM) lpstr );
}

/*!
 * \brief blah
 *
 * blah
 */

LRESULT DcxStatusBar::getTipText( int iPart, int nSize, LPSTR lpstr ) {
  return SendMessage( this->m_Hwnd, SB_GETTIPTEXT, (WPARAM) MAKEWPARAM (iPart, nSize), (LPARAM) lpstr );
}

/*!
 * \brief blah
 *
 * blah
 */

LRESULT DcxStatusBar::getRect( int iPart, LPRECT lprc ) {
  return SendMessage( this->m_Hwnd, SB_GETRECT, (WPARAM) iPart, (LPARAM) lprc );
}

/*!
 * \brief blah
 *
 * blah
 */

LRESULT DcxStatusBar::setIcon( int iPart, HICON hIcon ) {
  return SendMessage( this->m_Hwnd, SB_SETICON, (WPARAM) iPart, (LPARAM) hIcon );
}

/*!
 * \brief blah
 *
 * blah
 */

LRESULT DcxStatusBar::getIcon( int iPart ) {
  return SendMessage( this->m_Hwnd, SB_GETICON, (WPARAM) iPart, (LPARAM) 0 );
}

/*!
 * \brief blah
 *
 * blah
 */

int DcxStatusBar::hitTest( POINT & pt ) {

  RECT rc;
  int n = 0, tx = 0;
  int nParts = this->getParts( 256, 0 );

  while ( n < nParts ) {

    this->getRect( n, &rc );
    if ( PtInRect( &rc, pt ) )
      return n;

    n++;
  }
  return -1;
}

/*!
 * \brief blah
 *
 * blah
 */

LRESULT DcxStatusBar::PostMessage( UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL & bParsed ) {

  switch( uMsg ) {

    case WM_HELP:
      {
        char ret[256];
        this->callAliasEx( ret, "%s,%d", "help", this->getUserID( ) );
      }
      break;

    case WM_NOTIFY : 
      {

        LPNMHDR hdr = (LPNMHDR) lParam;

        if (!hdr)
          break;

        switch( hdr->code ) {

          case NM_CLICK:
            {
              //mIRCError( "Control WM_NOTIFY - NM_CLICK" );

              POINT pt;
              char ret[256];
              GetCursorPos( &pt );
              ScreenToClient( this->m_Hwnd, &pt );
              int cell = this->hitTest( pt );

              if ( cell != -1 )
                this->callAliasEx( ret, "%s,%d,%d", "sclick", this->getUserID( ), cell + 1 );

              bParsed = TRUE;
            }
            break;

          case NM_RCLICK:
            {
              //mIRCError( "Control WM_NOTIFY - NM_RCLICK" );

              POINT pt;
              char ret[256];
              GetCursorPos( &pt );
              ScreenToClient( this->m_Hwnd, &pt );
              int cell = this->hitTest( pt );

              if ( cell != -1 )
                this->callAliasEx( ret, "%s,%d,%d", "rclick", this->getUserID( ), cell + 1 );

              bParsed = TRUE;
            }
            break;

          case NM_DBLCLK: 
            {
              //mIRCError( "Control WM_NOTIFY - NM_DBLCLK" );

              POINT pt;
              char ret[256];
              GetCursorPos( &pt );
              ScreenToClient( this->m_Hwnd, &pt );
              int cell = this->hitTest( pt );

              if ( cell != -1 )
                this->callAliasEx( ret, "%s,%d,%d", "dclick", this->getUserID( ), cell + 1 );

              bParsed = TRUE;
            }
            break;

        } // switch
      }
      break;

    case WM_MOUSEMOVE:
      {
        this->m_pParentDialog->setMouseControl( this->getUserID( ) );
      }
      break;

    case WM_SETFOCUS:
      {
        this->m_pParentDialog->setFocusControl( this->getUserID( ) );
      }
      break;

    case WM_DESTROY:
      {
        //mIRCError( "WM_DESTROY" );
        delete this;
        bParsed = TRUE;
      }
      break;

    default:
      break;
  }

  return 0L;
}