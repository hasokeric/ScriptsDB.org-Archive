/*!
 * \file layoutmanager.cpp
 * \brief blah
 *
 * blah
 *
 * \author David Legault ( clickhere at scriptsdb dot org )
 * \version 1.0
 *
 * \b Revisions
 *
 * � ScriptsDB.org - 2005
 */

#include "layoutmanager.h"

/*!
 * \brief Constructor
 *
 * blah
 */

LayoutManager::LayoutManager( ) {

  this->m_pRoot = NULL;
  this->m_Hwnd = NULL;
}

/*!
 * \brief Constructor
 *
 * blah
 */

LayoutManager::LayoutManager( HWND mHwnd ) : m_Hwnd( mHwnd ) {

  this->m_pRoot = NULL;
}

/*!
 * \brief Destructor
 *
 * blah
 */

LayoutManager::~LayoutManager( ) {

}

/*!
 * \brief blah
 *
 * blah
 */

void LayoutManager::updateLayout( RECT & rc ) {

  if ( this->m_pRoot != NULL ) {

    HDWP hdwp = BeginDeferWindowPos( 1 );

    this->m_pRoot->setRect( rc );
    this->m_pRoot->LayoutChild( );
    hdwp = this->m_pRoot->ExecuteLayout( hdwp );

    EndDeferWindowPos( hdwp );
  }
}

/*!
 * \brief blah
 *
 * blah
 */

void LayoutManager::setRoot( LayoutCell * p_Root ) {

  // clean memory in case we use more than once
  if ( this->m_pRoot != NULL )
    delete this->m_pRoot;

  this->m_pRoot = p_Root;
}

/*!
 * \brief blah
 *
 * blah
 */

LayoutCell * LayoutManager::getRoot( ) {

  return this->m_pRoot;
}

/*!
 * \brief blah
 *
 * blah
 */

LayoutCell * LayoutManager::getCell( TString & path ) {

  return this->parsePath( path, this->m_pRoot, 1 );
}

/*!
 * \brief blah
 *
 * blah
 */

LayoutCell * LayoutManager::parsePath( TString & path, LayoutCell * hParent, int depth ) {

  int n = path.numtok( " " ), i = 1;
  int k = atoi( path.gettok( depth, " " ).to_chr( ) );
  LayoutCell * hCurrentCell;

  //char data[50];

  hCurrentCell = hParent->getFirstChild( );

  if ( hCurrentCell == NULL )
    return NULL;
 
  do {

    if ( i == k ) {

      //MessageBox( hwnd, "i == k", "i == k", MB_OK );
      // finished tree search and found
      if ( depth == n )
       return hCurrentCell;

      return this->parsePath( path, hCurrentCell, depth + 1 );
    }

    i++;

  } while ( ( hCurrentCell = hCurrentCell->getNextSibling( ) ) != NULL );

  return NULL;
}
