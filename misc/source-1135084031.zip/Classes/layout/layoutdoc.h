/*!
 * \file layoutdoc.h
 * \brief Documentation Header File
 */

/*!
 * \page layout LayoutCell Dialog Helper Documentation
 *
 * blah
 *
 * \author David Legault ( clickhere at scriptsdb dot org )
 * \version 1.0
 *
 * \b Revisions
 *
 * � ScriptsDB.org - 2005
 */