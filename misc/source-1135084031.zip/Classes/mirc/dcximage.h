/*!
 * \file dcximage.h
 * \brief blah
 *
 * blah
 *
 * \author David Legault ( clickhere at scriptsdb dot org )
 * \version 1.0
 *
 * \b Revisions
 *
 * � ScriptsDB.org - 2005
 */

#ifndef _DCXIMAGE_H_
#define _DCXIMAGE_H_

#include "../../defines.h"
#include "../dcxcontrol.h"

class DcxDialog;

/*!
 * \brief blah
 *
 * blah
 */

class DcxImage : public DcxControl {

public:

  DcxImage( UINT ID, DcxDialog * p_Dialog, RECT * rc, TString & styles );
  DcxImage( UINT ID, DcxDialog * p_Dialog, HWND mParentHwnd, RECT * rc, TString & styles );
  virtual ~DcxImage( );

  LRESULT PostMessage( UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL & bParsed );

  void parseInfoRequest( TString & input, char * szReturnValue );
  void parseCommandRequest( TString & input );
  void parseControlStyles( TString & styles, LONG * Styles, LONG * ExStyles, BOOL * bNoTheme );

protected:

  Image * m_pImage; //!< GDI+ Image Object
  HBITMAP m_hBitmap; //!< Bitmap

  COLORREF m_clrTransColor; //!< Transparent color
};

#endif // _DCXIMAGE_H_