/*!
 * \file dcxmdialog.h
 * \brief blah
 *
 * blah
 *
 * \author David Legault ( clickhere at scriptsdb dot org )
 * \version 1.0
 *
 * \b Revisions
 *
 * � ScriptsDB.org - 2005
 */

#ifndef _DCXMDIALOG_H_
#define _DCXMDIALOG_H_

#include "../defines.h"
#include "dcxcontrol.h"

class DcxDialog;

/*!
 * \brief blah
 *
 * blah
 */

class DcxMDialog : public DcxControl {

public:

  DcxMDialog( HWND cHwnd, UINT ID, DcxDialog * p_Dialog, RECT * rc, TString & styles );
  virtual ~DcxMDialog( );

  LRESULT PostMessage( UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL & bParsed );

  void parseInfoRequest( TString & input, char * szReturnValue );
  void parseCommandRequest( TString & input );
  void parseControlStyles( TString & styles, LONG * Styles, LONG * ExStyles, BOOL * bNoTheme ){ };

protected:

  LONG m_OrigStyles;      //!< Dialog Original Styles
  LONG m_OrigExStyles;    //!< Dialog Original Extended Styles
  HWND m_OrigParentHwnd;  //!< Dialog Original Parent Handle
  UINT m_OrigID;          //!< Dialog Original Control ID

};

#endif // _DCXMDIALOG_H_