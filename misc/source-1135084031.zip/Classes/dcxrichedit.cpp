/*!
 * \file dcxrichedit.cpp
 * \brief blah
 *
 * blah
 *
 * \author David Legault ( clickhere at scriptsdb dot org )
 * \version 1.0
 *
 * \b Revisions
 *
 * � ScriptsDB.org - 2005
 */

#include "dcxrichedit.h"
#include "dcxdialog.h"

/*!
 * \brief Constructor
 *
 * \param ID Control ID
 * \param p_Dialog Parent DcxDialog Object
 * \param rc Window Rectangle
 * \param styles Window Style Tokenized List
 */

DcxRichEdit::DcxRichEdit( UINT ID, DcxDialog * p_Dialog, RECT * rc, TString & styles ) 
: DcxControl( ID, p_Dialog ) 
{

  LONG Styles = 0, ExStyles = 0;
  BOOL bNoTheme = FALSE;
  this->parseControlStyles( styles, &Styles, &ExStyles, &bNoTheme );

  this->m_Hwnd = CreateWindowEx(	
    WS_EX_CLIENTEDGE, 
    DCX_RICHEDITCLASS, 
    NULL,
    WS_CHILD | WS_VISIBLE | Styles, 
    rc->left, rc->top, rc->right - rc->left, rc->bottom - rc->top,
    p_Dialog->getHwnd( ),
    (HMENU) ID,
    GetModuleHandle( NULL ), 
    NULL);

  if ( bNoTheme )
    SetWindowTheme( this->m_Hwnd , L" ", L" " );

  this->m_tsText = "";
  this->m_clrBackText = RGB(255,255,255);
  this->m_clrText = RGB(0,0,0);
  this->m_iFontSize = 10*20;
  this->m_bFontBold = FALSE;
  this->m_bFontItalic = FALSE;
  this->m_bFontUnderline = FALSE;
  this->m_bFontStrikeout = FALSE;
  this->m_tsFontFaceName = "";

  this->loadmIRCPalette( );
  this->setContentsFont( );

  this->registreDefaultWindowProc( );
  SetProp( this->m_Hwnd, "dcx_cthis", (HANDLE) this );
}

/*!
 * \brief Constructor
 *
 * \param ID Control ID
 * \param p_Dialog Parent DcxDialog Object
 * \param mParentHwnd Parent Window Handle
 * \param rc Window Rectangle
 * \param styles Window Style Tokenized List
 */

DcxRichEdit::DcxRichEdit( UINT ID, DcxDialog * p_Dialog, HWND mParentHwnd, RECT * rc, TString & styles ) 
: DcxControl( ID, p_Dialog ) 
{

  LONG Styles = 0, ExStyles = 0;
  BOOL bNoTheme = FALSE;
  this->parseControlStyles( styles, &Styles, &ExStyles, &bNoTheme );

  this->m_Hwnd = CreateWindowEx(	
    WS_EX_CLIENTEDGE, 
    DCX_RICHEDITCLASS, 
    NULL,
    WS_CHILD | WS_VISIBLE | Styles, 
    rc->left, rc->top, rc->right - rc->left, rc->bottom - rc->top,
    mParentHwnd,
    (HMENU) ID,
    GetModuleHandle(NULL), 
    NULL);

  if ( bNoTheme )
    SetWindowTheme( this->m_Hwnd , L" ", L" " );

  this->m_tsText = "";
  this->m_clrBackText = RGB(255,255,255);
  this->m_clrText = RGB(0,0,0);
  this->m_iFontSize = 10*20;
  this->m_bFontBold = FALSE;
  this->m_bFontItalic = FALSE;
  this->m_bFontUnderline = FALSE;
  this->m_bFontStrikeout = FALSE;
  this->m_tsFontFaceName = "";

  this->loadmIRCPalette( );
  this->setContentsFont( );

  this->registreDefaultWindowProc( );
  SetProp( this->m_Hwnd, "dcx_cthis", (HANDLE) this );
}

/*!
 * \brief blah
 *
 * blah
 */

DcxRichEdit::~DcxRichEdit( ) {

 this->unregistreDefaultWindowProc( );
}

/*!
 * \brief blah
 *
 * blah
 */

void DcxRichEdit::parseControlStyles( TString & styles, LONG * Styles, LONG * ExStyles, BOOL * bNoTheme ) {

  *Styles |= ES_NOHIDESEL | ES_READONLY;
  unsigned int i = 1, numtok = styles.numtok( " " );

  while ( i <= numtok ) {

    if ( styles.gettok( i , " " ) == "multi" ) 
      *Styles |= ES_MULTILINE;
    else if ( styles.gettok( i , " " ) == "center" ) 
      *Styles |= ES_CENTER;
    else if ( styles.gettok( i , " " ) == "right" ) 
      *Styles |= ES_RIGHT;
    else if ( styles.gettok( i , " " ) == "autohs" ) 
      *Styles |= ES_AUTOHSCROLL;
    else if ( styles.gettok( i , " " ) == "autovs" ) 
      *Styles |= ES_AUTOVSCROLL;
    else if ( styles.gettok( i , " " ) == "vsbar" ) 
      *Styles |= WS_VSCROLL;
    else if ( styles.gettok( i , " " ) == "hsbar" ) 
      *Styles |= WS_HSCROLL;
    else if ( styles.gettok( i , " " ) == "disablescroll" ) 
      *Styles |= ES_DISABLENOSCROLL;

    i++;
  }
  this->parseGeneralControlStyles( styles, Styles, ExStyles, bNoTheme );
}

/*!
 * \brief $xdid Parsing Function
 *
 * \param input [NAME] [ID] [PROP] (OPTIONS)
 * \param szReturnValue mIRC Data Container
 *
 * \return > void
 */

void DcxRichEdit::parseInfoRequest( TString & input, char * szReturnValue ) {

  int numtok = input.numtok( " " );

  // [NAME] [ID] [PROP] [N]
  if ( input.gettok( 3, " " ) == "text" ) {

    if ( this->isStyle( ES_MULTILINE ) ) {

      if ( numtok > 3 ) {
        int nLine = atoi( input.gettok( 4, " " ).to_chr( ) );

        if ( nLine > 0 && nLine <= this->m_tsText.numtok( "\r\n" ) ) {

          lstrcpy( szReturnValue, this->m_tsText.gettok( nLine, "\r\n" ).to_chr( ) );
          return;
        }
      }
    }
    else {
      lstrcpy( szReturnValue, this->m_tsText.to_chr( ) );
      return;
    }
  }
  // [NAME] [ID] [PROP]
  else if ( input.gettok( 3, " " ) == "num" ) {

    if ( this->isStyle( ES_MULTILINE ) ) {

      wsprintf( szReturnValue, "%d", this->m_tsText.numtok( "\r\n" ) );
      return;
    }
  }
  else if ( this->parseGlobalInfoRequest( input, szReturnValue ) ) {

    return;
  }
  
  szReturnValue[0] = 0;
}

/*!
 * \brief blah
 *
 * blah
 */

void DcxRichEdit::parseCommandRequest( TString & input ) {

  DCXSwitchFlags flags;
  ZeroMemory( (void*)&flags, sizeof( DCXSwitchFlags ) );
  this->parseSwitchFlags( &input.gettok( 3, " " ), &flags );

  int numtok = input.numtok( " " );

  // xdid -r [NAME] [ID] [SWITCH]
  if ( flags.switch_flags[17] ) {

    this->m_tsText = "";
    this->clearContents( );
  }

  // xdid -a [NAME] [ID] [SWITCH] [TEXT]
  if ( flags.switch_flags[0] && numtok > 3 ) {
    
    this->m_tsText += input.gettok( 4, -1, " " );
    this->parseContents( TRUE );
  }
  // xdid -d [NAME] [ID] [SWITCH] [N]
  else if ( flags.switch_flags[3] && numtok > 3 ) {
    
    if ( this->isStyle( ES_MULTILINE ) ) {

      int nLine = atoi( input.gettok( 4, " " ).to_chr( ) );
      this->m_tsText.deltok( nLine, "\r\n" );
    }
    this->parseContents( TRUE );
  }
  // special richedit interception for font change
  // xdid -f [NAME] [ID] [SWITCH] [+FLAGS] [SIZE] [FONTNAME]
  if ( flags.switch_flags[5] && numtok > 3 ) {

    UINT iFontFlags = this->parseFontFlags( input.gettok( 4, " " ) );

    if ( iFontFlags & DCF_DEFAULT ) {

      this->m_clrBackText = RGB(255,255,255);
      this->m_clrText = RGB(0,0,0);
      this->m_iFontSize = 10*20;
      this->m_bFontBold = FALSE;
      this->m_bFontItalic = FALSE;
      this->m_bFontUnderline = FALSE;
      this->m_bFontStrikeout = FALSE;
      this->setContentsFont( );
    }
    else if ( numtok > 5 ) {

      this->setRedraw( FALSE );

      this->m_iFontSize = 20 * atoi( input.gettok( 5, " " ).to_chr( ) );
      this->m_tsFontFaceName = input.gettok( 6, -1, " " );
      this->m_tsFontFaceName.trim( );

      //HDC hdc = GetDC( NULL );
      //chrf.yHeight = 20 * -MulDiv( fSize, GetDeviceCaps( hdc, LOGPIXELSY ), 72 );
      //ReleaseDC( NULL, hdc );

      if ( iFontFlags & DCF_BOLD )
        this->m_bFontBold = TRUE;
      else
        this->m_bFontBold = FALSE;

      if ( iFontFlags & DCF_ITALIC )
        this->m_bFontItalic = TRUE;
      else
        this->m_bFontItalic = FALSE;

      if ( iFontFlags & DCF_STRIKEOUT )
        this->m_bFontStrikeout = TRUE;
      else
        this->m_bFontStrikeout = FALSE;

      if ( iFontFlags & DCF_UNDERLINE )
        this->m_bFontUnderline = TRUE;
      else
        this->m_bFontUnderline = FALSE;

      this->setContentsFont( );

      this->parseContents( TRUE );
    }
  }
  // xdid -i [NAME] [ID] [SWITCH] [N] [TEXT]
  else if ( flags.switch_flags[8] && numtok > 4 ) {
    
    if ( this->isStyle( ES_MULTILINE ) ) {

      int nLine = atoi( input.gettok( 4, " " ).to_chr( ) );
      this->m_tsText.instok( input.gettok( 5, -1, " " ).to_chr( ), nLine, "\r\n" );
    }
    else {
      
      this->m_tsText = input.gettok( 4, -1, " " );
    }
    this->parseContents( TRUE );
  }
  // xdid -l [NAME] [ID] [SWITCH] [N] [COLOR]
  else if ( flags.switch_flags[11] && numtok > 4 ) {

    int nColor = atoi( input.gettok( 4, " " ).to_chr( ) ) - 1;

    if ( nColor > -1 && nColor < 16 ) {

      this->m_aColorPalette[nColor] = atol( input.gettok( 5, " " ).to_chr( ) );
      this->parseContents( TRUE );
    }
  }
  // xdid -m [NAME] [ID] [SWITCH]
  else if ( flags.switch_flags[12] ) {

    this->loadmIRCPalette( );
    this->parseContents( TRUE );
  }
  // xdid -o [NAME] [ID] [SWITCH] [N] [TEXT]
  else if ( flags.switch_flags[14] && numtok > 4 ) {
    
    if ( this->isStyle( ES_MULTILINE ) ) {

      int nLine = atoi( input.gettok( 4, " " ).to_chr( ) );
      this->m_tsText.puttok( input.gettok( 5, -1, " " ).to_chr( ), nLine, "\r\n" );
    }
    else {

      this->m_tsText = input.gettok( 4, -1, " " );
    }
    this->parseContents( TRUE );
  }
  // xdid -q [NAME] [ID] [SWITCH] [COLOR1] ... [COLOR16]
  else if ( flags.switch_flags[16] && numtok > 3 ) {

    int i = 0, len = input.gettok( 4, -1, " " ).numtok( " " );
    while ( i < len && i < 16 ) {

      this->m_aColorPalette[i] = atol( input.gettok( 4 + i, " " ).to_chr( ) );

      i++;
    }
    this->parseContents( TRUE );
  }
  // xdid -t [NAME] [ID] [SWITCH] [FILENAME]
  else if ( flags.switch_flags[19] && numtok > 3 ) {
    
    char * contents = readFile( input.gettok( 4, -1, " " ).to_chr( ) );

    if ( contents != NULL ) {

      this->m_tsText = contents;
      this->parseContents( TRUE );
    }
  }
  // xdid -u [NAME] [ID] [SWITCH] [FILENAME]
  else if ( flags.switch_flags[20] && numtok > 3 ) {

    FILE * file = fopen( input.gettok( 4, -1, " " ).to_chr( ), "wb" );

    if ( file != NULL ) {

      fwrite( this->m_tsText.to_chr( ), sizeof( char ), this->m_tsText.len( ), file );

      fflush( file );
      fclose( file );
    }
  }
  else {
    this->parseGlobalCommandRequest( input, flags );
  }
}

/*!
 * \brief blah
 *
 * blah
 */

void DcxRichEdit::loadmIRCPalette( ) {

  char com[512], res[512];
  lstrcpy( com, "$color(0) $color(1) $color(2) $color(3) $color(4) $color(5) $color(6) $color(7) $color(8) $color(9) $color(10) $color(11) $color(12) $color(13) $color(14) $color(15)" );
  mIRCeval( com, res );

  TString colors = res;

  //mIRCSignal( colors.to_chr( ) );

  int i = 0, len = colors.numtok( " " );
  while ( i < len ) {

    this->m_aColorPalette[i] = atol( colors.gettok( i + 1, " " ).to_chr( ) );

    i++;
  }
}

/*!
 * \brief blah
 *
 * blah
 */

void DcxRichEdit::setContentsFont( ) {

  CHARFORMAT2 chrf;
  ZeroMemory( &chrf, sizeof( CHARFORMAT2 ) );
  chrf.cbSize = sizeof( CHARFORMAT2 );
  chrf.dwMask = CFM_BACKCOLOR | CFM_BOLD | CFM_COLOR | CFM_FACE | CFM_SIZE | CFM_ITALIC | CFM_UNDERLINE | CFM_STRIKEOUT;
  chrf.yHeight = this->m_iFontSize;
  chrf.crTextColor = this->m_clrText;
  chrf.crBackColor = this->m_clrBackText;

  if ( this->m_bFontBold )
    chrf.dwEffects |= CFE_BOLD;

  if ( this->m_bFontItalic )
    chrf.dwEffects |= CFE_ITALIC;

  if ( this->m_bFontStrikeout )
    chrf.dwEffects |= CFE_STRIKEOUT;

  if ( this->m_bFontUnderline )
    chrf.dwEffects |= CFE_UNDERLINE;

  if ( this->m_tsFontFaceName != "" ) {
    lstrcpyn( chrf.szFaceName, this->m_tsFontFaceName.to_chr( ), 31 );
    chrf.szFaceName[31] = 0;
  }

  this->hideSelection( TRUE );
  this->setSel( 0, -1 );
  this->setCharFormat( SCF_ALL, &chrf );
  this->setSel( -1, 0 );
  this->hideSelection( FALSE );
}

/*!
 * \brief blah
 *
 * blah
 */

void DcxRichEdit::clearContents( ) {

  this->hideSelection( TRUE );
  this->setSel( 0, -1 );
  this->replaceSel( FALSE, "" );
  this->setSel( -1, 0 );
  this->hideSelection( FALSE );

  this->setContentsFont( );
}
/*!
 * \brief blah
 *
 * blah
 */

void DcxRichEdit::parseContents( BOOL fNewLine ) {

  this->setRedraw( FALSE );
  this->clearContents( );

  char * text = this->m_tsText.to_chr( );
  
  bool uline = false;
  bool bline = false;
  //int mcolor = -1;
  //int bkgcolor = -1;
  COLORREF mcolor = 0;
  COLORREF bkgcolor = 0;

  bool bmcolor = true;
  bool bbkgcolor = false;

  char cbuf[2];
  char colbuf[3];
  cbuf[1] = '\0';
  colbuf[2] = '\0';

  int i = 0;
  while ( text[i] != '\0' ) {

    cbuf[0] = text[i];

    // if current char is a control code
    if ( text[i] == 2 || text[i] == 3 || text[i] == 15 || text[i] == 22 || text[i] == 31 ) {

      // CTRL+B Parsing
      if ( text[i] == 2 )
        bline = !(bline);
      
      // CTRL+K Parsing
      else if ( text[i] == 3 ) {

        if ( text[i+1] >= '0' && text[i+1] <= '9' ) {
          //mIRCSignal( "digit detected" );
          colbuf[0] = text[i+1];
          colbuf[1] = '\0';
          i++;

          if ( text[i+1] >= '0' && text[i+1] <= '9' ) {
            //mIRCSignal( "double digit detected" );
            colbuf[1] = text[i+1];
            i++;
          }
          // color code number
          bmcolor = true;
          mcolor = this->m_aColorPalette[ this->unfoldColor( colbuf ) ];
          //mIRCSignal( colbuf );

          // maybe a background color
          if (text[i+1] == ',') {

            i++;
            if ( text[i+1] >= '0' && text[i+1] <= '9' ) {
              //mIRCSignal( "digit detected" );
              colbuf[0] = text[i+1];
              colbuf[1] = '\0';
              i++;

              if ( text[i+1] >= '0' && text[i+1] <= '9' ) {
                //mIRCSignal( "double digit detected" );
                colbuf[1] = text[i+1];
                i++;
              }
              // color code number
              bbkgcolor = true;
              bkgcolor = this->m_aColorPalette[ this->unfoldColor( colbuf ) ];
              //mIRCSignal( colbuf );
            }
          }
        }
        else {
          bmcolor = false;
          bbkgcolor = false;
        }
      }
      // CTRL+O Parsing
      else if ( text[i] == 15 ) {
        bline = false;
        uline = false;
        mcolor = -1;
        bkgcolor = -1;
      }
      // CTRL+R Parsing
      else if ( text[i] == 22 ) {
        bline = false;
        uline = false;
      }
      // CTRL+U Parsing
      else if ( text[i] == 31 ) {
        uline = !(uline);
      }

      //mIRCSignal( "Control Code Detected" );
    }
    // regular char
    else if ( text[i] == '\n' && fNewLine ) {
      bline = false;
      uline = false;
      mcolor = -1;
      bkgcolor = -1;
    }
    else {
      //mIRCSignal( cbuf );
      this->insertText( cbuf, bline, uline, bmcolor, mcolor, bbkgcolor, bkgcolor, 0 );
    }
    i++;
  }
  this->setSel( -1, 0 );
  this->setRedraw( TRUE );
  this->redrawControl( );
}

/*!
 * \brief blah
 *
 * blah
 */

int DcxRichEdit::unfoldColor( char * color ) {

  int nColor = atoi( color );

  while ( nColor > 15 ) {

    nColor -=16;
  }

  return nColor;
}

/*!
 * \brief blah
 *
 * blah
 */

void DcxRichEdit::insertText( char * text, bool bline, bool uline, bool bcolor, COLORREF color, bool bbkgcolor, COLORREF bkgcolor, int reverse ) {

  // get total length
  int len = GetWindowTextLength( this->m_Hwnd );
  // get line char number from end char pos
  int line = Edit_LineIndex( this->m_Hwnd, Edit_LineFromChar( this->m_Hwnd, len-1 ) );
  // get line length
  int linelen = Edit_LineLength( this->m_Hwnd, line );
  // total length of insert point
  len = line + linelen;

  this->hideSelection( TRUE );
  this->setSel( len, -1 );
  this->replaceSel( FALSE, text );
  this->setSel( -1, 0 );
  this->hideSelection( FALSE );

  CHARFORMAT2 chrf;
  ZeroMemory( &chrf, sizeof( CHARFORMAT2 ) );
  chrf.cbSize = sizeof( CHARFORMAT2 );
  chrf.dwMask = CFM_BACKCOLOR | CFM_BOLD | CFM_COLOR | CFM_FACE | CFM_SIZE | CFM_ITALIC | CFM_UNDERLINE | CFM_STRIKEOUT;
  chrf.yHeight = this->m_iFontSize;
  chrf.crTextColor = this->m_clrText;
  chrf.crBackColor = this->m_clrBackText;

  if ( this->m_bFontBold )
    chrf.dwEffects |= CFE_BOLD;

  if ( this->m_bFontItalic )
    chrf.dwEffects |= CFE_ITALIC;

  if ( this->m_bFontStrikeout )
    chrf.dwEffects |= CFE_STRIKEOUT;

  if ( this->m_bFontUnderline )
    chrf.dwEffects |= CFE_UNDERLINE;

  if ( this->m_tsFontFaceName != "" ) {
    lstrcpyn( chrf.szFaceName, this->m_tsFontFaceName.to_chr( ), 31 );
    chrf.szFaceName[31] = 0;
  }

  if ( bcolor == true ) 
    chrf.crTextColor = color;
  if ( bbkgcolor == true ) 
    chrf.crBackColor = bkgcolor;
  if ( bline == true ) 
    chrf.dwEffects |= CFE_BOLD;
  if ( uline == true ) 
    chrf.dwEffects |= CFE_UNDERLINE;

  this->hideSelection( TRUE );
  this->setSel( len, -1 );
  this->setCharFormat( SCF_SELECTION, &chrf );
  this->setSel( -1, 0 );
  this->hideSelection( FALSE );
}

/*!
 * \brief blah
 *
 * blah
 */

LRESULT DcxRichEdit::setAutoUrlDetect( BOOL iEnable ) {
  return SendMessage( this->m_Hwnd, EM_AUTOURLDETECT, (WPARAM) iEnable, (LPARAM) 0 );
}

/*!
 * \brief blah
 *
 * blah
 */

LRESULT DcxRichEdit::hideSelection( BOOL iHide ) {
  return SendMessage( this->m_Hwnd, EM_HIDESELECTION, (WPARAM) iHide, (LPARAM) 0 );
}

/*!
 * \brief blah
 *
 * blah
 */

LRESULT DcxRichEdit::setSel( int iStart, int iEnd ) {
  return SendMessage( this->m_Hwnd, EM_SETSEL, (WPARAM) iStart, (LPARAM) iEnd );
}

/*!
 * \brief blah
 *
 * blah
 */

LRESULT DcxRichEdit::replaceSel( BOOL bUndo, LPCTSTR lpstr ) {
  return SendMessage( this->m_Hwnd, EM_REPLACESEL, (WPARAM) bUndo, (LPARAM) lpstr );
}

/*!
 * \brief blah
 *
 * blah
 */

LRESULT DcxRichEdit::getCharFormat( UINT iType, CHARFORMAT2 * cfm ) {
  return SendMessage( this->m_Hwnd, EM_GETCHARFORMAT, (WPARAM) iType, (LPARAM) cfm );
}

/*!
 * \brief blah
 *
 * blah
 */

LRESULT DcxRichEdit::setCharFormat( UINT iType, CHARFORMAT2 * cfm ) {
  return SendMessage( this->m_Hwnd, EM_SETCHARFORMAT, (WPARAM) iType, (LPARAM) cfm );
}

/*!
 * \brief blah
 *
 * blah
 */

LRESULT DcxRichEdit::PostMessage( UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL & bParsed ) {

  switch( uMsg ) {

    case WM_HELP:
      {
        char ret[256];
        this->callAliasEx( ret, "%s,%d", "help", this->getUserID( ) );
      }
      break;

    case WM_MOUSEMOVE:
      {
        this->m_pParentDialog->setMouseControl( this->getUserID( ) );
      }
      break;

    case WM_SETFOCUS:
      {
        this->m_pParentDialog->setFocusControl( this->getUserID( ) );
      }
      break;

    case WM_DESTROY:
      {
        //mIRCError( "WM_DESTROY" );
        delete this;
        bParsed = TRUE;
      }
      break;

    default:
      break;
  }

  return 0L;
}