/*!
 * \file dcxdialog.h
 * \brief blah
 *
 * blah
 *
 * \author David Legault ( clickhere at scriptsdb dot org )
 * \version 1.0
 *
 * \b Revisions
 *
 * � ScriptsDB.org - 2005
 */

#ifndef _DCXDIALOG_H_
#define _DCXDIALOG_H_

#include "dcxwindow.h"
#include "layout/layoutmanager.h"

#define DBS_BKGCOLOR      0x01 //!< Control Background Color

// dummy runtime classe definition
class DcxControl;

typedef std::vector<DcxControl *> VectorOfControlPtrs; //!< blah

/*!
 * \brief blah
 *
 * blah
 */

class DcxDialog : public DcxWindow {

public:

  DcxDialog( HWND mHwnd, TString & tsName, TString & tsAliasName );
  virtual ~DcxDialog( );

  TString getName( );
  TString getAliasName( );

  static LRESULT WINAPI WindowProc( HWND mHwnd, UINT uMsg, WPARAM wParam, LPARAM lParam );

  void parseCommandRequest( TString & input );
  void parseInfoRequest( TString & input, char * szReturnValue );

  BOOL callAliasEx( char * szReturn, const char * szFormat, ... );

  DcxControl * getControlByID( UINT ID );
  DcxControl * getControlByHWND( HWND mHwnd );

  void addControl( DcxControl * p_Control );
  void deleteControl( DcxControl * p_Control );

  void updateLayout( RECT & rc );

  HBRUSH getBackClrBrush( );

  void setMouseControl( UINT mUID );
  void setFocusControl( UINT mUID );

protected:

  TString m_tsName;       //!< Dialog Name
  TString m_tsAliasName;  //!< Callback Alias Name

  WNDPROC m_hOldWindowProc; //!< Dialog Old Window Procedure

  VectorOfControlPtrs m_vpControls; //!< Vector of DCX Controls

  bool m_bInSizing; //!< In Moving Motion
  bool m_bInMoving; //!< In Sizing Motion

  HBRUSH m_hBackBrush;    //!< Background control color

  UINT m_MouseID; //!< Mouse Hover ID
  UINT m_FocusID; //!< Mouse Hover ID

  LayoutManager * m_pLayoutManager; //!< Layout Manager Object

  /* **** */

  void parseBorderStyles( TString & flags, LONG * Styles, LONG * ExStyles );
  DWORD getAnimateStyles( TString & flags );

  UINT parseLayoutFlags( TString & flags );
  UINT parseBkgFlags( TString & flags );
};

#endif // _DCXDIALOG_H_