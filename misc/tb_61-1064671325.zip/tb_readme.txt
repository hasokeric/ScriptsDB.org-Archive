- Description:

Toolbar pour mIRC 6.1 uniquement.
J'ai modifi� une toolbar de mIRC 6.1 avec les ic�nes Orange Cream, et j'ai cr�� trois ic�nes qui manquaient pour faire la toolbar.


- Utilisation:

Placer le fichier tb_61.bmp dans votre dossier principal de mIRC, ou bien un sous-dossier, c'est sans importance l'emplacement
du moment que vous sachiez o� elle se trouve.
Ensuite ouvrez mIRC, sur la toolbar, � un endroit vide, par exemple � droite de l'ic�ne About, faire un click-droit avec la souris.
Dans le menu, choississez: Buttons > Select...
Ensuite naviguez jusqu'au fichier tb_61.bmp, le choisir puis cliquer sur open.
La nouvelle toolbar sera en place.

PS: Cette toolbar peut aussi vous servir d'exemple si vous voulez vous en cr�er une.


- Cr�dits:

Les ic�nes Orange Cream (je ne connais pas le nom de l'auteur)
Artwerks




Artwerks
  ppnadeau@hotmail.com
  #scriptsdb.org@undernet
26 septembre 2003