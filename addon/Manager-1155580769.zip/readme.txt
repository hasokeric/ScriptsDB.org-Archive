* * * * * * * * * * * *
  Manager by ArKanis
*       Agenda        *
 Calendrier Perpetuel 
* * * * * * * * * * * *


Plan de l'aide :

I] Installation
II] Utilisation
  1) G�n�ral
       * Infos
       * Modes
           � Big
           � Alone
  2) Alarmes
       * Hebdomadaires
       * Pour un jour particulier
  3) Options
  4) L�gende des couleurs
III] D�sinstallation
IV] A propos
V] ChangeLog

_________________________________


I] Installation
---------------

  Dezippez/Copiez le dossier en int�gralit�. Chargez le fichier Manager.mrc (alt + r, file, load).
  Aucune DLL n'est utilis�e.


II] Utilisation
---------------

  1) G�n�ral

       * Infos
          Tapez /manager pour lancer la PicWin. Les boutons pour changer de mois sont sur la droite, en haut et en bas.
          Cliquez sur une case pour voir les �v�nements relatifs au jour. La liste o� sont affich�es les informations peut-�tre modif�e en cliquant sur les diff�rentes lignes.
          Le plus simple pour modifier un jour est de cliquer sur le triangle en bas � droite des cases. Il ouvre directement le fichier .txt correspondant au jour.
          Apr�s un changement, pour mettre � jour le calendrier, relancez la picwin ou changez de mois, puis revenez.
          La premi�re colonne ne repr�sente que des Lundi, 2e des Mardi, etc ...
      Il dispose de deux modes d'affichage. Pour changer de mode, soit vous utiliser le menu, soit vous cliquez sur la barre verticale entre les deux ascenseurs � droite.

       * Modes d'affichage
           � Big
               Ce mode d'affichage rend la PicWin plus grande que le second mais permet d'ajouter une image de fond dans le reste de la fen�tre.
               Cette fen�tre est dimensionable via le menu (clic droit)
               Vous pourrez �galement d�placer le calendrier � l'int�rieur de la fen�tre (avec la case en bas � droite), et bouger cette fen�tre par rapport � l'�cran.

               Quand vous cliquez sur un jour, une autre fen�tre vient s'ajouter sur la premi�re. Encore une fois, cette derni�re fen�tre peut avoir un fond d'�cran configur�.
               Une zone de texte (la zone o� s'afficheront les �v�nements du jour en particulier) peut �tre plac�e n'importe o� sur la fen�tre et peut �galement prendre la taille souhait�e (permet de ne pas masquer une partie de l'image de fond que vous aimez bien par exemple :p).
               Avec cette seconde fen�tre, vous pourrez visionner la f�te du jour

           � Alone
               Le deuxi�me mode est un mode r�duit. Vous ne disposerez pas d'arri�re-plan. La fen�tre a la taille du calendrier, que vous pourrez bouger n'importe o�.
               En cliquant sur un jour, vous aurez ici aussi une autre fen�tre qui s'affichera au dessus de la pr�c�dente, avec le m�me fond que dans le I]2). La diff�rence ici est que la zone de texte est agrandie au maximum, et ne peut �tre redimensionn�e.
               Ce mode est pratique pour les personnes qui ne veulent pas de fond. Il permet aussi de ne pas prendre beaucoup de place quand la fen�tre est plac�e en mode on-top (au dessus de tout)
               Le mode sera automatiquement chang� si vous voulez configurer les alarmes hebdomadaires.

  2) Alarmes

       Toutes les alarmes sont desactivables rapidement et en m�me temps via le menu.
       Une alarme se d�clenche en :
         Ouvrant une bo�te de dialogue "on top" o� le nom de l'alarme est donn�
         /beep 5 1

       * Hebdomadaires
           Celles-ci sont accessibles en cliquant sur l'image plac�e en bas � droite. Si le mode d'affichage est Alone, il basculera en Big.
           Ajoutez une alarme, donnez lui un nom et une heure d'ex�cution, puis cochez les jours o� vous voulez qu'elle s'active.
           Desactivez rapidement une alarme en cliquant sur son nom. Supprimez la en cliquant sur la case rouge � gauche du nom.

       * Pour un jour particulier
           Activable en visionnant le calendrier
           Une alarme peut �tre plac�e pour chaque jour et se d�clenchera � l'heure indiqu�e le jour m�me. Pour cela, d�placer la souris en bas � gauche de la case repr�sentant le jour souhait�.
           Un commentaire apparaitra en bas du calendrier pour indiquer qu'en cliquant sur la position actuelle, vous activerez une alarme ce jour.

  3) Options
      Elles sont toutes accessibles par le menu.
      - Vous pourrez selectionner l'image de fond lors de la visualisation du calendrier, et une deuxi�me pour les alarmes et les infos du jour.
      - On top (en premier plan)
      - Modifier la taille de la fen�tre (entrez la taille en X et Y)
      - Mettre en background de la fen�tre de statut et des salons le calendrier (type Photo, modifiez le code pour changer le type)
        Si cette option est activ�e, le fond changera tous les jours et � minuit.

  4) L�gende des couleurs
      Une case color�e en bleu repr�sente le jour actuel
      Une case color�e en rouge repr�sente une date pour laquelle des infos sont fournies (que ce soit du pass� ou du futur)
      Le point d'exclamation rouge sur une case montre qu'une alarme est activ�e pour ce jour.


III] D�sinstallation
--------------------

  Tapez "/manager remove" afin de supprimer tous les fichiers ayant un rapport direct avec Manager. Vous pourrez ensuite d�charger Manager en tapant :
  //unload -rs $$script(Manager.mrc)
  ou avec alt + r, view, Manager, puis File, Unload


IV] A propos
------------

Code r�alis� en 2006 par ArKanis
Merci � fjxokt et Wims, mes testeurs, et � Jordane pour la partie "perpetuel"

Contact : arkanisfr@free.fr
URL : www.arkanis.eu


V] Changelog
------------

V1.5 :
Ajout d'un menu sur les alarmes hebdomadaires (clic droit) permettant d'�diter/supprimer une alarme
Un peu de relief ajout�
Animations de survol de cases/boutons
Ajout du mois/ann�e en bas
Les cases contiennent le jour de la semaine et celui du mois
  Ex : L 10 (pour lundi 10)


V1.4 :
Compatibilit� du code pour un mIRC ne poss�dant pas mon add-on.


