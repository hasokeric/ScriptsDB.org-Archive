*************************
ReadMe - M�t�o By ArKanis
*************************

* Pr�sentation :

Ce code pr�sente la m�t�o fran�aise ainsi que celle des DOM-TOM dans une PicWin interactive.
Il dispose d'une champ de recherche et peut donner des pr�visions au niveau r�gional, en plus de donner des �ph�m�rides et temp�ratures d'une ville.
Il donne �galement la carte de vigilance au niveau de la France.

Il tire ses informations du site www.lachainemeteo.com qui donne Matin + Aprem de 0 � 3 jours, Journ�e au-del�.

C'est assez simple, et �tant donn� qu'une aide est incluse, je ne vais pas tout expliquer ici.

Tapez /meteo pour lancer la PicWin


* Installation :

Vous devez avoir les deux .mrc charg�s, GUI-ArKanis est indispensable.
Mettez les deux fichiers directement dans le dossier mIRC et tapez /load -rs Meteo-By-ArKanis.mrc 

* D�sinstallation :

Allez dans le menu "?", puis cliquez sur D�sinstaller.
Toutes les images seront supprim�es. Vous n'aurez qu'� taper la commande qui s'affichera, puis supprimer manuellement le fichier Meteo-By-ArKanis.mrc

Tapez /gui.unload pour d�charger l'autre fichier.


Vous devez avoir une version plus r�cente que la 6.17 (6.21 fortement conseill�e) pour que le code fonctionne correctement.


Amusez-vous bien :)