RadioCast PLayer V2
R�alis� par Bestdoud
mars 2007

Cet addon permet d'�couter les radios shoutcast.


Description du lecteur:

	Partie principale:

		Dans cette partie, vous pouvez:

			-r�gler le volume � l'aide de la barre situ�e � c�t� de la durr�e


		Les boutons dans l'ordre:
			-reculer d'une radio
			-Lecture
			-Pause
			-Stop
			-Avancer d'une radio
			-Afficher la zone de recherche
			-Afficher la playliste
			-Acc�der au site de Radioblog
			-Couper le son



	Zone de recherche:

		Pour acc�der � cette zone, il faut cliquer sur la loupe

		Pour rechercher un titre, il faut taper un mot dans le combo du milieu ou choisir une cat�gorie en bas � gauche puis cliquer sur la loupe � c�t� ou entr�e. Les r�sultats s'affichent alors dans la liste

		Pour ajouter un titre � la plaliste, il faut s�lectionner la ligne dans la liste puis cliquer sur la fl�che bleue � c�t� de la loupe

		POur lire une ligne, il faut s�lectionner une ligne dans la liste puis cliquer sur la fl�che verte ou en double cliquant (les fichiers sont mis dans a playliste qui sera effac�e)

		Pour refermer la zone de recherche, il faut de nouveau cliquer sur la loupe



	PLayliste:

		Pour acc�der � cette zone, il faut cliquer sur l'ic�ne qui repr�sente une liste � c�t� de la loupe

		POur lire une ligne, il faut cliquer sur la ligne puis cliquer sur la fl�che verte ou en double cliquant

		POur supprimer une ligne, il faut cliquer sur la ligne puis cliquer sur la croix rouge

		Pour effacer la liste, il faut cliquer sur les deux fl�ches bleues.

		Pour sauvegarder la liste, il faut rentrer le nom de la liste dans le combo en bas � gauche puis cliquer sur l'ic�ne repr�sentant une disquette juste � c�t�

		Pour afficher une liste sauegard�e, il faut la choisir dans le combo et elle s'affichera automatiquement

		POur supprimer une liste, il faut la choisir dans le combo puis cliquer sur l'icone repr�sentant une poubelle � c�t� de la disquette

		POur refermer la liste, cliquer � nouveau sur l'ic�ne de la liste

		Pour ajouter une radio manuellement, il faut cliquer sur l'icone repr�sentant une fl�che bleue


Mode de lecture:

la lecture se fait en boucle. POur arr�ter la lecture, il faudra cliquer manuellemnt sur stop


La fen�tre est redimensionnable.