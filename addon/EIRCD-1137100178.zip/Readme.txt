######################################
#######/  _____/    \#/ __ \ ___ \####
######/  /###| | |#\ | /##\_\|##\ \###
#####/  /####| | |#/ |/####| |###\ \##
####/       /| |    / |####| |####| |#
###/  /######| | |\ \ \####| |###/ /##
##/  /#######| | |#\ \ \##/�/|##/ /###
#/_______/###|_|_|##\_\____/_____/####
#EIRCD#EIRCD#EIRCD##EIRCD#EIRCD#EIRCD#
######################################
#             /�\   /�\   ��/        #
#        \  /  _/     <    /         #
#         \/  /__ . \_/ . /          #
######################################
# Best viewed with Fixedsys or any
#  other monospace font
######################################
# The way the version numbers work is
#  simple. The first number, 2, is the 
#  EIRCD version number. The second, 
#  3, is the EIRCD Services that where
#  writen for this version. And the
#  last number, 6, is the update
#  count for this version.
######################################
# Contents
######################################
# Changes
# Coming
# *NEW* EIRCD Services
# 1) Installation
# 2) Configuring
#   a. MOTD
#   b. Server Settings
#   c. IRCOps
#   d. Dont edit
# 3) Modes
#   a. User Modes
#   b. Channel Modes
# 4) EIRCD Control Dialog
#   a. Settings Tab
#   b. MOTD Tab
#   c. IRCOps Teab
#   d. User Control Tab
# 5) After All That
#   a. Starting the server
#   b. Turning the server off
#   c. Connecting to the server
#   d. Available commands
# 6) Signals
#   a. The signals
#   b. Using them
# 7) Credits
# 8) Contact
######################################
# Changes (- is Fix, + is Add)
######################################
# EIRCD v2.3.7
#  + /help command to get help on
#     server commands
#  + Topic variables:
#     $chan, $nick, $date, $time
#  + Better /getip, it now connects to
#     http://checkip.dyndns.org.
#  + +n mode for opers.
#  - /quit not closing socket
#  - Signals triggering even if the
#     command wasn't correctly done.
#  - Signals for /oper, /aoper, and
#     /poper bing ircop, aircop, and
#     pircop.
#  - Oper login failure notification
#     showing passwords.
# EIRCD v2.3.6
#  + /names command
#  - A few bugs when nick changing
#     with EIRCD Control Dialog
#  - Bug with oper changing nick
#  - Bug with /whois and not having
#     services
# EIRCD v2.3.5
#  + Local alias to send messages to
#     users and channels(/emsg)
#  + Local alias to send raws to users
#     (/eraw)
#  + Moved Signals
#  + ChanServ/HelpServ nick reserving
#  + Raw 330(logged in as) to whois
#  + New setting to disable Unknown
#     Command return on certain
#     commands
#  + Return of invalid characters with
#     erroneous nickname
#  + Setting to specify valid nickname
#     characters
#  - Bug with nick changes
#  - Bug with gline bracket missmatch
#  - Bug with raw 251 showing only
#     users only, without IRCOps
#  - Changed /ircop to /oper
#  - Changed /aircop to /aoper
#  - Changed /pircop to /poper
# EIRCD v2.0.4
#  + Local alias to send notices
#     to users(/enotice)
#  + Signals to all events(added new
#     topic to explain the signals)
#  - Bug with +S channel mode and
#     notices
#  - Bug with +S channel mode and
#     messages
#  - Bug with /who when not supplying
#     a channel
#  - Bug with /list stop
# EIRCD v2.0.3
#  + /aircop and /pircop
#  - /getip error
#  - Bug with kill from EIRCD Control 
#     Dialog
#  - Bug with flood check box allways 
#     being disabled
#  - Bug with topic only showing first
#     word on join
#  - Bug with user/socket count going
#     up 2 times per person
#  - Bug with ircops changing nick
#  - Bug with messaging a nick that is
#     not in use
# EIRCD v2.0.2
#  + Excess Flood
#  + Unknown Command
#  + -l to some alias's
#  + /motd command
#  - /ircop command being /oper
#  - Bug with /kill
######################################
# Coming
######################################
# I hope to be adding server linking
#  next.
######################################
# EIRCD Services
######################################
# The EIRCD Services are not out. When
#  I was about to release them, I
#  found some major bugs. I was going
#  to fix them but the lag of people
#  interested in it made me not fix
#  them yet. So they are pretty much
#  finished and if someone wants me to
#  actually finish them, then tell me,
#  I cant read minds.
######################################
# 1) Installation
######################################
# Extract all the files in the .ZIP
#  file to your mIRC directory or
#  sub-directory. After all files have
#  been extracted, you can do one of
#  2 things:
#   Open the mIRC and type:
#    /load -rs "C:Path\to\EIRCD.mrc"
#              Or
#   Open the mIRC, hit alt+r, then
#    go to file, load and find the
#    EIRCD.mrc file and load it
######################################
# 2) Configuration
######################################
# Before starting your server, you
#  should change the configuration to
#  what you want. If you wish to edit
#  the configuration open settings.ini
#  with any text editor.
#
#                              a. MOTD
# MOTD stands for Message of The Day.
#  Every server(that i know of) sends
#  a MOTD, it just contains anything
#  that the server may want everyone
#  joining to know. It could contain
#  rules, events, or anything else.
#  The MOTD section is set up like
#  so:
#   N=Line
#   N=Line
#   .
#   .
#   .
#  N is the MOTD line number, Line is
#  the line of text that will be sent
#  to the clients. Every line will be
#  sent. An easy way to edit the MOTD
#  is to use the EIRCD Control dialog
#  that is explained in topic 4.
#
#                   b. Server Settings
# The server settings are just misc
#  settings that the server uses. They
#  are necisary for the server to run.
#  This is just an explenation of all
#  the server settings:
#   server: 
#    The server address
#    (EX:irc.myserver.net)
#   desc: 
#    A little description of the
#    server(sent with a /whois call)
#   name: 
#    The name shown on the users
#    statusbar
#   port: 
#    The port the server uses(it is 
#    recomended that you do not change
#    this unless necisary)
#   hostmask: 
#    The hostmask sent when someone 
#    uses +x(User modes explained in
#    topic 3)
#   ircophostmask: 
#    The hostmask sent when an IRCOp 
#    is whoised and does not have +x
#   maxusers: 
#    The maximum users allowed to 
#    connect to the server(1 to 100)
#   maxcons: 
#    The maximum connections by the 
#    same IP(1 or more)
#   maxchans: 
#    The maximum channels a user can 
#    join(1 to 20)
#   maxnicklen: 
#    The maximum nick length a user 
#    can have(1 to 30)
#   nickallow:
#    The ASCII values of the
#    charactors that are allowed to be
#    in a nick, seperated by spaces
#    (space, tab, cariage return, line
#    feed, @, +, :, !, #, ., and , are 
#    allways disallowed).
#   maxchanlen: 
#    The maximum channel name length
#    (1 to 30)
#   maxparamlen: 
#    The maximum length of an Away 
#    Message, Kick Reason, or Part
#    reason(1 to 300)
#   ef:
#    Is 1 or 0 to say if excess flood #    is on or off
#   eflines
#    How many lines in the specified 
#    length untill excess flood
#   eflen:
#    How many seconds you have to
#    say the amount of lines
#
#                            c. IRCOps
# IRCOps is IRC Opperators, which is
#  a user that has access to more
#  commands, modes and can bypass
#  regular user limitations. The 
#  IRCOps section contains all the
#  ircop account names and passwords.
#  The passwords are all md5 encrypted
#  in the file for extra 'security'.
#  To add an IRCOp you can either use
#  the EIRCD Control Dialog explained
#  in topic 4 or do it manually:
#   Go into your mIRC and type
#   //echo -s $md5(password)
#   Then add user=md5password to the
#   IRCOp section
#
#                         d. Dont edit
# This section is just for your server
#  creation time and is useless other
#  than that.
######################################
# 3) Modes
######################################
# Modes are settings for users or
#  channels that can be set with the
#  /mode command.
#
#                        a. User Modes
# User modes are modes that are user
#  specific. The modes for users are:
#   x: Hostmask. IRCOps have their own
#       hostmask that is set all the
#       time(If an IRCOp uses x than
#       they use a regular user
#       hostmask)
#   i: Makes a user invisible in a
#       /who call
#   S: Strip control codes from
#       private messages(bold/
#       underline/reverse/colors)
#   a: Don't accept private messages
#       while away
#   w: Notification of a whois(IRCOp
#       only)
#   c: Hide channels in whois(IRCOp
#       only)
#   *NEW* 
#   n: No warnings, ie, failed ircop
#       logins(IRCOp only)
#
#                     b. Channel Modes
# Channel modes are modes that are
#  channel specific. The channel modes
#  are:
#   t: Only ops can set the topic
#   m: Channel is moderated(only @/+
#       can talk)
#   s: secret
#   k: Users must supply the key to
#       enter
#   l: A limit of users
#   O: Only IRCOps can join
#   x: Only people with mode +x can
#       join
#   N: No channel notices
#   n: No external messages
#   H: Block messages with heavy text
#       (Bold/ctrl+b)
#   h: Only @/+ can use heavy text
#   U: Block messages with underlined
#       text(ctrl+u)
#   u: Only @/+ can use underlined
#       text
#   R: Block messages with reverse
#       color text(ctrl+r)
#   r: Only @/+ can use reverse
#   C: Block colors(ctrl+k)
#   c: Only @/+ can use colors
#   A: Block all control codes(bold/
#       underline/reverse/colors)
#   S: Strip all control codes
#   o: Give/Remove op status from
#       the user 
#   v: Give/Rempve voice status from
#       the user
#   b: Ban user(because of the way
#       i made this version, bans
#       are done to the IP of the
#       user)
######################################
# 4) EIRCD Control Dialog
######################################
# The EIRCD Control Dialog was made to
#  make everything easily accessable.
#  To open the EIRCD Control Dialog
#  either use /eircd.con or right 
#  click the EIRCD Console and use the
#  popup.
#
#                      a. Settings Tab
# The settings tab lets you change the
#  server settings inside your mIRC
#  (You can only change the settings
#  when the server is not on). The
#  settings are save when you press
#  the Ok button.
#
#                          b. MOTD Tab
# The MOTD Tab lets you manipulate the
#  MOTD. The list shows all the lines
#  of the MOTD and the line numbers.
#  When you type something in the 
#  editbox the Add button becomes
#  enabled and you can add new lines.
#  When you click a line of the list
#  the Remove button becomes enabled
#  to remove lines of the MOTD.
#
#                        c. IRCOps Tab
# The IRCOps tab lets you add and
#  remove IRCOps. To add an IRCOp just
#  type in the account and password,
#  then press Add. The IRCOp is added
#  and the password is automatically
#  md5 encrypted for you.
#
#                  d. User Control Tab
# The user control tab lets you
#  users. When you select a user from
#  the list all the channels that user
#  is on come into the second list and
#  the buttons that do not require
#  a channel select will become 
#  enabled. Selecting a channel will
#  then enable the channel specific
#  buttons.
######################################
# 5) After all that
######################################
# This topic just tells you what to do
#  after you finish configuring.
#
#               a. Starting the server
# To start the server type /eircd. If
#  $ip does not return anything(you
#  have not connected to a server
#  before trying to starting EIRCD),
#  it will try and retreive your IP
#  from www.IPMonkey.com. When either
#  $ip returns something or the script
#  got your IP from the site, the
#  EIRCD Console will open, and echo
#  your IP and port used.
#
#            b. Turning the server off
# To turn the server off, you can do
#  one of 2 things:
#   Close the EIRCD Console
#             Or
#   Type /eircdoff
#
#          c. Connecting to the server
# To connect to the server, a user
#  will have to type
#   /server -m IP:PORT
#  where IP:PORT is what the EIRCD
#  Console gave you. When a user tries
#  to connect it will show you in the
#  EIRCD Console. If you try to
#  connect and it says nothing in the
#  EIRCD Console then you may have
#  a firewall/antivirus blocking the
#  port, or the wrong IP.
#
#                d. Available commands
# These are the server commands that
#  users can use:
#   /nick NewNick: 
#    Change your nick
#   /mode #chan/nick Modes Params:
#    Enables/Disables modes
#   /kick #chan Nick Reason:
#    Kicks a user from the channel
#   /join #chan Key
#    Joins a channel(key is only
#    required if +k channel mode is 
#    set
#   *NEW*
#   /topic #chan Topic:
#    Sets the channel topic. There
#     are also commands that can be
#     used in the topic:
#      $chan: The channel with the
#              topic.
#      $nick: The nick of the person
#              that joined.
#      $date: The servers date.
#      $time: The servers time.
#   /invite #chan Nick
#    Invites a user to a channel
#   /part #chan Reason:
#    Leaves a channel
#   /away Reason:
#    Sets you to away with reason or
#    back if no reason
#   /whois Nick:
#    Gets information about a user
#   /who #chan:
#    Returns information about the
#    users in the channel(if no 
#    channel is provided, it does it
#    for all the channels a user is
#    on)
#   /lusers:
#    General server user information
#   /list:
#    Gives a list of all the channels
#   /oper Account Password:
#    Logs a user in as an IRCOp
#   /aoper Account:
#    Creates the IRCOp account with
#     a random password
#   /poper Account OldPass NewPass:
#    Changes the password of Account
#     from Old to New
#   /kill Nick Reason:
#    Kills the user with Nick(Only
#    IRCOps)
#   /nick2ip Nick:
#    Returns the IP of the user with
#    the nick(Only IRCOps)
#   /gline IP Duration Reason:
#    G-Lines every connection by the
#    IP for Duration(Duration is in
#    seconds, IRCOps only)
#   /glines N/IP:
#    Looks up information on G-Line
#    number N or with the IP(IRCOps
#    only)
#   /rgline IP:
#    Removes the G-Line for the IP
#    (IRCOps only)
#   /global Text:
#    Sends a notice to every user
#    on the server(IRCOps only)
#   /motd:
#    Just makes the server return the
#    MOTD
#   *NEW*
#   /help:
#    Returns help on server commands
#    (most mIRC users use /help for
#    the help file, to overcome that
#    you can use /quote help)
#
#   Missing anything that i should
#    have? Well i dont remember things
#    well so please, tell me!
######################################
# 6) Signals
######################################
#                       a. The Signals
# When something happens with the
#  EIRCD, a signal is sent. To use
#  the signal you do this:
#   on *:SIGNAL:eircd:{ commands }
#  The first parameter of the signal
#  is the event(like notice, privmsg,
#  etc). The second parameter is the
#  users socket that did the event,
#  and the third is his nick on the
#  server. The rest of the parameters
#  are specific to the event:
#   nick:
#    OldNick NewNick
#     Or when connecting
#    Nick
#   MOTD:
#    None
#   mode:
#    #chan Modes Params
#     Or for user mode changes
#    modes
#   kick:
#    #chan KickedSocket KickedNick 
#     Reason
#   join:
#    #chan
#   topic:
#    #chan topic
#   invite:
#    #chan InvitedSocket InvitedNick
#   part:
#    #chan
#   notice:
#    #chan text
#     Or
#    NoticeSocket NoticeNick Message
#   privmsg:
#    #chan text
#     Or
#    PrivmsgSocket PrivmsgNick Message
#   away:
#    awaymessage
#     Or for returning from away
#    None
#   whois:
#    WhoisedSocket WhoisedNick
#   who:
#    #chan
#     Or for nick
#    None
#   lusers:
#    None
#   list:
#    Stop
#     Or for starting
#    None
#   oper:
#    account
#   aircop:
#    account temppassword
#   pircop:
#    account password newpassword
#   kill:
#    KilledSocket KilledNick Reason
#   nick2ip:
#    Nick2IPedSocket Nick2IPedNick IP
#   global:
#    Message
#   glines:
#    Number
#     Or for looking up ip
#    IP
#   gline:
#    IP Length Reason
#   rgline:
#    IP
#   quit:
#    Reason
#   unknown:
#    Command Parameters
#   flood:
#    None
#   *NEW*
#   help:
#    Topic
#
#                        b. Using them
# This is a little example that
#  records all the different nicknames
#  used on your server, and also how
#  many IRCOp logins there are:
#   on *:SIGNAL:eircd:{
#     if ($1 == nick) {
#       if (!$read(nicks.txt,s,$4)) {
#         write nicks.txt $4
#       }
#     }
#     elseif ($1 == ircop) {
#       inc %ircops
#     }
#   }
#  I wrote some aliases to easily
#  work with the server:
#   /enotice Socket Nickname Message
#   /emsg Socket Nickname Message
#   /eraw Socket Raw Params
#  Socket is the socket of the user
#  you want to send to, nickname is
#  the nickname of the sender,
#  message is, well you should know,
#  and raw is the raw numeric. Here 
#  is an example of how to inform 
#  people about your module when the
#  MOTD is sent:
#   on *:SIGNAL:eircd:{
#     if ($1 == motd) {
#       enotice $2 Modules I am &
#        currently running Nick and &
#        Oper recorder v1 by &
#        poiuy_qwert.
#     }
#   }
######################################
# 7) Credits
######################################
# v2.3.7
#  PumaKuma:
#   Lots of testing and ideas.
# v2.3.6
#  (unknown):
#   Im not sure of the person because
#    mirc.net is down at this time,
#    but someone told me about the
#    EIRCD Control Dialog nick change
#    bug.
# v2.3.5
#  stx-`Slipknot-:
#   Found some bugs in the server
#    while testing the services.
# v2.0.4
#  Darc:
#   Gave the idea for the signals.
# v2.0.3
#  JuLiaNc:
#   The person that told me of the
#    /getip error.
#  Fubar(not from ms.org):
#   My test dummy for some things.
#  stx-`Slipknot-:
#   Another test dummy.
# v2.0.2
#  JuLiaNc:
#   The person who found the bug in 
#   the kill command though he didn't
#   know it(he thought it was a bug in
#   joins).
#  MasterFugu:
#   Made me make a new release.
# v2.0.1
#  [ETTv]Marko:
#   Helped me a lot with brainstorming
#    the script. Without his help at
#    the begining the script would be
#    way worse than it is now.
#  Century0:
#   Did the main testing before the
#    release. He also kept me
#    motivated. Without that 
#    motivation i probably would not 
#    have finished the server.
#  Other Testers:
#   cr4z3d
#   conelli
######################################
# 8) Contact
######################################
# If you have any suggestions, bugs,
#  ideas, rants, or anything else
#  related to EIRCD, feel free to
#  contact me any of these ways:
#   irc.gamesurge.net in #script
#    with nickname poiuy_qwert
#   irc.scriptersirc.net in
#    #scriptersirc with nickname
#    poiuy_qwert
#   p_q-poiuy_qwert@hotmail.com is
#    my email you can contact me at
#    but i dont really check it too
#    much
#   http://p-q.no-ip.org
#   Or just post a reply wherever
#    you downloaded this at :)
######################################
#######/  _____/    \#/ __ \ ___ \####
######/  /###| | |#\ | /##\_\|##\ \###
#####/  /####| | |#/ |/####| |###\ \##
####/       /| |    / |####| |####| |#
###/  /######| | |\ \ \####| |###/ /##
##/  /#######| | |#\ \ \##/�/|##/ /###
#/_______/###|_|_|##\_\____/_____/####
#EIRCD#EIRCD#EIRCD##EIRCD#EIRCD#EIRCD#
######################################