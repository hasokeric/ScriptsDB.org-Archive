PicwinEdit v0.3b (version betas)
Par Sorn_Drixer - Sorn_Drixer@hotmail.com
http://www.Sorn-Creation.org

-

Merci d'avoir t�l�charg� PicwinEdit.
La version actuelle n'est qu'une betas pour le moment et est encore un peu mince niveau fonction.
La version finale s'annonce bien �videmment plus compl�te :)

Pour l'aide, rendez vous � cette url :
http://www.sorn-creation.org/picwinedit/index.php?inc=aide

Ou ouvrez tout simplement le fichier aide.chm se trouvant dans le r�pertoire picwinedit.