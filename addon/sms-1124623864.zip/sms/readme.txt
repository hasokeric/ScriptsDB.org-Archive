Bonjour et Merci d'utiliser cette addon pour le loader tapper:

//load -rs $shortfn($mircdirsms/sms.mrc)

puis puis l'ouvrir tapper :

/smsd

ou aller dans le menu command dans la menubar