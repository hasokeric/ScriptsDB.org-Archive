RemotePC v1.1 'This is only the beginning'
;----------------;
; How to Install ;
;----------------;
In your mIRC. In Status. Type: /load -rs <filedirectory>/RemotePC.mrc
Example: /load -rs Remote_PC/RemotePC.mrc

For best performance we have listed you some good settings.
----------------------------------------------------------------------------
640x480 = Untested
800x648 = Tested, Smooth Ride, Quick [BEST SETTING!] [RECOMMENDED]
1024x800 = Tested, Rough Ride, Slow.
----------------------------------------------------------------------------

:=: So once you are logged into the remote machine set its settings to 800x648 = BEST! :=:

;-----------;
; File Info ;
;-----------;

RemotePC.mrc - The Main file you load. it will do the rest for you.
 |
  - RClient.mrc - The Client Code, will be loaded automatically.
   |
    - RServer.mrc - The Server Code, will be loaded automatically
  /
 /
�

;-------------;
; The Authors ;
;-------------;
              -> Team mxS <-
                -codemastr			Rustynails
                          \_				\/\
                            |- b00hp			   \
				\			    - Shyne
				 \				/
				  |				- jaytea
				  \				 \
				  Team mxS-----------------------/

;---------;
; Credits ;
;---------;
nScreenshot.dll :-: nacitar
mouseevents.dll :-: fugitive
SendKey Code    :-: qwerty
FileSend Code   :-: [Znork]
poiuy_qwert     :-: help on $compress
Hell_RaZoR      :-: Beta Testing


;--------------;
; Future Plans ;
;--------------;
 * UDP Sockets instead of TCP.

;------------;
; Known Bugs ;
;------------;
 * Higher Resolution go much slower.
 * Couple minimum bugs
 fixed: * Cannot highlight on remote computer with mouse
 * Cannot drag icons on remote computer with mouse
 fixed: * Double click is not very good sometimes takes a tripler or 4x Click.
 * ALT,CTRL and some other keyboard buttons are not working.
 -

;---------------------------;
; irc.gamesurge.net -j #mxS ;
;---------------------------;