MSNMIRC 2.02r
>Sortie le 9 mai 2006
>Released may 9th 2006

Please visit my website for the latest release: http://msnmirc.scriptsdb.org/

MSNMIRC : Client MSN Messenger pour mIRC
> Cod� par Artwerks
MSNMIRC : MSN Messenger client for mIRC
> Coded by Artwerks

---------------------------------------------------------
Fran�ais:

D�zipper le dossier "msnmirc" dans le r�pertoire principal de mIRC.
Pour charger l'addon, veuillez taper dans mIRC puis appuyez sur Enter:
//load -rs $+(",$mircdirmsnmirc\msnload.mrc,")

Lorsque mIRC vous demandera si vous voulez ex�cuter le fichier, cliquez sur Yes.
---------------------------------------------------------

---------------------------------------------------------
English:

Unzip the folder "msnmirc" in the main directory of mIRC.
In order to load the addon, please type in mIRC then hit the Enter key:
//load -rs $+(",$mircdirmsnmirc\msnload.mrc,")

When mIRC will prompt you to execute it, click Yes.
---------------------------------------------------------

---------------------------------------------------------
Norwegian:

Unzip mappen "msnmirc" til den mappen der du installerte mIRC.
For � starte denne addonen, skriv f�lgende og trykk Enter:
//load -rs $+(",$mircdirmsnmirc\msnload.mrc,")

N�r mIRC sp�r deg om � hente denne filen, trykk Yes.
---------------------------------------------------------

---------------------------------------------------------
Dutch:

Unzip de map 'msnmirc' naar de hoofdmap van je mirc. Als je dit gedaan hebt en het wilt laden typ je: //load -rs $+(",$mircdirmsnmirc\msnload.mrc,") en je drukt op enter.

Als er iets komt van mirc druk je gewoon op 'Yes'. Dan word het script geladen.
---------------------------------------------------------

Sorry, no Spanish, German, Italian or Portuguese readme.
D�sol�, pas de readme en espagnol, en allemand, en italien ou en portugais.

Just type: //load -rs $+(",$mircdirmsnmirc\msnload.mrc,")

---------------------------------------------------------

Spanish version translated by Mefisto
Italian version translated by jHoNDoE
German version translated by SSJ4_Son_Goku
Portuguese version translated by roboTic_oN
Dutch version translated by iScripters
Norwegian version translated by Produck
> A great thanks to them, they made this addon available in your language!
English and French version by Artwerks

ssl.dll by Pixador, and a great thanks to FoLKeN^ :)