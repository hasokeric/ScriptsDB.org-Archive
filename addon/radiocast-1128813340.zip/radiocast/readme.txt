RadioCast By Bestdoud 2005

Cette addon vous permet d'�couter les radios Shoutcast sans coupure et sans tampon sur le disque dur

Ces fonctions:
-Lecture de radios au format mp3 et ogg vorbis
-Gestion radio multi-urls
-possibilt� d'ajouter ses propres radios
-posibilit� de modifier et de supprimer une radio
-affichage du titre en cours et du titre � suivre
-affichage du temps �coul�
-r�glage du volume
-mode normal et r�duit
-acc�s direct au site de la radio s'il est pr�sent dans  le stream
-sauvegarde des r�glages � la fermeture
-Liste de pres de 500 radios avec mises � jour
-mise � jour intelligente automatique du lecteur au d�marrage


installation:
tapper /load -rc radiocast.ini

(ne pas oublier de mettre le chemin)

lancement:
tapper la commande /RCradiocast

Aide en ligne
HTTP://amigagaamp.free.fr/aide_pour_radiocast.htm