RC version 0.1
--------------
Cet addon permet de v�rifier les RC (Recent Changes) de n'importe quel projet 
Wikimedia � partir de l'IRC.

Les RC sont diffus�s automatiquement sur irc : irc.wikimedia.org sur les canaux : #langue.projet
Par exemple : #fr.wikipedia

Vous pouvez lancer autant de fen�tre de RC que vous voulez, voir plusieurs pour un m�me canal
si cela vous est n�cessaire.


Pour d�marrer
-------------
- D�zippez le dossier dans votre dossier de mIRC (O� se trouve le mIRC.exe)
- Tapez /load -rs rc/rc.mrc
- Si un avertissement apparait, cliquez sur OK
- Dans la menubar, le menu RC apparait


