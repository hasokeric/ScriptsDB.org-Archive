;Solitaire

Le principe est de faire passer les "pions" les uns par dessus les autres, en �liminant un pion a chaque coup.
Le but �tant de n'avoir qu'un seul pion a la fin.

Pour charger l'addon, mettez le fichier .mrc dans la racine de votre script et loadez-le en tapant //load -rs $mircdirsolitaire.mrc puis clicquer sur Yes
Pour le d�charger, tap� //unload -rs $shortfn($mircdirsolitaire.mrc)
Pour lancer le jeu, tapez /solitaire
Utilisez le clique droit pour afficher les meilleurs scores

Infos : pour centr� le texte, j'utilise un alias tout simple trouv� ici : http://www.codyx.org/snippet_centrer-texte-dans-window_179.aspx
