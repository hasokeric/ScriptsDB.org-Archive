PLAYSIMU:

description:
ce petit bout de code vous permet de jouer plusieurs sons wav ou mp3 en m�me temps.
Ceci peut �tre utile pour ceux qui d�veloppent des jeux.

installation:
/load -rs playsimu.mrc

Lancer un son:
/playsimu son

son est le chemin de votre sons
exemple:
/playsimu c:\monson.wav

Arr�ter les sons:
/playsimu.end